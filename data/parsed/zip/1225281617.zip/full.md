# 天津锐新昌科技股份有限公司

# 关于对深圳证券交易所 2025 年年报问询函回复的公告

本公司及董事会全体成员保证信息披露内容的真实、准确和完整，没有虚假记载、误导性陈述或重大遗漏。

天津锐新昌科技股份有限公司（以下简称“公司”）于近期收到深圳证券交易所创业板公司管理部发送的《关于对天津锐新昌科技股份有限公司的年报问询函》（创业板年报问询函〔2026〕第 25 号）（以下简称“《问询函》”），公司会同年审会计师事务所容诚会计师事务所（特殊普通合伙）（以下简称“容诚所”或“年审会计师”）就《问询函》有关问题逐项进行了认真的核查落实，现就相关问题回复如下：

问题 1.年报显示，你公司报告期实现营业收入 5.94 亿元，同比下降 $4 . 4 6 \%$ ；净利润 3,259.77 万元，同比下降 $4 1 . 0 6 \%$ 。营业收入和净利润均连续三年下滑。其中，电力电子散热器业务收入 2.28 亿元，同比下降 $1 . 6 6 \%$ ，毛利率 $2 1 . 2 0 \%$ ；汽车轻量化部件业务收入 1.75 亿元，同比增长 $4 . 6 2 \%$ ，毛利率 $9 . 6 0 \%$ ；自动化设备及医疗设备精密部件业务收入 0.89 亿元，同比增长 $9 . 2 1 \%$ ，毛利率 $2 3 . 9 1 \%$ ；其他业务收入 1.02 亿元，同比下降 $2 7 . 6 9 \%$ ，毛利率 $1 4 . 0 7 \%$ 。你公司称，营业收入下降的主要原因是面对原材料价格持续上涨，部分废料、边角料回收处理方式由对外销售变更为委托有熔铸资质企业加工熔铸成原材料，以致其他业务收入同比下降；净利润下降的主要原因是报告期市场竞争加剧。

# 请你公司：

（1）列示其他业务收入下降的具体计算过程，并说明部分废料、边角料回收处理方式变更导致其他业务收入下降的原因及合理性；

（2）说明电力电子散热器和汽车轻量化部件业务近三年前十大客户的具体情况，包括客户名称、注册成立时间、与公司发生交易的最早时间、收入确认金额及占比、销售的具体产品及其单价数量、支付结算安排、目前回款情况等，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并结合同行业可比公司情况，说明报告期内电力电子散热器和汽车轻量化部件业务毛利率下滑的原因及合理性；

（3）说明自动化设备及医疗设备精密部件业务近三年前十大客户的具体情况，包括客户名称、注册成立时间、与公司发生交易的最早时间、收入确认金额及占比、销售的具体产品及其单价数量、支付结算安排、目前回款情况等，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并结合同行业可比公司情况，说明报告期内自动化设备及医疗设备精密部件业务营业收入增长以及毛利率水平较高的原因及合理性。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

（一）列示其他业务收入下降的具体计算过程，并说明部分废料、边角料回收处理方式变更导致其他业务收入下降的原因及合理性；

# 1、其他业务收入下降的具体计算过程

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>2025年</td><td rowspan=1 colspan=3>2024年</td><td rowspan=2 colspan=1>收入变动金额（万元）</td><td rowspan=2 colspan=1>收入变动率</td></tr><tr><td rowspan=1 colspan=1>重量(吨)</td><td rowspan=1 colspan=1>单位售价（万元/吨）</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>重量(吨）</td><td rowspan=1 colspan=1>单位售价（万元/吨）</td><td rowspan=1 colspan=1>收入（万元）</td></tr><tr><td rowspan=1 colspan=1>废铝</td><td rowspan=1 colspan=1>5,208.47</td><td rowspan=1 colspan=1>1.67</td><td rowspan=1 colspan=1>8,721.78</td><td rowspan=1 colspan=1>7,358.67</td><td rowspan=1 colspan=1>1.64</td><td rowspan=1 colspan=1>12,068.28</td><td rowspan=1 colspan=1>-3,346.50</td><td rowspan=1 colspan=1>-27.73%</td></tr><tr><td rowspan=1 colspan=1>废铜</td><td rowspan=1 colspan=1>225.02</td><td rowspan=1 colspan=1>6.49</td><td rowspan=1 colspan=1>1,460.01</td><td rowspan=1 colspan=1>333.99</td><td rowspan=1 colspan=1>6.03</td><td rowspan=1 colspan=1>2,014.67</td><td rowspan=1 colspan=1>-554.66</td><td rowspan=1 colspan=1>-27.53%</td></tr><tr><td rowspan=1 colspan=1>其它</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>26.94</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>34.64</td><td rowspan=1 colspan=1>-7.7</td><td rowspan=1 colspan=1>-22.23%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>5,433.49</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>10,208.73</td><td rowspan=1 colspan=1>7,692.66</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>14,117.59</td><td rowspan=1 colspan=1>-3,908.86</td><td rowspan=1 colspan=1>-27.69%</td></tr></table>

公司 2025 年度其他业务收入 10,208.73 万元，较 2024 年度下降 3,908.86 万元，降幅 $2 7 . 6 9 \%$ 。其中废铝销量减少 2,150.20 吨，废铝收入下降 3,346.50 万元，占总下降金额 3,908.86 万元的 $8 5 . 6 1 \%$ ，是其他业务收入下降的主要因素。

2、部分废料、边角料回收处理方式变更导致其他业务收入下降的原因及合

# 理性

公司废铝处置方式分为“直接销售”和“委托加工成铝棒”两种方式。2025年度铝锭价格持续走高，为应对原材料价格上涨，公司增加了将废铝委托加工成铝棒的处置方式。将废铝采用委托加工方式收回铝棒只需支付加工费，节约现金流出、降低单位材料成本（铝锭价格持续走高时，前期低价采购的铝棒产生的废铝成本价格低于现行价格），符合降本增效导向。2024 及 2025 年度两种方式下处置废铝的数量如下：

单位：吨   

<table><tr><td rowspan=1 colspan=1>处置方式</td><td rowspan=1 colspan=1>2025 年度处置数量</td><td rowspan=1 colspan=1>2024年度处置数量</td><td rowspan=1 colspan=1>变动率</td></tr><tr><td rowspan=1 colspan=1>直接销售</td><td rowspan=1 colspan=1>5,208.47</td><td rowspan=1 colspan=1>7,358.67</td><td rowspan=1 colspan=1>-29.22%</td></tr><tr><td rowspan=1 colspan=1>委托加工</td><td rowspan=1 colspan=1>863.41</td><td rowspan=1 colspan=1>144.51</td><td rowspan=1 colspan=1>497.46%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>6,071.88</td><td rowspan=1 colspan=1>7,503.18</td><td rowspan=1 colspan=1>-19.08%</td></tr></table>

综上所述，公司其他业务收入下降主要原因系公司为应对原材料价格上涨，增加了委托加工的废铝数量，从而减少了直接销售的数量，系优化成本结构的合理经营举措，具有合理性。

（二）说明电力电子散热器和汽车轻量化部件业务近三年前十大客户的具体情况，包括客户名称、注册成立时间、与公司发生交易的最早时间、收入确认金额及占比、销售的具体产品及其单价数量、支付结算安排、目前回款情况等，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并结合同行业可比公司情况，说明报告期内电力电子散热器和汽车轻量化部件业务毛利率下滑的原因及合理性；

# 1、电力电子散热器和汽车轻量化部件业务近三年前十大客户的具体情况

（1）电力电子散热器近三年前十大客户的具体情况

2025 年度电力电子散热器前十大客户的具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>1996年</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>1,959.88</td><td rowspan=1 colspan=1>3.36</td><td rowspan=1 colspan=1>6,594.40</td><td rowspan=1 colspan=1>95天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>1994年</td><td rowspan=1 colspan=1>2004年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>1,210.21</td><td rowspan=1 colspan=1>3.61</td><td rowspan=1 colspan=1>4,370.60</td><td rowspan=1 colspan=1>90天/120天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户C</td><td rowspan=1 colspan=1>1995年</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>自动化设备散热器</td><td rowspan=1 colspan=1>681.48</td><td rowspan=1 colspan=1>3.81</td><td rowspan=1 colspan=1>2,594.84</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户G</td><td rowspan=1 colspan=1>2015年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>逆变器散热器</td><td rowspan=1 colspan=1>634.64</td><td rowspan=1 colspan=1>2.48</td><td rowspan=1 colspan=1>1,572.71</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2001年</td><td rowspan=1 colspan=1>2009年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>347.30</td><td rowspan=1 colspan=1>3.84</td><td rowspan=1 colspan=1>1,334.42</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户D</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>2014年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>166.79</td><td rowspan=1 colspan=1>6.85</td><td rowspan=1 colspan=1>1,141.81</td><td rowspan=1 colspan=1>120天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>2017年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>280.43</td><td rowspan=1 colspan=1>3.26</td><td rowspan=1 colspan=1>915.19</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户H</td><td rowspan=1 colspan=1>1994年</td><td rowspan=1 colspan=1>2007年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>120.95</td><td rowspan=1 colspan=1>4.00</td><td rowspan=1 colspan=1>484.14</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户I</td><td rowspan=1 colspan=1>2004年</td><td rowspan=1 colspan=1>2015年</td><td rowspan=1 colspan=1>自动化设备散热器</td><td rowspan=1 colspan=1>95.90</td><td rowspan=1 colspan=1>4.65</td><td rowspan=1 colspan=1>446.00</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户M</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>2020年</td><td rowspan=1 colspan=1>逆变器散热器</td><td rowspan=1 colspan=1>125.93</td><td rowspan=1 colspan=1>3.41</td><td rowspan=1 colspan=1>428.87</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr></table>

<table><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>5,623.51</td><td rowspan=1 colspan=1>3.54</td><td rowspan=1 colspan=1>19,882.98</td></tr></table>

<table><tr><td>注1</td></tr></table>

2024 年度电力电子散热器前十大客户的具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>1996年</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>2,009.45</td><td rowspan=1 colspan=1>3.34</td><td rowspan=1 colspan=1>6,716.11</td><td rowspan=1 colspan=1>95天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>1994年</td><td rowspan=1 colspan=1>2004年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>1,220.15</td><td rowspan=1 colspan=1>3.62</td><td rowspan=1 colspan=1>4,420.56</td><td rowspan=1 colspan=1>90天/120天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户C</td><td rowspan=1 colspan=1>1995年</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>自动化设备散热器</td><td rowspan=1 colspan=1>769.78</td><td rowspan=1 colspan=1>3.61</td><td rowspan=1 colspan=1>2,778.00</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>2017年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>398.22</td><td rowspan=1 colspan=1>3.25</td><td rowspan=1 colspan=1>1,294.93</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2001年</td><td rowspan=1 colspan=1>2009年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>314.53</td><td rowspan=1 colspan=1>3.80</td><td rowspan=1 colspan=1>1,194.59</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户G</td><td rowspan=1 colspan=1>2015年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>逆变器散热器</td><td rowspan=1 colspan=1>434.69</td><td rowspan=1 colspan=1>2.37</td><td rowspan=1 colspan=1>1,030.09</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户D</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>2014年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>177.91</td><td rowspan=1 colspan=1>5.57</td><td rowspan=1 colspan=1>990.20</td><td rowspan=1 colspan=1>120天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户L</td><td rowspan=1 colspan=1>1993年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>逆变器散热器</td><td rowspan=1 colspan=1>449.31</td><td rowspan=1 colspan=1>2.11</td><td rowspan=1 colspan=1>948.31</td><td rowspan=1 colspan=1>120天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户H</td><td rowspan=1 colspan=1>1994年</td><td rowspan=1 colspan=1>2007年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>109.22</td><td rowspan=1 colspan=1>4.15</td><td rowspan=1 colspan=1>453.69</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户J</td><td rowspan=1 colspan=1>1995年</td><td rowspan=1 colspan=1>2017年</td><td rowspan=1 colspan=1>变频器散热器</td><td rowspan=1 colspan=1>126.26</td><td rowspan=1 colspan=1>2.89</td><td rowspan=1 colspan=1>364.88</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>合计</td><td rowspan=1 colspan=1>6,009.51</td><td rowspan=1 colspan=1>3.36</td><td rowspan=1 colspan=1>20,191.35</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

2023 年度电力电子散热器前十大客户的具体情况如下：

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">成立时间</td><td colspan="1" rowspan="1">最早交易时间</td><td colspan="1" rowspan="1">销售产品</td><td colspan="1" rowspan="1">数量（吨）</td><td colspan="1" rowspan="1">平均单价（万元/吨）</td><td colspan="1" rowspan="1">销售额（万元）</td><td colspan="1" rowspan="1">支付结算安排</td><td colspan="1" rowspan="1">是否正常回款</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">客户A</td><td colspan="1" rowspan="1">1996年</td><td colspan="1" rowspan="1">2005年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">1,961.72</td><td colspan="1" rowspan="1">3.22</td><td colspan="1" rowspan="1">6,316.99</td><td colspan="1" rowspan="1">95天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">客户B</td><td colspan="1" rowspan="1">1994年</td><td colspan="1" rowspan="1">2004年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">1,763.53</td><td colspan="1" rowspan="1">3.52</td><td colspan="1" rowspan="1">6,199.93</td><td colspan="1" rowspan="1">90天/120天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">客户C</td><td colspan="1" rowspan="1">1992年</td><td colspan="1" rowspan="1">2013年</td><td colspan="1" rowspan="1">自动化设备散热器</td><td colspan="1" rowspan="1">652.64</td><td colspan="1" rowspan="1">3.86</td><td colspan="1" rowspan="1">2,516.79</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">客户D</td><td colspan="1" rowspan="1">2007年</td><td colspan="1" rowspan="1">2014年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">289.01</td><td colspan="1" rowspan="1">6.57</td><td colspan="1" rowspan="1">1,899.95</td><td colspan="1" rowspan="1">120天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">客户E</td><td colspan="1" rowspan="1">2001年</td><td colspan="1" rowspan="1">2009年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">393.92</td><td colspan="1" rowspan="1">3.86</td><td colspan="1" rowspan="1">1,520.11</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">客户F</td><td colspan="1" rowspan="1">1993年</td><td colspan="1" rowspan="1">2010年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">322.48</td><td colspan="1" rowspan="1">3.87</td><td colspan="1" rowspan="1">1,246.70</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">客户G</td><td colspan="1" rowspan="1">2015年</td><td colspan="1" rowspan="1">2021年</td><td colspan="1" rowspan="1">逆变器散热器</td><td colspan="1" rowspan="1">464.06</td><td colspan="1" rowspan="1">2.40</td><td colspan="1" rowspan="1">1,115.24</td><td colspan="1" rowspan="1">60天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">客户H</td><td colspan="1" rowspan="1">1994年</td><td colspan="1" rowspan="1">2007年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">124.93</td><td colspan="1" rowspan="1">4.17</td><td colspan="1" rowspan="1">520.40</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">客户I</td><td colspan="1" rowspan="1">2004年</td><td colspan="1" rowspan="1">2015年</td><td colspan="1" rowspan="1">自动化设备散热器</td><td colspan="1" rowspan="1">79.36</td><td colspan="1" rowspan="1">5.12</td><td colspan="1" rowspan="1">406.51</td><td colspan="1" rowspan="1">60天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">客户J</td><td colspan="1" rowspan="1">1995年</td><td colspan="1" rowspan="1">2017年</td><td colspan="1" rowspan="1">变频器散热器</td><td colspan="1" rowspan="1">124.23</td><td colspan="1" rowspan="1">3.10</td><td colspan="1" rowspan="1">384.50</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="5" rowspan="1">小计</td><td colspan="1" rowspan="1">6,175.87</td><td colspan="1" rowspan="1">3.58</td><td colspan="1" rowspan="1">22,127.12</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

（2）汽车轻量化部件近三年前十大客户的具体情况

2025 年度汽车轻量化部件前十大客户的具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>2001年</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>1,321.25</td><td rowspan=1 colspan=1>3.51</td><td rowspan=1 colspan=1>4,631.33</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电控部件</td><td rowspan=1 colspan=1>177.81</td><td rowspan=1 colspan=1>22.58</td><td rowspan=1 colspan=1>4,015.30</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>2006年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>874.30</td><td rowspan=1 colspan=1>3.39</td><td rowspan=1 colspan=1>2,963.72</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户M</td><td rowspan=1 colspan=1>2017年</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>377.46</td><td rowspan=1 colspan=1>2.73</td><td rowspan=1 colspan=1>1,032.00</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>301.11</td><td rowspan=1 colspan=1>2.93</td><td rowspan=1 colspan=1>882.80</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr></table>

2024 年度汽车轻量化部件前十大客户的具体情况如下：  

<table><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户N</td><td rowspan=1 colspan=1>2017年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>电池结构件</td><td rowspan=1 colspan=1>250.95</td><td rowspan=1 colspan=1>3.28</td><td rowspan=1 colspan=1>822.56</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户0</td><td rowspan=1 colspan=1>1997年</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>239.23</td><td rowspan=1 colspan=1>2.25</td><td rowspan=1 colspan=1>538.97</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户I</td><td rowspan=1 colspan=1>2003年</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>128.10</td><td rowspan=1 colspan=1>3.93</td><td rowspan=1 colspan=1>503.02</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户P</td><td rowspan=1 colspan=1>2008年</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>105.68</td><td rowspan=1 colspan=1>3.99</td><td rowspan=1 colspan=1>421.76</td><td rowspan=1 colspan=1>75天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户D</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>175.49</td><td rowspan=1 colspan=1>2.38</td><td rowspan=1 colspan=1>418.36</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>合计</td><td rowspan=1 colspan=1>3,951.38</td><td rowspan=1 colspan=1>4.11</td><td rowspan=1 colspan=1>16,229.81</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>2001年</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>1,380.12</td><td rowspan=1 colspan=1>3.47</td><td rowspan=1 colspan=1>4,785.08</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电控部件</td><td rowspan=1 colspan=1>180.65</td><td rowspan=1 colspan=1>22.23</td><td rowspan=1 colspan=1>4,015.77</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>2006年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>411.53</td><td rowspan=1 colspan=1>3.44</td><td rowspan=1 colspan=1>1,415.12</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户D</td><td rowspan=1 colspan=1>2016年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>515.45</td><td rowspan=1 colspan=1>2.53</td><td rowspan=1 colspan=1>1,304.20</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户H</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>304.36</td><td rowspan=1 colspan=1>3.61</td><td rowspan=1 colspan=1>1,099.38</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户C</td><td rowspan=1 colspan=1>2006年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>243.22</td><td rowspan=1 colspan=1>3.76</td><td rowspan=1 colspan=1>913.52</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>246.32</td><td rowspan=1 colspan=1>3.07</td><td rowspan=1 colspan=1>756.27</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户I</td><td rowspan=1 colspan=1>2003年</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>134.55</td><td rowspan=1 colspan=1>3.53</td><td rowspan=1 colspan=1>474.94</td><td rowspan=1 colspan=1>75天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户L</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>电池结构件</td><td rowspan=1 colspan=1>128.73</td><td rowspan=1 colspan=1>2.93</td><td rowspan=1 colspan=1>376.97</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户G</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>107.82</td><td rowspan=1 colspan=1>3.36</td><td rowspan=1 colspan=1>362.69</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>合计</td><td rowspan=1 colspan=1>3,652.74</td><td rowspan=1 colspan=1>4.24</td><td rowspan=1 colspan=1>15,503.93</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

2023 年度汽车轻量化部件前十大客户的具体情况如下：  

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>客户名称</td><td rowspan=2 colspan=1>成立时间</td><td rowspan=2 colspan=1>最早交易时间</td><td rowspan=2 colspan=1>销售产品</td><td rowspan=2 colspan=1>数量（吨）</td><td rowspan=2 colspan=1>平均单价（万元/吨）</td><td rowspan=2 colspan=1>销售额（万元）</td><td rowspan=2 colspan=1>支付结算安排</td><td rowspan=2 colspan=1>是否正常回款</td></tr><tr></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>2,338.79</td><td rowspan=1 colspan=1>3.50</td><td rowspan=1 colspan=1>8,174.97</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>2001年</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>1,163.53</td><td rowspan=1 colspan=1>3.61</td><td rowspan=1 colspan=1>4,198.82</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户C</td><td rowspan=1 colspan=1>2006年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>870.70</td><td rowspan=1 colspan=1>3.92</td><td rowspan=1 colspan=1>3,411.45</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户D</td><td rowspan=1 colspan=1>2016年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>电池箱体配件</td><td rowspan=1 colspan=1>1,039.69</td><td rowspan=1 colspan=1>2.75</td><td rowspan=1 colspan=1>2,858.44</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>电控部件</td><td rowspan=1 colspan=1>96.00</td><td rowspan=1 colspan=1>21.77</td><td rowspan=1 colspan=1>2,089.53</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户F</td><td rowspan=1 colspan=1>2009年</td><td rowspan=1 colspan=1>2014年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>553.07</td><td rowspan=1 colspan=1>2.32</td><td rowspan=1 colspan=1>1,282.64</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户G</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>2012年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>379.96</td><td rowspan=1 colspan=1>3.33</td><td rowspan=1 colspan=1>1,264.98</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户H</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>电机部件</td><td rowspan=1 colspan=1>208.58</td><td rowspan=1 colspan=1>3.68</td><td rowspan=1 colspan=1>767.58</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户I</td><td rowspan=1 colspan=1>2003年</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>110.30</td><td rowspan=1 colspan=1>3.42</td><td rowspan=1 colspan=1>377.03</td><td rowspan=1 colspan=1>75天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户J</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>车身件</td><td rowspan=1 colspan=1>127.52</td><td rowspan=1 colspan=1>2.23</td><td rowspan=1 colspan=1>284.13</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>合计</td><td rowspan=1 colspan=1>6,888.14</td><td rowspan=1 colspan=1>3.59</td><td rowspan=1 colspan=1>24,709.57</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# 2、说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系

根据《深圳证券交易所创业板股票上市规则》7.2.3 的规定，公司对于电力电子散热器和汽车轻量化部件业务近三年前十大客户是否为关联方的判断参考依据如下：

（1）电力电子散热器和汽车轻量化部件业务近三年前十大客户没有直接或者间接控制本公司；

（2）电力电子散热器和汽车轻量化部件业务近三年前十大客户不是本公司控股股东直接或间接控制的企业；

（3）电力电子散热器和汽车轻量化部件业务近三年前十大客户不是本公司关联自然人直接或者间接控制的企业，本公司关联自然人亦未在上述前十大客户担任董事、高级管理人员；

（4）电力电子散热器和汽车轻量化部件业务近三年前十大客户未持有本公司 $5 \%$ 以上的股份，与持有本公司 $5 \%$ 以上股份的法人不是一致行动人。

综上，电力电子散热器和汽车轻量化部件业务近三年前十大客户与本公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。

# 3、结合同行业可比公司情况，说明报告期内电力电子散热器和汽车轻量化部件业务毛利率下滑的原因及合理性

（1）公司近三年分产品毛利率变动情况

2023-2025 年度公司电力电子散热器、汽车轻量化部件毛利率及综合毛利率情况如下表所示：

<table><tr><td colspan="1" rowspan="1">产品类别</td><td colspan="1" rowspan="1">2025年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">2023年</td></tr><tr><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">21.20%</td><td colspan="1" rowspan="1">23.86%</td><td colspan="1" rowspan="1">27.54%</td></tr><tr><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">9.60%</td><td colspan="1" rowspan="1">15.51%</td><td colspan="1" rowspan="1">17.62%</td></tr><tr><td>电力电子散热器及汽车 轻量化部件综合毛利率</td><td>16.16%</td><td>20.79%</td><td>22.50%</td></tr></table>

（2）同行业可比公司近三年毛利率变动情况

<table><tr><td rowspan=1 colspan=1>同行业可比公司</td><td rowspan=1 colspan=1>收入类别</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>和胜股份</td><td rowspan=1 colspan=1>铝型材</td><td rowspan=1 colspan=1>13.28%</td><td rowspan=1 colspan=1>11.86%</td><td rowspan=1 colspan=1>16.24%</td></tr><tr><td rowspan=1 colspan=1>亚太科技</td><td rowspan=1 colspan=1>铝制产品</td><td rowspan=1 colspan=1>10.70%</td><td rowspan=1 colspan=1>13.02%</td><td rowspan=1 colspan=1>14.66%</td></tr><tr><td rowspan=1 colspan=1>春兴精工</td><td rowspan=1 colspan=1>精密铝合金结构件</td><td rowspan=1 colspan=1>10.08%</td><td rowspan=1 colspan=1>11.68%</td><td rowspan=1 colspan=1>13.08%</td></tr><tr><td rowspan=1 colspan=1>豪美新材</td><td rowspan=1 colspan=1>铝型材</td><td rowspan=1 colspan=1>9.38%</td><td rowspan=1 colspan=1>11.08%</td><td rowspan=1 colspan=1>11.27%</td></tr><tr><td rowspan=1 colspan=1>华峰铝业</td><td rowspan=1 colspan=1>铝加工</td><td rowspan=1 colspan=1>13.87%</td><td rowspan=1 colspan=1>16.17%</td><td rowspan=1 colspan=1>15.84%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>11.46%</td><td rowspan=1 colspan=1>12.76%</td><td rowspan=1 colspan=1>14.25%</td></tr><tr><td rowspan=1 colspan=1>锐新科技</td><td rowspan=1 colspan=1>电力电子散热器及汽车轻量化部件</td><td rowspan=1 colspan=1>16.16%</td><td rowspan=1 colspan=1>20.79%</td><td rowspan=1 colspan=1>22.50%</td></tr></table>

通过上表可知，同行业可比公司 2023-2025 年毛利率均呈下滑趋势，公司近三年主营业务毛利率变动趋势与同行业可比公司一致，具有合理性。

（3）毛利率下滑的原因及合理性

2023-2025 年公司电力电子散热器、汽车轻量化部件产品毛利率均呈下滑趋势，主要受原材料价格上涨及行业竞争加剧导致加工费下降等因素共同影响，具体分析如下：

$\textcircled{1}$ 原材料价格持续上涨，成本端压力显著a、公司产品主要原材料为铝棒，铝棒占生产成本比重高，对价格波动高度敏感；b、报告期内长江现货铝锭价格持续上行，直接推高单位生产成本；c、公司采用“铝锭基准价 $^ +$ 加工费”的定价模式，下游客户多执行季度定价机制，售价调整滞后于原材料采购价格，成本上涨无法即时完全传导至下游，导致毛利率在短期内有所下滑。

$\textcircled{2}$ 行业竞争加剧，加工费水平有所下降

1、随着电力电子散热器、汽车轻量化领域快速发展，市场竞争逐渐加剧，

行业整体加工费呈下行趋势。

2、下游新能源车企、电力电子设备厂商集中采购、年度降价条款等进一步压缩盈利空间。由于汽车轻量化部件行业竞争更为激烈、整车降价压力更大，因此毛利率降幅显著大于电力电子散热器。

综上所述，公司电力电子散热器和汽车轻量化部件业务近三年前十大客户与本公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。公司近三年电力电子散热器、汽车轻量化部件业务毛利率下滑，主要受原材料价格上涨及行业竞争加剧导致加工费下降等因素共同影响，相关变动趋势与同行业可比公司一致，具有合理性。

（三）说明自动化设备及医疗设备精密部件业务近三年前十大客户的具体情况，包括客户名称、注册成立时间、与公司发生交易的最早时间、收入确认金额及占比、销售的具体产品及其单价数量、支付结算安排、目前回款情况等，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并结合同行业可比公司情况，说明报告期内自动化设备及医疗设备精密部件业务营业收入增长以及毛利率水平较高的原因及合理性。

# 1、自动化设备及医疗设备精密部件业务近三年前十大客户的具体情况

2025 年度自动化设备及医疗设备精密部件前十大客户的具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户P</td><td rowspan=1 colspan=1>1999年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>341.74</td><td rowspan=1 colspan=1>2.53</td><td rowspan=1 colspan=1>863.19</td><td rowspan=1 colspan=1>45天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>2016年</td><td rowspan=1 colspan=1>风电设备部件</td><td rowspan=1 colspan=1>221.61</td><td rowspan=1 colspan=1>3.81</td><td rowspan=1 colspan=1>843.93</td><td rowspan=1 colspan=1>125天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户F</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>2020年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>264.99</td><td rowspan=1 colspan=1>2.35</td><td rowspan=1 colspan=1>622.60</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>1993年</td><td rowspan=1 colspan=1>2010年</td><td rowspan=1 colspan=1>轨道交通设备部件</td><td rowspan=1 colspan=1>235.06</td><td rowspan=1 colspan=1>2.60</td><td rowspan=1 colspan=1>611.89</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2010年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>211.97</td><td rowspan=1 colspan=1>2.39</td><td rowspan=1 colspan=1>506.53</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户N</td><td rowspan=1 colspan=1>1961年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>医疗设备结构件</td><td rowspan=1 colspan=1>81.73</td><td rowspan=1 colspan=1>5.76</td><td rowspan=1 colspan=1>470.81</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>1980年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>151.52</td><td rowspan=1 colspan=1>2.85</td><td rowspan=1 colspan=1>432.26</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户Q</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>123.66</td><td rowspan=1 colspan=1>3.11</td><td rowspan=1 colspan=1>384.75</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户R</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>163.73</td><td rowspan=1 colspan=1>2.30</td><td rowspan=1 colspan=1>377.20</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户0</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>62.35</td><td rowspan=1 colspan=1>4.95</td><td rowspan=1 colspan=1>308.87</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>小计</td><td rowspan=1 colspan=1>1,858.36</td><td rowspan=1 colspan=1>2.92</td><td rowspan=1 colspan=1>5,422.03</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# 2024 年度自动化设备及医疗设备精密部件前十大客户的具体情况如下：

2023 年度自动化设备及医疗设备精密部件前十大客户的具体情况如下：  

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>最早交易时间</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>数量（吨）</td><td rowspan=1 colspan=1>平均单价（万元/吨）</td><td rowspan=1 colspan=1>销售额（万元）</td><td rowspan=1 colspan=1>支付结算安排</td><td rowspan=1 colspan=1>是否正常回款</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户A</td><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>2016年</td><td rowspan=1 colspan=1>风电设备部件</td><td rowspan=1 colspan=1>471.16</td><td rowspan=1 colspan=1>3.81</td><td rowspan=1 colspan=1>1,797.32</td><td rowspan=1 colspan=1>125天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户B</td><td rowspan=1 colspan=1>1993年</td><td rowspan=1 colspan=1>2010年</td><td rowspan=1 colspan=1>轨道交通设备部件</td><td rowspan=1 colspan=1>340.80</td><td rowspan=1 colspan=1>2.58</td><td rowspan=1 colspan=1>879.32</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户E</td><td rowspan=1 colspan=1>2010年</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>235.74</td><td rowspan=1 colspan=1>2.35</td><td rowspan=1 colspan=1>553.97</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户K</td><td rowspan=1 colspan=1>1980年</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>180.86</td><td rowspan=1 colspan=1>2.90</td><td rowspan=1 colspan=1>525.03</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户L</td><td rowspan=1 colspan=1>2015年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>风电设备部件</td><td rowspan=1 colspan=1>182.32</td><td rowspan=1 colspan=1>2.34</td><td rowspan=1 colspan=1>426.76</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>客户M</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>179.99</td><td rowspan=1 colspan=1>2.27</td><td rowspan=1 colspan=1>408.83</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>客户G</td><td rowspan=1 colspan=1>2013年</td><td rowspan=1 colspan=1>2020年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>117.35</td><td rowspan=1 colspan=1>2.63</td><td rowspan=1 colspan=1>309.08</td><td rowspan=1 colspan=1>30天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>客户F</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>2020年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>132.18</td><td rowspan=1 colspan=1>2.31</td><td rowspan=1 colspan=1>305.64</td><td rowspan=1 colspan=1>款到发货</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>客户N</td><td rowspan=1 colspan=1>1961年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>医疗设备结构件</td><td rowspan=1 colspan=1>57.17</td><td rowspan=1 colspan=1>4.89</td><td rowspan=1 colspan=1>279.68</td><td rowspan=1 colspan=1>60天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>客户0</td><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>自动化设备部件</td><td rowspan=1 colspan=1>58.91</td><td rowspan=1 colspan=1>4.19</td><td rowspan=1 colspan=1>246.59</td><td rowspan=1 colspan=1>90天</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=5>小计</td><td rowspan=1 colspan=1>1,956.48</td><td rowspan=1 colspan=1>2.93</td><td rowspan=1 colspan=1>5,732.23</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">成立时间</td><td colspan="1" rowspan="1">最早交易时间</td><td colspan="1" rowspan="1">销售产品</td><td colspan="1" rowspan="1">数量（吨）</td><td colspan="1" rowspan="1">平均单价（万元/吨）</td><td colspan="1" rowspan="1">销售额（万元）</td><td colspan="1" rowspan="1">支付结算安排</td><td colspan="1" rowspan="1">是否正常回款</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">客户A</td><td colspan="1" rowspan="1">2005年</td><td colspan="1" rowspan="1">2016年</td><td colspan="1" rowspan="1">风电设备部件</td><td colspan="1" rowspan="1">384.20</td><td colspan="1" rowspan="1">3.99</td><td colspan="1" rowspan="1">1,533.90</td><td colspan="1" rowspan="1">125天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">客户B</td><td colspan="1" rowspan="1">1993年</td><td colspan="1" rowspan="1">2010年</td><td colspan="1" rowspan="1">轨道交通设备部件</td><td colspan="1" rowspan="1">293.37</td><td colspan="1" rowspan="1">2.63</td><td colspan="1" rowspan="1">772.45</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">客户C</td><td colspan="1" rowspan="1">2012年</td><td colspan="1" rowspan="1">2015年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">194.58</td><td colspan="1" rowspan="1">2.64</td><td colspan="1" rowspan="1">514.25</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">客户D</td><td colspan="1" rowspan="1">2004年</td><td colspan="1" rowspan="1">2021年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">205.08</td><td colspan="1" rowspan="1">2.40</td><td colspan="1" rowspan="1">492.58</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">客户E</td><td colspan="1" rowspan="1">2010年</td><td colspan="1" rowspan="1">2019年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">210.25</td><td colspan="1" rowspan="1">2.24</td><td colspan="1" rowspan="1">470.84</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">客户F</td><td colspan="1" rowspan="1">2018年</td><td colspan="1" rowspan="1">2020年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">176.01</td><td colspan="1" rowspan="1">2.13</td><td colspan="1" rowspan="1">374.37</td><td colspan="1" rowspan="1">款到发货</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">客户G</td><td colspan="1" rowspan="1">2013年</td><td colspan="1" rowspan="1">2020年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">140.31</td><td colspan="1" rowspan="1">2.10</td><td colspan="1" rowspan="1">295.14</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">客户H</td><td colspan="1" rowspan="1">2010年</td><td colspan="1" rowspan="1">2011年</td><td colspan="1" rowspan="1">医疗设备部件</td><td colspan="1" rowspan="1">20.99</td><td colspan="1" rowspan="1">13.60</td><td colspan="1" rowspan="1">285.45</td><td colspan="1" rowspan="1">90天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">客户I</td><td colspan="1" rowspan="1">1992年</td><td colspan="1" rowspan="1">2010年</td><td colspan="1" rowspan="1">医疗设备部件</td><td colspan="1" rowspan="1">28.26</td><td colspan="1" rowspan="1">7.16</td><td colspan="1" rowspan="1">202.31</td><td colspan="1" rowspan="1">60天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">客户J</td><td colspan="1" rowspan="1">2004年</td><td colspan="1" rowspan="1">2022年</td><td colspan="1" rowspan="1">自动化设备部件</td><td colspan="1" rowspan="1">92.66</td><td colspan="1" rowspan="1">2.16</td><td colspan="1" rowspan="1">199.97</td><td colspan="1" rowspan="1">60天</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="5" rowspan="1">小计</td><td colspan="1" rowspan="1">1,745.70</td><td colspan="1" rowspan="1">2.95</td><td colspan="1" rowspan="1">5,141.25</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

# 2、说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系

根据《深圳证券交易所创业板股票上市规则》7.2.3 的规定，公司对于自动化设备及医疗设备精密部件业务近三年前十大客户是否为关联方的判断参考依据如下：

（1）自动化设备及医疗设备精密部件业务近三年前十大客户没有直接或者间接控制本公司；

（2）自动化设备及医疗设备精密部件业务近三年前十大客户不是本公司控股股东直接或间接控制的企业；

（3）自动化设备及医疗设备精密部件业务近三年前十大客户不是本公司关联自然人直接或者间接控制的企业，本公司关联自然人亦未在上述前十大客户担任董事、高级管理人员；

（4）自动化设备及医疗设备精密部件业务近三年前十大客户未持有本公司$5 \%$ 以上的股份，与持有本公司 $5 \%$ 以上股份的法人不是一致行动人。

综上，自动化设备及医疗设备精密部件业务近三年前十大客户与本公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。

# 3、结合同行业可比公司情况，说明报告期内自动化设备及医疗设备精密部件业务营业收入增长以及毛利率水平较高的原因及合理性

（1）公司营业收入与同行业可比公司对比

公司近三年自动化设备及医疗设备精密部件收入变动情况及同行业可比公司近三年收入情况如下：

单位：万元  

<table><tr><td colspan="1" rowspan="1">同行业可比公司名称</td><td colspan="1" rowspan="1">收入类别</td><td colspan="1" rowspan="1">2025年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">2023年</td></tr><tr><td colspan="1" rowspan="1">津荣天宇</td><td colspan="1" rowspan="1">电气精密部品</td><td colspan="1" rowspan="1">99,643.51</td><td colspan="1" rowspan="1">93,788.16</td><td colspan="1" rowspan="1">68,451.94</td></tr><tr><td colspan="1" rowspan="1">恒工精密</td><td colspan="1" rowspan="1">液压装备件</td><td colspan="1" rowspan="1">36,511.35</td><td colspan="1" rowspan="1">34,126.92</td><td colspan="1" rowspan="1">25,906.62</td></tr><tr><td colspan="1" rowspan="1">华亚智能</td><td colspan="1" rowspan="1">精密金属结构件</td><td colspan="1" rowspan="1">55,545.50</td><td colspan="1" rowspan="1">52,461.01</td><td colspan="1" rowspan="1">45,353.17</td></tr><tr><td colspan="1" rowspan="1">瑞玛精密</td><td colspan="1" rowspan="1">精密金属结构件</td><td colspan="1" rowspan="1">118,923.06</td><td colspan="1" rowspan="1">112,950.80</td><td colspan="1" rowspan="1">88,412.49</td></tr><tr><td colspan="1" rowspan="1">锐新科技</td><td colspan="1" rowspan="1">自动化设备及医疗设备精密部件</td><td colspan="1" rowspan="1">8,867.48</td><td colspan="1" rowspan="1">8,119.84</td><td colspan="1" rowspan="1">7,926.88</td></tr></table>

行业整体 2023-2025 年营收均呈稳步增长趋势，行业需求持续向好。公司业务规模虽小于行业可比公司，但收入增速与行业整体增长趋势保持一致，业务增长符合行业发展规律，具备合理性。

（2）公司毛利率与同行业可比公司对比

公司近三年自动化设备及医疗设备精密部件毛利率情况及同行业可比公司近三年毛利率情况如下：

<table><tr><td rowspan=1 colspan=1>可比公司名称</td><td rowspan=1 colspan=1>收入类别</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>津荣天宇</td><td rowspan=1 colspan=1>电气精密部品</td><td rowspan=1 colspan=1>25.12%</td><td rowspan=1 colspan=1>24.94%</td><td rowspan=1 colspan=1>24.33%</td></tr><tr><td rowspan=1 colspan=1>恒工精密</td><td rowspan=1 colspan=1>液压装备件</td><td rowspan=1 colspan=1>24.60%</td><td rowspan=1 colspan=1>26.01%</td><td rowspan=1 colspan=1>24.23%</td></tr><tr><td rowspan=1 colspan=1>华亚智能</td><td rowspan=1 colspan=1>精密金属结构件</td><td rowspan=1 colspan=1>27.30%</td><td rowspan=1 colspan=1>30.08%</td><td rowspan=1 colspan=1>32.51%</td></tr><tr><td rowspan=1 colspan=1>瑞玛精密</td><td rowspan=1 colspan=1>精密金属结构件</td><td rowspan=1 colspan=1>19.33%</td><td rowspan=1 colspan=1>18.80%</td><td rowspan=1 colspan=1>21.02%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>24.09%</td><td rowspan=1 colspan=1>24.96%</td><td rowspan=1 colspan=1>24.53%</td></tr><tr><td rowspan=1 colspan=1>锐新科技</td><td rowspan=1 colspan=1>自动化设备及医疗设备精密部件</td><td rowspan=1 colspan=1>23.91%</td><td rowspan=1 colspan=1>22.89%</td><td rowspan=1 colspan=1>25.38%</td></tr></table>

整体来看，公司毛利率与行业可比公司平均值较为接近，处于行业合理区间，差异主要源于各公司产品定位、工艺难度及客户结构不同。

（3）营业收入增长以及毛利率水平较高的原因及合理性

a、下游行业景气度持续提升，市场需求稳步扩容。近年来工业自动化、高端智能装备、医疗器械产业政策支持力度加大，行业整体快速发展，下游客户设备更新、产能扩张需求旺盛，公司 2025 年下游订单落地及交付量增加，直接推动业务收入逐年提升。

b、自动化设备及医疗设备精密部件产品对零部件精度、性能、工艺标准要求更高，产品单价及附加值高于普通通用类零部件，故毛利率相对较高。

综上所述，报告期内公司自动化设备及医疗设备精密部件业务营业收入增长趋势、毛利率水平均处于行业合理区间，变化趋势与行业基本一致，具有合

理性。

# 二、核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

（1）了解、测试并评价公司销售收入确认和成本核算相关的内控设计和执行的有效性；

（2）了解公司收入确认和成本核算政策，获取、检查销售和采购合同关键条款，复核公司的收入确认政策和成本核算政策是否符合企业会计准则并得到一贯执行；

（3）执行收入实质性分析程序，从产品、客户等多维度，分析公司销售收入、销售成本及毛利率的变动的合理性；

（4）获取同行业可比公司信息，执行毛利率对比分析程序，分析公司产品毛利率与同行业公司毛利率差异的原因，以及合理性；

（5）执行函证程序，选取公司重要客户，执行交易金额及应收账款余额函证程序，以检查确认收入金额和应收账款期末余额的准确性；

（6）执行截止测试，实施资产负债表日前及日后截止测试，检查是否存在重大跨期错报；

（7）通过公开渠道查询公司本报告期内各业务板块前十大客户的工商信息，识别相关客户与公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间是否存在关联关系或可能造成利益倾斜的其他关系。

# （二）核查意见

经核查，容诚所认为：

1、公司其他业务收入下降主要系废铝的回收处理方式变化所致，具有合理性。

2、公司电力电子散热器和汽车轻量化部件业务近三年前十大客户与公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。公司近三年电力电子散热器和汽车轻量化部件业务毛利率持续下滑，主要受原材料价格上涨及行业竞争加剧导致加工费下降等因素共同影响所致，与同行业可比公司毛利率变动趋势一致，具有合理性。

3、公司自动化设备及医疗设备精密部件业务近三年前十大客户与公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。公司近三年自动化设备及医疗设备精密部件业务营业收入增长主要原因系下游工业自动化、高端智能装备及医疗器械行业需求持续增长；毛利率较高主要原因系该类产品工艺较为复杂，产品附加值高。营业收入增长以及毛利率水平与同行业可比公司趋势一致，具有合理性。

问题 2.年报显示，你公司报告期末应收账款账面余额 1.1 亿元，报告期未计提坏账准备，坏账准备期末余额 1,232.25 万元，计提比例为 $1 1 . 1 5 \%$ 。其中，按组合计提坏账准备的应收账款账面余额 1.05 亿元，坏账准备余额 660 万元，计提比例为 $6 . 3 0 \%$ ；按单项计提坏账准备的应收账款账面余额 572.23 万元，均已全额计提坏账准备。

# 请你公司：

（1）列示报告期末应收账款账面余额前十名客户的名称、对应销售内容、合同约定的回款时间、已确认的销售收入、账龄、欠款金额、已计提的坏账准备及期后回款情况，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并逐一说明客户是否按照合同约定支付款项，如否，请说明原因以及公司已采取和拟采取的应对措施（如有）；

（2）结合应收账款账龄分布、客户信用状况、行业特点、往年应收账款基于迁徙模型所测算的历史损失率、前瞻性信息调整情况及依据、近三年报告期末应收账款逾期情况、期后回款情况、同行业可比公司坏账准备计提情况等因素，说明应收账款坏账准备计提是否合理、充分，是否符合企业会计准则的有关规定；

（3）披露按单项计提坏账准备应收账款的具体情况，包括但不限于客户基本情况、销售内容及金额、对应收入的确认期间，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，以及你公司已采取和拟采取的应对措施（如有），并结合客户资信变化、回款情况等因素，说明单项计提坏账准备的及时性与准确性。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

（一）列示报告期末应收账款账面余额前十名客户的名称、对应销售内容、合同约定的回款时间、已确认的销售收入、账龄、欠款金额、已计提的坏账准备及期后回款情况，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，并逐一说明客户是否按照合同约定支付款项，如否，请说明原因以及公司已采取和拟采取的应对措施（如有）

# 1、应收账款账面余额前十名客户的相关情况

单位：万元  

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">销售内容</td><td colspan="1" rowspan="1">合同约定回款时间</td><td colspan="1" rowspan="1">2025年度销售收入</td><td colspan="1" rowspan="1">应收账款余额</td><td colspan="1" rowspan="1">账龄</td><td colspan="1" rowspan="1">已计提的坏账准备</td><td colspan="1" rowspan="1">期后回款金额</td><td colspan="1" rowspan="1">期后回款比例</td><td colspan="1" rowspan="1">是否按照合同约定支付款项</td><td colspan="1" rowspan="1">是否存在关联关系</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">第一名</td><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">月结95天</td><td colspan="1" rowspan="1">6,594.40</td><td colspan="1" rowspan="1">1,287.93</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">77.28</td><td colspan="1" rowspan="1">1,287.93</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">第二名</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">月结90天</td><td colspan="1" rowspan="1">1,032.00</td><td colspan="1" rowspan="1">1,111.09</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">66.67</td><td colspan="1" rowspan="1">1,104.35</td><td colspan="1" rowspan="1">99.39%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">第三名</td><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">票到90天</td><td colspan="1" rowspan="1">4,370.60</td><td colspan="1" rowspan="1">700.39</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">42.02</td><td colspan="1" rowspan="1">644.61</td><td colspan="1" rowspan="1">92.04%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">第四名</td><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">月结60天</td><td colspan="1" rowspan="1">1,572.71</td><td colspan="1" rowspan="1">582.93</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">34.98</td><td colspan="1" rowspan="1">582.93</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">第五名</td><td colspan="1" rowspan="1">自动化设备及医疗设备精密部件</td><td colspan="1" rowspan="1">月结45天</td><td colspan="1" rowspan="1">863.19</td><td colspan="1" rowspan="1">569.15</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">34.15</td><td colspan="1" rowspan="1">569.15</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">第六名</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">月结60天</td><td colspan="1" rowspan="1">538.97</td><td colspan="1" rowspan="1">567.44</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">34.05</td><td colspan="1" rowspan="1">567.44</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">第七名</td><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">票到120天</td><td colspan="1" rowspan="1">1,141.81</td><td colspan="1" rowspan="1">419.89</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">25.19</td><td colspan="1" rowspan="1">412.71</td><td colspan="1" rowspan="1">98.29%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">第八名</td><td colspan="1" rowspan="1">电力电子散热器、自动化设备及医疗设备精密部件</td><td colspan="1" rowspan="1">月结90天</td><td colspan="1" rowspan="1">2,699.62</td><td colspan="1" rowspan="1">611.09</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">36.73</td><td colspan="1" rowspan="1">585.05</td><td colspan="1" rowspan="1">95.74%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">第九名</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">30天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">391.92</td><td colspan="1" rowspan="1">3年以上</td><td colspan="1" rowspan="1">391.92</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">0.00%</td><td colspan="1" rowspan="1">香</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">第十名</td><td colspan="1" rowspan="1">电力电子散热器</td><td colspan="1" rowspan="1">月结90天</td><td colspan="1" rowspan="1">1,334.42</td><td colspan="1" rowspan="1">470.93</td><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">28.26</td><td colspan="1" rowspan="1">470.93</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="4" rowspan="1">合计</td><td colspan="1" rowspan="1">20,147.72</td><td colspan="1" rowspan="1">6,712.77</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">771.23</td><td colspan="1" rowspan="1">6,225.10</td><td colspan="1" rowspan="1">92.74%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

注：期后回款金额为 2026 年 1-4 月回款额

北京国能电池科技股份有限公司 2025 年末欠款金额 391.92 万元，期后无回款，该客户已被列为失信被执行人，公司已对该客户进行单项计提。

综上所述，公司前十名应收账款客户与本公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。前十名客户应收账款账面余额6,712.77 万元，截至2026 年4月30 日回款金额6,225.10 万元，回款比例为$9 2 . 7 4 \%$ ，除北京国能电池科技股份有限公司外，基本已按合同约定回款。

（二）结合应收账款账龄分布、客户信用状况、行业特点、往年应收账款基于迁徙模型所测算的历史损失率、前瞻性信息调整情况及依据、近三年报告期末应收账款逾期情况、期后回款情况、同行业可比公司坏账准备计提情况等因素，说明应收账款坏账准备计提是否合理、充分，是否符合企业会计准则的有关规定；

# 1、公司近三年按照账龄组合计提坏账准备的应收账款账龄分布情况

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>10,361.94</td><td rowspan=1 colspan=1>11,247.44</td><td rowspan=1 colspan=1>12,835.92</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>101.86</td><td rowspan=1 colspan=1>28.67</td><td rowspan=1 colspan=1>13.43</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>11.49</td><td rowspan=1 colspan=1>10.43</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>2.00</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>10,477.29</td><td rowspan=1 colspan=1>11,678.46</td><td rowspan=1 colspan=1>13,241.27</td></tr><tr><td rowspan=1 colspan=1>减：坏账准备</td><td rowspan=1 colspan=1>660.02</td><td rowspan=1 colspan=1>1,080.58</td><td rowspan=1 colspan=1>1,167.79</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>9,817.27</td><td rowspan=1 colspan=1>10,597.88</td><td rowspan=1 colspan=1>12,073.48</td></tr></table>

# 2、行业特点及客户信用状况

公司主要产品为电力电子散热器和汽车轻量化部件，在电力电子散热器领域，公司主要客户为 ABB、 施耐德、 西门子、 丹佛斯等国际知名变频器制造商等优质客户，信用风险较低。

在汽车轻量化领域，公司生产的部品及部件主要包括汽车车身及天窗结构件、防撞梁、新能源模组保护端板、电池箱体及配件、电机机壳、汽车电源管理器散热器等产品，主要应用于丰田、吉利、沃尔沃、比亚迪、零跑等传统燃油车及新能源车。下游客户主要是比亚迪汽车股份有限公司、宁波英利汽车工业有限公司等汽车零部件制造企业，该类客户为大型汽车集团的供应商或者为大型汽车集团的子公司，信用风险较低。

# 3、应收账款历史损失率、前瞻性信息调整情况及依据

（1） 预期信用损失率确认方法

公司根据《企业会计准则第 22 号——金融工具确认和计量（2017 年修订）》

规定，基于信用损失迁徙模型测算出历史损失率并在此基础上进行前瞻性因素调整，计算得出并确认预期信用损失率。具体流程及方法：

$\textcircled{1}$ 公司结合应收账款的账龄和回款情况，计算应收账款各年度未收回而迁徙至下一个年度的应收账款的比例，即迁徙率；

$\textcircled{2}$ 使用迁徙率计算账龄组合应收账款的历史损失率；

$\textcircled{3}$ 基于谨慎性的原则，结合当前市场情况以及对未来情况的预测，对预计损失率进行适当修正，将历史损失率进行恰当调整。

（2） 公司历史损失率、前瞻性信息调整情况

第一步：公司按组合计提坏账准备的应收账款期末账面余额

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2022年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2025年12月31日</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>15,790.95</td><td rowspan=1 colspan=1>12,835.92</td><td rowspan=1 colspan=1>11,247.44</td><td rowspan=1 colspan=1>10,361.94</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>13.43</td><td rowspan=1 colspan=1>28.67</td><td rowspan=1 colspan=1>101.86</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>10.43</td><td rowspan=1 colspan=1>11.49</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>402.35</td></tr><tr><td rowspan=1 colspan=1>其中：上年末为3年以上账龄,本年继续迁徙的金额</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td><td rowspan=1 colspan=1>391.92</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>16,182.87</td><td rowspan=1 colspan=1>13,241.27</td><td rowspan=1 colspan=1>11,678.46</td><td rowspan=1 colspan=1>10,877.64</td></tr></table>

注：为还原账龄迁徙的真实性，上表中 2025 年度 3年以上金额包含按照账龄计提的 2.00 万元以及在 2025 年度当年由账龄计提转为单项计提的 400.35 万元。

第二步：公司应收账款迁徙率  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2022年迁徙至2023年</td><td rowspan=1 colspan=1>2023年迁徙至2024年</td><td rowspan=1 colspan=1>2024年迁徙至2025年</td><td rowspan=1 colspan=1>平均迁徙率</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>0.09%</td><td rowspan=1 colspan=1>0.22%</td><td rowspan=1 colspan=1>0.91%</td><td rowspan=1 colspan=1>0.40%</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>77.66%</td><td rowspan=1 colspan=1>40.08%</td><td rowspan=1 colspan=1>58.87%</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

第三步：公司应收账款历史损失率

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>注释</td><td rowspan=1 colspan=1>平均迁徙率</td><td rowspan=1 colspan=1>历史损失率的计算公式</td><td rowspan=1 colspan=1>历史损失率</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>a</td><td rowspan=1 colspan=1>0.40%</td><td rowspan=1 colspan=1>aXbXcXd</td><td rowspan=1 colspan=1>0.24%</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>b</td><td rowspan=1 colspan=1>58.87%</td><td rowspan=1 colspan=1>bXcXd</td><td rowspan=1 colspan=1>58.87%</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>C</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>cXd</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>d</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>d</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

第四步：公司坏账计提比例与预期信用损失率对比

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=1>历史信用损失率</td><td rowspan=1 colspan=1>考虑前瞻性</td><td rowspan=1 colspan=1>预期信用损失率</td><td rowspan=1 colspan=1>公司实际坏账计提比例</td></tr><tr><td rowspan=1 colspan=1>A</td><td rowspan=1 colspan=1>B</td><td rowspan=1 colspan=1>C=A*(1+B)</td><td rowspan=1 colspan=1>D</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>0.24%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>0.25%</td><td rowspan=1 colspan=1>6.00%</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>58.87%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>61.81%</td><td rowspan=1 colspan=1>30.00%</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>50.00%</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

第五步：按预期信用损失率计算坏账准备与账面坏账准备金额对比

单位：万元  

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=1>2025/12/31应收账款余额</td><td rowspan=1 colspan=1>预期信用损失率</td><td rowspan=1 colspan=1>按预期信用损失率计算坏账准备</td><td rowspan=1 colspan=1>账面坏账准备金额</td><td rowspan=1 colspan=1>差异</td></tr><tr><td rowspan=1 colspan=1>A</td><td rowspan=1 colspan=1>B</td><td rowspan=1 colspan=1>C=A*B</td><td rowspan=1 colspan=1>D</td><td rowspan=1 colspan=1>E=D-C</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>10,361.94</td><td rowspan=1 colspan=1>0.25%</td><td rowspan=1 colspan=1>25.92</td><td rowspan=1 colspan=1>621.72</td><td rowspan=1 colspan=1>595.80</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>101.86</td><td rowspan=1 colspan=1>61.81%</td><td rowspan=1 colspan=1>62.96</td><td rowspan=1 colspan=1>30.56</td><td rowspan=1 colspan=1>-32.40</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>11.49</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>11.49</td><td rowspan=1 colspan=1>5.75</td><td rowspan=1 colspan=1>-5.75</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>2.00</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>2.00</td><td rowspan=1 colspan=1>2.00</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>10,477.29</td><td rowspan=1 colspan=1>0.98%</td><td rowspan=1 colspan=1>102.38</td><td rowspan=1 colspan=1>660.02</td><td rowspan=1 colspan=1>557.65</td></tr></table>

由上表可知，公司账面计提的应收账款坏账准备高于按照预期信用损失率计算的坏账准备，公司应收账款坏账准备计提充分、适当。

# 4、近三年报告期末应收账款逾期情况及期后回款

（1）近三年应收账款逾期情况

单位：万元  

<table><tr><td colspan="1" rowspan="1">年度</td><td colspan="1" rowspan="1">余额</td><td colspan="1" rowspan="1">逾期金额</td><td colspan="1" rowspan="1">期后已回款金额</td><td colspan="1" rowspan="1">期后未回款金额</td></tr><tr><td colspan="1" rowspan="1">2025/12/31</td><td colspan="1" rowspan="1">11,049.52</td><td colspan="1" rowspan="1">859.32</td><td colspan="1" rowspan="1">271.13</td><td colspan="1" rowspan="1">588.25</td></tr><tr><td colspan="1" rowspan="1">2024/12/31</td><td colspan="1" rowspan="1">12,036.33</td><td colspan="1" rowspan="1">1,363.87</td><td colspan="1" rowspan="1">762.99</td><td colspan="1" rowspan="1">600.88</td></tr><tr><td colspan="1" rowspan="1">2023/12/31</td><td colspan="1" rowspan="1">13,598.86</td><td colspan="1" rowspan="1">2,968.96</td><td colspan="1" rowspan="1">2,173.40</td><td colspan="1" rowspan="1">795.56</td></tr></table>

注： 2023 年末、 2024 年末的应收账款期后回款金额为下一年度回款额， 2025 年末应收账款期后回款为 2026 年 1-4 月回款额

主要逾期且期后未回款的客户如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>年度</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>应收账款余额</td><td rowspan=1 colspan=1>逾期金额</td><td rowspan=1 colspan=1>逾期款项期后回款金额</td><td rowspan=1 colspan=1>逾期款项期后未回款金额</td></tr><tr><td rowspan=3 colspan=1>2025年度</td><td rowspan=1 colspan=1>惠森汽车科技（宁波）有限公司</td><td rowspan=1 colspan=1>168.50</td><td rowspan=1 colspan=1>168.50</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>168.50</td></tr><tr><td rowspan=1 colspan=1>河南国能电池有限公司</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>390.34</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>558.84</td><td rowspan=1 colspan=1>558.84</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>558.84</td></tr><tr><td rowspan=3 colspan=1>2024年度</td><td rowspan=1 colspan=1>惠森汽车科技（宁波）有限公司</td><td rowspan=1 colspan=1>351.09</td><td rowspan=1 colspan=1>351.09</td><td rowspan=1 colspan=1>182.59</td><td rowspan=1 colspan=1>168.50</td></tr><tr><td rowspan=1 colspan=1>河南国能电池有限公司</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>390.34</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>741.43</td><td rowspan=1 colspan=1>741.43</td><td rowspan=1 colspan=1>182.59</td><td rowspan=1 colspan=1>558.84</td></tr><tr><td rowspan=3 colspan=1>2023年度</td><td rowspan=1 colspan=1>惠森汽车科技（宁波）有限公司</td><td rowspan=1 colspan=1>357.59</td><td rowspan=1 colspan=1>357.59</td><td rowspan=1 colspan=1>8.27</td><td rowspan=1 colspan=1>349.32</td></tr><tr><td rowspan=1 colspan=1>河南国能电池有限公司</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1>390.34</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>390.34</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>741.43</td><td rowspan=1 colspan=1>741.43</td><td rowspan=1 colspan=1>8.27</td><td rowspan=1 colspan=1>739.66</td></tr></table>

针对以上逾期且未回款客户，公司在报告期内均已全额计提坏账准备。

# （2）应收账款期后回款情况

公司近三年应收账款原值及期后回款情况如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>年度</td><td rowspan=1 colspan=1>应收账款余额</td><td rowspan=1 colspan=1>期后回款</td><td rowspan=1 colspan=1>期后回款占应收余额比例</td></tr><tr><td rowspan=1 colspan=1>2025/12/31</td><td rowspan=1 colspan=1>11,049.52</td><td rowspan=1 colspan=1>10,203.40</td><td rowspan=1 colspan=1>92.34%</td></tr><tr><td rowspan=1 colspan=1>2024/12/31</td><td rowspan=1 colspan=1>12,036.33</td><td rowspan=1 colspan=1>11,431.57</td><td rowspan=1 colspan=1>94.98%</td></tr><tr><td rowspan=1 colspan=1>2023/12/31</td><td rowspan=1 colspan=1>13,598.86</td><td rowspan=1 colspan=1>12,780.29</td><td rowspan=1 colspan=1>93.98%</td></tr></table>

注： 2023 年末、 2024 年末的应收账款期后回款金额为下一年度回款额， 2025 年末应收账款期后回款为 2026 年 1-4 月回款额

由上表分析可知，公司近三年期后回款率分别为 $9 2 . 3 4 \%$ 、 $9 4 . 9 8 \%$ 及 $9 3 . 9 8 \%$ ，主要逾期的应收账款客户已全额计提坏账准备。

# 5、同行业可比公司坏账计提情况

公司预期信用损失率和同行业可比公司对比如下：

<table><tr><td rowspan=2 colspan=1>账龄</td><td rowspan=1 colspan=6>同行业可比公司</td><td rowspan=2 colspan=1>锐新科技</td></tr><tr><td rowspan=1 colspan=1>和胜股份</td><td rowspan=1 colspan=1>亚太科技</td><td rowspan=1 colspan=1>春兴精工</td><td rowspan=1 colspan=1>豪美新材</td><td rowspan=1 colspan=1>华峰铝业</td><td rowspan=1 colspan=1>平均值</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>2%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>4%</td><td rowspan=1 colspan=1>6%</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>20%</td><td rowspan=1 colspan=1>10%</td><td rowspan=1 colspan=1>10%</td><td rowspan=1 colspan=1>10%</td><td rowspan=1 colspan=1>10%</td><td rowspan=1 colspan=1>12%</td><td rowspan=1 colspan=1>30%</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>80%</td><td rowspan=1 colspan=1>50%</td><td rowspan=1 colspan=1>30%</td><td rowspan=1 colspan=1>50%</td><td rowspan=1 colspan=1>50%</td><td rowspan=1 colspan=1>52%</td><td rowspan=1 colspan=1>50%</td></tr><tr><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>100%</td></tr></table>

资料来源： 年度报告

通过上述对比可知，公司应收账款坏账计提比例与同行业可比公司不存在较大差异。

综上所述，公司应收账款坏账准备计提合理、充分，符合企业会计准则的有关规定。

（三）披露按单项计提坏账准备应收账款的具体情况，包括但不限于客户基本情况、销售内容及金额、对应收入的确认期间，说明该等客户是否与你公司、实际控制人、持股 $5 \%$ 以上股东、董监高等之间存在关联关系或可能造成利益倾斜的其他关系，以及你公司已采取和拟采取的应对措施（如有），并结合客户资信变化、回款情况等因素，说明单项计提坏账准备的及时性与准确性。

# 1、单项计提坏账准备应收账款的具体情况

单位：万元

<table><tr><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">成立时间</td><td colspan="1" rowspan="1">注册资本</td><td colspan="1" rowspan="1">主营业务</td><td colspan="1" rowspan="1">经营状销售内态</td><td colspan="1" rowspan="1">经营状销售内容</td><td colspan="1" rowspan="1">应收账款余额</td><td colspan="1" rowspan="1">对应收入期间</td><td colspan="1" rowspan="1">是否存在关联关系</td></tr><tr><td colspan="1" rowspan="1">惠森汽车科技（宁波）有限公|2015-12-28司</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">300.00</td><td colspan="1" rowspan="1">汽车零部件及配件制造</td><td colspan="1" rowspan="1">已破产</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">168.50和2023</td><td colspan="1" rowspan="1">2022年168.50和2023年</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">河南国能电池有限公司</td><td colspan="1" rowspan="1">2014-08-21|60,000.00</td><td colspan="1" rowspan="1">2014-08-21|60,000.00</td><td colspan="1" rowspan="1">锂电池生产与销售</td><td colspan="1" rowspan="1">已被列为失信被执行人</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1">390.34和2019</td><td colspan="1" rowspan="1">2018年390.34和2019年</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">深圳市英威腾交通技术有限公司</td><td colspan="1" rowspan="1">2010-11-17|11,253.57</td><td colspan="1" rowspan="1">2010-11-17|11,253.57</td><td colspan="1" rowspan="1">轨道交通牵引</td><td colspan="1" rowspan="1">已被列为失信</td><td colspan="1" rowspan="1">电力电子散热</td><td colspan="1" rowspan="1">8.43</td><td colspan="1" rowspan="1">2022年</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">成立时间</td><td colspan="1" rowspan="1">注册资本</td><td colspan="1" rowspan="1">主营业务</td><td colspan="1" rowspan="1">经营状态</td><td colspan="1" rowspan="1">销售内容</td><td colspan="1" rowspan="1">应收账款余额</td><td colspan="1" rowspan="1">对应收入期间</td><td colspan="1" rowspan="1">是否存在关联关系</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">系统研发与生产</td><td colspan="1" rowspan="1">被执行人</td><td colspan="1" rowspan="1">器</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">中稀东洋永磁电机有限公司</td><td colspan="1" rowspan="1">2019-06-10|6,000.00</td><td colspan="1" rowspan="1">2019-06-10|6,000.00</td><td colspan="1" rowspan="1">电机、变配电装置等研发与制造</td><td colspan="1" rowspan="1">存续</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3.382023年</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">北京国能电池科技股份有限公司</td><td colspan="1" rowspan="1">2011-11-14|36,000.00</td><td colspan="1" rowspan="1">2011-11-14|36,000.00</td><td colspan="1" rowspan="1">锂电池生产与销售</td><td colspan="1" rowspan="1">已被列为失信被执行人</td><td colspan="1" rowspan="1">汽车轻量化部件</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1.582018年</td><td colspan="1" rowspan="1">否</td></tr></table>

# 2、已采取和拟采取的应对措施

公司已采取和拟采取的应对措施如下：

$\textcircled{1}$ 持续关注客户经营情况、舆情及资信变化情况；

$\textcircled{2}$ 努力维系客户关系，公司与客户积极协商，采取多种措施，例如委派专人专员驻场催收，争取尽快收回货款；

$\textcircled{3}$ 对于多次协调后，确定无法通过沟通途径收回的款项，由公司负责法务部门发送律师函和法务函等法律手段维护公司合法权益；

$\textcircled{4}$ 若客户已进入破产程序，公司依法申报债权；

$\textcircled{5}$ 根据相关情况考虑是否启动诉讼仲裁程序。

# 3、结合客户资信变化、回款情况等因素，说明单项计提坏账准备的及时性与准确性。

单位：万元  

<table><tr><td colspan="1" rowspan="2">年度</td><td colspan="1" rowspan="2">客户名称</td><td colspan="4" rowspan="1">单项计提</td><td colspan="1" rowspan="1">资信情况</td></tr><tr><td colspan="1" rowspan="1">应收账款余额</td><td colspan="1" rowspan="1">坏账准备余额</td><td colspan="1" rowspan="1">计提比例</td><td colspan="1" rowspan="1">期后回款</td><td colspan="1" rowspan="1">2025年</td></tr><tr><td colspan="1" rowspan="2">2025年12月31日</td><td colspan="1" rowspan="1">惠森汽车科技（宁波）有限公司</td><td colspan="1" rowspan="1">168.50</td><td colspan="1" rowspan="1">168.50</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">已破产清算</td></tr><tr><td colspan="1" rowspan="1">河南国能电池有限公司</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="4"></td><td colspan="1" rowspan="1">深圳市英威腾交通技术有限公司</td><td colspan="1" rowspan="1">8.43</td><td colspan="1" rowspan="1">8.43</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">中稀东洋永磁电机有限公司</td><td colspan="1" rowspan="1">3.38</td><td colspan="1" rowspan="1">3.38</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">进入破产清算程序</td></tr><tr><td colspan="1" rowspan="1">北京国能电池科技股份有限公司</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">572.23</td><td colspan="1" rowspan="1">572.23</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="6">2024年12月31日</td><td colspan="1" rowspan="1">惠森汽车科技（宁波）有限公司</td><td colspan="1" rowspan="1">351.09</td><td colspan="1" rowspan="1">351.09</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">182.59</td><td colspan="1" rowspan="1">限制高消费</td></tr><tr><td colspan="1" rowspan="1">河南国能电池有限公司</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">深圳市英威腾交通技术有限公司</td><td colspan="1" rowspan="1">8.43</td><td colspan="1" rowspan="1">4.21</td><td colspan="1" rowspan="1">50.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">中稀东洋永磁电机有限公司</td><td colspan="1" rowspan="1">6.77</td><td colspan="1" rowspan="1">6.77</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">3.38</td><td colspan="1" rowspan="1">公司提起诉讼</td></tr><tr><td colspan="1" rowspan="1">北京国能电池科技股份有限公司</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">572.23</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="6">2023年12月31日</td><td colspan="1" rowspan="1">惠森汽车科技（宁波）有限公司</td><td colspan="1" rowspan="1">357.59</td><td colspan="1" rowspan="1">357.59</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">6.50</td><td colspan="1" rowspan="1">限制高消费</td></tr><tr><td colspan="1" rowspan="1">河南国能电池有限公司</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">390.34</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">深圳市英威腾交通技术有限公司</td><td colspan="1" rowspan="1">8.43</td><td colspan="1" rowspan="1">2.53</td><td colspan="1" rowspan="1">30.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">中稀东洋永磁电机有限公司</td><td colspan="1" rowspan="1">6.77</td><td colspan="1" rowspan="1">0.41</td><td colspan="1" rowspan="1">6.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">正常</td></tr><tr><td colspan="1" rowspan="1">北京国能电池科技股份有限公司</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">1.58</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">失信被执行、限制高消费</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">572.23</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

注：2023 年末、 2024 年末的应收账款期后回款金额为下一年度回款额， 2025 年末应收账款期后回款为 2026 年 1-4月回款额

深圳市英威腾交通技术有限公司系上市公司深圳市英威腾电气股份有限公司子公司，2023 及2024 年度公司判断该笔应收账款可能部分收回，故未进行单项计提。2025 年度该笔应收账款一直未收回，公司对该笔应收账款进行单项计提。

公司单项计提的应收账款坏账准备对应的客户基本为失信被执行人、被限制消费令或相关公司已破产，公司综合判断相关客户的资信情况变化及客户经营情况单项计提对应的应收账款坏账准备，单项计提坏账准备具有及时性与准确性。

综上所述，上述单项计提坏账的应收账款客户与本公司、实际控制人、持股$5 \%$ 以上股东、董监高等之间不存在关联关系或可能造成利益倾斜的其他关系。公司单项计提应收账款坏账准备对应的客户中，对于尚未注销的客户，公司通过诉讼、函件等方式进行催收。公司单项计提坏账准备综合考虑了客户资信变化及回款情况等，公司单项计提坏账准备具有及时性与准确性。

# 二、会计师核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

1、了解、评价并测试销售与收款内部控制设计和执行的有效性；

2、获取管理层编制的应收账款账龄明细及预期信用损失计提表，通过分析应收账款的账龄、客户结算账期、信誉情况以及结合预期信用损失计提方法，重新计算并评价应收账款预期信用损失计提的合理性；

3、对于单项计提坏账准备的应收账款，通过检查已发生减值的客观证据，并结合相关客户历史回款情况分析等情况测试，复核管理层对应收账款可收回金额评估的合理性并检查坏账准备是否在恰当的期间计提；

4、执行函证程序，选取公司重要客户，执行应收账款余额函证程序，以检查确认应收账款期末余额的准确性；

5、执行应收账款期后检查程序，进一步评价管理层应收账款预期信用损失计提的合理性；

6、执行同行业可比公司对比分析程序，结合公司与同行业可比公司的经营及业务模式，分析应收账款坏账计提比例情况差异的合理性；

7、通过公开信息查询公司主要客户工商信息，分析是否与公司存在关联关系。

# （二）核查意见

经核查，容诚所认为：

公司应收账款坏账准备计提充分，不存在违反《企业会计准则第 22 号——金融工具确认和计量（2017 年修订）》的规定情形；公司前十名应收账款的客户及按单项计提坏账准备的应收账款对应客户与公司、实际控制人、持股 $5 \%$ 以上股东、董监高人员不存在关联关系或可能造成利益倾斜的其他关系。

问题 3.年报显示，你公司报告期末货币资金余额 1.16 亿元，交易性金融资产余额 1,000 万元；短期借款余额 4,009.31 万元，均为报告期新增。报告期内，实现利息收入 233.62 万元，发生利息支出 129.99 万元。

# 请你公司：

（1）说明货币资金的具体用途、存放类型、存放地点，并结合利率水平、年度日均存款余额等因素，说明货币资金存放安排是否合理，利息收入与存款规模是否匹配；

（2）列示前五大金额的短期有息负债明细，包括但不限于债权人名称、与公司是否存在关联关系、借款性质、借款金额、借款利率、到期日期、是否逾期、逾期金额，并补充说明截至回函日流动负债偿还情况、逾期债务情况及占比（如有），梳理未来一年到期债务情况，并结合公司可自由支配货币资金、经营性现金流情况、未来资金支出安排与偿债计划、公司融资渠道和能力、货币资金受限情况等，评估公司的偿债能力，说明你公司后续的债务偿付安排，是否存在债务逾期风险，如是，请充分提示风险并说明已采取或拟采取的应对措施。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

（一）说明货币资金的具体用途、存放类型、存放地点，并结合利率水平、年度日均存款余额等因素，说明货币资金存放安排是否合理，利息收入与存款规模是否匹配；

# 1、货币资金概况

单位：万元  

<table><tr><td rowspan=1 colspan=1>货币资金类型</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>用途</td></tr><tr><td rowspan=1 colspan=1>库存现金</td><td rowspan=1 colspan=1>6.02</td><td rowspan=1 colspan=1>27.31</td><td rowspan=1 colspan=1>用于日常经营</td></tr><tr><td rowspan=1 colspan=1>银行存款</td><td rowspan=1 colspan=1>11,326.17</td><td rowspan=1 colspan=1>4,193.51</td><td rowspan=1 colspan=1>用于日常经营</td></tr><tr><td rowspan=1 colspan=1>其中：活期存款</td><td rowspan=1 colspan=1>2,276.90</td><td rowspan=1 colspan=1>2,497.05</td><td rowspan=1 colspan=1>用于日常经营</td></tr><tr><td rowspan=1 colspan=1>定期存款</td><td rowspan=1 colspan=1>9,049.27</td><td rowspan=1 colspan=1>1,696.46</td><td rowspan=1 colspan=1>在满足流动性的前提下进行资金管理</td></tr><tr><td rowspan=1 colspan=1>其他货币资金</td><td rowspan=1 colspan=1>231.57</td><td rowspan=1 colspan=1>0.68</td><td rowspan=1 colspan=1>保证金</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>11,563.76</td><td rowspan=1 colspan=1>4,221.49</td><td rowspan=1 colspan=1>丨</td></tr></table>

截至 2025 年 12 月 31 日，公司货币资金总金额为 11,563.76 万元， 其中：11,557.74 万元为存放于各对应银行的银行存款账户、保证金户；现金 6.02 万元存放于公司保险柜。

公司 2025 年利息收入 233.62 万元， 年度日均存款余额约为 10,877.73 万元，交易性金融资产中的理财产品日均余额约为 1,267.25 万元，2025 年利息收入/年度日均存款余额与年度日均交易性金融资产余额之和约为 $1 . 9 2 \%$ ，该比例高于银行的活期利率，但低于定期存款及理财产品的利率， 利息收入与存款规模匹配。

（二）列示前五大金额的短期有息负债明细，包括但不限于债权人名称、与公司是否存在关联关系、借款性质、借款金额、借款利率、到期日期、是否逾期、逾期金额，并补充说明截至回函日流动负债偿还情况、逾期债务情况及占比（如有），梳理未来一年到期债务情况，并结合公司可自由支配货币资金、经营性现金流情况、未来资金支出安排与偿债计划、公司融资渠道和能力、货币资金受限情况等，评估公司的偿债能力，说明你公司后续的债务偿付安排，是否存在债务逾期风险，如是，请充分提示风险并说明已采取或拟采取的应对措施。

# 1、前五大金额的短期有息负债明细

截至 2025 年 12 月 31 日，公司短期借款余额 4,009.31 万元，其中短期借款4,000.00 万元，票据贴现借款 6.96 万元，短期借款利息 2.36 万元。

单位：万元

<table><tr><td rowspan=1 colspan=1>借款银行</td><td rowspan=1 colspan=1>与公司是否存在关联关系</td><td rowspan=1 colspan=1>借款性质</td><td rowspan=1 colspan=1>借款金额</td><td rowspan=1 colspan=1>借款利率</td><td rowspan=1 colspan=1>到期日期</td><td rowspan=1 colspan=1>是否逾期</td></tr><tr><td rowspan=1 colspan=1>中国银行股份有限公司天津西青支行</td><td rowspan=1 colspan=1>香</td><td rowspan=1 colspan=1>抵押</td><td rowspan=1 colspan=1>1,000.00</td><td rowspan=1 colspan=1>2.15%</td><td rowspan=1 colspan=1>2026/2/28</td><td rowspan=1 colspan=1>香</td></tr><tr><td rowspan=1 colspan=1>中国银行股份有限公司天津西青支行</td><td rowspan=1 colspan=1>香</td><td rowspan=1 colspan=1>抵押</td><td rowspan=1 colspan=1>3,000.00</td><td rowspan=1 colspan=1>2.11%</td><td rowspan=1 colspan=1>2026/9/29</td><td rowspan=1 colspan=1>香</td></tr><tr><td rowspan=1 colspan=1>中信银行股份有限公司</td><td rowspan=1 colspan=1>香</td><td rowspan=1 colspan=1>票据贴现借款</td><td rowspan=1 colspan=1>5.59</td><td rowspan=1 colspan=1>2.4%</td><td rowspan=1 colspan=1>2026/3/9</td><td rowspan=1 colspan=1>香</td></tr><tr><td rowspan=1 colspan=1>中国银行股份有限公司</td><td rowspan=1 colspan=1>香</td><td rowspan=1 colspan=1>票据贴现借款</td><td rowspan=1 colspan=1>1.37</td><td rowspan=1 colspan=1>1.35%</td><td rowspan=1 colspan=1>2026/01/22</td><td rowspan=1 colspan=1>香</td></tr></table>

# 2、流动负债偿还情况及偿债能力评估

公司2025 年底的流动负债余额为4,009.31 万元，截至回函日公司已偿还金额2,009.31 万元，无逾期债务情况。

截至回函日，公司可自由支配的货币资金约为 8,514.33 万元，且不存在货币资金受限的情况，能够覆盖公司有息负债金额。且公司与银行合作良好，授信额度充足，预计到期债务能够按期偿还，不存在债务逾期的风险。

# 二、核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

1、了解公司货币资金相关的内部控制制度，评价其设计是否有效，并测试相关内部控制的运行有效性；

2、获取货币资金明细表，了解货币资金的构成情况，复核加计是否正确，并与总账数和明细账合计数核对是否相符；

3、对期末库存现金进行监盘， 以核实期末现金余额的存在；

4、获取公司的已开立账户结算清单、征信报告，将其与公司银行账户予以核

对，取得并检查银行账户的开户、销户等资料；

5、取得银行对账单及银行存款余额调节表， 对公司所有银行账户实施函证程序， 核实账户余额、 受限情况、 质押担保、 是否存在资金归集等信息；

6、根据银行存款年度日均余额和存款利率分析复核利息收入的合理性；

7、获取借款台账，并检查相关借款合同、综合授信合同、抵押合同等资料，与征信报告相关信息核对是否一致，并进行银行函证，检查回函信息是否相符；

8、检查公司短期借款期后偿还情况，了解公司关于偿还短期借款的资金安排，结合资金情况、公司融资渠道和能力等复核公司偿还短期借款的资金安排是否具有可实现性。

# （二）核查意见

经核查，容诚所认为：

1、公司货币资金在满足流动性的前提下进行资金管理，存放安排合理，利息收入与存款规模相匹配；

2、截至回函日，公司短期借款均已按期偿还，不存在逾期债务。公司账面货币资金充足，银行融资能力较强，不存在重大债务偿还风险。

问题 4.你公司报告期资产减值损失 337.59 万元，主要为存货跌价损失536.96 万元（转回或转销 81.56 万元）。请你公司结合存货构成及库龄、在手订单、期后生产和结转情况、存货跌价准备测试过程、同行业可比公司情况等，说明存货跌价准备计提是否充分、准确。同时，说明报告期内存货跌价准备转回或转销的具体原因、确定依据、与计提时测算的差异，报告期及前期存货跌价准备计提的合理性、充分性和准确性。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

（一）结合存货构成及库龄、在手订单、期后生产和结转情况、存货跌价准备测试过程、同行业可比公司情况等，说明存货跌价准备计提是否充分、准

# 确

# 1、公司存货的具体构成和库龄

截至 2025 年末，公司存货账面余额 19,362.88 万元，存货跌价准备 564.28 万元，存货账面价值 18,798.60 万元，存货构成及库龄情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=4>存货原值及库龄</td><td rowspan=2 colspan=1>存货跌价准备余额</td></tr><tr><td rowspan=1 colspan=1>存货原值</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2年以上</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>4,606.83</td><td rowspan=1 colspan=1>3,930.79</td><td rowspan=1 colspan=1>313.12</td><td rowspan=1 colspan=1>362.92</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>发出商品</td><td rowspan=1 colspan=1>2,759.38</td><td rowspan=1 colspan=1>2,731.64</td><td rowspan=1 colspan=1>2.87</td><td rowspan=1 colspan=1>24.87</td><td rowspan=1 colspan=1>135.31</td></tr><tr><td rowspan=1 colspan=1>半成品</td><td rowspan=1 colspan=1>5,167.35</td><td rowspan=1 colspan=1>4,533.07</td><td rowspan=1 colspan=1>521.55</td><td rowspan=1 colspan=1>112.74</td><td rowspan=1 colspan=1>111.77</td></tr><tr><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>6,667.42</td><td rowspan=1 colspan=1>5,579.56</td><td rowspan=1 colspan=1>607.12</td><td rowspan=1 colspan=1>480.74</td><td rowspan=1 colspan=1>317.20</td></tr><tr><td rowspan=1 colspan=1>在产品</td><td rowspan=1 colspan=1>161.90</td><td rowspan=1 colspan=1>161.90</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>19,362.88</td><td rowspan=1 colspan=1>16,936.95</td><td rowspan=1 colspan=1>1,444.67</td><td rowspan=1 colspan=1>981.26</td><td rowspan=1 colspan=1>564.28</td></tr></table>

公司存货主要系原材料、发出商品、半成品、库存商品；从库龄结构分析，公司存货以1年以内为主，占比达到 $8 7 . 4 7 \%$ ，整体符合铝制品行业生产经营特点，存货周转情况良好。

# 2、在手订单情况

公司产品为定制化产品，根据客户的产品设计需求进行定制化的协同开发，在通过客户的定点并取得销售订单后，依据订单采用以客户滚动需求预测为导向的“订单式生产” 的经营模式。截至 2025 年末，公司存货账面余额为 19,362.88 万元，在手订单不含税金额为 10,265.93 万元。2026 年1-3 月份签订合同订单金额为15,917.18 万元，新签订单情况良好，订单获取能力稳定。

# 3、期后生产和结转情况

公司存货期后生产和结转情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2025/12/31账面余2026年1-3月发生额</td><td colspan="1" rowspan="1">2025/12/31账面余2026年1-3月发生额</td><td colspan="1" rowspan="1">2026年1-3月结转金额</td><td colspan="1" rowspan="1">2026/3/31账面余额</td></tr><tr><td colspan="1" rowspan="1">原材料</td><td colspan="1" rowspan="1">4,606.83</td><td colspan="1" rowspan="1">17,797.06</td><td colspan="1" rowspan="1">16,584.60</td><td colspan="1" rowspan="1">5,819.29</td></tr><tr><td colspan="1" rowspan="1">发出商品</td><td colspan="1" rowspan="1">2,759.38</td><td colspan="1" rowspan="1">14,260.97</td><td colspan="1" rowspan="1">14,124.42</td><td colspan="1" rowspan="1">2,895.93</td></tr><tr><td colspan="1" rowspan="1">半成品</td><td colspan="1" rowspan="1">5,167.35</td><td colspan="1" rowspan="1">37,028.13</td><td colspan="1" rowspan="1">35,845.35</td><td colspan="1" rowspan="1">6,350.13</td></tr><tr><td colspan="1" rowspan="1">库存商品</td><td colspan="1" rowspan="1">6,667.42</td><td colspan="1" rowspan="1">7,532.25</td><td colspan="1" rowspan="1">8,525.30</td><td colspan="1" rowspan="1">5,674.37</td></tr><tr><td colspan="1" rowspan="1">在产品</td><td colspan="1" rowspan="1">161.90</td><td colspan="1" rowspan="1">13,511.88</td><td colspan="1" rowspan="1">13,365.58</td><td colspan="1" rowspan="1">308.20</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">19,362.88</td><td colspan="1" rowspan="1">90,130.29</td><td colspan="1" rowspan="1">88,445.25</td><td colspan="1" rowspan="1">21,047.92</td></tr></table>

# 4、存货跌价准备测试过程

公司通常对存货按照单个存货项目分别进行存货跌价准备测试， 对于数量繁多、单价较低的存货，按照存货类别计提存货跌价准备。 资产负债表日，按照成本与可变现净值孰低计量， 当其可变现净值低于成本时，计提存货跌价准备。可变现净值是按存货的估计售价减去至完工时估计将要发生的成本、估计的销售费用以及相关税费后的金额。具体各类别存货跌价准备测试过程如下：

单位：万元  

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>期末余额</td><td rowspan=2 colspan=1>存货可变现净值的方法</td></tr><tr><td rowspan=1 colspan=1>账面余额</td><td rowspan=1 colspan=1>跌价准备</td><td rowspan=1 colspan=1>账面价值</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>4,606.83</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>4,606.83</td><td rowspan=1 colspan=1>以所生产的产成品的估计售价减去至完工时估计将要发生的成本、估计的销售费用和相关税费后的金额确定其可变现净值</td></tr><tr><td rowspan=1 colspan=1>发出商品</td><td rowspan=1 colspan=1>2,759.38</td><td rowspan=1 colspan=1>135.31</td><td rowspan=1 colspan=1>2,624.07</td><td rowspan=1 colspan=1>合同约定销售价格减去估计的销售费用和相关税费后的金额</td></tr><tr><td rowspan=1 colspan=1>半成品</td><td rowspan=1 colspan=1>5,167.35</td><td rowspan=1 colspan=1>111.77</td><td rowspan=1 colspan=1>5,055.58</td><td rowspan=1 colspan=1>以所生产的产成品的估计售价减去至完工时估计将要发生的成本、估计的销售费用和相关税费后的金额确定其可变现净值</td></tr><tr><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>6,667.42</td><td rowspan=1 colspan=1>317.20</td><td rowspan=1 colspan=1>6,350.22</td><td rowspan=1 colspan=1>对于库龄较短、具有销售订单支持等正常结存的产成品，根据存货的预计售价减去估计的销售费用和相关税费后的金额，确定其可变现净值；对于库龄较长，不具有销售订单支持且呆滞的产成品，出于谨慎性考虑，期末可变现净值根据废料的价格计算。</td></tr><tr><td rowspan=1 colspan=1>在产品</td><td rowspan=1 colspan=1>161.90</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>161.90</td><td rowspan=1 colspan=1>以所生产的产成品的估计售价减去至完工时估计将要发生的成本、估计的销售费用和相关税费后的金额确定其可变现净值</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>19,362.88</td><td rowspan=1 colspan=1>564.28</td><td rowspan=1 colspan=1>18,798.60</td><td rowspan=1 colspan=1></td></tr></table>

# 5、存货跌价准备计提与同行业可比公司的比较情况

报告期末公司存货跌价准备计提比例与同行业可比公司对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>存货原值</td><td rowspan=1 colspan=1>存货跌价准备余额</td><td rowspan=1 colspan=1>计提比例</td></tr><tr><td rowspan=1 colspan=1>和胜股份</td><td rowspan=1 colspan=1>66,592.48</td><td rowspan=1 colspan=1>1,372.88</td><td rowspan=1 colspan=1>2.06%</td></tr><tr><td rowspan=1 colspan=1>亚太科技</td><td rowspan=1 colspan=1>92,764.31</td><td rowspan=1 colspan=1>4,406.49</td><td rowspan=1 colspan=1>4.75%</td></tr><tr><td rowspan=1 colspan=1>春兴精工</td><td rowspan=1 colspan=1>46,507.98</td><td rowspan=1 colspan=1>3,074.95</td><td rowspan=1 colspan=1>6.61%</td></tr><tr><td rowspan=1 colspan=1>豪美新材</td><td rowspan=1 colspan=1>75,765.94</td><td rowspan=1 colspan=1>1,364.09</td><td rowspan=1 colspan=1>1.80%</td></tr><tr><td rowspan=1 colspan=1>华峰铝业</td><td rowspan=1 colspan=1>315,188.26</td><td rowspan=1 colspan=1>1,978.24</td><td rowspan=1 colspan=1>0.63%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1>119,363.79</td><td rowspan=1 colspan=1>2,439.33</td><td rowspan=1 colspan=1>2.04%</td></tr><tr><td rowspan=1 colspan=1>锐新科技</td><td rowspan=1 colspan=1>19,362.88</td><td rowspan=1 colspan=1>564.28</td><td rowspan=1 colspan=1>2.91%</td></tr></table>

由上表可知：公司存货跌价准备计提比例为 $2 . 9 1 \%$ ，同行业上市公司存货跌价计提比例在 $0 . 6 3 \%$ 至 $5 . 9 1 \%$ ，公司的存货跌价计提比例处于中等合理水平。

综上所述，公司存货跌价准备的相关会计处理符合《企业会计准则》的规定，存货跌价准备计提比例与同行业可比公司不存在重大差异，存货跌价准备计提充分、准确。

（二）说明报告期内存货跌价准备转回或转销的具体原因、确定依据、与计提时测算的差异，报告期及前期存货跌价准备计提的合理性、充分性和准确性

2025 年度， 公司存货跌价准备存在转销的情况，为以前年度计提减值存货在本期实现销售或者领用所致， 金额合计 81.56 万元。 具体情况如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>本年转销金额</td><td rowspan=1 colspan=1>转销原因</td></tr><tr><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>69.76</td><td rowspan=1 colspan=1>2024 年末库存商品在报告期已实现对外销售</td></tr><tr><td rowspan=1 colspan=1>半成品</td><td rowspan=1 colspan=1>11.80</td><td rowspan=1 colspan=1>2024年末半成品在报告期已生产领用</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>81.56</td><td rowspan=1 colspan=1></td></tr></table>

本期存货跌价准备的转销系以前年度计提减值存货在本期实现销售或者领用所致，转销金额与计提金额一致，不存在差异。公司报告期及前期存货跌价准备系按照成本高于其可变现净值的差额计提，符合《企业会计准则》的相关规定，

具有合理性，不存在存货跌价准备计提不充分的情形。

# 二、核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

1、了解、评价并测试采购与付款、生产与仓储以及存货跌价准备计提相关的内部控制设计和运行的有效性；

2、了解并评价锐新科技存货跌价准备计提政策的适当性；

3、了解并询问存货存放地点、存货核算方法，确定存货监盘范围；

4、与管理层讨论存货盘点情况，对存货实施监盘，检查存货的数量、状况等；

5、取得存货的年末库龄清单，结合产品的状况，进行库龄分析性复核，分析存货跌价准备是否合理；

6、复核与评估管理层确定可变现净值时做出的重大估计的合理性；

7、获取存货跌价准备计算表，复核存货跌价准备计提是否按相关会计政策执行，并重新测算存货跌价准备，检查以前年度计提的存货跌价在本期的变化情况等，分析存货跌价准备计提是否充分；

8、获取2025 年期末在手订单以及2026 年1-3 月份已签订的订单。

# （二）核查意见

经核查，容诚所认为：

1、报告期期末，公司按照制定的存货跌价准备计提政策对存货进行跌价测试，存货跌价准备的计提充分、准确。公司存货跌价准备计提比例接近同行业平均水平，与同行业可比公司不存在重大差异。

2、报告期内存货跌价准备转回或转销主要系以前年度计提减值的存货在本期实现销售或者领用所致，报告期及前期存货跌价准备计提充分、准确，符合《企业会计准则》的相关规定。

问题 5.你公司报告期末在建工程余额 1,157.68 万元，较期初余额减少$8 3 . 4 9 \%$ 。其中，“新建挤压型材生产厂房”“在安装设备”报告期内分别转固金额 4,046.77 万元、4,025.52 万元，“新建挤压型材生产厂房”期末余额为 0。你公司未对上述 2 个项目计提减值准备。请你公司：

（1）说明上述 2 个项目的开工时间、预计完工时间、具体建设进展及是否与计划匹配，是否存在减值迹象，相关减值准备计提是否充分。

（2）说明报告期内在建工程转入固定资产的具体情况，包括不限于项目内容、投资预算金额、开工与完工时间、累计投入金额、转入固定资产内容、依据、时间、金额等，并说明结转时点及金额是否准确，是否存在未及时转入固定资产的情形，转固新增的折旧费用对你公司当期及未来经营业绩产生的具体影响。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

（一）说明上述 2 个项目的开工时间、预计完工时间、具体建设进展及是否与计划匹配，是否存在减值迹象，相关减值准备计提是否充分。

# 1、报告期在建工程项目情况

报告期在建工程项目主要是新能源汽车轻量化部件研发生产基地项目的新建挤压型材生产厂房，在安装设备可以分为在安装设备-挤压生产线以及在安装设备-其他生产设备，具体情况如下：

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>开工时间</td><td rowspan=1 colspan=1>预计完工时间</td><td rowspan=1 colspan=1>实际完工时间</td><td rowspan=1 colspan=1>具体建设进展</td><td rowspan=1 colspan=1>是否与计划匹配</td></tr><tr><td rowspan=1 colspan=1>新建挤压型材生产厂房</td><td rowspan=1 colspan=1>2023年9月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>已完工</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>在安装设备-挤压生产线</td><td rowspan=1 colspan=1>2023年9月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>已完工</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>在安装设备-其它生产设备</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>已完工</td><td rowspan=1 colspan=1>是</td></tr></table>

注：其他生产设备较为分散，于安装调试完毕达到预定可使用状态后转入固定资产

# 2、减值迹象判断及减值计提充分性说明

报告期内，公司严格按照《企业会计准则第 8 号 —— 资产减值》要求，持续对上述在建及转固项目开展减值迹象排查。

项目建设期间施工正常、资金投入稳定、产品下游需求稳定，不存在项目停滞、技术淘汰、行业政策重大不利变化等情形；项目完工转固后，厂房及生产线均已正式投产使用，设备运行稳定、产品良率达标、产能释放符合预期，不存在资产闲置、产能利用率不足、实体损毁、技术落后、产品市场价格大幅下滑、可收回金额低于账面价值等减值迹象。

综上所述，公司在建工程建设进展基本与计划相匹配，公司于报告期末结合《企业会计准则第 8 号—资产减值》关于资产减值迹象的规定，判断公司在建工程不存在减值迹象，故未计提减值准备。

（二）说明报告期内在建工程转入固定资产的具体情况，包括不限于项目内容、投资预算金额、开工与完工时间、累计投入金额、转入固定资产内容、依据、时间、金额等，并说明结转时点及金额是否准确，是否存在未及时转入固定资产的情形，转固新增的折旧费用对你公司当期及未来经营业绩产生的具体影响。

# 1、报告期内在建工程转入固定资产具体情况

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资预算金额</td><td rowspan=1 colspan=1>开工时间</td><td rowspan=1 colspan=1>预计完工时间</td><td rowspan=1 colspan=1>实际完工时间</td><td rowspan=1 colspan=1>累计投入金额</td><td rowspan=1 colspan=1>转入固定资产内容</td><td rowspan=1 colspan=1>转固依据</td><td rowspan=1 colspan=1>转固时间</td><td rowspan=1 colspan=1>转固金额</td></tr><tr><td rowspan=1 colspan=1>新建挤压型材生产厂房</td><td rowspan=1 colspan=1>4,200.00</td><td rowspan=1 colspan=1>2023年9月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>4,046.77</td><td rowspan=1 colspan=1>固定资产，房屋及建筑物</td><td rowspan=1 colspan=1>①主体建设工程及配套工程已完工；②建设工程达到预定可使用状态</td><td rowspan=1 colspan=1>2025年8月31日</td><td rowspan=1 colspan=1>4,046.77</td></tr><tr><td rowspan=1 colspan=1>在安装设备-挤压生产线</td><td rowspan=1 colspan=1>3,000.00</td><td rowspan=1 colspan=1>2023年9月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>2025年8月</td><td rowspan=1 colspan=1>2,786.81</td><td rowspan=2 colspan=1>固定资产_机器设备</td><td rowspan=2 colspan=1>①相关设备及其他配套设施已安装完毕；②设备经过调试可在-一段时间内保持正常稳定运行；③设备达到预定可使用状态。</td><td rowspan=1 colspan=1>2025年4-8月（产线设备陆续验收转固）</td><td rowspan=1 colspan=1>2,786.81</td></tr><tr><td rowspan=1 colspan=1>在安装设备-其它生产设备</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1,238.71</td><td rowspan=1 colspan=1>设备陆续验收转固</td><td rowspan=1 colspan=1>1,238.71</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>8,072.29</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>8,072.29</td></tr></table>

# 2、说明结转时点及金额是否准确，是否存在未及时转入固定资产的情形

（1）结转金额准确性：上述项目转固金额与项目累计实际投入金额一致，成本归集严格按照《企业会计准则》的规定执行，包含了项目建造、安装过程中发生的必要支出，结转金额准确。

（2）结转时点准确性与及时性：公司严格按照《企业会计准则第 4 号固定资产》的规定，以“达到预定可使用状态”作为在建工程转固的时点判断标准。其中，新建挤压型材生产厂房项目于2025 年8 月完成全部实体建造工作，已完成竣工验收，符合设计要求，具备投产使用条件，达到预定可使用状态；挤压生产线于 2025 年8月全部安装调试完成，达到预定可使用状态；其他生产设备分别于安装调试完成、达到预定可使用状态时进行转固。

# 3、转固新增折旧费用对公司当期及未来经营业绩的具体影响

（1）公司报告期转固资产折旧政策

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>折旧方法</td><td rowspan=1 colspan=1>折旧年限</td><td rowspan=1 colspan=1>残值率</td><td rowspan=1 colspan=1>年折旧率</td></tr><tr><td rowspan=1 colspan=1>新建挤压型材生产厂房</td><td rowspan=1 colspan=1>年限平均法</td><td rowspan=1 colspan=1>40年</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>2.38%</td></tr><tr><td rowspan=1 colspan=1>在安装设备-挤压生产线设备</td><td rowspan=1 colspan=1>年限平均法</td><td rowspan=1 colspan=1>20年</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>4.75%</td></tr><tr><td rowspan=1 colspan=1>在安装设备-其它生产设备</td><td rowspan=1 colspan=1>年限平均法</td><td rowspan=1 colspan=1>5-10年</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>9.50%-19.00%</td></tr></table>

# （2）对2025 年当期经营业绩的影响

上述转固资产2025 年新增折旧费用金额如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>年折旧额</td><td rowspan=1 colspan=1>2025 年折旧额</td></tr><tr><td rowspan=1 colspan=1>新建挤压型材生产厂房</td><td rowspan=1 colspan=1>93.47</td><td rowspan=1 colspan=1>30.48</td></tr><tr><td rowspan=1 colspan=1>在安装设备-挤压生产线设备</td><td rowspan=1 colspan=1>132.13</td><td rowspan=1 colspan=1>60.24</td></tr><tr><td rowspan=1 colspan=1>在安装设备-其它生产设备</td><td rowspan=1 colspan=1>122.48</td><td rowspan=1 colspan=1>41.99</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>348.08</td><td rowspan=1 colspan=1>132.71</td></tr></table>

2025 年当期转固资产累计新增折旧费用合计 132.71 万元，占公司 2025 年度归母净利润的比例为 $4 . 0 7 \%$ ，对公司当期经营业绩影响较小，不会导致公司盈亏性质发生变化。

（3）对未来经营业绩的影响

上述资产在正常使用年限内，未来完整会计年度每年将新增固定折旧费用合计 348.08 万元，但本次转固厂房及挤压生产线为公司在新能源行业的重点布局，投产后将有效提升自动化生产水平、扩大产能规模、优化产品结构，新增产能带来的营业收入及利润增长可逐步覆盖折旧增量影响，对公司长期持续经营及盈利能力无重大不利影响。

综上所述，公司固定资产转固时点及金额准确，不存在未及时转入固定资产的情形。转固新增的折旧费对公司当期及未来经营业绩无重大不利影响。

# 二、核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

1、取得公司在建工程、固定资产和无形资产的主要明细情况，了解主要在建工程项目的实施计划及最新进展；

2、获取管理层在资产负债表日就固定资产及在建工程是否存在可能发生减值迹象判断的说明，关注是否存在减值的情况；

3、实地查看在建工程及其进度，对在建工程、固定资产实施了监盘，查看在建工程的状况及是否已达到可使用状态；

4、检查 2025 年度在建工程减少的原始凭证，包括工程建设合同、发票、付款单据、验收文件等，核实在建工程转固时点、转固金额的准确性；

5、复核本年转固的固定资产折旧年限是否合理，按公司的固定资产政策重新测算折旧；评估转固新增的折旧费用对公司当期及未来经营业绩产生的影响。

# （二）核查意见

经核查，容诚所认为：

1、公司在建工程建设进展与计划相匹配，相关建设项目不存在减值迹象。

2、报告期内公司在建工程结转固定资产金额准确、结转及时，不存在未及时转入固定资产的情形。新增产能带来的营业收入及利润增长可逐步覆盖折旧增量影响，对公司长期持续经营及盈利能力无重大不利影响。

问题 6.你公司报告期末受限资产金额合计 0.91 亿元，包括固定资产 0.71 亿元和无形资产 0.19 亿元等，与期初相比变化较小。请你公司说明资产权利持续受限的具体情况，相关固定资产、无形资产受限是否对公司生产经营产生重大不利影响，截至目前资产受限情况进展及采取的应对措施，并说明是否及时履行信息披露义务。

请会计师事务所核查上述事项并发表明确意见。

# 一、公司回复

# 1、固定资产、无形资产持续受限的具体情况

本公司于 2024年12月26日与中国银行股份有限公司天津西青支行签订编号“津中银司授 R2024020 西青-D1”的最高额抵押合同，以坐落于滨海高新区华苑产业区（环外）海泰北道 5 号建筑面积 38,399.72 平方米的房产、51,147.00平方米的建设用地使用权作为抵押，担保最高债权额人民币 8,000.00 万元，截至 2025 年末已取得借款余额 4,000.00 万元。截至 2025 年 12 月 31 日，本公司用于抵押的房屋账面原值 7,064.18 万元，账面价值 2,122.51 万元，土地使用权账面原值 1,932.00 万元，账面价值 1,217.37 万元。

# 2、相关固定资产和无形资产受限是否对公司生产经营产生重大不利影响

上述受限资产所对应的银行借款是基于公司生产经营及业务发展所需，有利于促进公司资金融通和业务持续健康发展。公司目前经营状况良好，货币资金储备足以覆盖到期债务，能够按期偿还借款，不存在因违约导致资产被处置的风险。此外，虽然上述固定资产及无形资产处于抵押状态，但公司仍保留对资产的正常占有、使用和收益权，日常生产经营活动未受限制。因此，相关资产受限未对公司生产经营产生重大不利影响。

# 3、截至目前资产受限情况进展及采取的应对措施，并说明是否及时履行信息披露义务

截至回函日，由于上述银行授信合同尚未到期，相关固定资产和无形资产仍受限，但受限资产对公司生产经营无重大不利影响。公司目前自有资金充沛，且与银行保持良好合作，维持银行授信额度，预计能按期归还所有银行贷款，不存在抵押资产被处置的风险。

根据《深圳证券交易所创业板股票上市规则》相关规定，公司营业用主要资产被查封、扣押、冻结、抵押、质押或者报废超过总资产的 $30 \%$ ，应当及时披露相关情况及对公司的影响。报告期末公司受限资产账面价值合计 3,475.10万元，占期末经审计资产总额的 $4 . 0 1 \%$ ，公司受限资产未达到上述披露标准。因此，公司不存在未及时履行信息披露义务的情形。并且公司已在当期年报中充分披露了上述资产抵押情况，履行了及时、充分的信息披露义务，不存在应披露而未披露的情形。

# 二、核查程序及核查意见

# （一）核查程序

针对以上事项，容诚所执行的核查程序如下：

1. 获取并查阅公司报告期末的受限资产清单；

2. 查阅房产证、 土地使用权证等产权证书原件， 关注抵押、质押登记信息；

3. 获取并检查相关借款合同、抵押合同，核实受限资产对应的债务金额、债务期限、抵押物范围及担保责任范围，与征信报告相关内容进行核对检查，对短期借款执行函证程序；

4. 了解受限资产形成原因及评估对公司财务状况和经营状况的影响，检查受限资产在财务报表附注中的披露是否充分、准确。

# （二）核查意见

经核查，容诚所认为：

截至报告期末，公司受限资产系因贷款抵押形成，主要资产均由公司正常使用，相关固定资产和无形资产受限不会对公司日常生产经营活动产生重大不利影响，公司不存在未及时履行信息披露义务的情形。

问题 7.你公司报告期内有 6 人次董事、高管离职，占比超过全体董事、高管人数的三分之一，包括董事长、总经理国占昌，董事王发、高建，副总经理刘建、刘国才。请说明你公司报告期内董高变动占比较高的具体情况及原因，是否会对公司治理和正常生产经营产生不利影响，公司内部治理、财务管理及信息披露事务管理等方面的内部控制是否存在问题。

# 公司回复：

2025 年 8 月公司控制权发生变更，控股股东变更为黄山开投领盾创业投资有限公司，实际控制人变更为黄山市人民政府国有资产监督管理委员会，经股东会决定，董事会提前进行换届选举，原董事国占昌、高建、王发、郭宝季 4人离任董事职务，公司新一届董事会成员变更为凌沧桑、张旭、乔乔、王清、刘洋。2025 年 10 月，国占昌辞任公司总经理职务，刘建、刘国才辞任公司副总经理职务，王哲辞任公司董事会秘书职务。2025 年 10 月 21 日，公司召开董事会，同意董事长凌沧桑代为履行公司总经理职责，并聘任李然为公司副总经理、董事会秘书。公司高级管理人员变更为凌沧桑(代行总经理职责)、王发、王哲、李然。本次董事会换届及董事、高管人员变动系公司控制权发生变更后，根据公司战略规划及运营情况做出的合理安排，上述人员已做好工作交接，除郭宝季以外，其他离任董事、高级管理人员仍在公司任职，公司董事、高级管理人员变更不会对公司治理和正常生产经营产生不利影响。

公司已依法制定《公司章程》《董事会议事规则》《股东会议事规则》《总经理工作细则》《关联交易管理制度》《对外投资管理制度》《内部审计管理制度》等全套治理制度，治理架构健全、权责清晰、运作规范，严格按照相关规定规范召集召开股东会、董事会等会议，决策程序合法合规，会议记录等文件完整存档；建立了《独立董事工作制度》，保障独立董事勤勉尽责履职，充分发挥监督作用。财务管理方面，公司已建立完善的会计核算、资金管理、费用审批、财务报告编制等财务内控制度，实行财务岗位不相容职务分离，内审部门定期开展财务核查，确保财务管理规范合规。公司已制定《信息披露管理制度》《重大信息内部报告制度》等信披制度，严格遵循真实、准确、完整、及时、公平原则履行信息披露义务，建立了重大信息内部报告、审核及披露程序，公告编制、审核、披露流程闭环管控，内幕信息登记、保密管理规范，不存在内幕信息泄露的情形。公司已建立健全有效的内部治理、财务管理及信息披露事务管理内部控制体系，各项制度得到有效执行，不存在内部控制重大缺陷，亦不存在相关违规及治理失控问题。

问题 8.你公司于 2026 年 2 月 26 日披露发行股份及支付现金购买资产的预案，拟向童小平等 10 名交易对方购买其合计持有的德恒装备 $5 1 \%$ 的股权，同时向包括不超过 35 名特定对象发行股份募集配套资金。请你公司说明截至回函日就该事项开展了哪些方面的工作，相关事项的进展情况及后续推进计划，是否存在实质性障碍，如是，请及时提示风险。

公司回复：

# 一、本次交易的主要工作

因筹划本次交易，经申请，公司股票自 2026 年 2 月 5 日开市起开始停牌，具体内容详见公司于 2026 年 2 月 4 日披露的《关于筹划发行股份及支付现金购买资产并募集配套资金暨关联交易事项的停牌公告》（公告编号：2026-001）。停牌期间，公司按照规定及时披露了停牌进展公告，具体内容详见公司于 2026年 2 月 11 日披露的《关于筹划发行股份及支付现金购买资产并募集配套资金暨关联交易事项的停牌进展公告》（公告编号：2026-002）。

2026 年 2 月 26 日，公司召开第七届董事会第五次会议，审议通过了《关于公司发行股份及支付现金购买资产并募集配套资金暨关联交易方案的议案》等相关议案，具体内容详见公司于 2026 年 2 月 26 日于巨潮资讯网（http：//www.cninfo.com.cn）上披露的相关公告。同时，经申请，公司股票（证券简称：锐新科技，证券代码：300828）自 2026 年 2 月 27 日开市起复牌。

2026 年 3 月 26 日，公司披露《关于发行股份及支付现金购买资产并募集配套资金暨关联交易的进展公告》（编号：2026-008）。

2026 年 4 月 24 日，公司披露《关于发行股份及支付现金购买资产并募集配套资金暨关联交易事项的进展公告》（编号：2026-026）。

# 二、本次交易的进展及后续推进计划

截至本回复披露日，本次交易涉及各方正在积极、有序推进本次重组的各项工作，近期进展如下：

公司及公司所聘中介机构在交易各方配合下，本次重组涉及的尽职调查、审计、评估现场工作正在有序开展，所聘中介机构正在起草、形成标的公司审计报告、评估报告等重要文件；本次交易涉及各方就本次重组交易方案的细节问题进行商讨、谈判。

公司将在相关工作正式完成后，再次召开董事会审议本次交易的相关事项，披露正式方案，并按照相关法律法规的规定履行有关的后续审批程序及信息披露义务。

# 三、风险提示

截至本问询函回复之日，除本次交易预案中已披露的风险因素外，公司尚未发现可能导致公司董事会或者交易对方撤销、中止本次交易方案或者对本次交易方案作出实质性变更的相关事项，本次交易相关工作正在持续推进过程中。

截至本问询函回复之日，本次交易相关工作正在积极推进中，本次交易相关方尚需就交易方案进行进一步磋商。本次交易尚需公司董事会再次审议及公司股东会审议通过，并经国有资产监督管理机构批准、深圳证券交易所审核同意及中国证监会同意注册后方可正式实施，本次交易能否取得上述批准或注册，以及最终取得批准或注册的时间存在不确定性。

公司将继续推进本次交易的相关工作，并严格按照相关法律法规的规定和要求履行信息披露义务。公司有关信息以公司在指定信息披露媒体发布的公告为准。敬请广大投资者注意投资风险。

特此公告。