# 金健米业股份有限公司关于对湖南证监局行政监管措施决定相关事项的整改报告

本公司董事会及全体董事保证本公告内容不存在任何虚假记载、误导性陈述或者重大遗漏，并对其内容的真实性、准确性和完整性承担法律责任。

金健米业股份有限公司（以下简称“上市公司”“公司”“金健米业”）于2026年2月4日收到中国证券监督管理委员会湖南监管局《关于对金健米业股份有限公司采取责令改正并对相关责任人员采取出具警示函行政监管措施的决定》（〔2026〕5号）（以下统称“《决定书》”）。具体详见公司于 2026 年 2 月 5 日登载于上海证券交易所网站（www.sse.com.cn）上的《金健米业股份有限公司关于公司及有关责任人收到湖南证监局行政监管措施决定书的公告》（编号：临2026-08号）。

收到《决定书》后，公司对此高度重视，及时向全体董事、高级管理人员进行传达，本着严格自律、规范运作的态度，结合公司实际情况，积极落实整改工作，针对《决定书》中指出的问题，严格按照相关法律法规和规范性文件的要求，深入分析问题原因，明确责任部门，制定整改措施，形成整改报告。公司于2026 年 3 月 3 日召开第十届董事会第三次会议，审议通过了《关于对湖南证监局行政监管措施决定相关事项的整改报告》。现将相关情况公告如下：

## 一、存在的问题

2020 年至2022 年，公司原子公司金健农产品（营口）有限公司（以下简称“金健营口公司”）开展的部分贸易业务无实物流转且缺乏商业实质，部分收入确认不符合会计准则规定，共导致公司 2020年至 2022 年度虚增营业收入分别为 22,761.39 万元、26,556.59 万元、9,295.60 万元，分别占当年营业收入的 3.98%、3.96%、1.45%；虚增营业成本分别为 22,750.95 万元、26,525.56 万元、9,288.44 万元，分别占当年营业成本的3.99%、3.95%、1.43%；虚增利润总额分别为 10.43 万元、31.04 万元、7.16 万元，分别占当年利润总额的0.31%、-1.19%、-0.16%。

上述行为违反了《上市公司信息披露管理办法》（证监会令第182号）第三条第一款规定。公司时任董事长全臻、时任总裁、代董事长陈伟、时任副总裁（分管贸易业务）吴飞、时任财务总监马先明对上述违法违规行为负有主要责任，违反了《上市公司信息披露管理办法》第四条、第五十一条第一款、第三款规定。

## 二、整改措施

## （一）聚焦核心主责主业，重定贸易业务功能

2024 年，公司间接控股股东湖南农业发展投资集团有限责任公司为兑现 2022 年 7 月在《详式权益变动报告书》中“于2024 年6月30 日前解决与上市公司之间同业竞争”的承诺，以及支持上市公司聚焦粮油主责主业，金健米业与控股股东湖南粮食集团有限责任公司实施了资产置换，上市公司置入了湖南裕湘食品有限公司和中南粮油食品科学研究院有限公司，将从事饲料贸易业务为主的3家贸易公司(含金健农产品（营口）有限公司)置出，公司进一步聚焦粮油主业，产业结构得到进一步优化。自此，公司现有贸易业务聚焦粮油食品加工主责主业，围绕大米、油脂、面制品等食品加工业务板块的原材料采购需求开展，起到配套保障的服务作用。

【整改进度】：已完成。

## （二）强化治理主体协同管控，构建长效合规管理机制

公司充分发挥党委会、董事会、审计委员会、独立董事各治理主体职能，形成统筹推进、分级负责、全程监督的整改管控体系。

党委会牵头成立贸易业务整改专项小组，统筹整改方向，将整改成效与子公司绩效考核、履职评价挂钩，通过专项督查等方式压实政治责任，推动整改要求穿透至子公司。

董事会建立完善风控合规管理的相关内控制度体系，从制度层面加强对业务的全流程制度管控，强化决策监督。公司经营管理层按季度分析贸易业务核心指标及风险情况，同时部分子公司配齐配强风控专职人员，夯实合规人力资源保障。

董事会审计委员会通过内部审计职能部门开展全面风险自查，聚焦贸易业务上下游关联交易、业务背景等关键风险建立问题清单与整改台账，明确整改责任、时限及标准，定期跟踪督办，整改结果与绩效考核挂钩。

独立董事重点跟进自查整改及内控落实情况，结合财务、法律等专业优势，在货物存放和管理、应收账款风险预警等方面提出专业建议，确保整改不走形式、取得实效。

【整改进度】：已完成，将持续深化落实。

## （三）开展全面风险排查，严控业务环节全程

为全面规范贸易业务流程和资金运作流程，有效防范和管理贸易运作风险，公司内部审计职能部门对从事贸易业务的子公司开展风险贸易业务专项检查，全面自查贸易业务合规风险；财务管理职能部门对贸易客户的履约保证金比例、资金结算支付、收入确认方式等关键环节从严督导，坚决保障粮油大宗采购业务合规开展；从事贸易业务的子公司在业务前期严格执行“三关三核查”，即把牢业务模式关、客户准入关、合同风险关，充分核查商业实质、主体关联关系、合同异常条款；在业务中期严格执行“三流三核查”，即重点核查货物流是否实质发生、发票流是否充分对应、资金流是否违规或异常；在业务后期严格基于业务实质按照会计准则的要求对收入进行正确审慎确认和计量。

【整改进度】：已完成，将持续深化落实。

## （四）更正前期会计差错，提升财务信息质量

公司因2020 年度至2022 年度财务报告中存在的前期会计差错，对相关财务报表进行了追溯重述。公司已就上述会计差错事项与会计师事务所进行沟通，并形成一致意见。追溯调整对各期间合并财务报表相关科目的影响如下：

1.上述前期差错更正事项对2020 年度合并财务报表项目影响

## （1）合并资产负债表

单位：元，下同

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>资本公积</td><td rowspan=1 colspan=1>469,360,956.95</td><td rowspan=1 colspan=1>104,337. 04</td><td rowspan=1 colspan=1>469,465,293.99</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-388,684,982. 70</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>-388, 789,319. 74</td></tr></table>

（2）合并利润表
<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>5,715,996,407. 78</td><td rowspan=1 colspan=1>-227,613, 877. 04</td><td rowspan=1 colspan=1>5,488,382,530. 74</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>5, 443, 964,967. 18</td><td rowspan=1 colspan=1>-227,509,540.00</td><td rowspan=1 colspan=1>5,216,455,427. 18</td></tr><tr><td rowspan=1 colspan=1>营业利润</td><td rowspan=1 colspan=1>33,806,857. 84</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>33,702,520.80</td></tr><tr><td rowspan=1 colspan=1>利润总额</td><td rowspan=1 colspan=1>33,920,308. 41</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>33,815,971. 37</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>22, 746,985. 18</td><td rowspan=1 colspan=1>-104, 337. 04</td><td rowspan=1 colspan=1>22,642, 648.14</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>21, 061,399. 71</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>20,957,062.67</td></tr><tr><td rowspan=1 colspan=1>综合收益总额</td><td rowspan=1 colspan=1>22, 708,746. 13</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>22,604,409.09</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的综合收益总额</td><td rowspan=1 colspan=1>21,023,160.66</td><td rowspan=1 colspan=1>-104,337. 04</td><td rowspan=1 colspan=1>20,918,823.62</td></tr></table>

## （3）合并现金流量表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>销售商品、提供劳务收到的现金</td><td rowspan=1 colspan=1>6,332,777,100. 29</td><td rowspan=1 colspan=1>-150,901,701. 67</td><td rowspan=1 colspan=1>6,181,875,398. 62</td></tr><tr><td rowspan=1 colspan=1>收到其他与经营活动有关的现金</td><td rowspan=1 colspan=1>69,144,595.73</td><td rowspan=1 colspan=1>150,901,701.67</td><td rowspan=1 colspan=1>220,046,297.40</td></tr><tr><td rowspan=1 colspan=1>购买商品、接受劳务支付的现金</td><td rowspan=1 colspan=1>6,217,251,965. 63</td><td rowspan=1 colspan=1>-150,787,974. 30</td><td rowspan=1 colspan=1>6,066,463,991. 33</td></tr><tr><td rowspan=1 colspan=1>支付其他与经营活动有关的现金</td><td rowspan=1 colspan=1>160,915,015. 11</td><td rowspan=1 colspan=1>150,787,974.30</td><td rowspan=1 colspan=1>311, 702, 989.41</td></tr></table>

2.上述前期差错更正事项对2021 年度合并财务报表项目影响

## （1）合并资产负债表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>资本公积</td><td rowspan=1 colspan=1>469,360,956.95</td><td rowspan=1 colspan=1>414,691. 54</td><td rowspan=1 colspan=1>469,775,648.49</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-411, 953, 994. 18</td><td rowspan=1 colspan=1>-414, 691. 54</td><td rowspan=1 colspan=1>-412, 368,685. 72</td></tr></table>

## （2）合并利润表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>6,706,482,232.32</td><td rowspan=1 colspan=1>-265,565,906.18</td><td rowspan=1 colspan=1>6,440,916,326.14</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>6,445,570,507. 18</td><td rowspan=1 colspan=1>-265,255,551.68</td><td rowspan=1 colspan=1>6,180,314,955.50</td></tr><tr><td rowspan=1 colspan=1>营业利润</td><td rowspan=1 colspan=1>-25,589,789. 50</td><td rowspan=1 colspan=1>-310,354. 50</td><td rowspan=1 colspan=1>-25,900,144.00</td></tr><tr><td rowspan=1 colspan=1>利润总额</td><td rowspan=1 colspan=1>-25,976,997. 85</td><td rowspan=1 colspan=1>-310,354. 50</td><td rowspan=1 colspan=1>-26,287,352. 35</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>-38,508,486.81</td><td rowspan=1 colspan=1>-310,354. 50</td><td rowspan=1 colspan=1>-38,818,841. 31</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>-23,269,011. 48</td><td rowspan=1 colspan=1>-310,354. 50</td><td rowspan=1 colspan=1>-23,579,365.98</td></tr><tr><td rowspan=1 colspan=1>综合收益总额</td><td rowspan=1 colspan=1>-38,563,132.38</td><td rowspan=1 colspan=1>-310,354. 50</td><td rowspan=1 colspan=1>-38,873,486.88</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的综合收益总额</td><td rowspan=1 colspan=1>-23,323,657. 05</td><td rowspan=1 colspan=1>-310,354.50</td><td rowspan=1 colspan=1>-23,634,011. 55</td></tr></table>

## （3）合并现金流量表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>销售商品、提供劳务收到的现金</td><td rowspan=1 colspan=1>7, 321,344,344. 37</td><td rowspan=1 colspan=1>-289, 466,837. 74</td><td rowspan=1 colspan=1>7, 031,877, 506. 63</td></tr><tr><td rowspan=1 colspan=1>收到其他与经营活动有关的现金</td><td rowspan=1 colspan=1>75,879, 970. 11</td><td rowspan=1 colspan=1>289,466,837.74</td><td rowspan=1 colspan=1>365,346,807. 85</td></tr><tr><td rowspan=1 colspan=1>购买商品、接受劳务支付的现金</td><td rowspan=1 colspan=1>6,990,949,696.10</td><td rowspan=1 colspan=1>-289,128,551.33</td><td rowspan=1 colspan=1>6,701,821,144. 77</td></tr><tr><td rowspan=1 colspan=1>支付其他与经营活动有关的现金</td><td rowspan=1 colspan=1>150,718,606.97</td><td rowspan=1 colspan=1>289,128,551.33</td><td rowspan=1 colspan=1>439, 847,158. 30</td></tr></table>

## 3.上述前期差错更正事项对2022 年度合并财务报表项目影响

## （1）合并资产负债表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>资本公积</td><td rowspan=1 colspan=1>469,360,956.95</td><td rowspan=1 colspan=1>486,246.34</td><td rowspan=1 colspan=1>469,847,203.29</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-462, 773, 924. 53</td><td rowspan=1 colspan=1>-486,246.34</td><td rowspan=1 colspan=1>-463,260,170. 87</td></tr></table>

## （2）合并利润表

<table><tr><td colspan="1" rowspan="1">报表项目</td><td colspan="1" rowspan="1">调整前金额</td><td colspan="1" rowspan="1">调整金额</td><td colspan="1" rowspan="1">调整后金额</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">6,412,071,601. 89</td><td colspan="1" rowspan="1">-92,955,963.30</td><td colspan="1" rowspan="1">6,319,115,638. 59</td></tr><tr><td colspan="1" rowspan="1">营业成本</td><td colspan="1" rowspan="1">6,225,085,454.84</td><td colspan="1" rowspan="1">-92,884,408.50</td><td colspan="1" rowspan="1">6,132,201,046. 34</td></tr><tr><td colspan="1" rowspan="1">营业利润</td><td colspan="1" rowspan="1">-44,467,696.97</td><td colspan="1" rowspan="1">-71,554.80</td><td colspan="1" rowspan="1">-44, 539,251. 77</td></tr><tr><td colspan="1" rowspan="1">利润总额</td><td colspan="1" rowspan="1">-44,247,277. 84</td><td colspan="1" rowspan="1">-71,554.80</td><td colspan="1" rowspan="1">-44,318,832. 64</td></tr><tr><td colspan="1" rowspan="1">净利润</td><td colspan="1" rowspan="1">-50,389,656.27</td><td colspan="1" rowspan="1">-71,554.80</td><td colspan="1" rowspan="1">-50, 461, 211. 07</td></tr><tr><td colspan="1" rowspan="1">归属于母公司股东的净利润</td><td colspan="1" rowspan="1">-50,819,930. 35</td><td colspan="1" rowspan="1">-71,554.80</td><td colspan="1" rowspan="1">-50,891,485. 15</td></tr><tr><td colspan="1" rowspan="1">综合收益总额</td><td colspan="1" rowspan="1">-50,368,636.47</td><td colspan="1" rowspan="1">-71,554.80</td><td colspan="1" rowspan="1">-50, 440,191. 27</td></tr><tr><td colspan="1" rowspan="1">归属于母公司股东的综合收益总额</td><td colspan="1" rowspan="1">-50,798,910. 55</td><td colspan="1" rowspan="1">-71, 554.80</td><td colspan="1" rowspan="1">-50,870,465. 35</td></tr></table>

（3）合并现金流量表
<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>销售商品、提供劳务收到的现金</td><td rowspan=1 colspan=1>6,980,817, 573. 50</td><td rowspan=1 colspan=1>-101,322,000.00</td><td rowspan=1 colspan=1>6,879,495,573. 50</td></tr><tr><td rowspan=1 colspan=1>收到其他与经营活动有关的现金</td><td rowspan=1 colspan=1>81,238,385. 62</td><td rowspan=1 colspan=1>101,322,000.00</td><td rowspan=1 colspan=1>182,560,385. 62</td></tr><tr><td rowspan=1 colspan=1>购买商品、接受劳务支付的现金</td><td rowspan=1 colspan=1>6,502,718,498.22</td><td rowspan=1 colspan=1>-101, 244,005. 27</td><td rowspan=1 colspan=1>6,401,474,492.95</td></tr><tr><td rowspan=1 colspan=1>支付其他与经营活动有关的现金</td><td rowspan=1 colspan=1>163,247,092.59</td><td rowspan=1 colspan=1>101,244,005.27</td><td rowspan=1 colspan=1>264,491,097. 86</td></tr></table>

## 4.上述前期差错更正事项对2023 年度合并财务报表项目影响

## （1）合并资产负债表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>资本公积</td><td rowspan=1 colspan=1>469,360,956.95</td><td rowspan=1 colspan=1>486,246. 34</td><td rowspan=1 colspan=1>469,847,203.29</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-434, 115, 244. 11</td><td rowspan=1 colspan=1>-486,246. 34</td><td rowspan=1 colspan=1>-434,601, 490. 45</td></tr></table>

5.上述前期差错更正事项对2024 年度合并财务报表项目影响

## （1）合并资产负债表

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>调整前金额</td><td rowspan=1 colspan=1>调整金额</td><td rowspan=1 colspan=1>调整后金额</td></tr><tr><td rowspan=1 colspan=1>资本公积</td><td rowspan=1 colspan=1>485,357,002.49</td><td rowspan=1 colspan=1>486,246.34</td><td rowspan=1 colspan=1>485,843,248.83</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-478, 017,247. 80</td><td rowspan=1 colspan=1>-486,246. 34</td><td rowspan=1 colspan=1>-478, 503,494. 14</td></tr></table>

【整改进度】：已完成。

## （五）健全内控制度体系，压实决策监督责任

1.完善制度体系。公司已先后制定发布《公司风控合规管理制度》《公司合规管理体系建设方案》《公司贸易合规工作规范制度（试行）》《公司合规管理三张清单（试行）》等相关制度方案，从体系建设到核心制度，再到业务细则层面将风险防控贯穿于企业经营全过程。《公司贸易合规工作规范制度（试行）》全面规范了贸易业务流程和资金运作流程，并通过制度中的“贸易业务开展负面清单”“贸易业务行为负面清单”“贸易业务风险防控清单”，对禁止的贸易业务范围、禁止的贸易行为、贸易风险防范进行了明确规范和界定。

2.压实层级责任。公司按照权责对等原则，对贸易合规实行分级管理，明确管理层、部门层、执行层在贸易业务中的核心职责，层层压实决策责任、监督责任、业务责任。管理层统筹贸易业务决策管理，严把业务合规性与风险可控性；部门层履行日常监督管理职责，强化业务流程审核、风险排查与过程管控；执行层严格落实贸易合规制度要求，规范开展业务操作，确保各层级各主体履职到位、责任到人，形成决策、执行、监督相互制约。

【整改进度】：已完成，将持续完善。

## （六）加强全员培训宣教，强化合规意识能力

公司定期组织公司董事、高级管理人员和相关业务人员开展上市公司规范运作相关的法律法规和公司内控制度宣贯、市场监管案例学习、业务专题培训，严格树牢全员依法合规经营意识，切实提升全员规范运作能力。

同时，针对本次事项，公司通过内部 OA 发布案例专项通报，此举旨在以案为鉴，进一步督促全员强化合规意识，严守监管红线，切实防范同类风险，筑牢经营安全防线。

【整改进度】：已完成，将持续强化。

## 三、责任追究

按照《上市公司治理准则》（2025年修订）及公司内部管理制度的相关规定，公司已严格落实本次事项的责任处理。公司已对《决定书》中的相关事项及时任责任人存在问题在公司进行内部通报，督促全体员工以此为戒，吸取教训，持续提高规范运作意识和能力，合规合法地开展相关业务。同时根据财务报表已追溯调整情况重新核定公司时任有关责任人员在相应年度的应发绩效薪酬，并采取措施对在公司领取薪酬的时任责任人进行部分绩效薪酬的追索。对于公司原全资子公司金健农产品（营口）有限公司的时任相关责任人员，公司间接控股股东及所属管理单位对4名时任责任人员进行了组织处理，并分别扣减追回个人年度的部分绩效薪酬。

## 四、整改情况总结

针对《决定书》所指出的问题，公司现已整改完毕并将持续规范执行。本次湖南证监局采取的责令改正措施对公司进一步提升公司治理、信息披露、财务管理等方面的水平起到了重要作用。公司将以本次整改为契机，深刻汲取教训，不断加强全体相关人员对法律法规和公司内控管理制度的学习，强化子公司和业务流程的规范管理，持续提高规范运作意识，坚持提升公司信息披露质量，切实维护公司及全体股东利益，促进公司持续、稳健发展。

特此公告。

金健米业股份有限公司董事会

2026 年 3 月 3 日