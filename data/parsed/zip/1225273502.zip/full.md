股票简称：永辉超市

股票代码：601933

# 关于永辉超市股份有限公司

# 申请向特定对象发行股票的审核问询函的

保荐人（主承销商）

中信证券股份有限公司CITIC Securities Company Limited

（广东省深圳市福田区中心三路 8号卓越时代广场（二期）北座）

二〇二六年四月

7-1-1

## 上海证券交易所：

贵所于 2025 年 11 月 6 日印发的《关于永辉超市股份有限公司向特定对象发行股票申请文件的审核问询函》（上证上审（再融资）〔2025〕353 号）（以下简称“审核问询函”）已收悉。永辉超市股份有限公司（以下简称“永辉超市”、“公司”、“发行人”或“申请人”）与中信证券股份有限公司（以下简称“保荐机构”或“保荐人”）、上海市通力律师事务所（以下简称“发行人律师”）、安永华明会计师事务所（特殊普通合伙）（以下简称“会计师”、“发行人会计师”）等相关方对审核问询函所列问题进行了逐项落实、核查。

现就本次审核问询函提出的问题书面回复如下，请予审核。

如无特别说明，本审核问询函回复所使用的简称与募集说明书中的释义相同；以下回复中若出现各分项数值之和与总数尾数不符的情况，均为四舍五入原因造成。

本审核问询函回复中的字体格式说明如下：

<table><tr><td rowspan=1 colspan=1>黑体</td><td rowspan=1 colspan=1>审核问询函所列问题</td></tr><tr><td rowspan=1 colspan=1>宋体</td><td rowspan=1 colspan=1>对审核问询函所列问题的回复</td></tr><tr><td rowspan=1 colspan=1>楷体 (加粗)</td><td rowspan=1 colspan=1>涉及对募集说明书等申请文件的修订、补充</td></tr></table>

## 目 录

问题 1 关于募投项目  
问题 2 关于经营情况 31  
问题 3 其他 . 68

## 问题 1 关于募投项目

根据申报材料，1）本次向特定对象发行股票募集资金总额不超过311,386.04 万元，扣除发行费用后将投向“门店升级改造项目”“物流仓储升级改造项目”和补充流动资金或偿还银行贷款。2）门店升级改造项目内部收益率（税后）为 21.57%，投资回收期为 4.84年。

请发行人说明：（1）结合行业发展及市场需求、同行业公司的升级改造、公司前期门店关闭情况、本次拟升级改造门店选取标准、升级改造内容及预测效益等，说明“门店升级改造项目”实施的必要性；（2）结合现有物流仓储中心的运行情况、拟升级改造内容及同行业可比公司相应投入情况等，说明“物流仓储升级改造项目”是否与门店实际需求相匹配,该项目实施的可行性；（3）本次募投项目投资构成的测算依据及设备购置价格的公允性，资本性支出的构成及占比情况，并结合货币资金余额、日常经营资金积累、资金缺口等情况说明本次融资规模的合理性；（4）结合本次募投项目客单价、毛利率等关键指标的测算依据，与公司和同行业公司可比项目相关指标的比较情况，说明效益测算是否谨慎、合理。

请保荐机构核查并发表明确意见。

回复：

一、结合行业发展及市场需求、同行业公司的升级改造、公司前期门店关闭情况、本次拟升级改造门店选取标准、升级改造内容及预测效益等，说明“门店升级改造项目”实施的必要性

（一）行业发展及市场需求情况

## 1、国家政策的鼓励支持为项目实施奠定良好基础

公司的主营业务为零售业。根据国家统计局发布的《国民经济行业分类与代码》（GB/T4754-2017），公司所处行业属于“批发和零售业（F）”中的“零售业（F52）”中的“综合零售（F521）。本次募投项目包括“门店升级改造项目”和“物流仓储升级改造项目”，其中“门店升级改造项目”所处行业属于“零售业（F52）”下的“综合零售（F521），“物流仓储升级改造项目”所处的行业属于“交通运输、仓储和邮政业（G）”中的“装卸搬运和仓储业（G59）”。

根据《产业结构调整指导目录（2024 年本）》，本次募投项目“门店升级改造项目”属于“第一类 鼓励类”之“三十三 商贸服务业”，本次募投项目“物流仓储升级改造项目”属于“第一类 鼓励类”之“二十九 现代物流业”，因此本次募投项目均为鼓励类项目。

近年来党中央、国务院为大力提振消费，全方位扩大国内需求，发布了一系列政策制度，促进零售业的转型升级，推动零售业的高质量发展。2025年3月，中共中央办公厅、国务院印发《提振消费专项行动方案》，提出以高质量供给创造有效需求，以优化消费环境增强消费意愿，促进生活服务消费，强化消费品牌引领；2024 年 11 月，商务部、发改委、住建部等 7 部联合颁布《关于印发<零售业创新提升工程实施方案>的通知》，鼓励优化内外环境、增设人性化服务设施，推动品质化供给，优化商品和服务体验，推动多元创新，支持搭载便民服务项目，提升客流、平效和场地利用率；2024 年 11 月，商务部、发改委、工信部等 9 部联合印发《关于完善现代商贸流通体系推动批发零售业高质量发展的行动计划》，提出推动零售业创新提升，赋能传统零售业态，改造传统零售门店，以提高市场分析、进销存管理水平，并拓展时尚化、主题化、智慧化消费场景，提高商业设施运营效能。2024 年 7 月，国务院印发《国务院关于促进服务消费高质量发展的意见》，提出着力提升服务品质、丰富消费场景、优化消费环境，以创新激发服务消费内生动能，培育服务消费新增长点，为经济高质量发展提供有力支撑。2024 年 6 月，国家发改委、商务部等六部门联合印发《关于打造消费新场景培育消费新增长点的措施》，提出围绕居民吃穿住用行等传统消费和服务消费，培育一批带动性广、显示度高的消费新场景，推广一批特色鲜明、市场引领突出的典型案例，支持一批创新能力强、成长性好的消费端领军企业加快发展，推动消费新业态、新模式、新产品不断涌现，不断激发消费市场活力和企业潜能。2024年 4月，国务院印发《推动大规模设备更新和消费品以旧换新行动方案》，提出推动高质量耐用消费品更多进入居民生活，畅通资源循环利用链条，大幅提高国民经济循环质量和水平，充分发挥市场配置资源的决定性作用，结合各类设备和消费品更新换代差异化需求，依靠市场提供多样化供给和服务，更好发挥政府作用，加大财税、金融、投资等政策支持力度。

本项目所属行业属于国家政策大力支持的行业，不属于落后或淘汰类产业，本项目的实施旨在为消费者提供更具品质化的商品和更优质的服务，是公司积极响应国家推动高质量供给、改造和提升传统零售业态号召的重要举措。

## 2、我国零售业与连锁超市行业市场规模稳定增长，传统零售业亟需转型升级

近年来，受国家政策引导、国民经济增长、消费结构升级等多重因素影响，我国消费市场持续向好发展。根据国家统计局数据，我国社会消费品零售总额整体呈现稳步增长态势，从 2020 年的 39.05 万亿元增长至 2024 年的 48.33 万亿元，年均复合增长率为 5.47%。其中，连锁超市是我国重要的商品流通渠道，2023年我国连锁超市零售额为 7,346 亿元，同比增长 6.7%。伴随国内经济稳定增长，叠加国家刺激消费的政策措施持续落地，未来连锁超市行业将持续向好发展，到2027 年零售额有望达到 7,950 亿元。由此可见，伴随国内消费市场的不断发展，我国零售业与连锁超市行业市场规模有望维持稳定增长态势。

与此同时，为满足消费者日趋多元化、个性化、便捷化的消费需求，我国零售行业迈入转型发展阶段，零售模式持续创新、消费场景更加丰富、购物体验不断提升。然而，目前传统连锁超市存在经营模式落后，商品更新换代速度慢、运营成本高等诸多问题，难以适应零售行业快速增长及居民消费升级需求，叠加便利店、会员店、折扣店以及即时零售等新兴零售业态的快速兴起，对传统零售业造成一定冲击。因此，在政策支持、消费者需求变化、市场竞争加剧等多方面因素影响下，传统零售行业亟需推进转型升级。

综上，我国零售业与连锁超市行业市场规模保持增长，同时消费者逐渐强调高产品品质和多样化线下服务体验，因此，公司通过本次门店升级改造项目，可以更好满足顾客体验需求和质价比需求，力图打造“国民超市、品质永辉”的品质零售新范式，引领零售行业发展趋势。

## （二）同行业公司升级改造情况

当前，传统超市行业存在经营模式落后、商品更新换代速度慢、运营成本高等问题，难以适应零售行业快速增长及居民消费升级需求，行业内企业积极推进门店空间设计进行优化，改善经营环境；同时通过增加休闲、便利等配套设施，增强消费舒适性和体验感，满足消费者的体验需求和服务需求。

2024 年以来，永辉超市、华润万家、联华超市、银座超市等知名传统超市品牌纷纷开启自主调改布局，并取得初步成效。根据中国连锁经营协会《2025年中国连锁超市发展情况概览》数据，2025 年经调改后，连锁超市销售收入增长超过 50%的超市占比为5%，销售收入增长在 30%-50%（含）的超市占比 6%、销售收入增长在 20%-30%（含）的超市占比为 10%，销售收入增长在 10%-20%（含）的超市占比为 18%，销售收入增长在 0%-10%（含）的超市占比为 34%。

2025年连锁超市调改后的收入增长情况  
![](images/7adc1179b79f6b4388413c7b3a9b03f37acd23ab6fc3e3938f5c95a431e6053b.jpg)  
数据来源：CCFA《2025 年中国连锁超市发展情况概览》

同行业上市公司中，步步高和家家悦也相应进行了门店调改，并取得了较好的成效。其中，步步高 2025 年半年度报告披露：“2025 年上半年，公司继续深入学习胖东来，超市业态通过逐步关闭低效门店、调改潜力门店，开展自有品牌战略，整体经营业绩较同期改善。报告期内，公司实现营业收入 21.29 亿元，同比增长 24.45%；归属于上市公司股东的净利润 2.01 亿元，同比增长 357.71%”；家家悦 2025 年年度报告披露，“分类推进门店调改，门店调改工作精准落地，报告期完成大改门店 44 处，调改后门店销售和利润均较快增长，显著提升卖场品质与顾客吸引力，为公司业绩提升提供了有力支撑”；通过加快重点门店的调改升级，家家悦提高了门店整体的运营质量和效率，使得公司归母净利润增长 52.09%。

## （三）公司前期门店关闭情况及本次拟升级改造门店选取标准

2024 年下半年以来，公司积极推进战略转型，持续关闭尾部亏损门店，2025年公司共关闭门店381家。公司在选择关闭的门店时，主要考虑门店的历史经营数据及门店所处商圈，首先是历史上持续亏损且亏损迹象在过去几年没有改善的门店，其次是门店所处的社区老化、周边物业配套较落后、客流量较低的门店，第三是门店区位较远，物流成本较高的门店，上述门店若公司判断未来实现盈利的可能性较低时会选择闭店。

本次募投项目拟升级改造门店的选取主要考虑如下因素：一是该门店的商圈是否符合未来重点聚焦的新中产客群，比如位于客流量较大的商业综合体内的门店或新中产人群较为聚集的高品质社区门店；二是门店的物理条件和物业条件，包括停车位是否充足、楼层数、动线设计和整体空间布局是否直接影响顾客的体验感。三是调改团队的运营能力，门店所在城市团队及员工需要有较强的基础运营能力或者可以通过培训得到提升，能够达到调改门店要求的运营标准水平。

此外，公司在选择拟升级改造门店时，一方面选择头部店，即当前表现最好的门店，它们代表着公司的最佳形象，通过调改可以进一步提升门店表现，发挥标杆和带动作用。另一方面选择潜力店，即那些过去经营业绩不佳甚至亏损，但通过调改有可能焕发生机的门店，在具备升级改造的同等条件下，公司会优先选择调改目前处于亏损或盈亏平衡线的门店。

本次拟升级改造的 216家门店满足上述调改店的选取的具体标准情况如下：
<table><tr><td colspan="1" rowspan="1">所处商圈情况</td><td colspan="1" rowspan="1">核心商圈</td><td colspan="1" rowspan="1">社区商圈但人流密集</td><td colspan="1" rowspan="1">合计</td></tr><tr><td colspan="1" rowspan="1">门店家数（家）</td><td colspan="1" rowspan="1">154</td><td colspan="1" rowspan="1">62</td><td colspan="1" rowspan="1">216</td></tr><tr><td colspan="1" rowspan="1">物业条件情况</td><td colspan="1" rowspan="1">标准化购物中心</td><td colspan="1" rowspan="1">非标准化购物中心但门店空间布局较为合理</td><td colspan="1" rowspan="1">合计</td></tr><tr><td colspan="1" rowspan="1">门店家数（家）</td><td colspan="1" rowspan="1">149</td><td colspan="1" rowspan="1">67</td><td colspan="1" rowspan="1">216</td></tr><tr><td colspan="1" rowspan="1">城市团队情况</td><td colspan="1" rowspan="1">城市团队本身运营实力较强</td><td colspan="1" rowspan="1">城市团队调改配合意愿较强</td><td colspan="1" rowspan="1">合计</td></tr><tr><td colspan="1" rowspan="1">门店家数（家）</td><td colspan="1" rowspan="1">201</td><td colspan="1" rowspan="1">15</td><td colspan="1" rowspan="1">216</td></tr><tr><td colspan="1" rowspan="1">过往经营业绩情况</td><td colspan="1" rowspan="1">过往业绩盈利，通过调改能进步提高盈利水平</td><td colspan="1" rowspan="1">过往业绩处于亏损或盈亏平衡线但可以通过调改提升盈利水平</td><td colspan="1" rowspan="1">合计</td></tr><tr><td colspan="1" rowspan="1">门店家数（家）</td><td colspan="1" rowspan="1">155</td><td colspan="1" rowspan="1">61</td><td colspan="1" rowspan="1">216</td></tr></table>

本次拟升级改造的 216家门店中，从所处商圈来看，有 154 家门店位于所在城市的核心商圈，62 家位于人流量密集的社区商圈；从物业条件来看，有 149家门店位于城市标准化购物中心内，配套设施较为完善，另有 67 家门店虽未处于标准化购物中心，但门店空间布局合理，停车位充足，具备调改条件；从城市团队来看，有201家门店位于公司门店较为密集的重庆、四川、福建等省份的主要城市，该等城市团队本身运营实力较强，另有 15 家门店的地理位置虽不属于公司门店密集的城市，但该等城市团队配合调改意愿较强，可以通过培训等方式提升团队运营能力；从过往经营业绩情况来看，有 155 家门店属于过往经营业绩盈利的门店，可通过调改进一步提高盈利水平，另有 61 家门店属于过往经营业绩不佳，但可以通过调改提升盈利水平的门店。

## （四）门店升级改造内容

近年来，零售业竞争日益激烈，提供便利的购物体验和高质量的消费者服务逐步成为传统超市转型升级的必要途径。在此背景下，公司明确以“品质零售”为核心的改革方向，积极推进门店优化以及战略和经营模式转型。公司拟通过本项目的建设，进一步推动门店调改进程，解决门店存在的区域空间布局不合理、陈列装修陈旧等问题，同时增加冷链、现场烘烤及烹饪设备，为客户提供便捷、高品质的用餐服务，提升消费场景体验，加速从传统超市向品质化、体验化零售模式的转型。

门店升级改造的具体内容包括：（1）通过对招牌、门头和灯光的重新设计，提升门店外部氛围，使整体形象更加明亮、具有吸引力；（2）在店内装修和布局方面进行升级，包括地面、天花板、灯光和货架排列，营造更加舒适的购物环境；（3）对门店空间设计进行优化，调整动线布局、取消强制动线，拓宽通道、扩大收银区域，降低货架高度，使顾客能够更顺畅地完成购物，同时更好地接触核心商品，从而提升整体体验；（4）提升生鲜及 3R 产品占比，加大具有烟火气的烘焙、熟食、包点等区域。（5）新增日配冷链、生鲜、散称杂粮、卖场端架等设备设施，并对原有设备进行了全方位的维护保养和更新迭代，以更好的保障产品品质；（6）增加休闲、便利等配套设施，增强消费舒适性和体验感，满足消费者的体验需求和服务需求。项目建成后，将有利于公司提升门店的市场形象和服务品质，提高门店运营质量，进一步增强品牌影响力。

## （五）本次门店升级改造预测效益情况

## 1、计算期

项目效益计算期为 6年，其中前 2年为项目建设期。

## 2、项目效益测算情况

本项目的预期效益根据国家发改委和建设部印发的《建设项目经济评价方法与参数（第三版）》进行测算，具体测算结果如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1</td><td rowspan=1 colspan=1>T+2</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1>T+5</td><td rowspan=1 colspan=1>T+6</td></tr><tr><td rowspan=1 colspan=1>一、、营业收入</td><td rowspan=1 colspan=1>1,714,471.39</td><td rowspan=1 colspan=1>2,554,214.25</td><td rowspan=1 colspan=1>3,281,687.16</td><td rowspan=1 colspan=1>3,379,421.56</td><td rowspan=1 colspan=1>3,480,088.00</td><td rowspan=1 colspan=1>3,583,774.43</td></tr><tr><td rowspan=1 colspan=1>减：主营业务成本</td><td rowspan=1 colspan=1>1,340,409.05</td><td rowspan=1 colspan=1>2,000,851.53</td><td rowspan=1 colspan=1>2,541,094.49</td><td rowspan=1 colspan=1>2,583,771.85</td><td rowspan=1 colspan=1>2,626,722.86</td><td rowspan=1 colspan=1>2,669,925.54</td></tr><tr><td rowspan=1 colspan=1>二、毛利</td><td rowspan=1 colspan=1>374,062.34</td><td rowspan=1 colspan=1>553,362.72</td><td rowspan=1 colspan=1>740,592.67</td><td rowspan=1 colspan=1>795,649.72</td><td rowspan=1 colspan=1>853,365.14</td><td rowspan=1 colspan=1>913,848.89</td></tr><tr><td rowspan=1 colspan=1>营业税金及附加</td><td rowspan=1 colspan=1>1,727.33</td><td rowspan=1 colspan=1>4,572.28</td><td rowspan=1 colspan=1>7,241.12</td><td rowspan=1 colspan=1>7,797.87</td><td rowspan=1 colspan=1>8.421.20</td><td rowspan=1 colspan=1>9.074.42</td></tr><tr><td rowspan=1 colspan=1>期间费用</td><td rowspan=1 colspan=1>412,594.03</td><td rowspan=1 colspan=1>548,441.60</td><td rowspan=1 colspan=1>661,042.78</td><td rowspan=1 colspan=1>681,104.62</td><td rowspan=1 colspan=1>698,157.20</td><td rowspan=1 colspan=1>694,119.16</td></tr><tr><td rowspan=1 colspan=1>三、利润总额</td><td rowspan=1 colspan=1>-43,934.02</td><td rowspan=1 colspan=1>-4,551.16</td><td rowspan=1 colspan=1>67,408.77</td><td rowspan=1 colspan=1>101,847.22</td><td rowspan=1 colspan=1>141,886.74</td><td rowspan=1 colspan=1>205,755.31</td></tr><tr><td rowspan=1 colspan=1>减：所得税</td><td rowspan=1 colspan=1>0.00</td><td rowspan=1 colspan=1>0.00</td><td rowspan=1 colspan=1>16,852.19</td><td rowspan=1 colspan=1>25,461.81</td><td rowspan=1 colspan=1>35,471.68</td><td rowspan=1 colspan=1>51,438.83</td></tr><tr><td rowspan=1 colspan=1>四、净利润</td><td rowspan=1 colspan=1>-43,934.02</td><td rowspan=1 colspan=1>-4,551.16</td><td rowspan=1 colspan=1>50,556.58</td><td rowspan=1 colspan=1>76,385.42</td><td rowspan=1 colspan=1>106,415.05</td><td rowspan=1 colspan=1>154,316.48</td></tr><tr><td rowspan=1 colspan=1>年均营业收入</td><td rowspan=1 colspan=6>2,998,942.80</td></tr><tr><td rowspan=1 colspan=1>年均净利润</td><td rowspan=1 colspan=6>56,531.39</td></tr><tr><td rowspan=1 colspan=1>税后投资内部收益率</td><td rowspan=1 colspan=6>21.57%</td></tr><tr><td rowspan=1 colspan=1>税后投资回收周期</td><td rowspan=1 colspan=6>4.84年</td></tr></table>

本次门店升级改造项目的测算税后静态投资回收期为 4.84 年（含建设期 2年），税后投资内部收益率为 21.57%，按照 10%的折现率计算，税后净现值为126,834.86 万元，项目建成后，将有效改善公司的整体盈利能力。

## 3、升级后带来增量效益的情况及测算依据

本次拟升级改造的 216 家门店预期营业收入及税前利润与该等门店 2024 年的经营效益对比情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>调改前</td><td rowspan=1 colspan=4>升级改造建设期满稳态经营后</td></tr><tr><td rowspan=1 colspan=1>年份</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1>T+5</td><td rowspan=1 colspan=1>T+6</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>1,984,699.59</td><td rowspan=1 colspan=1>3,281,687.16</td><td rowspan=1 colspan=1>3,379,421.56</td><td rowspan=1 colspan=1>3,480,088.00</td><td rowspan=1 colspan=1>3,583,774.43</td></tr><tr><td rowspan=1 colspan=1>营业收入增长额</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1,296,987.57</td><td rowspan=1 colspan=1>97,734.40</td><td rowspan=1 colspan=1>100,666.44</td><td rowspan=1 colspan=1>103,686.43</td></tr><tr><td rowspan=1 colspan=1>税前利润</td><td rowspan=1 colspan=1>56,710.94</td><td rowspan=1 colspan=1>67,408.77</td><td rowspan=1 colspan=1>101,847.22</td><td rowspan=1 colspan=1>141,886.74</td><td rowspan=1 colspan=1>205,755.31</td></tr><tr><td rowspan=1 colspan=1>税前利润增长额</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>10,697.83</td><td rowspan=1 colspan=1>34,438.45</td><td rowspan=1 colspan=1>40.039.52</td><td rowspan=1 colspan=1>63,868.57</td></tr></table>

本次拟升级改造的 216 家门店于 2024 年累计实现营业收入 1,984,699.59 万元，由于本次升级改造的效益测算中 T+1 年及 $_ { \mathrm { T } + 2 }$ 年为建设期，相关门店陆续完成改造并投入运营，建设期满后的 T+3年，216家门店全部投入运营后的累计营业收入预计将达到 3,281,687.16 万元，较 2024 年提升 1,296,987.57 万元。本次拟升级改造的 216 家门店于 2024 年累计实现税前利润 56,710.94 万元，本次升级改造建设期满后的 T+3 年，216 家门店累计税前利润预计将达到 67,408.77 万元，较 2024 年提升 10,697.83 万元。

本次门店升级改造项目预期效益的具体测算依据见本回复“问题 1、四、（一）本次门店升级改造项目效益测算情况及依据”。

综上，本次门店升级改造项目的实施是公司积极响应国家推动高质量供给、改造和提升传统零售业态号召的重要举措，也是公司顺应行业发展和消费者需求变化，引领行业转型发展的必经路径。项目建成后，将有利于公司提升门店的市场形象和服务品质，提高门店运营质量，进一步增强品牌影响力，提升公司的市场竞争力，本项目建成后预测经济效益良好，将有助于提升上市公司的整体盈利能力。因此，本次门店升级改造项目具有必要性。

二、结合现有物流仓储中心的运行情况、拟升级改造内容及同行业可比公司相应投入情况等，说明“物流仓储升级改造项目”是否与门店实际需求相匹配,该项目实施的可行性

## （一）现有物流仓储中心的运行情况及本次拟升级改造的内容

物流是超市企业供应链管理的重要组成部分，公司始终将物流体系的构建与发展置于重要战略位置，多年来公司已构建起仓储、加工、配送一体化的服务体系。截至 2025 年 9 月，公司物流中心覆盖全国 26 个省市，并且拥有 18 个物流园，为 28个大区服务。

2024 年以来公司以“品质零售”为核心方向，陆续对现有门店进行调改升级，从商品结构、配套设施、动线布局等全方面对门店进行系列改革，调改后门店客流量及销售额均实现明显提升。未来，伴随门店调改进程的不断深入以及到家业务的发展，现有仓储物流水平将难以匹配当前的产品结构，亟需进行改造升级。公司当前物流使用的自建仓总面积31万 $\mathrm { m } ^ { 2 }$ ，其中常温仓面积 23万 $\mathrm { m } ^ { 2 }$ ，占比 74%，冷链仓面积 8 万 m²，占比 26%。公司预期全面调改后，生鲜及 3R 产品的占比将达到 50%，而其中 80%以上需要在冷链环境下存储和作业，冷链仓面积需提升至 40%左右较为合理，公司冷链仓面积存在较大缺口。

同时，近年来在租金成本上升、人力短缺、消费需求碎片化等因素影响下，连锁超市零售业对于物流配送效率升级、决策精准化等方面提出更高要求，尤其是生鲜类产品对于分拣配送效率、配送时效性、运输环境等方面要求严苛，然而现有物流配送中心建立时间较早，存在设备老旧、智能化程度不高等问题，在货物存储、分拣、配送、库存管理等环节仍存在一定提升空间。

2025 年，本次拟升级改造的物流仓储中心运行情况如下：
<table><tr><td rowspan=1 colspan=1>物流园区</td><td rowspan=1 colspan=1>总仓储面积（平方米)</td><td rowspan=1 colspan=1>总年标准周转量（万箱/件/份）</td><td rowspan=1 colspan=1>总年实际周转量（万箱/件/份）</td><td rowspan=1 colspan=1>总仓储利用率</td><td rowspan=1 colspan=1>其中：冷冻库标准周转量（万箱/件/份）</td><td rowspan=1 colspan=1>冷库实际周转量（万箱/件/份）</td><td rowspan=1 colspan=1>冷库仓储利用率</td></tr><tr><td rowspan=1 colspan=1>重庆</td><td rowspan=1 colspan=1>73,171</td><td rowspan=1 colspan=1>7,000</td><td rowspan=1 colspan=1>5,475</td><td rowspan=1 colspan=1>78%</td><td rowspan=1 colspan=1>4,000</td><td rowspan=1 colspan=1>4,250</td><td rowspan=1 colspan=1>106%</td></tr><tr><td rowspan=1 colspan=1>四川</td><td rowspan=1 colspan=1>59,292</td><td rowspan=1 colspan=1>5,000</td><td rowspan=1 colspan=1>5,085</td><td rowspan=1 colspan=1>102%</td><td rowspan=1 colspan=1>2.500</td><td rowspan=1 colspan=1>2,250</td><td rowspan=1 colspan=1>90%</td></tr><tr><td rowspan=1 colspan=1>陕西</td><td rowspan=1 colspan=1>29,285</td><td rowspan=1 colspan=1>2,700</td><td rowspan=1 colspan=1>1,482</td><td rowspan=1 colspan=1>55%</td><td rowspan=1 colspan=1>1,000</td><td rowspan=1 colspan=1>699</td><td rowspan=1 colspan=1>70%</td></tr><tr><td rowspan=1 colspan=1>河南</td><td rowspan=1 colspan=1>23,251</td><td rowspan=1 colspan=1>2.500</td><td rowspan=1 colspan=1>2.342</td><td rowspan=1 colspan=1>94%</td><td rowspan=1 colspan=1>800</td><td rowspan=1 colspan=1>821</td><td rowspan=1 colspan=1>103%</td></tr><tr><td rowspan=1 colspan=1>福州</td><td rowspan=1 colspan=1>60,579</td><td rowspan=1 colspan=1>5,000</td><td rowspan=1 colspan=1>5,170</td><td rowspan=1 colspan=1>103%</td><td rowspan=1 colspan=1>2.500</td><td rowspan=1 colspan=1>2,677</td><td rowspan=1 colspan=1>107%</td></tr></table>

本次拟升级改造的物流仓储中心目前整体利用率较高，且公司重庆、福州物流园区的冷库仓储利用率较高，已超过 100%，具有进一步升级改造提升仓储能力的必要性。

基于上述情况，本次物流仓储升级改造项目的改造内容主要包括：（1）对重庆、福州两个物流中心的常温仓改建为冷冻库及冷藏库，以适应公司调改后生鲜、熟食产品占比提升的趋势，提高公司全温层仓储物流能力，具体各物流中心的改造内容及投资额情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>重庆物流园</td><td rowspan=1 colspan=1>福州物流园</td></tr><tr><td rowspan=1 colspan=1>改造面积 (平方米)</td><td rowspan=1 colspan=1>19.000.00</td><td rowspan=1 colspan=1>8,476.00</td></tr><tr><td rowspan=1 colspan=1>库体保温（万元）</td><td rowspan=1 colspan=1>912.00</td><td rowspan=1 colspan=1>406.85</td></tr><tr><td rowspan=1 colspan=1>制冷设备备（万元）</td><td rowspan=1 colspan=1>1,235.00</td><td rowspan=1 colspan=1>550.94</td></tr><tr><td rowspan=1 colspan=1>土建工程（万元）</td><td rowspan=1 colspan=1>760.00</td><td rowspan=1 colspan=1>339.04</td></tr><tr><td rowspan=1 colspan=1>配套工程呈（万元）</td><td rowspan=1 colspan=1>399.00</td><td rowspan=1 colspan=1>178.00</td></tr><tr><td rowspan=1 colspan=1>证照综合（万元）</td><td rowspan=1 colspan=1>874.00</td><td rowspan=1 colspan=1>389.90</td></tr><tr><td rowspan=1 colspan=1>累计投资额（万元）</td><td rowspan=1 colspan=1>4,180.00</td><td rowspan=1 colspan=1>1,864.72</td></tr></table>

（2）在重庆、四川、陕西、河南、福州五个物流中心引进自动分拣线、AGV机器人、高密度存储系统等先进自动化设备，更换迭代原有的手工分拣设备，提升公司现有物流基地自动化、智能化水平，提高商品分拣配送效率、节约商品流通成本与人力成本，具体各物流中心的改造内容及投资额情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>重庆</td><td rowspan=1 colspan=1>四川</td><td rowspan=1 colspan=1>陕西</td><td rowspan=1 colspan=1>河南</td><td rowspan=1 colspan=1>福州</td></tr><tr><td rowspan=1 colspan=1>自动分拣线</td><td rowspan=1 colspan=1>2,080.00</td><td rowspan=1 colspan=1>3.900.00</td><td rowspan=1 colspan=1>3.900.00</td><td rowspan=1 colspan=1>2.600.00</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>AGV机器人</td><td rowspan=1 colspan=1>1,080.00</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1080.00</td><td rowspan=1 colspan=1>720.00</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>高密度存储系统</td><td rowspan=1 colspan=1>800.00</td><td rowspan=1 colspan=1>600.00</td><td rowspan=1 colspan=1>600.00</td><td rowspan=1 colspan=1>600.00</td><td rowspan=1 colspan=1>800.00</td></tr><tr><td rowspan=1 colspan=1>重型货架</td><td rowspan=1 colspan=1>646.00</td><td rowspan=1 colspan=1>902.00</td><td rowspan=1 colspan=1>375.00</td><td rowspan=1 colspan=1>303.00</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>总投资金额</td><td rowspan=1 colspan=1>4,606.00</td><td rowspan=1 colspan=1>5,402.00</td><td rowspan=1 colspan=1>5,955.00</td><td rowspan=1 colspan=1>4,223.00</td><td rowspan=1 colspan=1>800.00</td></tr></table>

（3）配置升级 WMS 智能仓储管理系统、TMS物流运输管理系统等先进的数字化、智能化物流仓储配送系统，实现对库存动态变化、商品追踪、系统运行、故障诊断等场景的可视化管控，全面提升公司对仓储物流的智能化监控水平，推动公司业务规模与盈利水平的进一步提升，相关信息系统为全公司各物流园区共同使用，具体投资金额情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>投资金额</td></tr><tr><td rowspan=1 colspan=1>WMS升级改造</td><td rowspan=1 colspan=1>800</td></tr><tr><td rowspan=1 colspan=1>TMS升级改造</td><td rowspan=1 colspan=1>800</td></tr><tr><td rowspan=1 colspan=1>冷库检测系统</td><td rowspan=1 colspan=1>1,080</td></tr><tr><td rowspan=1 colspan=1>水产仓运数字化监测系统</td><td rowspan=1 colspan=1>1,190</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>3,870</td></tr></table>

基于上述情况，本次物流仓储升级改造项目的改造内容主要包括（1）对重庆、福州两个物流中心的常温仓改建为冷冻库及冷藏库，以适应公司调改后生鲜、熟食产品占比提升的趋势，提高公司全温层仓储物流能力；（2）在重庆、四川、陕西、河南、福州五个物流中心引进自动分拣线、AGV 机器人、高密度存储系统等先进自动化设备，更换迭代原有的手工分拣设备，提升公司现有物流基地自动化、智能化水平，提高商品分拣配送效率、节约商品流通成本与人力成本；（3）配置升级 WMS 智能仓储管理系统、TMS 物流运输管理系统等先进的数字化、智能化物流仓储配送系统，实现对库存动态变化、商品追踪、系统运行、故障诊断等场景的可视化管控，全面提升公司对仓储物流的智能化监控水平，推动公司业务规模与盈利水平的进一步提升。

## （二）同行业可比公司相应投入情况等

近年来，同行业可比上市公司亦存在大规模投资或改建物流仓储项目，提升仓储配送能力的情形，具体情况如下：

<table><tr><td rowspan=1 colspan=1>可比公司</td><td rowspan=1 colspan=1>投资时间</td><td rowspan=1 colspan=1>建设项目</td><td rowspan=1 colspan=1>投资金额（万元）</td><td rowspan=1 colspan=1>建设面积（平方米）</td></tr><tr><td rowspan=1 colspan=1>国光连锁</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>吉安物流配送中心升级项目</td><td rowspan=1 colspan=1>3,361.57</td><td rowspan=1 colspan=1>6,100.00</td></tr><tr><td rowspan=1 colspan=1>利群股份</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>利群智能供应链及粮食产业园二期项目</td><td rowspan=1 colspan=1>79,342.10</td><td rowspan=1 colspan=1>141,353.63</td></tr><tr><td rowspan=3 colspan=1>家家悦</td><td rowspan=2 colspan=1>2019年</td><td rowspan=1 colspan=1>威海物流改扩建</td><td rowspan=1 colspan=1>15,205.00</td><td rowspan=1 colspan=1>12,000.00</td></tr><tr><td rowspan=1 colspan=1>烟台物流中心（临港综合物流园)</td><td rowspan=1 colspan=1>27,764.00</td><td rowspan=1 colspan=1>65,221.00</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>家家悦商河智慧产业园项目(一期)</td><td rowspan=1 colspan=1>29,076.00</td><td rowspan=1 colspan=1>49,040.71</td></tr></table>

## （三）物流仓储升级改造项目与门店需求的匹配性

本次物流仓储升级改造项目物流中心主要配送区域、未来区域内所覆盖的门店的增量仓储需求及改造完成后仓储利用率情况如下：

<table><tr><td rowspan=1 colspan=1>物流中心名称</td><td rowspan=1 colspan=1>主要配送区域</td><td rowspan=1 colspan=1>截至2025年末仓储需求年周转总量（万箱/件/份）</td><td rowspan=1 colspan=1>未来三年新增仓储需求(万箱/件/份）</td><td rowspan=1 colspan=1>门店升级改造完成后年仓储需求（万箱/件/份）</td><td rowspan=1 colspan=1>改造完成后标准周转量（万箱/件/份）</td><td rowspan=1 colspan=1>改造完成后仓储利用率</td></tr><tr><td rowspan=1 colspan=1>重庆</td><td rowspan=1 colspan=1>重庆大区，渝南大区，渝东大区，渝西大区，云贵大区</td><td rowspan=1 colspan=1>5,475</td><td rowspan=1 colspan=1>1,643</td><td rowspan=1 colspan=1>7,118</td><td rowspan=1 colspan=1>8,500</td><td rowspan=1 colspan=1>83.74%</td></tr><tr><td rowspan=1 colspan=1>四川</td><td rowspan=1 colspan=1>成都大区，川北大区，川东大区，川南大区，西北大区</td><td rowspan=1 colspan=1>5,085</td><td rowspan=1 colspan=1>1,526</td><td rowspan=1 colspan=1>6,611</td><td rowspan=1 colspan=1>7,000</td><td rowspan=1 colspan=1>94.44%</td></tr><tr><td rowspan=1 colspan=1>陕西</td><td rowspan=1 colspan=1>陕西大区</td><td rowspan=1 colspan=1>1,482</td><td rowspan=1 colspan=1>1,586</td><td rowspan=1 colspan=1>3.068</td><td rowspan=1 colspan=1>3.800</td><td rowspan=1 colspan=1>80.73%</td></tr><tr><td rowspan=1 colspan=1>河南</td><td rowspan=1 colspan=1>河南大区、湖北大区</td><td rowspan=1 colspan=1>2,342</td><td rowspan=1 colspan=1>703</td><td rowspan=1 colspan=1>3,045</td><td rowspan=1 colspan=1>3,500</td><td rowspan=1 colspan=1>86.99%</td></tr><tr><td rowspan=1 colspan=1>,福州</td><td rowspan=1 colspan=1>福州大区、闽北大区、闽南大区、江西大区</td><td rowspan=1 colspan=1>5,170</td><td rowspan=1 colspan=1>1,551</td><td rowspan=1 colspan=1>6,721</td><td rowspan=1 colspan=1>7,500</td><td rowspan=1 colspan=1>89.61%</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>19,554</td><td rowspan=1 colspan=1>7,007</td><td rowspan=1 colspan=1>26,561</td><td rowspan=1 colspan=1>30,300</td><td rowspan=1 colspan=1>87.66%</td></tr></table>

本次物流仓储升级改造项目所涉及的物流中心均属于公司门店分布较为密集，需求量较大的区域，共覆盖 241家线下门店，占公司截至 2025年12月末门店总数量的 60%。未来 3年内随着公司调改门店全面进入稳态经营，一方面调改门店单店销售金额有所上升，另一方面调改后生鲜、3R 食品等冷链业务占比提升，同时，生鲜散品转标品也使得冷链仓储需求进一步提升，因此未来三年重庆、四川、陕西、河南、福州物流中心所覆盖大区新增仓储需求周转量均有所提升。物流中心升级改造完成后，上述五个物流中心的仓储利用率预计均保持在 80%以上。

综上，本次物流仓储升级改造项目，主要是包括将福州、重庆两个物流中心的常温仓改建为冷链仓，提升公司全温层仓储物流能力，同时引入自动分拣线、AGV 机器人、高密度存储系统等先进自动化设备以及配置 WMS 智能仓储管理系统、TMS 物流运输管理系统等物流管理系统，提升公司现有物流基地自动化、智能化水平，提高商品分拣配送效率、节约商品流通成本与人力成本。本次物流仓储升级改造项目投资与同行业公司的整体投资方向相符，与公司的门店需求具有匹配性。

三、本次募投项目投资构成的测算依据及设备购置价格的公允性，资本性支出的构成及占比情况，并结合货币资金余额、日常经营资金积累、资金缺口等情况说明本次融资规模的合理性

（一）本次募投项目投资构成的测算依据及设备购置价格的公允性，资本性支出的构成及占比情况

## 1、门店升级改造项目

本项目总投资金额为397,929.14万元，本次拟使用募集资金投入240,485.32万元。项目总投资具体资金使用计划如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>项目总投资</td><td rowspan=1 colspan=1>拟使用募集资金</td><td rowspan=1 colspan=1>是否为资本性支出</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>89,024.77</td><td rowspan=1 colspan=1>87,885.62</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>106,016.00</td><td rowspan=1 colspan=1>105,799.70</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>铺货及其他费用</td><td rowspan=1 colspan=1>202,888.36</td><td rowspan=1 colspan=1>46,800.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>397,929.14</td><td rowspan=1 colspan=1>240,485.32</td><td rowspan=1 colspan=1></td></tr></table>

## （1）建筑工程投资

本项目建筑工程投资费用参考公司已调改门店的单位造价进行估算，本项目总建筑面积941,346.93平方米，单位面积投资额为946元/平方米。截至2025年9月末，公司已完成调改门店平均单位面积建筑工程支出为990元/平方米，投资额测算具有公允性。

## （2）设备购置及安装

本项目设备购置及安装投资共计 106,016.00万元，具体投资明细如下表：

单位：万元

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">设备名称</td><td colspan="1" rowspan="1">总投资金额</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">冷链设备</td><td colspan="1" rowspan="1">41,727.02</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">货架设备</td><td colspan="1" rowspan="1">25,490.47</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">加工设备</td><td colspan="1" rowspan="1">10,010.62</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">公共设备</td><td colspan="1" rowspan="1">8,345.71</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">标识标牌</td><td colspan="1" rowspan="1">6,289.49</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">海鲜池设备</td><td colspan="1" rowspan="1">5,140.56</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">办公设备</td><td colspan="1" rowspan="1">2,658.80</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">机电设备及材料</td><td colspan="1" rowspan="1">5,595.72</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">收银设备</td><td colspan="1" rowspan="1">757.62</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">106,016.00</td></tr></table>

本项目设备购置及安装费用参考已调改门店相关设备的采购价格确定。本项目单位面积设备购置及安装费用为 1126 元/平方米，截至 2025 年 9 月末，公司已完成调改的设备购置及安装费用平均为 1066元/平方米，其中设备支出相对已调改店较高主要是因为前期调改过程中利旧设备使用相对较多，随着调改的全面开展，公司可供调改使用的旧设备已不足，需要另行采购。公司 2025 年 7 月开业的 24 家调改店单位面积设备购置及安装支出已达到 1105 元/平方米，与本次募投项目计划支出基本一致。

## （3）铺货及其他费用

铺货及其他费用投入 202,888.36 万元，具体投资明细如下表：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>区域</td><td rowspan=1 colspan=1>总投资金额</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>调改期间运营费用</td><td rowspan=1 colspan=1>51,686.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>铺货费用</td><td rowspan=1 colspan=1>151,202.36</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>202,888.36</td></tr></table>

其中，调改期间运营费用拟使用募集资金，主要包括筹备及开业期间的人力费用，耗材、维修等运营费用，媒体广告等营销费用等，该类费用主要参考已调改门店的实际费用投入确定。铺货费用为首批商品物料的投放费用，该部分公司拟使用自有资金投入。

## 2、物流仓储升级改造项目

本项目总投资金额为 30,900.72 万元，本次拟使用募集资金投入 30,900.72万元。项目总投资具体资金使用计划如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>项目总投资</td><td rowspan=1 colspan=1>募集资金净额</td><td rowspan=1 colspan=1>是否为资本性支出</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>6,044.72</td><td rowspan=1 colspan=1>6.044.72</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>24,856.00</td><td rowspan=1 colspan=1>24,856.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>30,900.72</td><td rowspan=1 colspan=1>30,900.72</td><td rowspan=1 colspan=1></td></tr></table>

## （1）建筑工程投资

本项目建筑工程总投资为 6,044.72 万元，具体投资明细如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>面积</td><td rowspan=1 colspan=1>单价</td><td rowspan=1 colspan=1>总投资金额</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>重庆冷库改造</td><td rowspan=1 colspan=1>19,000.00</td><td rowspan=1 colspan=1>2,200.00</td><td rowspan=1 colspan=1>4,180.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>福州冷库改造</td><td rowspan=1 colspan=1>8,476.00</td><td rowspan=1 colspan=1>2,200.00</td><td rowspan=1 colspan=1>1,864.72</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>27,476.00</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>6,044.72</td></tr></table>

本项目建筑工程主要参照当地同类结构的建构筑物的单位造价进行估算。重庆和福州冷库改造项目单位面积造价为 2200元/平方米，根据同行业上市公司家家悦公开信息披露，其青岛生鲜物流中心系由常温仓改建为生鲜物流仓（即冷链仓），单位面积投资额为 3000 元/平方米。因此，公司冷库改造的单位面积造价估算具有合理性。

## （2）设备购置及安装

本项目设备购置及安装投资共计 24,856.00 万元，具体投资明细如下表；

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">设备名称</td><td colspan="1" rowspan="1">数量（套）</td><td colspan="1" rowspan="1">总投资金额（万元）</td></tr><tr><td colspan="1" rowspan="1">二</td><td colspan="1" rowspan="1">硬件设备</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">20,986.00</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">自动分拣线</td><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">12,480.00</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">AGV</td><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">2,880.00</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">高密度存储系统</td><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">3,400.00</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">重型货架</td><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">2,226.00</td></tr><tr><td colspan="1" rowspan="1">三</td><td colspan="1" rowspan="1">软件</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3,870.00</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">WMS升级改造</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">800.00</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">TMS升级改造</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">800.00</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">冷库检测系统</td><td colspan="1" rowspan="1">36</td><td colspan="1" rowspan="1">1,080.00</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">水产仓运数字化监测系统</td><td colspan="1" rowspan="1">17</td><td colspan="1" rowspan="1">1,190.00</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">24,856.00</td></tr></table>

本项目设备购置费用主要参考公司现有设备的采购价格或相关设备的供应商报价确定，具有公允性。

## 3、本次募投项目资本性支出的构成及占比情况

本次募投项目资本性支出的构成及占比情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>募投项目构成</td><td rowspan=1 colspan=1>项目总投资</td><td rowspan=1 colspan=1>拟使用募集资金金额</td><td rowspan=1 colspan=1>占募集资金总金额比例</td><td rowspan=1 colspan=1>是否为资本性支出</td></tr><tr><td rowspan=3 colspan=1>1</td><td rowspan=3 colspan=1>门店升级改造项目</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>89,024.77</td><td rowspan=1 colspan=1>87,885.62</td><td rowspan=1 colspan=1>28.22%</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>106,016.00</td><td rowspan=1 colspan=1>105,799.70</td><td rowspan=1 colspan=1>33.98%</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>铺货及其他费用</td><td rowspan=1 colspan=1>202,888.36</td><td rowspan=1 colspan=1>46,800.00</td><td rowspan=1 colspan=1>15.03%</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=2 colspan=1>2</td><td rowspan=2 colspan=1>物流仓储升级改造项目</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>6,044.72</td><td rowspan=1 colspan=1>6,044.72</td><td rowspan=1 colspan=1>1.94%</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>24,856.00</td><td rowspan=1 colspan=1>24,856.00</td><td rowspan=1 colspan=1>7.98%</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>补充流动资金或偿还银行贷款</td><td rowspan=1 colspan=1>补充流动资金或偿还银行贷款</td><td rowspan=1 colspan=1>40,000.00</td><td rowspan=1 colspan=1>40,000.00</td><td rowspan=1 colspan=1>12.85%</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=3>合计</td><td rowspan=1 colspan=1>468,829.85</td><td rowspan=1 colspan=1>311,386.04</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1></td></tr></table>

公司本次募集资金用于资本性支出的金额为 224,586.04万元，占募集资金总金额的比例为 72.12%，非资本性支出金额以及直接用于补充流动资金的金额合计为 86,800 万元，占本次拟募集资金总额的比例为 27.88%，非资本性支出金额未超过本次募集资金总额的 30.00%。

## （二）结合货币资金余额、日常经营资金积累、资金缺口等情况说明本次融资规模的合理性

公司资金缺口的测算过程如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">公式</td><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">索引</td></tr><tr><td colspan="1" rowspan="1">截至2026年3月末货币资金</td><td colspan="1" rowspan="1">A</td><td colspan="1" rowspan="1">261, 941. 48</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">截至2026年3月末受限资金</td><td colspan="1" rowspan="1">B</td><td colspan="1" rowspan="1">33, 891.73</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">截至2026年3月末交易性金融资产余额</td><td colspan="1" rowspan="1">C</td><td colspan="1" rowspan="1">166, 258. 92</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">可自由支配的资金</td><td colspan="1" rowspan="1">D=A-B+C</td><td colspan="1" rowspan="1">394, 308. 67</td><td colspan="1" rowspan="1">1</td></tr><tr><td colspan="1" rowspan="1">未来期间预计产生的累计经营活动现金流量净额</td><td colspan="1" rowspan="1">E</td><td colspan="1" rowspan="1">327,131. 20</td><td colspan="1" rowspan="1">2</td></tr><tr><td colspan="1" rowspan="1">总体资金累计合计</td><td colspan="1" rowspan="1">F=D+E</td><td colspan="1" rowspan="1">721, 439. 87</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">最低现金保有量</td><td colspan="1" rowspan="1">G1</td><td colspan="1" rowspan="1">391, 679.97</td><td colspan="1" rowspan="1">3</td></tr><tr><td colspan="1" rowspan="1">未来期间新增最低现金保有量</td><td colspan="1" rowspan="1">G2</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">4</td></tr><tr><td colspan="1" rowspan="1">未来期间投资项目资金需求</td><td colspan="1" rowspan="1">G3</td><td colspan="1" rowspan="1">225,941.49</td><td colspan="1" rowspan="1">5</td></tr><tr><td colspan="1" rowspan="1">未偿还贷款的利息</td><td colspan="1" rowspan="1">G4</td><td colspan="1" rowspan="1">22, 811. 43</td><td colspan="1" rowspan="1">6</td></tr><tr><td colspan="1" rowspan="1">拟偿还的租赁负债及利息</td><td colspan="1" rowspan="1">G5</td><td colspan="1" rowspan="1">518, 318. 43</td><td colspan="1" rowspan="1">7</td></tr><tr><td colspan="1" rowspan="1">未来期间预计现金分红所需资金</td><td colspan="1" rowspan="1">G6</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">8</td></tr><tr><td colspan="1" rowspan="1">总体资金需求合计</td><td colspan="1" rowspan="1">G=G1+G2+G3+G4+G5+G6</td><td colspan="1" rowspan="1">1, 158, 751. 32</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">资金缺口</td><td colspan="1" rowspan="1">H=G-F</td><td colspan="1" rowspan="1">437, 311. 46</td><td colspan="1" rowspan="1"></td></tr></table>

综合考虑公司货币资金及交易性金融资产余额、未来资金使用需求、日常经营积累等，公司 2026年二季度至 2028 年总体资金缺口为437,311.46 万元，大于本次发行募集资金总额 311,386.04 万元，本次募集资金具有合理性。未来资金使用需求、货币资金及交易性金融资产余额、日常经营积累的测算过程详见后文分析。

## 1、可自由支配的现金

截至 2026 年 3 月 31 日，公司货币资金余额为 261,941.48 万元、交易性金融资产金额为 166,258.92 万元、受限资金 33,891.73 万元，具体如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>截至2026年3月末货币资金</td><td rowspan=1 colspan=1>261, 941. 48</td></tr><tr><td rowspan=1 colspan=1>减去：截至2026年3月末受限资金</td><td rowspan=1 colspan=1>33, 891. 73</td></tr><tr><td rowspan=1 colspan=1>截至2026年3月末交易性金融资产余额</td><td rowspan=1 colspan=1>166, 258.92</td></tr><tr><td rowspan=1 colspan=1>可自由支配的资金</td><td rowspan=1 colspan=1>394,308. 67</td></tr></table>

## 2、未来期间预计产生的累计经营活动现金流量净额

2023 年至 2026 年 1-3 月，公司现金流量净额占营业收入的比例如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>2026年1-3月</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>1,336, 675.95</td><td rowspan=1 colspan=1>5,350,757.06</td><td rowspan=1 colspan=1>6,757,382.41</td><td rowspan=1 colspan=1>7,864,217.16</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流量净额</td><td rowspan=1 colspan=1>47, 839. 49</td><td rowspan=1 colspan=1>64,568.19</td><td rowspan=1 colspan=1>219,142.81</td><td rowspan=1 colspan=1>456,888.10</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流量净额占收入比重</td><td rowspan=1 colspan=1>3.58%</td><td rowspan=1 colspan=1>1.21%</td><td rowspan=1 colspan=1>3.24%</td><td rowspan=1 colspan=1>5.81%</td></tr></table>

报告期内，受居民消费意愿波动和宏观经济环境变化影响，商贸零售行业处境较为艰难；同时，公司也在持续进行门店优化，对于业绩不好的门店进行关店，2023 年底至 2026 年 3 月底，公司的门店数量分别为 1,000 家、775 家，403 家和 392 家。随着公司门店的减少，公司的营业收入有一定程度的下滑。同时，公司在不断优化商品结构和采购模式，在淘汰旧品、引入新品的过程中主动推动裸价和控后台的策略，导致经营活动现金流量净额占营业收入的比例出现下滑。

2024 年至2025年期间，公司在大规模推进门店调改和关店，截至 2026 年 3月 31 日，公司已完成 327 家门店的调改工作，门店数量已经较 2024年年底减少383 家；基于公司推进门店调改速度较快，2026年门店调改进入尾声，鉴于公司未来的门店运营数量将基本维持在 2025 年年末的水平，未来导致公司收入下滑的闭店因素预计将消失，后续年度公司的收入不会进一步下降；同时，2025 年门店调改大部分已完成，2024 年至 2025 年的运营情况变化体现了调改期间公司的整体经营情况，因此使用 2024 年至 2025 年的财务数据，推测门店调改后稳态运营期的经营性现金流，能够全面衡量公司未来期间的现金流入情况，因此以 2024 年、2025 年的经营活动现金流量净额占收入的比重，推测未来调改期间的现金流入情况，具有合理性。

假设未来期间（2026 年第二季度至第四季度、2027 年和 2028 年）公司营业收入水平保持为 2026 年 1-3 月收入的年化值，基于此，测算未来期间预计产生的累计经营活动现金流量净额为 327,131.20 万元，计算结果如下所示：

单位：万元

<table><tr><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>2026年4-12月</td><td rowspan=1 colspan=1>2027E</td><td rowspan=1 colspan=1>2028E</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>4,010,027.85</td><td rowspan=1 colspan=1>5,346,703.80</td><td rowspan=1 colspan=1>5,346,703. 80</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流量净额占比</td><td rowspan=1 colspan=1>2. 22%</td><td rowspan=1 colspan=1>2. 22%</td><td rowspan=1 colspan=1>2. 22%</td></tr><tr><td rowspan=1 colspan=1>经营性现金流净额</td><td rowspan=1 colspan=1>89, 217. 60</td><td rowspan=1 colspan=1>118,956. 80</td><td rowspan=1 colspan=1>118,956. 80</td></tr><tr><td rowspan=1 colspan=1>未来期间预计产生的累计经营活动现金流量净额</td><td rowspan=1 colspan=3>327, 131. 20</td></tr></table>

## 3、最低现金保有量

公司选取付现成本月度覆盖法计算最低现金保有量。

2023 年至 2026 年 1-3月，发行人付现成本及可自由支配现金覆盖情况计算如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>会计科目</td><td rowspan=1 colspan=1>2026年1-3月</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>1,032,286. 88</td><td rowspan=1 colspan=1>4,289, 941. 13</td><td rowspan=1 colspan=1>5,375,059.27</td><td rowspan=1 colspan=1>6,193,981.95</td></tr><tr><td rowspan=1 colspan=1>税金及附加</td><td rowspan=1 colspan=1>3,893. 45</td><td rowspan=1 colspan=1>16,469. 23</td><td rowspan=1 colspan=1>21,352.25</td><td rowspan=1 colspan=1>21,791.50</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>223,599.54</td><td rowspan=1 colspan=1>1,108,443. 91</td><td rowspan=1 colspan=1>1,305,891.61</td><td rowspan=1 colspan=1>1,468,013.34</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>33,743.92</td><td rowspan=1 colspan=1>186,439.53</td><td rowspan=1 colspan=1>179,177.99</td><td rowspan=1 colspan=1>188,714.60</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>479.84</td><td rowspan=1 colspan=1>4, 548.89</td><td rowspan=1 colspan=1>18,299.89</td><td rowspan=1 colspan=1>31,826.73</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>16, 805. 52</td><td rowspan=1 colspan=1>81,417.81</td><td rowspan=1 colspan=1>113,752.87</td><td rowspan=1 colspan=1>132,305.25</td></tr><tr><td rowspan=1 colspan=1>所得税</td><td rowspan=1 colspan=1>5,769. 25</td><td rowspan=1 colspan=1>-8,376. 68</td><td rowspan=1 colspan=1>-516.06</td><td rowspan=1 colspan=1>10,331.24</td></tr><tr><td rowspan=1 colspan=1>减：非付现成本</td><td rowspan=1 colspan=1>39,361.11</td><td rowspan=1 colspan=1>211,411.94</td><td rowspan=1 colspan=1>316,936.46</td><td rowspan=1 colspan=1>359,743.22</td></tr><tr><td rowspan=1 colspan=1>合计付现成本</td><td rowspan=1 colspan=1>1,277,217. 30</td><td rowspan=1 colspan=1>5,467,471. 88</td><td rowspan=1 colspan=1>6,696,081.36</td><td rowspan=1 colspan=1>7,687,221.39</td></tr><tr><td rowspan=1 colspan=1>月均付现成本</td><td rowspan=1 colspan=1>425,739.10</td><td rowspan=1 colspan=1>455, 622. 66</td><td rowspan=1 colspan=1>558,006.78</td><td rowspan=1 colspan=1>640,601.78</td></tr><tr><td rowspan=1 colspan=1>期末可自由支配现金</td><td rowspan=1 colspan=1>394, 308. 67</td><td rowspan=1 colspan=1>452, 072. 44</td><td rowspan=1 colspan=1>713,120.05</td><td rowspan=1 colspan=1>643,374.09</td></tr><tr><td rowspan=1 colspan=1>期末可自由支配现金覆盖月数</td><td rowspan=1 colspan=1>0.93</td><td rowspan=1 colspan=1>0.99</td><td rowspan=1 colspan=1>1.28</td><td rowspan=1 colspan=1>1.00</td></tr></table>

其中，非付现成本主要包括折旧和摊销。报告期内，可比公司基于付现成本计算的期末可自由支配现金覆盖月数如下：

单位：月

<table><tr><td>公司名称</td><td>2025年</td><td>2024年</td><td>2023年</td></tr><tr><td colspan="1" rowspan="1">家家悦</td><td colspan="1" rowspan="1">1.90</td><td colspan="1" rowspan="1">1.47</td><td colspan="1" rowspan="1">1.81</td></tr><tr><td colspan="1" rowspan="1">步步高</td><td colspan="1" rowspan="1">2. 65</td><td colspan="1" rowspan="1">3.50</td><td colspan="1" rowspan="1">1.77</td></tr><tr><td colspan="1" rowspan="1">红旗连锁</td><td colspan="1" rowspan="1">4.10</td><td colspan="1" rowspan="1">3.34</td><td colspan="1" rowspan="1">2.86</td></tr><tr><td colspan="1" rowspan="1">百联股份</td><td colspan="1" rowspan="1">6.58</td><td colspan="1" rowspan="1">9.26</td><td colspan="1" rowspan="1">8.24</td></tr><tr><td colspan="1" rowspan="1">国光连锁</td><td colspan="1" rowspan="1">3.08</td><td colspan="1" rowspan="1">2.77</td><td colspan="1" rowspan="1">3.64</td></tr><tr><td colspan="1" rowspan="1">平均值</td><td colspan="1" rowspan="1">3.66</td><td colspan="1" rowspan="1">4.07</td><td colspan="1" rowspan="1">3.66</td></tr><tr><td colspan="1" rowspan="1">中位数</td><td colspan="1" rowspan="1">3.08</td><td colspan="1" rowspan="1">3.34</td><td colspan="1" rowspan="1">2.86</td></tr></table>

注：可比公司 2026 年 1-3 月折旧和摊销金额和受限资金金额未披露，此处展示 2025 年的比例。

发行人的期末可自由支配现金覆盖月数低于可比公司，主要系以下原因所致：

## （1）发行人经营规模较可比公司更广、日常现金支出金额高

零售行业的公司，多数具有经营层面的地域集中性，如家家悦主要在山东经营、步步高主要在湖南经营、红旗连锁多数门店在四川成都周围、国光连锁经营集中于江西省、百联股份主要集中在华东地区。截至2026 年 3 月 31 日，发行人业务覆盖 24 个省市，共有 392 家门店，覆盖全国，业务经营体量和覆盖区域广度显著高于可比公司，需采购的商品和支付的相关费用（如运输、物流等）显著高于其他企业，日常经营资金支出较高，使得期末可自由支配现金覆盖月数低于可比公司。

## （2）发行人以租赁方式为主经营门店，相关费用支出较高

发行人主要以租赁物业方式经营门店，需要支付租金以维持门店正常运营。而可比公司中部分企业包含百货/购物中心业态，为自有物业（如步步高、百联股份）；部分可比公司经营社区生鲜综合超市，所需租金支出较小（如家家悦）；以零售业态为主要业务的可比公司中，国光连锁门店均为自有门店，无需支付租金。基于业态差异，发行人需支付较多租金以维持日常运营，由此产生了较多的管理费用和销售费用，导致可自由支配现金覆盖倍数较低。

## （3）发行人深入实施门店调改，产生较多成本和支出

发行人自 2024 年开始深入实施门店调改，作为提升主营业务经营质量、推动公司中长期良性发展的重要手段，并主动关闭经营不善的门店。截至 2026 年3 月 31 日，发行人门店总数为 392 家，其中已完成调改的门店共计 327 家，已开业门店数相较于 2024 年年末减少 383 家。在公司关闭门店的过程中，需要支付遣散费、退租费等相关支出，产生大量的成本；在公司门店调改的过程中，需要招募人员、完成门店装修改造、重新设计动线等，产生付现成本较高。以上两个因素叠加导致公司可自由支配现金减少和付现成本增加，使得可自由支配现金覆盖月数较低。同行业推进调改的可比公司中，家家悦门店改造数量较少，其2025 年年报披露其分类推进门店调改，已完成 44 家门店的调改；步步高 2025年年报披露，2025 年公司关闭超市门店共 5 家、完成胖改（胖东来模式调改）门店 8 家，截至 2025 年 12 月 31 日，公司拥有超市业态门店 22 家，超市事业部合计完成 21 家门店的调改工作。以上两家可比公司的调改力度显著低于发行人，导致发行人期末可自由支配现金覆盖月数较低。总体而言，发行人该指标与家家悦和步步高较为接近，覆盖月数较低具有合理性。

（4）发行人持续推动供应链体系改革，导致成本增加

发行人将供应链体系改革作为提升公司竞争力的重要手段，主动采取裸采模式、优化供应商管理、加大源头采购、推动3R商品去联营化等。在淘汰原供应商、选择新供应商、研发新产品过程中，公司完成了大量供应商及商品的升级汰换，短期内承受一定的成本上升，间接导致期末可自由支配现金覆盖月数降低。

基于业务运营稳健性考量，考虑到公司日常经营活动现金需求量较大、门店调改和供应链升级需占用资金等因素，结合零售行业平均指标，在测算最低现金保有量时采用 0.92 个月的月平均经营活动现金流出作为最低资金保有量具有合理性。以此测算，发行人最低现金保有量为 391,679.97 万元。

因此，基于谨慎性测算，发行人最低现金保有量为 391,679.97 万元。

## 4、未来期间新增最低货币资金保有量

最低货币资金保有量的需求与公司和经营规模相关，根据谨慎性原则，假设2026年和 2027年营业收入不变，未来期间新增最低货币资金保有量为 0。

## 5、未来期间投资项目资金需求

截至本回复出具之日，公司经董事会审议通过的投资项目，为本次募投所涉及的门店升级改造项目和物流仓储升级改造项目。本次募投项目旨在提升门店经营成效和供应链管理能力，投资明细如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>募投项目构成</td><td rowspan=1 colspan=1>项目总投资</td></tr><tr><td rowspan=3 colspan=1>1</td><td rowspan=3 colspan=1>门店升级改造项目</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>89,024.77</td></tr><tr><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>106,016.00</td></tr><tr><td rowspan=1 colspan=1>铺货及其他费用</td><td rowspan=1 colspan=1>202,888.36</td></tr><tr><td rowspan=2 colspan=1>2</td><td rowspan=2 colspan=1>物流仓储升级改造项目</td><td rowspan=1 colspan=1>建筑工程投资</td><td rowspan=1 colspan=1>6,044.72</td></tr><tr><td rowspan=1 colspan=1>设备购置及安装</td><td rowspan=1 colspan=1>24,856.00</td></tr><tr><td rowspan=1 colspan=3>合计</td><td rowspan=1 colspan=1>428,829.85</td></tr></table>

本次募投项目所涉及的投资支出包括“门店升级改造项目”和“物流仓储升级改造项目”中的建筑工程投资、设备购置及安装投资，合计支出金额为225,941.49 万元。

因此，未来期间投资项目资金需求预计为 225,941.49万元。

## 6、未偿还贷款的利息

报告期内，公司的有息债务结构如下所示：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2026年3月末</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>365, 347. 32</td><td rowspan=1 colspan=1>392, 689. 77</td><td rowspan=1 colspan=1>493,811.77</td><td rowspan=1 colspan=1>513,022.01</td></tr><tr><td rowspan=1 colspan=1>长期借款</td><td rowspan=1 colspan=1>81,940.00</td><td rowspan=1 colspan=1>81,890.00</td><td rowspan=1 colspan=1>0.00</td><td rowspan=1 colspan=1>34,988.98</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>365, 347.32</td><td rowspan=1 colspan=1>392, 689. 77</td><td rowspan=1 colspan=1>493,811.77</td><td rowspan=1 colspan=1>548,010.99</td></tr></table>

公司的短期借款包括短期流动贷款和票据融资，公司长期借款为中期流动贷款。截至 2026 年 3 月末，公司短期流动借款、票据融资和中期流动借款平均年化利率为 2.20%、1.43%和 2.36%。假设 2026 年二季度至四季度、2027 年和 2028年公司债务规模和结构不变，公司需偿还的有息债务利息计算如下：

单位：万元

<table><tr><td>项目</td><td>2026年二至四季度</td><td>2027E</td><td>2028E</td></tr><tr><td colspan="1" rowspan="1">未偿还贷款的利息</td><td colspan="1" rowspan="1">6,221. 30</td><td colspan="1" rowspan="1">8,295. 07</td><td colspan="1" rowspan="1">8,295. 07</td></tr><tr><td colspan="1" rowspan="1">未偿还贷款的利息合计</td><td colspan="3" rowspan="1">22, 811. 43</td></tr></table>

## 7、拟偿付的租赁负债及利息

作为零售商超行业企业，发行人存在较多以使用权资产和租赁负债核算的租赁物业，需定期支付租金维持公司正常经营。租赁开展业务与发行人日常经营密切相关，但未在未来期间预计产生的累计经营性现金流量净额中予以考虑，因此考虑未来资金需求时应考虑支付租赁负债本金及利息支出。

报告期各期，公司支付的租金与公司的整体营业收入规模密切相关，比例保持相对稳定。2023 年、2024 年、2025 年及 2026 年 1-3 月，公司承租物业支付的固定租金（包含租赁负债和利息）与营业收入的比例关系如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>报告期</td><td rowspan=1 colspan=1>2026年1-3月</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>1,336, 675. 95</td><td rowspan=1 colspan=1>5,350,757.06</td><td rowspan=1 colspan=1>6,757,382.41</td><td rowspan=1 colspan=1>7,864,217.16</td></tr><tr><td rowspan=1 colspan=1>非豁免承租合同支付的固定租金</td><td rowspan=1 colspan=1>32,369.06</td><td rowspan=1 colspan=1>168, 145. 82</td><td rowspan=1 colspan=1>264,067.42</td><td rowspan=1 colspan=1>295,633.04</td></tr><tr><td rowspan=1 colspan=1>租金与营业收入的比例</td><td rowspan=1 colspan=1>2. 42%</td><td rowspan=1 colspan=1>3.14%</td><td rowspan=1 colspan=1>3.91%</td><td rowspan=1 colspan=1>3.76%</td></tr></table>

假设未来期间（2026 年二至四季度、2027 年和 2028 年）公司营业收入水平保持为 2026 年 1-3 月收入的年化值，支付的固定租金占营业收入的比例维持在3.53%（即调改执行期完整运营年度 2024 年和 2025 年租金与营业收入比例的平均值），2026 年二至四季度、2027 年、2028 年公司共需支付租赁负债和利息518,318.43 万元。未来，发行人存在新门店开业需求，会新增租赁协议；同时公司现有租赁合同为 10年以上的长期租赁合同，在合同存续期内租金保持不变，因此以支付的固定租金占营业收入的比例测算未来期间拟偿付的租赁负债及利息具有合理性。

单位：万元

<table><tr><td colspan="1" rowspan="1">预测期</td><td colspan="1" rowspan="1">2026年二至四季度</td><td colspan="1" rowspan="1">2027E</td><td colspan="1" rowspan="1">2028E</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">4,010, 027. 85</td><td colspan="1" rowspan="1">5,346,703. 80</td><td colspan="1" rowspan="1">5,346,703. 80</td></tr><tr><td colspan="1" rowspan="1">固定租金占营业收入比例</td><td colspan="1" rowspan="1">3.53%</td><td colspan="1" rowspan="1">3.53%</td><td colspan="1" rowspan="1">3.53%</td></tr><tr><td colspan="1" rowspan="1">未来各期支付固定租金金额所产生的经营相关现金流流出额</td><td colspan="1" rowspan="1">141, 359. 57</td><td colspan="1" rowspan="1">188, 479. 43</td><td colspan="1" rowspan="1">188, 479. 43</td></tr><tr><td colspan="1" rowspan="1">未来期间拟偿付的租赁负债及利息</td><td colspan="3" rowspan="1">518, 318.43</td></tr></table>

## 8、未来期间预计现金分红所需资金

未来三年预计现金分红所需资金采用未来三年归属于上市公司股东的净利润乘现金分红比例测算。报告期内，发行人处于亏损状态，未进行现金分红，基于谨慎性原则，假设未来期间预计现金分红所需资金的金额为 0。

基于以上计算，发行人未来期间资金缺口为 437,311.46 万元，高于本次募集资金总额 311,386.04万元，本次募集资金具有合理性。

四、结合本次募投项目客单价、毛利率等关键指标的测算依据，与公司和同行业公司可比项目相关指标的比较情况，说明效益测算是否谨慎、合理

## （一）本次门店升级改造项目效益测算依据

## 1、营业收入

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1</td><td rowspan=1 colspan=1>T+2</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1>T+5</td><td rowspan=1 colspan=1>T+6</td></tr><tr><td rowspan=1 colspan=1>总销售收入（万元）</td><td rowspan=1 colspan=1>1,714,471.39</td><td rowspan=1 colspan=1>2,554,214.25</td><td rowspan=1 colspan=1>3,281,687.16</td><td rowspan=1 colspan=1>3,379,421.56</td><td rowspan=1 colspan=1>3,480,088.00</td><td rowspan=1 colspan=1>3,583,774.43</td></tr><tr><td rowspan=1 colspan=1>超市业务收入</td><td rowspan=1 colspan=1>1,695,123.95</td><td rowspan=1 colspan=1>2,530,340.54</td><td rowspan=1 colspan=1>3,257,813.45</td><td rowspan=1 colspan=1>3,355,547.85</td><td rowspan=1 colspan=1>3,456,214.29</td><td rowspan=1 colspan=1>3,559,900.72</td></tr><tr><td rowspan=1 colspan=1>外租招商收入</td><td rowspan=1 colspan=1>19,347.44</td><td rowspan=1 colspan=1>23,873.71</td><td rowspan=1 colspan=1>23,873.71</td><td rowspan=1 colspan=1>23,873.71</td><td rowspan=1 colspan=1>23,873.71</td><td rowspan=1 colspan=1>23,873.71</td></tr><tr><td rowspan=1 colspan=1>可实现收入的调改面积（年化）</td><td rowspan=1 colspan=1>504,501.18</td><td rowspan=1 colspan=1>753,077.54</td><td rowspan=1 colspan=1>941,346.93</td><td rowspan=1 colspan=1>941,346.93</td><td rowspan=1 colspan=1>941,346.93</td><td rowspan=1 colspan=1>941,346.93</td></tr><tr><td rowspan=1 colspan=1>坪效（元/平米/月）</td><td rowspan=1 colspan=1>2.800.00</td><td rowspan=1 colspan=1>2.800.00</td><td rowspan=1 colspan=1>2.884.00</td><td rowspan=1 colspan=1>2,970.52</td><td rowspan=1 colspan=1>3,059.64</td><td rowspan=1 colspan=1>3,151.42</td></tr></table>

本项目预测营业收入包括超市业务收入及外租招商收入，其中：1）超市业务收入主要参考各年度可实现收入的调改面积及月基准坪效 2800 元/平方米，谨慎确定，对应客单价为 90 元/人次；由于公司预期门店调改后门店销售额有望实现明显增长，本项目预计月坪效在 T+1 年和 T+2 年保持不变，T+3 年及以后年增长率预计为 3%，本项目预计客单价在测算期内保持不变，预期坪效的增长主要来源于预期客流量的增加；2）外租招商收入主要参考公司各门店实际租金及调改后拟租赁面积确定。

2025 年，公司已调改满 6 个月的 123 家门店的月坪效已达到 3182 元/平方米，远高于 2800 元/平方米的基准坪效，且达到效益测算 T+6 年的水平，效益测算使用的坪效具有谨慎性。2025 年，公司已调改满 6 个月的 123 家门店的月平均客单价为 86 元/人次，与效益测算使用的客单价 90 元/人次接近，具有合理性。

## 2、毛利率

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1</td><td rowspan=1 colspan=1>T+2</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1> T+5</td><td rowspan=1 colspan=1>T+6</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>20.93%</td><td rowspan=1 colspan=1>20.93%</td><td rowspan=1 colspan=1>22.00%</td><td rowspan=1 colspan=1>23.00%</td><td rowspan=1 colspan=1>24.00%</td><td rowspan=1 colspan=1>25.00%</td></tr></table>

本项目效益测算预计超市业务基准毛利率参考公司已调改门店毛利率确定为 20.93%，由于公司调改初期涉及供应链重新整合，主动取消后台费用、低毛利大单品销售占比较高等因素，牺牲了一定毛利率。因此在调改期间 T+1 年及T+2年使用的毛利率相对较低，T+3年后毛利率预计每年将会有 1%的提升。

2025 年，公司已调改满 6 个月的稳态经营调改店毛利率已达到 21.8%，高于效益测算使用的基准毛利率。未来公司将进一步通过重新梳理供应商结构，推进裸价源头直采去除中间商等方式进一步提升毛利。因此本次募投项目效益测算使用的毛利率具有谨慎性。

## 3、期间费用率

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1</td><td rowspan=1 colspan=1>T+2</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1>T+5</td><td rowspan=1 colspan=1>T+6</td></tr><tr><td rowspan=1 colspan=1>期间费用率</td><td rowspan=1 colspan=1>24.28%</td><td rowspan=1 colspan=1>21.66%</td><td rowspan=1 colspan=1>20.29%</td><td rowspan=1 colspan=1>20.30%</td><td rowspan=1 colspan=1>20.20%</td><td rowspan=1 colspan=1>19.51%</td></tr></table>

本项目效益测算预计期间费用率参考已调改门店期间费用率 T+1 年确定为24.28%，后逐年下降至 T+6 年的 19.51%。考虑到调改初期（主要是调改首月）产生的费用较高，T+1年和T+2 年整体使用了较高的期间费用率，截至 2025年，公司已调改满 6 个月的稳态经营门店平均月期间费用率为 22.65%，已低于效益测算 T+1 年的期间费用率。2025 年，公司 31 家于 2024 年开业的调改店平均期间费用率已降至 21.54%，与测算 T+2 年的期间费用率相符，随着公司的调改经验不断丰富，公司后续调改的费用也会逐步降低，因此，本项目效益测算使用的期间费用率具有谨慎性。

## 4、净利润

根据上述假设，本项目效益测算在 T+1 年为亏损，T+2 年亏损大幅收窄，T+3年以后可以实现盈利，效益测算期间年平均净利润为 56,531.39 万元。

## （二）同行业可比公司相关项目效益测算情况

同行业可比公司中家家悦2019年连锁超市改造项目及2022年羊亭广场项目的测算情况与本项目效益测算对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>测算年度</td><td rowspan=1 colspan=1>基准坪效（元/平方米/月）</td><td rowspan=1 colspan=1>收入/坪效增长率</td><td rowspan=1 colspan=1>计算期平均毛利率</td><td rowspan=1 colspan=1>计算期平均费用率</td><td rowspan=1 colspan=1>计算期平均利润率</td><td rowspan=1 colspan=1>内部收益率</td></tr><tr><td rowspan=1 colspan=1>家家悦</td><td rowspan=1 colspan=1>连锁超市改造项目</td><td rowspan=1 colspan=1>2019年</td><td rowspan=1 colspan=1>1450</td><td rowspan=1 colspan=1>第2至第6年分别较前一年增长11%、7.5%、6%、5%、3%</td><td rowspan=1 colspan=1>21.61%</td><td rowspan=1 colspan=1>13.44%</td><td rowspan=1 colspan=1>7.81%</td><td rowspan=1 colspan=1>未披露</td></tr><tr><td rowspan=1 colspan=1>家家悦</td><td rowspan=1 colspan=1>羊亭购物广场项目</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>1650.07</td><td rowspan=1 colspan=1>第一年收入为基准收入的90%，后续收入与第五年持平，具体如下：第1-5年收入增长率分别为12%、8%、7%、4%、3%，第六年及后续收入与第五年持平</td><td rowspan=1 colspan=1>21.19%</td><td rowspan=1 colspan=1>16.91%</td><td rowspan=1 colspan=1>3.03%</td><td rowspan=1 colspan=1>21.26%</td></tr><tr><td rowspan=1 colspan=1>永辉超市</td><td rowspan=1 colspan=1>门店升级改造项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2800</td><td rowspan=1 colspan=1>第三年起每年增长3%</td><td rowspan=1 colspan=1>23.51%</td><td rowspan=1 colspan=1>20.54%</td><td rowspan=1 colspan=1>1.89%</td><td rowspan=1 colspan=1>21.57%</td></tr></table>

公司本次门店升级改造项目效益测算使用的基准坪效高于家家悦的连锁超市改造项目及羊亭购物广场项目，主要是因为本次门店升级改造是从卖场布局、商品结构、价格品质、顾客服务、员工福利、员工成长等核心方面对传统商超经营模式进行全面调改，调改后门店的经营成果较调改前会出现较大提升。截至2025 年 9 月，公司调改满 6 个月的稳态经营门店月平均销售额较该门店调改前已实现较大提升。此外，根据同行业可比公司步步高公开信息披露，其 2024 年已调改完毕的 13家门店销售额平均较 2023年提升292.49%，表明同行业公司在完成调改后，门店销售额及坪效较调改之前也存在明显提升。因此，本次门店升级改造项目效益测算使用的基准坪效高于家家悦2019年及2022年的募投项目具有合理性。

本次门店升级改造项目效益测算使用的毛利率和费用率高于家家悦，主要是因为门店调改后，高毛利的生鲜标品、3R 食品占比提升，同时在供应链端大力推进裸价源头直采，去除中间商等举措将使得调改店整体的毛利率高于传统商超门店，但同时由于调改店需要加大在顾客服务、员工福利等方面的投入，也使得调改店的费用率较传统商超门店有所提升。综合来看，本次门店升级改造项目的利润率低于家家悦 2019年及2022 年的募投项目，具有谨慎性。

## 五、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构主要执行了以下核查程序：

1、查阅了发行人报告期内的审计报告、年度报告、2025 年半年报和 2025三季报；

2、查阅了发行人募投项目可行性研究报告；

3、针对本次募投项目涉及的各项细节信息，对发行人高级管理人员、相关财务人员、相关业务人员进行了访谈，并查阅了相关资料；

4、查阅了可比公司的年度报告、半年度报告、三季度报告和公开信息。

## （二）核查意见

经核查，保荐机构认为：

1、本次募投项目中的“门店升级改造项目”，门店选取标准合理；项目实施后将有利于公司提升门店的市场形象和服务品质，提高门店运营质量，进一步增强品牌影响力，提升公司的市场竞争力。项目预计募投效益良好、实施该项目具有必要性；

2、本次募投项目中的“物流仓储升级改造项目”与门店实际需求相匹配，能够提升仓储物流能力和供应链智能化管理水平，募投项目实施具有可行性；

3、本次募投项目的非资本性支出占募集资金总额比例低于 30%，发行人未来期间资金缺口大于募集资金总额，资金缺口测算审慎，本次融资规模具备合理性；

4、本次募投项目坪效、毛利率等关键指标的测算依据符合公司已完成调改门店的情况，与同行业公司可比项目相关指标的差异具有合理性，效益测算谨慎、合理。

## 问题 2 关于经营情况

根据申报材料，1）报告期内，公司营业收入分别为 9,009,081.94 万元、7,864,217.16 万元、6,757,382.41 万元和 2,994,845.78 万元，归母净利润分别为-276,316.61 万元、-132,905.21 万元、-146,545.59 万元和-24,057.16 万元；2）报告期内，公司计提资产减值损失金额分别为-63,520.77 万元、-52,308.32万元、-20,783.90 万元和-5,154.43 万元；3）报告期各期末，公司货币资金余额分别为 761,594.07 万元、583,906.96 万元、399,619.26 万元和 492,480.20万元，交易性金融资产余额分别为 89,082.67 万元、73,597.18 万元、329,053.43万元和 115,443.33 万元，短期借款账面价值分别为 652,848.04 万元、513,022.01万元、493,811.77 万元和 398,914.57 万元，一年内到期的非流动负债分别为201,186.37 万元、179,235.19 万元、184,802.86 万元和 134,566.14 万元；4）报告期各期末，公司存货账面价值分别为 1,046,658.95 万元、826,898.25 万元、705,838.32 万元和 413,449.60 万元，未计提存货跌价准备。

请发行人说明：（1）报告期内公司营业收入持续下降、连续亏损的原因，经营业绩与同行业可比公司变动趋势是否一致，相关因素对后续经营的影响，相关风险提示是否充分；（2）报告期内公司资产减值损失计提金额减少的原因，各类主要资产减值测试的计算依据，资产减值损失确认时点与减值迹象发生时点的匹配性、计提金额的充分性;（3）报告期内货币资金及相关交易性金融资产余额与利息收入的匹配性，维持大额货币资金及交易性金融资产的同时借入大量有息负债的原因及合理性，货币资金是否存在使用受限的情况；（4）结合产品保质期、过期产品处理方式、库龄情况、期后销售情况、存货跌价准备计提政策、同行业可比公司情况等说明未计提存货跌价准备的合理性，是否符合企业会计准则要求。

请保荐机构及申报会计师核查并发表明确意见，说明对货币资金履行的核查方式、核查结论。

回复：

一、报告期内公司营业收入持续下降、连续亏损的原因，经营业绩与同行业可比公司变动趋势是否一致，相关因素对后续经营的影响，相关风险提示是否充分

（一）报告期内公司营业收入持续下降、连续亏损的原因，经营业绩与同行业可比公司变动趋势的比较分析

## 1、报告期内公司营业收入持续下降的原因及合理性

报告期各期，公司营业收入分别为 7,864,217.16 万元、6,757,382.41 万元和5,350,757.06 万元，呈现持续下降趋势，主要系公司不断闭店，经营规模下降所致。报告期各期末，公司处于开业状态的超市门店数量分别为 1,000 家、775家和403 家。

此外，公司为国内实体零售行业的龙头企业，近年来零售行业竞争加剧、消费需求放缓以及部分居民消费习惯的改变，也对公司的经营业绩产生了一定不利影响。公司于 2024 年下半年起开启整体战略与经营的深度转型工作，关闭长期经营亏损门店以及门店调改期歇业，导致短期内营业收入下滑较大。公司调改完成的门店收入较同期有大幅度增加，但在短期内无法弥补因关店产生的收入下降。

综上所述，报告期内发行人营业收入受公司闭店及深度转型、行业竞争格局加剧、消费需求总体放缓和部分居民消费习惯改变的影响下呈现下降态势，具有客观性和合理性。

## 2、报告期内公司连续亏损的原因及合理性

报告期各期，公司归属于母公司股东的净利润分别为-132,905.21 万元、-146,545.59 万元和-255,234.19 万元，存在连续亏损的情况。

报告期内，公司与连续亏损相关的主要科目情况具体如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=2>2023年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占营业收入比例</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占营业收入比例</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占营业收入比例</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>5,350,757.06</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>6,757,382.41</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>7,864,217.16</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>4,289, 941. 13</td><td rowspan=1 colspan=1>80.17%</td><td rowspan=1 colspan=1>5,375,059.27</td><td rowspan=1 colspan=1>79.54%</td><td rowspan=1 colspan=1>6,193,981.95</td><td rowspan=1 colspan=1>78.76%</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>1, 108, 443. 91</td><td rowspan=1 colspan=1>20.72%</td><td rowspan=1 colspan=1>1,305,891.61</td><td rowspan=1 colspan=1>19.33%</td><td rowspan=1 colspan=1>1,468,013.34</td><td rowspan=1 colspan=1>18.67%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>186, 439. 53</td><td rowspan=1 colspan=1>3. 48%</td><td rowspan=1 colspan=1>179,177.99</td><td rowspan=1 colspan=1>2.65%</td><td rowspan=1 colspan=1>188,714.60</td><td rowspan=1 colspan=1>2.40%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>4, 548. 89</td><td rowspan=1 colspan=1>0.09%</td><td rowspan=1 colspan=1>18,299.89</td><td rowspan=1 colspan=1>0.27%</td><td rowspan=1 colspan=1>31,826.73</td><td rowspan=1 colspan=1>0.40%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>81, 417. 81</td><td rowspan=1 colspan=1>1.52%</td><td rowspan=1 colspan=1>113,752.87</td><td rowspan=1 colspan=1>1.68%</td><td rowspan=1 colspan=1>132,305.25</td><td rowspan=1 colspan=1>1.68%</td></tr><tr><td rowspan=1 colspan=1>公允价值变动收益（损失以“_”号填列）</td><td rowspan=1 colspan=1>-46, 084. 42</td><td rowspan=1 colspan=1>-0.86%</td><td rowspan=1 colspan=1>-29,771.77</td><td rowspan=1 colspan=1>-0.44%</td><td rowspan=1 colspan=1>-7,634.30</td><td rowspan=1 colspan=1>-0.10%</td></tr><tr><td rowspan=1 colspan=1>资产减值损失（损失以“_”号填列)</td><td rowspan=1 colspan=1>-35,004. 59</td><td rowspan=1 colspan=1>-0.65%</td><td rowspan=1 colspan=1>-20,783.90</td><td rowspan=1 colspan=1>-0.31%</td><td rowspan=1 colspan=1>-52,308.32</td><td rowspan=1 colspan=1>-0.67%</td></tr><tr><td rowspan=1 colspan=1>营业外支出</td><td rowspan=1 colspan=1>98,390.73</td><td rowspan=1 colspan=1>1.84%</td><td rowspan=1 colspan=1>52,433.17</td><td rowspan=1 colspan=1>0.78%</td><td rowspan=1 colspan=1>16,733.23</td><td rowspan=1 colspan=1>0.21%</td></tr><tr><td rowspan=1 colspan=1>净利润（净亏损以“一&quot;号填列)</td><td rowspan=1 colspan=1>-266, 067. 01</td><td rowspan=1 colspan=1>-4.97%</td><td rowspan=1 colspan=1>-163,865.93</td><td rowspan=1 colspan=1>-2.42%</td><td rowspan=1 colspan=1>-146,473.05</td><td rowspan=1 colspan=1>-1.86%</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润（净亏损以“-”号填列）</td><td rowspan=1 colspan=1>-255, 234. 19</td><td rowspan=1 colspan=1>-4.77%</td><td rowspan=1 colspan=1>-146,545.59</td><td rowspan=1 colspan=1>-2.17%</td><td rowspan=1 colspan=1>-132,905.21</td><td rowspan=1 colspan=1> -1.69%</td></tr></table>

对报告期内公司连续亏损的原因具体分析如下：

1）线下零售行业受到行业竞争加剧、消费需求放缓及电商冲击影响，线下商超行业普遍面临转型挑战

近年来，零售行业竞争加剧、消费需求放缓以及受电商影响部分居民消费习惯改变等客观因素对线下零售行业冲击较大，线下商超行业普遍面临转型挑战。公司作为线下零售上市公司中少有的全国性企业，在行业下行期间，相较于其他区域性商超上市企业，供应链较为复杂、管理成本较高等因素被进一步放大，导致经营业绩承压较为明显。

2024 年下半年以来，公司加速战略转型，对标胖东来模式进行门店调改和关闭长期亏损门店。由于门店调改需要大量前期费用投入且调改期需要歇业，而关闭亏损门店也需要支付相应租赁违约金、承担清仓货物及清退人员带来的损失，短期内增加了大量的成本费用。

2）报告期内，公司计提了较高的资产减值损失和公允价值变动损失

## ①公司计提资产减值损失的具体情况

报告期各期，公司计提资产减值损失金额 52,308.32 万元、20,783.90 万元和35,004.59 万元，主要以长期资产减值损失和长期股权投资减值损失为主。

其中，报告期各期，若门店业绩未达预期或被批准闭店，该情况下，门店长期资产（包括固定资产、使用权资产及长期待摊费用等）被认为存在减值迹象，公司将上述长期资产所属门店作为资产组进行减值测试，对可收回金额低于其账面价值的门店资产组计提减值准备。由于报告期内公司闭店门店较多，公司各期分别进行了门店资产组的减值测试，并计提了长期资产减值损失如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>一、固定资产减值损失</td><td rowspan=1 colspan=1>2,712. 66</td><td rowspan=1 colspan=1>4,270.25</td><td rowspan=1 colspan=1>779.46</td></tr><tr><td rowspan=1 colspan=1>二、使用权资产减值损失</td><td rowspan=1 colspan=1>13, 537. 81</td><td rowspan=1 colspan=1>12,781.51</td><td rowspan=1 colspan=1>5,703.92</td></tr><tr><td rowspan=1 colspan=1>三、长期待摊减值损失</td><td rowspan=1 colspan=1>4,311. 82</td><td rowspan=1 colspan=1>3,030.14</td><td rowspan=1 colspan=1>1,909.60</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>20, 562. 29</td><td rowspan=1 colspan=1>20,081.90</td><td rowspan=1 colspan=1>8,392.98</td></tr></table>

公司在 2023 年度和 2025 年度分别计提了 43,622.00 万元和 9,088.23 万元的长期股权投资减值损失。公司各年度计提的长期股权投资减值及判断相关资产存在减值迹象的情况具体如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">年份</td><td colspan="1" rowspan="1">计提金额</td><td colspan="1" rowspan="1">判断减值迹象具体依据</td></tr><tr><td colspan="1" rowspan="1">中百控股集团股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">3,506.40</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr><tr><td colspan="1" rowspan="1">成都红旗连锁股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">35,822.69</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr><tr><td colspan="1" rowspan="1">湘村高科农业股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">4,292.92</td><td colspan="1" rowspan="1">已经全部停止运营，全额计提减值</td></tr><tr><td colspan="1" rowspan="1">永辉云金科技有限公司</td><td colspan="1" rowspan="1">2025</td><td colspan="1" rowspan="1">9,088.23</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr></table>

公司报告期各期已对其长期股权投资减值及判断是否具有减值迹象的依据进行了审慎的判断，除湘村高科农业股份有限公司（以下简称“湘村高科”）2023年由于已无法正常经营因此全额计提减值，以及永辉云金科技有限公司 2025 年根据交易约定的价格计提减值外，其余减值均依据第三方评估师对长期股权投资出具的评估报告确认可回收金额，对长期股权投资计提相应的减值准备。

②报告期各期交易性金融资产和其他非流动金融资产公允价值变动损失较高的原因，相关资产投资的具体情况

A. 报告期各期交易性金融资产和其他非流动金融资产公允价值变动损失较高的原因

公司公允价值变动损益来源为交易性金融资产和其他非流动金融资产，报告期各期金额分别为-7,634.30 万元、-29,771.77 万元和-46,084.42 万元，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>-38, 595.79</td><td rowspan=1 colspan=1>-29,771.77</td><td rowspan=1 colspan=1>-7,634.30</td></tr><tr><td rowspan=1 colspan=1>其他非流动金融资产</td><td rowspan=1 colspan=1>-7,488. 63</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>-46, 084. 42</td><td rowspan=1 colspan=1>-29,771.77</td><td rowspan=1 colspan=1>-7,634.30</td></tr></table>

其中，交易性金融资产公允价值变动损失主要是报告期内公司投资的美股上市公司 Advantage Solutions Inc.（以下简称“ADV”）股价变动及公司购买的基金理财产品价格波动所致，其中基金理财产品公允价值下降主要是由于基金分红后基金净值下降计入公允价值变动损益；其他非交易性金融资产公允价值变动主要是公司持有的万达商管基于评估报告估值变动形成的公允价值变动收益。报告期内交易性金融资产和其他非流动金融资产公允价值变动情况及变动原因如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">报告期</td><td colspan="1" rowspan="1">资产类别</td><td colspan="1" rowspan="1">内容</td><td colspan="1" rowspan="1">期初资产账面价值</td><td colspan="1" rowspan="1">期末资产账面价值</td><td colspan="1" rowspan="1">当期公允价值变动</td><td colspan="1" rowspan="1">产生公允价值变动损益的原因</td></tr><tr><td colspan="1" rowspan="8">2025年12月31日/2025年1-12月</td><td colspan="1" rowspan="4">交易性金融资产</td><td colspan="1" rowspan="1">权益工具投资ADV</td><td colspan="1" rowspan="1">33,516.45</td><td colspan="1" rowspan="1">9,876. 45</td><td colspan="1" rowspan="1">-23, 639.86</td><td colspan="1" rowspan="1">基于二级市场交易价格形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">基金理财产品</td><td colspan="1" rowspan="1">95,076.46</td><td colspan="1" rowspan="1">75,711.79</td><td colspan="1" rowspan="1">-15,236.70</td><td colspan="1" rowspan="1">基于证券公司、基金公司或银行提供的理财产品每月最后一日的对账单载明的期末产品净值确定形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">结构性存款</td><td colspan="1" rowspan="1">200,460.52</td><td colspan="1" rowspan="1">70,280. 78</td><td colspan="1" rowspan="1">280.78</td><td colspan="1" rowspan="1">基于银行提供的理财产品每月最后一日的对账单载明的期末产品净值确定形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">329,053.43</td><td colspan="1" rowspan="1">155,869. 01</td><td colspan="1" rowspan="1">-38, 595.79</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="3">其他非流动金融资产</td><td colspan="1" rowspan="1">万达商管</td><td colspan="1" rowspan="1">312, 588. 63</td><td colspan="1" rowspan="1">305,100.00</td><td colspan="1" rowspan="1">-7,488. 63</td><td colspan="1" rowspan="1">万达商管股权估值下降</td></tr><tr><td colspan="1" rowspan="1">福建联创智业建设工程有限公司</td><td colspan="1" rowspan="1">488.43</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">于2025年9月,福建联创智业建设工程有限公司已处置</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">313,077. 06</td><td colspan="1" rowspan="1">305,100.00</td><td colspan="1" rowspan="1">-7,488. 63</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">642, 130. 49</td><td colspan="1" rowspan="1">460,969. 01</td><td colspan="1" rowspan="1">-46, 084. 42</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="8">2024年12月31日/2024年1-12月</td><td colspan="1" rowspan="4">交易性金融资产</td><td colspan="1" rowspan="1">权益工具投资-ADV</td><td colspan="1" rowspan="1">38,893.22</td><td colspan="1" rowspan="1">33,516.45</td><td colspan="1" rowspan="1">-5,376.77</td><td colspan="1" rowspan="1">基于二级市场交易价格形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">基金理财产品</td><td colspan="1" rowspan="1">34,103.71</td><td colspan="1" rowspan="1">95,076.46</td><td colspan="1" rowspan="1">-24,395.00</td><td colspan="1" rowspan="1">基于证券公司、基金公司或银行提供的理财产品每月最后一日的对账单载明的期末产品净值确定形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">结构性存款</td><td colspan="1" rowspan="1">600.25</td><td colspan="1" rowspan="1">200,460.52</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">73,597.17</td><td colspan="1" rowspan="1">329.053.43</td><td colspan="1" rowspan="1">-29,771.77</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="3">其他非流动金融资产</td><td colspan="1" rowspan="1">万达商管</td><td colspan="1" rowspan="1">364,659.58</td><td colspan="1" rowspan="1">312,588.63</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">福建联创智业建设工程有限公司</td><td colspan="1" rowspan="1">488.43</td><td colspan="1" rowspan="1">488.43</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">365,148.01</td><td colspan="1" rowspan="1">313,077.06</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">438,745.18</td><td colspan="1" rowspan="1">642,130.49</td><td colspan="1" rowspan="1">-29,771.77</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2023年12月31日/2023年</td><td colspan="1" rowspan="1">交易性金融资产</td><td colspan="1" rowspan="1">权益工具投资-ADV</td><td colspan="1" rowspan="1">20,629.54</td><td colspan="1" rowspan="1">38,893.22</td><td colspan="1" rowspan="1">18,263.69</td><td colspan="1" rowspan="1">基于二级市场交易价格形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="9">1-12月</td><td colspan="1" rowspan="5"></td><td colspan="1" rowspan="1">基金理财产品</td><td colspan="1" rowspan="1">47,736.80</td><td colspan="1" rowspan="1">34,103.71</td><td colspan="1" rowspan="1">-25,897.99</td><td colspan="1" rowspan="1">基于证券公司、基金公司或银行提供的理财产品每月最后一日的对账单载明的期末产品净值确定形成的公允价值变动损益</td></tr><tr><td colspan="1" rowspan="1">结构性存款</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">600.25</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">权益工具投资—一万达商管（待出售部分）</td><td colspan="1" rowspan="1">20,000.00</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">权益工具投资—宁波梅山保税港区康御投资合伙企业（有限合伙）</td><td colspan="1" rowspan="1">716.33</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">89,082.67</td><td colspan="1" rowspan="1">73,597.17</td><td colspan="1" rowspan="1">-7,634.30</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="3">其他非流动金融资产</td><td colspan="1" rowspan="1">万达商管</td><td colspan="1" rowspan="1">391,800.00</td><td colspan="1" rowspan="1">364,659.58</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">福建联创智业建设工程有限公司</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">488.43</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">不适用</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">391,800.00</td><td colspan="1" rowspan="1">365,148.01</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">480,882.67</td><td colspan="1" rowspan="1">438,745.18</td><td colspan="1" rowspan="1">-7,634.30</td><td colspan="1" rowspan="1"></td></tr></table>

如上表所示，报告期交易性金融资产及其他非流动金融资产公允价值变动主要是由于相关资产二级市场交易价格变动、期末净值变动或评估估值变动所致。报告期各期，公司公允价值变动收益占营业收入的比例分别为-0.10%、-0.44%和-0.86%，占比较低。

## B．相关资产投资的具体情况

## i. 基金理财产品及结构性存款的具体情况

报告期各期末，公司基金理财及结构性存款的具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">日期</td><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">理财/基金名称</td><td colspan="1" rowspan="1">金额</td></tr><tr><td colspan="1" rowspan="3">2025年12月31日</td><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">结构性存款</td><td colspan="1" rowspan="1">70,280. 78</td></tr><tr><td colspan="1" rowspan="1">福州富平供应链管理有限公司</td><td colspan="1" rowspan="1">鹏华普天债券B</td><td colspan="1" rowspan="1">20, 143. 22</td></tr><tr><td colspan="1" rowspan="1">四川辉彭电子商务有限公司</td><td colspan="1" rowspan="1">鹏华普天债券B</td><td colspan="1" rowspan="1">10,000. 54</td></tr><tr><td colspan="1" rowspan="4"></td><td colspan="1" rowspan="1">四川辉彭电子商务有限公司</td><td colspan="1" rowspan="1">东方恒瑞短债债券C</td><td colspan="1" rowspan="1">5,565. 89</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">信银理财日盈象天天利223号</td><td colspan="1" rowspan="1">20,001. 48</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">信银理财安盈象固收稳益日开12号</td><td colspan="1" rowspan="1">20,000.66</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">145, 992. 57</td></tr><tr><td colspan="1" rowspan="11">2024年12月31日</td><td colspan="1" rowspan="1">福建云通供应链有限公司</td><td colspan="1" rowspan="1">中银稳汇短债债券C</td><td colspan="1" rowspan="1">10.008.34</td></tr><tr><td colspan="1" rowspan="1">福建云通供应链有限公司</td><td colspan="1" rowspan="1">东方中债1-5年政策性金融债C</td><td colspan="1" rowspan="1">5,020.43</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">民生理财贵竹固收增利月月盈30天持有期20号理财产品</td><td colspan="1" rowspan="1">20.019.28</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">招银理财招赢日日金59 号</td><td colspan="1" rowspan="1">10,007.78</td></tr><tr><td colspan="1" rowspan="1">福建永辉超市有限公司</td><td colspan="1" rowspan="1">招银理财招赢日日金59号</td><td colspan="1" rowspan="1">10,007.78</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">华夏理财现金100 号B</td><td colspan="1" rowspan="1">10.006.42</td></tr><tr><td colspan="1" rowspan="1">福建永辉超市有限公司</td><td colspan="1" rowspan="1">华夏理财现金100号B</td><td colspan="1" rowspan="1">10.006.42</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">招银理财招赢日日金63 号</td><td colspan="1" rowspan="1">10.000.00</td></tr><tr><td colspan="1" rowspan="1">福建永辉超市有限公司</td><td colspan="1" rowspan="1">招银理财招赢日日金63号</td><td colspan="1" rowspan="1">10,000.00</td></tr><tr><td colspan="1" rowspan="1">永辉超市股份有限公司</td><td colspan="1" rowspan="1">结构性存款</td><td colspan="1" rowspan="1">200,460.52</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">295,536.98</td></tr><tr><td colspan="1" rowspan="5">2023年12月31日</td><td colspan="1" rowspan="1">福建云通供应链有限公司</td><td colspan="1" rowspan="1">申万菱信合利纯债债券C</td><td colspan="1" rowspan="1">20.000.00</td></tr><tr><td colspan="1" rowspan="1">福建云通供应链有限公司</td><td colspan="1" rowspan="1">中银上清0-5年农发债</td><td colspan="1" rowspan="1">10,000.89</td></tr><tr><td colspan="1" rowspan="1">永辉青禾商业保理（重庆）有限公司</td><td colspan="1" rowspan="1">恒生前海恒源泓利债券C</td><td colspan="1" rowspan="1">4,102.82</td></tr><tr><td colspan="1" rowspan="1">广东永辉超市有限公司</td><td colspan="1" rowspan="1">招商银行点金系列看涨两层区间94天结构性存款</td><td colspan="1" rowspan="1">600.25</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">34,703.95</td></tr></table>

公司的交易性金融资产主要为公司基于资金管理目的而购买的结构性存款及基金理财产品，均为较低风险或保本型的产品，安全性较高。根据《企业会计准则第 22 号——金融工具确认和计量》的要求，公司上述结构性存款及基金理财产品属于以公允价值计量且其变动计入当期损益的金融资产，采用公允价值进行后续计量，公允价值变动计入当期损益。公司基金理财及结构性存款占交易性金融资产的比例为 47.15%、89.81%及 93.66%。2023 年度及 2024 年度受到理财产品持有期间分红及债券市场波动的影响，公司基金理财及结构性存款公允价值变动占交易性金融资产公允价值变动损益的比例较高，公司基金理财产品及结构性存款公允价值变动的影响较大。2025 年度，公司基金理财及结构性存款公允价值变动占交易性金融资产公允价值变动损益的比例为 38.75%，其公允价值变动的影响较小。

## 投资 ADV 的具体情况

公司对 ADV 的投资系 2017 年 ADV 换股吸收合并公司联营企业 DaymonNew Co LLC.子公司 Daymon World wide Inc.所致。2023 年 9 月，永辉控股对 ADV由间接持股变更为直接持股。截至本回复出具日，公司持有 ADV1,596.76 万股，占ADV的股权比例为 4.89%。该笔投资的具体情况如下：

<table><tr><td rowspan=1 colspan=1>投资标的</td><td rowspan=1 colspan=1>最初投资时间</td><td rowspan=1 colspan=1>最初投资成本</td><td rowspan=1 colspan=1>资金来源</td><td rowspan=1 colspan=1>后续投资日期</td><td rowspan=1 colspan=1>后续投资金额</td><td rowspan=1 colspan=1>处置日期</td><td rowspan=1 colspan=1>处置金额</td></tr><tr><td rowspan=1 colspan=1>ADV</td><td rowspan=1 colspan=1>2017年3月</td><td rowspan=1 colspan=1>64,679.72万元</td><td rowspan=1 colspan=1>自有资金</td><td rowspan=1 colspan=1>不适用</td><td rowspan=1 colspan=1>不适用</td><td rowspan=1 colspan=1>2025年9月</td><td rowspan=1 colspan=1>191.00美元</td></tr></table>

## iii. 宁波梅山保税港区康御投资合伙企业（有限合伙）的具体情况

宁波梅山保税港区康御投资合伙企业（有限合伙）（以下简称“康御投资”）系上海康煦股权投资基金管理有限公司（以下简称“康煦公司”）与上海永辉云创科技有限公司（以下简称“上海云创”）于 2017 年 7 月 4 日共同发起设立，用于投资零售运营一体化服务商成立的有限合伙企业。总认缴出资额为 1,952.00万元，其中，康煦公司认缴出资额为 2.00 万元，上海云创认缴出资额为 1,950.00万元。2018 年因处置原子公司永辉云创科技有限公司股权导致丧失康御投资控制权。2022 年2月康御投资退出被投企业，2023年10月，康御投资注销。

该笔投资具体情况如下：

<table><tr><td rowspan=1 colspan=1>投资标的</td><td rowspan=1 colspan=1>最初投资时间</td><td rowspan=1 colspan=1>最初投资成本</td><td rowspan=1 colspan=1>资金来源</td><td rowspan=1 colspan=1>后续投资日期</td><td rowspan=1 colspan=1>后续投资金额</td><td rowspan=1 colspan=1>处置日期</td><td rowspan=1 colspan=1>处置金额</td></tr><tr><td rowspan=2 colspan=1>康御投资</td><td rowspan=2 colspan=1>2017年7月</td><td rowspan=2 colspan=1>1,134.10</td><td rowspan=2 colspan=1>自有资金</td><td rowspan=2 colspan=1>不适用</td><td rowspan=2 colspan=1>不适用</td><td rowspan=1 colspan=1>2022年5月</td><td rowspan=1 colspan=1>680.46</td></tr><tr><td rowspan=1 colspan=1>2023年6月</td><td rowspan=1 colspan=1>713.57</td></tr></table>

单位：万元

## iv. 投资万达商管的具体情况

2018 年 12 月 3 日，为了战略拓展优质物业，公司与大连一方集团有限公司（以下简称“一方集团”）、孙喜双先生签订股份转让协议，拟受让大连一方集团有限公司持有的大连万达商业管理集团股份有限公司（以下简称“万达商管”）股份 67,910,214 股，占万达商管股份总数的 1.5%。每股转让价格为 52 元,标的资产价格为 3,531,331,128 元。2022 年 10 月，珠海祥意企业管理有限公司与公司签订股份转让协议，购买公司持有的万达商管 3,126,881 股万达商管股份，标的转让价格为 20,000 万元。2023 年 12 月，大连御锦贸易有限公司（以下简称“大连御锦”）拟向公司现金购买公司持有的万达商管股份 388,699,998 股，占万达商管总股本的 1.43%，转让价格为 4,530,059,250.07 元。该笔投资具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>投资标的</td><td rowspan=1 colspan=1>最初投资时间</td><td rowspan=1 colspan=1>最初投资成本</td><td rowspan=1 colspan=1>资金来源</td><td rowspan=1 colspan=1>后续投资日期</td><td rowspan=1 colspan=1>后续投资金额</td><td rowspan=1 colspan=1>预计处置日期</td><td rowspan=1 colspan=1>处置金额</td></tr><tr><td rowspan=11 colspan=1>万达商管</td><td rowspan=11 colspan=1>2018年12月</td><td rowspan=11 colspan=1>353,133.11</td><td rowspan=11 colspan=1>自有资金</td><td rowspan=11 colspan=1>不适用</td><td rowspan=11 colspan=1>不适用</td><td rowspan=1 colspan=1>2022年12月</td><td rowspan=1 colspan=1>20,000.00</td></tr><tr><td rowspan=1 colspan=1>2023年12月</td><td rowspan=1 colspan=1>30,000.00</td></tr><tr><td rowspan=1 colspan=1>2024年3月</td><td rowspan=1 colspan=1>39,097.02</td></tr><tr><td rowspan=1 colspan=1>2024年6月</td><td rowspan=1 colspan=1>20,000.00</td></tr><tr><td rowspan=1 colspan=1>2024年9月</td><td rowspan=1 colspan=1>30.000.00</td></tr><tr><td rowspan=1 colspan=1>2024年12月</td><td rowspan=1 colspan=1>50,000.00</td></tr><tr><td rowspan=1 colspan=1>2025年3月</td><td rowspan=1 colspan=1>70,000.00</td></tr><tr><td rowspan=1 colspan=1>2025年6月</td><td rowspan=1 colspan=1>76,480.00</td></tr><tr><td rowspan=1 colspan=1>2025年9月</td><td rowspan=1 colspan=1>67,900.00</td></tr><tr><td rowspan=1 colspan=1>2025年12月</td><td rowspan=1 colspan=1>34,760.00</td></tr><tr><td rowspan=1 colspan=1>2026年3月</td><td rowspan=1 colspan=1>34,768.91</td></tr></table>

注：大连御锦已支付 2023 年12 月-2024 年 6 月的第一至三期股权转让款 89,097.02 万元，后续由于交易对手方存在短期资金周转困难未能按时支付，公司已向上海国际经济贸易仲裁委员会提起仲裁申请，上海国际经济贸易仲裁委员会已裁决大连御锦、王健林先生、孙喜双先生、一方集团履行付款义务。

## v. 投资福建联创智业建设工程有限公司的具体情况

福建联创智业建设工程有限公司主要从事装修装饰工程业务，为公司超市门店提供装修、维修维保等服务，2016 年 1 月，公司与原工程管理中心剥离维保业务、员工分离出去后成立福州首要建筑劳务工程有限责任公司（以下简称“首要建筑”）按照 60%、40%的比例共同投资人民币 3,000 万元在福建省福州市设立福建联创智业建设工程有限公司（下称“联创智业”）。2023 年11月23日，将联创智业 45%股权转让给首要建筑；2025 年 9 月，公司与福州首要建筑劳务工程有限责任公司签署股权转让协议，约定公司将剩余注册资金补缴后将公司持有的剩余联创智业 15%股权转让给首要建筑，目前已完成工商登记。截至本回复出具日，公司已不再持有联创智业股权。该项投资具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>投资标的</td><td rowspan=1 colspan=1>最初投资时间</td><td rowspan=1 colspan=1>最初投资成本</td><td rowspan=1 colspan=1>资金来源</td><td rowspan=1 colspan=1>后续投资日期</td><td rowspan=1 colspan=1>后续投资金额</td><td rowspan=1 colspan=1>处置日期</td><td rowspan=1 colspan=1>处置金额</td></tr><tr><td rowspan=2 colspan=1>联创智业</td><td rowspan=2 colspan=1>2016年1月</td><td rowspan=2 colspan=1>900.00</td><td rowspan=2 colspan=1>自有资金</td><td rowspan=2 colspan=1>2025年9月</td><td rowspan=2 colspan=1>225.00</td><td rowspan=1 colspan=1>2023年11月</td><td rowspan=1 colspan=1>1,465.29</td></tr><tr><td rowspan=1 colspan=1>2025年10月</td><td rowspan=1 colspan=1>713.43</td></tr></table>

## 3）报告期内闭店较多导致营业外支出较高

公司营业外支出主要为非流动资产报废损失和赔款及诉讼支出等支出，报告期各期金额分别为 16,733.23 万元、52,433.17 万元和 98,390.73 万元。2024 年下半年以来，公司加速战略转型，对标胖东来模式进行门店调改和关闭长期亏损门店，导致营业外支出中的非流动资产报废损失较高，对于净利润影响较大。

综上所述，报告期内发行人受闭店及深度转型、行业竞争格局加剧、消费需求总体放缓和部分居民消费习惯改变等因素的影响较深，叠加各年有较高的资产减值损失、公允价值变动损失和营业外支出，且公司作为全国性的线下零售龙头经营业绩承压更为明显，报告期内归属于母公司股东的净利润呈现持续亏损态势具有客观性和合理性。

## 3、经营业绩与同行业可比公司变动趋势的比较分析

## （1）营业收入分析

报告期内，公司及同行业可比公司的营业收入变化情况具体如下：

单位：亿元

<table><tr><td rowspan=2 colspan=1>公司名称</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>同比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>同比</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>百联股份</td><td rowspan=1 colspan=1>247. 85</td><td rowspan=1 colspan=1>-10. 44%</td><td rowspan=1 colspan=1>276.75</td><td rowspan=1 colspan=1>-9.32%</td><td rowspan=1 colspan=1>305.19</td></tr><tr><td rowspan=1 colspan=1>家家悦</td><td rowspan=1 colspan=1>179. 57</td><td rowspan=1 colspan=1>-1. 64%</td><td rowspan=1 colspan=1>182.56</td><td rowspan=1 colspan=1>2.77%</td><td rowspan=1 colspan=1>177.63</td></tr><tr><td rowspan=1 colspan=1>红旗连锁</td><td rowspan=1 colspan=1>95.56</td><td rowspan=1 colspan=1>-5. 61%</td><td rowspan=1 colspan=1>101.23</td><td rowspan=1 colspan=1>-0.09%</td><td rowspan=1 colspan=1>101.33</td></tr><tr><td rowspan=1 colspan=1>国光连锁</td><td rowspan=1 colspan=1>28.17</td><td rowspan=1 colspan=1>4.80%</td><td rowspan=1 colspan=1>26.88</td><td rowspan=1 colspan=1>11.43%</td><td rowspan=1 colspan=1>24.12</td></tr><tr><td rowspan=1 colspan=1>步步高</td><td rowspan=1 colspan=1>42. 10</td><td rowspan=1 colspan=1>22.71%</td><td rowspan=1 colspan=1>34.31</td><td rowspan=1 colspan=1>11.14%</td><td rowspan=1 colspan=1>30.87</td></tr><tr><td rowspan=1 colspan=1>平均数</td><td rowspan=1 colspan=1>118. 65</td><td rowspan=1 colspan=1>1. 96%</td><td rowspan=1 colspan=1>124.35</td><td rowspan=1 colspan=1>3.19%</td><td rowspan=1 colspan=1>127.83</td></tr><tr><td rowspan=1 colspan=1>永辉超市</td><td rowspan=1 colspan=1>535.08</td><td rowspan=1 colspan=1>-20.82%</td><td rowspan=1 colspan=1>675.74</td><td rowspan=1 colspan=1>-14.07%</td><td rowspan=1 colspan=1>786.42</td></tr></table>

数据来源：各上市公司定期报告等公开数据。

如上表所示，报告期内公司营业收入较上年同期变动率分别为-14.07%和-20.82%，同行业可比公司营业收入较上年同期变动率分别为 3.19%和 1.96%

公司于 2024 年下半年起开启整体战略与经营的深度转型工作，关闭长期经营亏损门店以及门店调改期歇业，导致营业收入下滑，虽然调改门店收入较同期有大幅度增加，但无法弥补因关店产生的收入下降。因此，公司 2024 年度及 2025年度的营业收入下降较大，与同行业可比公司的营业收入变动趋势存在不一致具有合理性。

## （2）归属于母公司股东的净利润分析

报告期内，公司及同行业可比公司的归属于母公司股东的净利润变化情况具体如下：

单位：亿元

<table><tr><td colspan="1" rowspan="2">公司名称</td><td colspan="2" rowspan="1">2025年度</td><td colspan="2" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">同比</td><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">同比</td><td colspan="1" rowspan="1">金额</td></tr><tr><td colspan="1" rowspan="1">百联股份</td><td colspan="1" rowspan="1">6.31</td><td colspan="1" rowspan="1">-59. 74%</td><td colspan="1" rowspan="1">15.67</td><td colspan="1" rowspan="1">292.73%</td><td colspan="1" rowspan="1">3.99</td></tr><tr><td colspan="1" rowspan="1">家家悦</td><td colspan="1" rowspan="1">2.01</td><td colspan="1" rowspan="1">52. 09%</td><td colspan="1" rowspan="1">1.32</td><td colspan="1" rowspan="1">-3.26%</td><td colspan="1" rowspan="1">1.36</td></tr><tr><td colspan="1" rowspan="1">红旗连锁</td><td colspan="1" rowspan="1">4.81</td><td colspan="1" rowspan="1">-7.78%</td><td colspan="1" rowspan="1">5.21</td><td colspan="1" rowspan="1">-7.12%</td><td colspan="1" rowspan="1">5.61</td></tr><tr><td colspan="1" rowspan="1">国光连锁</td><td colspan="1" rowspan="1">0.16</td><td colspan="1" rowspan="1">486. 22%</td><td colspan="1" rowspan="1">0.03</td><td colspan="1" rowspan="1">-81.62%</td><td colspan="1" rowspan="1">0.15</td></tr><tr><td colspan="1" rowspan="1">步步高</td><td colspan="1" rowspan="1">1. 13</td><td colspan="1" rowspan="1">-90. 69%</td><td colspan="1" rowspan="1">12.12</td><td colspan="1" rowspan="1">不适用</td><td colspan="1" rowspan="1">-18.89</td></tr><tr><td colspan="1" rowspan="1">平均数</td><td colspan="1" rowspan="1">2.88</td><td colspan="1" rowspan="1">76. 02%</td><td colspan="1" rowspan="1">6.87</td><td colspan="1" rowspan="1"> 50.18%</td><td colspan="1" rowspan="1">-1.56</td></tr><tr><td colspan="1" rowspan="1">永辉超市</td><td colspan="1" rowspan="1">-25.52</td><td colspan="1" rowspan="1">不适用</td><td colspan="1" rowspan="1">-14.65</td><td colspan="1" rowspan="1">不适用</td><td colspan="1" rowspan="1">-13.29</td></tr></table>

数据来源：各上市公司定期报告等公开数据，公司与步步高涉及亏损年度不适用同比变化。

如上表所示，报告期内公司归属于母公司股东的净利润持续亏损，亏损幅度总体上升。可比公司归属于母公司股东的净利润变化较大，与公司对应指标的变动趋势存在较大差异，主要原因系报告期内公司受闭店及深度转型的影响较深，且公司作为全国性的线下零售龙头经营业绩承压更为明显，相关变动趋势差异具有客观性和合理性。

（二）相关因素对后续经营的影响，相关风险提示是否充分，结合目前闭店情况及未来闭店计划、店均收益改善情况等具体分析是否存在业绩下滑风险;

公司在 2025 年进行了重大的经营战略调整，从“规模扩张”转向“质量增长”，重新定位了“新永辉、新品质”的战略发展，对公司原有门店进行了大规模调改。2025 年公司累计完成 284 家门店的调改工作，较上年同期增加 253家，同时有 6 家门店于 2025 年末启动调改，截至 2025 年末尚未开业。上述门店调改过程中产生的调改费用均直接计入当期损益，对公司 2025 年净利润影响较大，调改费用主要包括门店原有固定资产和装修的报废损失，停业调改期间人力及租赁费用，以及调改需要的营运工具与耗材的前期准备、相关运输费、营销投入等开业一次性支出。2025 年，公司调改门店的资产报废损失较上年增加 1.96 亿元，停业调改期间的人力及租赁费用较上年增加 3.25 亿元，相关耗材、运输及营销费用等开业一次性投入较上年增加 2.15 亿元。上述门店累计产生调改费用 8.79 亿元，较上年同期增加 7.36 亿元，是公司亏损额扩大的最主要原因。

2025 年，公司积极推进战略转型，持续关闭尾部亏损门店。2025 年，公司累计关闭了 381 家门店，较 2024 年增加 149 家，公司关闭的 381家门店当期累计收入较上年同期减少 101.6 亿元，同时公司 2024 年关闭的门店导致公司 2025年销售收入较上年减少 67.4 亿元，是公司营业收入下降的最主要原因。此外，公司关闭的门店本身经营业绩亏损金额较大，且闭店过程中还会产生资产报废损失以及租赁赔偿金、员工赔偿金等支出。2025 年，公司闭店门店的资产报废损失较上年增加 1.71 亿元，闭店门店的员工辞退赔偿金较上年增加 0.99 亿元，闭店门店的经营亏损及减值损失较上年增加 4.75 亿元，尽管租赁相关资产/负债的处置收益较上年增加 6.37 亿元，公司闭店门店相关的亏损总额累计仍较上年增加 1.09 亿元。

从已调改门店的经营业绩改善情况来看，公司于 2024 年完成调改的 31 家门店，在 2025 年累计实现销售额 59.27 亿元，较 2024年同比提升 47.5%，累计实现门店端利润 1.21 亿元，较上年增加 2.0 亿元，实现扭亏为盈。公司的门店调改显著提升了门店的营业收入和净利润，但由于上述 2024 年完成调改的门店占比较低，而 2025 年调改的门店由于前期调改费用较高，整体尚未实现盈利，因此调改店业绩对公司 2025 年当期净利润的贡献较为有限。截至 2025 年末，公司门店数量为 403 家，其中已完成调改的门店数量为 315家（含 2025 年新开业门店），上述门店在 2026 年将全部进入稳态经营状态，该等门店预计将对公司2026 年营业收入及净利润带来较大的积极贡献。2026年一季度，公司归属于母公司股东的净利润为 2.87 亿元较 2025 年同期增长 94.40%，经营业绩已有所回升。

2025 年全年，公司累计关闭门店 381 家，同时完成 284 家现有门店的调改工作，公司的门店关闭和调改工作主要集中于 2025 年完成，公司初步预计 2026年拟关闭门店的数量约 24 家，拟调改门店数量约 64家，较 2025 年明显减少，因闭店和门店调改过程对经营业绩带来的负面影响将显著减少。因此，公司 2026年经营业绩进一步下滑的风险较小。

公司 2024 年、2025 年及预计 2026 年因门店调改工作和闭店工作对当期税前利润带来的主要影响情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">2025年</td><td colspan="1" rowspan="1">2026年 (预计）</td></tr><tr><td colspan="1" rowspan="1">(拟）调改门店数量(家)</td><td colspan="1" rowspan="1">31</td><td colspan="1" rowspan="1">284</td><td colspan="1" rowspan="1">64</td></tr><tr><td colspan="1" rowspan="1">(拟）关闭门店数量(家)</td><td colspan="1" rowspan="1">232</td><td colspan="1" rowspan="1">381</td><td colspan="1" rowspan="1">24</td></tr><tr><td colspan="1" rowspan="1">调改费用税前利润影响额</td><td colspan="1" rowspan="1">-14,200. 16</td><td colspan="1" rowspan="1">-87,891. 06</td><td colspan="1" rowspan="1">-19,806. 44</td></tr><tr><td colspan="1" rowspan="1">当年闭店门店税前利润(含门店经营利润、闭店损失及租赁资产处置收益)</td><td colspan="1" rowspan="1">-12, 531. 35</td><td colspan="1" rowspan="1">-23,385. 02</td><td colspan="1" rowspan="1">-1,473. 07</td></tr><tr><td colspan="1" rowspan="1">合计税前利润影响额</td><td colspan="1" rowspan="1">-26,731.51</td><td colspan="1" rowspan="1">-111, 276. 08</td><td colspan="1" rowspan="1">-21, 279. 51</td></tr></table>

注：2026年预计数按2025年单店的调改费用与2025年闭店门店单店税前利润乘以2026年预计调改和闭店门店数量进行估计

2025 年全年，公司仅因门店调改产生的一次性费用为 8.79 亿元，公司当年闭店的门店累计税前利润为-2.34 亿元，合计对公司税前利润影响额为-11.13亿元，2026 年在公司预计调改和关闭门店数量大幅减少的情况下，上述因闭店和调改对公司税前利润的影响额将降至-2.13亿元，即使在不考虑已调改门店业绩增长的情况下，公司 2026 年预计税前利润较 2025年会增加 9.00 亿元。

综上所述，发行人闭店及门店调改工作主要集中在 2025 年完成，未来因闭店和门店调改过程对经营业绩带来的负面影响将显著减少。随着发行人大部分闭店及门店调改工作已完成，调改店进入稳态经营状态，预期未来调改门店的营业收入和净利润较调改前将保持增长。导致 2025 年公司亏损的主要因素对公司未来经营不会产生重大不利影响。

针对前述对公司经营业绩具有不利影响的因素，关于宏观经济及行业风险，发行人已在募集说明书“第五节 本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（一）宏观经济波动的风险”之“1、宏观经济波动的风险”和“2、行业竞争加剧的风险”中进行了充分披露；关于门店调改相关风险，发行人已在募集说明书“第五节 本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（二）经营风险”之“1、门店调改成效不及预期带来的风险”中进行了充分披露；关于财务相关风险，发行人已在募集说明书“第五节 本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（三）财务风险”之“4、资产减值损失的风险”和“5、公允价值变动的风险”中进行了充分披露。

二、报告期内公司资产减值损失计提金额减少的原因，各类主要资产减值测试的计算依据，资产减值损失确认时点与减值迹象发生时点的匹配性、计提金额的充分性

（一）报告期内公司资产减值损失计提金额减少的原因

## 1、报告期内公司资产减值损失计提情况

单位：万元

<table><tr><td rowspan=1 colspan=1>报表项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>变动</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>变动</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>计算公式</td><td rowspan=1 colspan=1>(a)</td><td rowspan=1 colspan=1>(a) - (b)</td><td rowspan=1 colspan=1>(b）</td><td rowspan=1 colspan=1>(b)-(c)</td><td rowspan=1 colspan=1>（C）</td></tr><tr><td rowspan=1 colspan=1>长期股权投资减值损失</td><td rowspan=1 colspan=1>9,088. 23</td><td rowspan=1 colspan=1>9,088. 23</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-43,622.00</td><td rowspan=1 colspan=1>43,622.00</td></tr><tr><td rowspan=1 colspan=1>长期资产减值损失</td><td rowspan=1 colspan=1>20,562. 29</td><td rowspan=1 colspan=1>480.39</td><td rowspan=1 colspan=1>20,081.90</td><td rowspan=1 colspan=1>11, 688. 92</td><td rowspan=1 colspan=1>8,392.98</td></tr><tr><td rowspan=1 colspan=1>存货跌价损失及合同履约成本减值损失</td><td rowspan=1 colspan=1>4,247.94</td><td rowspan=1 colspan=1>4,247.94</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>无形资产减值损失</td><td rowspan=1 colspan=1>740.00</td><td rowspan=1 colspan=1>38.00</td><td rowspan=1 colspan=1>702.00</td><td rowspan=1 colspan=1>408. 67</td><td rowspan=1 colspan=1>293.33</td></tr><tr><td rowspan=1 colspan=1>商誉减值损失</td><td rowspan=1 colspan=1>366. 14</td><td rowspan=1 colspan=1>366.14</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>资产减值损失合计</td><td rowspan=1 colspan=1>35,004.59</td><td rowspan=1 colspan=1>14, 220. 69</td><td rowspan=1 colspan=1>20,783.90</td><td rowspan=1 colspan=1>-31,524.41</td><td rowspan=1 colspan=1>52,308.31</td></tr></table>

注：长期资产减值损失包括固定资产减值损失、使用权资产减值损失及长期待摊减值损失。

如上表所示，报告期各期，公司计提资产减值损失金额分别为 52,308.32 万元、20,783.90 万元和 35,004.59 万元。公司的资产减值损失主要包括对联营企业的权益性投资的长期股权投资减值损失、针对门店相关的资产组计提的长期资产减值损失以及存货跌价损失及合同履约成本减值损失。其中，2025 年度公司对长期股权投资计提减值损失 9,088.23 万元。同时，由于存在预计进一步关闭的门店，当期计提了长期资产减值损失 20,562.29 万元。

公司 2024 年度较 2023 年度的资产减值损失减少人民币 31,524.41 万元，主要变化来自于长期资产减值损失增加 11,688.92 万元，长期股权投资减值损失计提减少 43,622.00万元。公司 2025 年度较 2024 年度的资产减值损失增加人民币14,220.69 万元，主要变化来自于长期资产减值损失增加 480.39 万元，长期股权投资减值损失计提增加 9,088.23 万元，存货跌价损失及合同履约成本减值损失增加 4,247.94 万元。

现对主要影响公司资产减值损失金额的长期股权投资减值损失、长期资产减值损失以及存货跌价损失及合同履约成本减值损失具体分析如下：

（1）长期股权投资减值损失计提变化情况分析

1）湘村高科

2022 年，湘村高科存在亏损情况，公司结合对湘村高科现场情况的了解以及对未来经营情况的判断，认为对于湘村高科的长期股权投资存在减值迹象。由于湘村高科不存在市场公开报价，公司聘请了第三方评估师上海东洲资产评估有限公司对公司持有的 20%湘村高科股权进行评估。2023年2月 17日，上海东洲资产评估有限公司出具了《永辉超市股份有限公司拟对其长期股权投资进行减值测试涉及的湘村高科农业股份有限公司 20%股权可回收价值估值报告》（东洲咨报字【2023】第 0198 号），采用市净率法对湘村高科 20%账面价值为 24,890.00万元的股权于估值基准日 2022 年 12 月 31 日的可回收价值进行测算，最终确定相关股权估值为 5,300.00 万元。公司根据该评估报告，于 2022 年度对湘村高科的长期股权投资计提了减值准备约人民币 19,682.67 万元。

2023 年，湘村高科已无实际经营活动，资金链彻底断裂，面临多起外部诉讼，已无法继续经营，企业面临破产清算。因此公司管理层无法合理预估持有的湘村高科的股权在未来是否可以带来经济利益。基于湘村高科当时所处的实际情况，公司预计极大可能无法收回其投资款项，因此于资产负债表日，永辉超市对湘村高科的投资进一步计提资产减值损失人民币 4,292.92万元，至此，已经全额计提对湘村高科的长期股权投资的减值准备。

2）成都红旗连锁股份有限公司（以下简称“红旗连锁”）

2023 年 12 月 21 日，公司发布《永辉超市股份有限公司关于出售资产的公告》，经公司第五届董事会第十二次会议全票通过，四川商投投资有限责任公司拟向永辉超市现金购买永辉超市持有的红旗连锁 13,600.00 万股股份，转让股份占红旗连锁总股本的 10.00%，协议转让价款，即标的股份的转让价格为每股 5.88元，转让总价为 8.00亿元。转让价格低于 2023年末红旗连锁折合每股账面价值，故判断存在减值迹象。

公司聘请了上海东洲资产评估有限公司为红旗连锁的长期股权投资可回收金额进行评估，2024年2月28 日，上海东洲资产评估有限公司出具了《永辉超市股份有限公司拟对其长期股权投资进行减值测试所涉及的其持有成都红旗连锁股份有限公司流通股的可回收价值估值报告》（东洲咨报字【2024】第 0167号），对公司持有的红旗连锁 28,560.00 万股进行减值测试。在确定红旗连锁的长期股权投资的可回收金额时，同时测算了公允价值减去处置费用后的净额和预计未来现金流量的现值。按照公允价值减去处置费用后的净额和预计未来现金流量的现值中较高者作为可收回金额，判断红旗连锁的长期股权投资的可回收金额为人民币 168,000.00 万元。公司将可收回金额与长期股权投资的账面金额进行比较，计提长期股权投资减值准备人民币 35,822.69万元。

2024 年及 2025 年，公司未识别出红旗连锁股权存在减值迹象，未执行减值测试。

3）中百控股集团股份有限公司（以下简称“中百集团”）

2023 年，按2023年12月 31日其每股价格4.37元计算的公司持股份额价值为人民币 2.93 亿元，低于该部分股权的账面价值。因此，管理层认为中百集团的股权存在减值迹象。

公司聘请评估师上海东洲资产评估有限公司，对公司持有的中百集团股权可收回金额进行评估。2024 年 2 月 28 日，上海东洲资产评估有限公司出具了《永辉超市股份有限公司拟对其长期股权投资进行减值测试所涉及的其持有中百控股集团股份有限公司流通股的可回收价值估值报告》（东洲咨报字【2024】第0168 号）。经评估，公司持有的中百集团 6,710.13 万股股份于 2023 年 12 月 31日的公允价值减处置费用后的净额为人民币 3.22 亿元，低于公司持有的中百集团长期股权投资的账面价值，需要计提长期股权投资减值准备。公司将公允价值减去处置费用的净额作为可收回金额，根据其与减值前账面金额人民币 3.57 亿元的差异计提长期股权投资减值准备人民币 3,506.40 万元。

2024 年，公司陆续处置中百集团股权，于 2024 年末公司不再持有中百集团股份。

4）永辉云金科技有限公司（以下简称“云金科技”）

公司于2025年9月向上海派慧科技有限公司出售所持有的云金科技6.905%股权，转让总价为人民币 41,452,226.87 元。本次交易完成后，本公司仍持有云金科技 28.095%的股权，以权益法核算剩余部分股权。于 2025 年 12 月 30 日，公司拟通过重庆联合产权交易所公开挂牌交易方式转让云金科技 28.095%的股权。上海派慧科技有限公司已向本公司出具《关于进一步收购永辉云金科技有限公司 28.1%股权的非约束性报价函》。因无其他意向受让方，本公司于 2026年 1 月 12 日调价至人民币 1.53 亿元，于 2026 年 1 月 19 日调价至人民币 1.20亿元。于 2026 年 1 月 21 日终止了公开挂牌程序，并拟通过协议转让方式向派慧科技出售持有的云金科技剩余股权,交易对价为人民币 80,000,000.00 元。2025 年度，公司按照拟对价对于云金科技的剩余股权计提了减值人民币9,088.23 万元。截至本回复出具日，该交易已完成工商变更。

## （2）长期资产减值损失计提变化情况分析

公司主营业务为零售业，主要的长期资产都集中在门店。对于长期资产减值，公司按照门店资产组进行减值损失的计提。公司于资产负债表日判断资产是否存在减值迹象，主要结合近年门店经营表现、门店周边环境、本年整改效果、是否存在对门店经营产生重大影响的偶发事项等因素，对门店的盈利能力进行综合考虑。存在减值迹象的，公司将上述长期资产所属门店作为资产组编制盈利预测并计算可收回金额进行减值测试，对可收回金额低于其账面价值的门店资产组计提减值准备。在确定资产组的预计未来现金流量的现值时，公司根据历史经验及对市场发展的预测确定收入增长率和毛利率，采用了 11.0%作为反映相关资产特定风险的税前折现率，具体分析如下：

2024 年度，公司长期资产减值损失相较 2023年度增加11,688.92 万元，主要系当年公司主动寻求变革，以“品质零售”为核心启动战略转型，全面推进调改门店及组织转型，计划于 2025 年进一步关闭尾部门店所致。2025 年末，公司对后续仍有闭店计划的门店计提了 20,562.29 万元的长期资产减值损失。

## （3）存货跌价损失及合同履约成本减值损失

公司2023-2024年度无需计提存货跌价损失及合同履约成本减值损失，2025年度主要由于酒类产品价格下降幅度较大等原因，公司基于会计政策按照成本与可变现净值孰低对成本高于可变现净值的存货计提存货跌价准备，2025 年末计提的存货跌价准备金额为 4,247.94 万元，相关处理具有合理性。具体请见本问题之“四、结合产品保质期、过期产品处理方式、库龄情况、期后销售情况、存货跌价准备计提政策、同行业可比公司情况等说明未计提存货跌价准备的合理性，是否符合企业会计准则要求”之分析。

综上所述，报告期内公司资产减值损失计提的变化情况具有合理性。

## （二）各类主要资产减值测试的计算依据

（1）长期股权投资减值测试的计算依据

公司管理层在资产负债表日进行长期股权投资减值迹象分析。具体如下：

1）资产的市价当期大幅度下跌，其跌幅明显高于因时间的推移或者正常使用而预计的下跌；

2）企业经营所处的经济、技术或者法律等环境以及资产所处的市场在当期或者将在近期发生重大变化，从而对企业产生不利影响；

3）市场利率或者其他市场投资报酬率在当期已经提高，从而影响企业计算资产预计未来现金流量现值的折现率，导致资产可收回金额大幅度降低；

4）有证据表明资产已经陈旧过时或者其实体已经损坏；

5）资产已经或者将被闲置、终止使用或者计划提前处置；

6）企业内部报告的证据表明资产的经济绩效已经低于或者将低于预期，如资产所创造的净现金流量或者实现的营业利润（或者亏损）远远低于（或者高于）预计金额等；

7）其他表明资产可能已经发生减值的迹象。

公司各年度计提的长期股权投资减值及判断相关资产存在减值迹象的情况具体如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">年份</td><td colspan="1" rowspan="1">计提金额</td><td colspan="1" rowspan="1">判断减值迹象具体依据</td></tr><tr><td colspan="1" rowspan="1">中百控股集团股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">3,506.40</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr><tr><td colspan="1" rowspan="1">成都红旗连锁股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">35,822.69</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr><tr><td colspan="1" rowspan="1">湘村高科农业股份有限公司</td><td colspan="1" rowspan="1">2023</td><td colspan="1" rowspan="1">4,292.92</td><td colspan="1" rowspan="1">已经全部停止运营，全额计提减值</td></tr><tr><td colspan="1" rowspan="1">永辉云金科技有限公司</td><td colspan="1" rowspan="1">2025</td><td colspan="1" rowspan="1">9, 088. 23</td><td colspan="1" rowspan="1">资产的市价当期下跌</td></tr></table>

对于存在减值迹象的，公司执行减值测试，主要依据第三方评估师对长期股权投资出具的评估报告确认可回收金额，对长期股权投资计提相应的减值准备。此外，湘村高科 2023 年由于已无法正常经营，不具备出具评估报告的条件，因此全额计提减值。永辉云金科技有限公司 2025 年根据交易约定的价格计提减值。

## （2）长期资产的减值测试的计算依据

公司将单个门店的固定资产、无形资产、使用权资产、长期待摊费用等作为一个资产组。由于门店资产组中的固定资产类别较多且定制化程度较高，相关资产不存在活跃的交易市场，公司无法对资产组的公允价值进行可靠估计，因此根据《企业会计准则第 8 号— —资产减值》第八条的相关规定，以资产组的预计未来现金流量现值作为其可收回金额，并对低于账面资产余额的资产组相应地计提资产减值准备。公司对于门店资产组的可收回金额的评估已结合以前年度绩效情况、当年经营业绩以及门店未来的经营预期，对于收入增长率、毛利率、费用率等重大参数进行复核，使得对于存在减值迹象的门店长期资产减值模型具备恰当性、各项参数具备合理性。因此，计提长期资产减值的计算依据为长期资产所在资产组的预计未来现金流量现值低于账面价值的部分。

综上所述，公司各类主要资产减值测试的计算依据充分，具有合理性。

## （三）减值损失确认时点与减值迹象发生时点具有匹配性，减值损失计提金额具有充分性

公司在资产负债表日对长期股权投资进行逐项检查，对存在减值迹象的长期股权投资按照企业会计准则的要求进行减值测试，并依据第三方评估师对长期股权投资出具的评估报告、市场价格等客观依据作为可回收金额，对长期股权投资计提相应的减值准备，因此长期股权投资的资产减值损失确认时点和减值迹象发生时点具有匹配性，减值损失计提金额具有充分性。

公司长期资产计提减值准备系公司管理层结合门店以前年度绩效情况、当年经营业绩以及门店未来的经营预期，对于收入增长率、毛利率、费用率等重大参数进行复核，使得对于存在减值迹象的门店长期资产减值模型具备恰当性、各项参数具备合理性，是基于资产减值测试工作的结果审慎作出的，因此长期资产的资产减值损失确认时点和减值迹象发生时点具有匹配性，减值损失计提金额具有充分性。

## 三、报告期内货币资金及相关交易性金融资产余额与利息收入的匹配性，维持大额货币资金及交易性金融资产的同时借入大量有息负债的原因及合理性，货币资金是否存在使用受限的情况

（一）报告期内，公司货币资金与利息收入具有匹配性，交易性金融资产与其收益具有匹配性

## 1、货币资金与利息收入的匹配性分析

报告期各期，发行人货币资金与利息收入的匹配性分析如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度/2025年12月31日</td><td rowspan=1 colspan=1>2024年度/2024年12月31日</td><td rowspan=1 colspan=1>2023年度/2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>330, 197. 57</td><td rowspan=1 colspan=1>399,619.26</td><td rowspan=1 colspan=1>583,906.96</td></tr><tr><td rowspan=1 colspan=1>其中：银行存款</td><td rowspan=1 colspan=1>251, 025. 60</td><td rowspan=1 colspan=1>380,809.56</td><td rowspan=1 colspan=1>549,013.05</td></tr><tr><td rowspan=1 colspan=1>银行存款月均余额</td><td rowspan=1 colspan=1>389,970.30</td><td rowspan=1 colspan=1>463,218.83</td><td rowspan=1 colspan=1>535,237.41</td></tr><tr><td rowspan=1 colspan=1>银行存款利息收入</td><td rowspan=1 colspan=1>2,172. 48</td><td rowspan=1 colspan=1>8,166.18</td><td rowspan=1 colspan=1>11,305.22</td></tr><tr><td rowspan=1 colspan=1>利息收入占银行存款月均余额比例</td><td rowspan=1 colspan=1>0.56%</td><td rowspan=1 colspan=1>1.76%</td><td rowspan=1 colspan=1>2.11%</td></tr></table>

注：银行存款月均余额=(Σ各月持有的银行存款的余额)/月份数。

发行人利息收入为银行存款的利息，收益率变动与市场存款利率走势密切相关。报告期各期，利息收入占银行存款月均余额的比例分别为 2.11%、1.76%和0.56%，报告期内收益率整体下行，与市场利率波动情况基本一致，2025 年度该比例下降较大，主要系该期间受银行政策调整等多重因素影响，银行存款利率普遍下降较大所致。该宏观变化与公司利息收入占银行存款平均余额比例的阶段性下降趋势基本吻合。

综上所述，整体而言，公司的货币资金与利息收入具有匹配性。

## 2、交易性金融资产与其收益的匹配性分析

报告期各期，发行人交易性金融资产主要包括权益工具投资、基金理财产品和结构性存款，交易性金融资产与其收益的匹配性分析如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>明细项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>155, 869. 01</td><td rowspan=1 colspan=1>329,053.43</td><td rowspan=1 colspan=1>73,597.18</td></tr><tr><td rowspan=1 colspan=1>其中：权益工具投资</td><td rowspan=1 colspan=1>9, 876. 45</td><td rowspan=1 colspan=1>33,516.45</td><td rowspan=1 colspan=1>38,893.22</td></tr><tr><td rowspan=1 colspan=1> Advantage Solutions Inc.</td><td rowspan=1 colspan=1>9, 876. 45</td><td rowspan=1 colspan=1>33,516.45</td><td rowspan=1 colspan=1>38,893.22</td></tr><tr><td rowspan=1 colspan=1>万达商管</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>宁波梅山保税港区康御投资合伙企业（有限合伙）</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其中：基金理财产品期末余额</td><td rowspan=1 colspan=1>75, 711. 79</td><td rowspan=1 colspan=1>95,076.46</td><td rowspan=1 colspan=1>34,103.71</td></tr><tr><td rowspan=1 colspan=1>基金理财产品当期平均持有额</td><td rowspan=1 colspan=1>71, 324. 08</td><td rowspan=1 colspan=1>87,897.86</td><td rowspan=1 colspan=1>36,299.68</td></tr><tr><td rowspan=1 colspan=1>基金理财产品当期收益</td><td rowspan=1 colspan=1>1, 434. 41</td><td rowspan=1 colspan=1>1,011.82</td><td rowspan=1 colspan=1>109.72</td></tr><tr><td rowspan=1 colspan=1>平均收益率</td><td rowspan=1 colspan=1>2.01%</td><td rowspan=1 colspan=1>1.15%</td><td rowspan=1 colspan=1>0.30%</td></tr><tr><td rowspan=1 colspan=1>其中：结构性存款期末余额</td><td rowspan=1 colspan=1>70,280. 78</td><td rowspan=1 colspan=1>200,460.52</td><td rowspan=1 colspan=1>600.25</td></tr><tr><td rowspan=1 colspan=1>结构性存款当期平均投资额</td><td rowspan=1 colspan=1>242,164. 38</td><td rowspan=1 colspan=1>152,750.68</td><td rowspan=1 colspan=1>5,864.38</td></tr><tr><td rowspan=1 colspan=1>结构性存款投资收益金额</td><td rowspan=1 colspan=1>5, 934.93</td><td rowspan=1 colspan=1>4,104.59</td><td rowspan=1 colspan=1>131.42</td></tr><tr><td rowspan=1 colspan=1>投资收益率</td><td rowspan=1 colspan=1>2. 45%</td><td rowspan=1 colspan=1>2.69%</td><td rowspan=1 colspan=1>2.24%</td></tr></table>

注 1：基金理财产品当期平均持有额=（Σ各月持有的基金理财产品的余额）/月份数；  
注 2：基金理财产品当期收益除分红、处置收益外，还包括期末未赎回产品的公允价值变动部分；  
注 3：结构性存款当期平均投资额=投资额 x 投资期限/365；  
注 4：结构性存款投资收益金额为结构性存款公允价值变动损益。

如上表所示，报告期各期，发行人交易性金融资产中，权益工具投资不存在利息或分红等收益。公司基金理财产品收益除分红、处置收益外，还包括期末未赎回产品的公允价值变动部分，各期公司基金理财产品的收益与当期平均持有额计算的平均收益率总体小幅提升，主要受市场客观因素影响所致。公司的结构性存款各年度的平均收益率分别为 2.24%、2.69%和 2.45%，总体与市场利率变化趋势一致。其中，2023 年公司购买的结构性存款利率较低主要系当年结构性存

款受挂钩标的市场行情影响所致。

综上所述，整体而言，公司交易性金融资产与其收益相匹配。

## （二）维持大额货币资金及交易性金融资产的同时借入大量有息负债的原因及合理性

报告期内，发行人货币资金、交易性金融资产及有息负债情况具体如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>330, 197.57</td><td rowspan=1 colspan=1>399,619.26</td><td rowspan=1 colspan=1>583,906.96</td></tr><tr><td rowspan=1 colspan=1>其中：不受限货币资金</td><td rowspan=1 colspan=1>296, 203. 43</td><td rowspan=1 colspan=1>384,066.62</td><td rowspan=1 colspan=1>569,776.91</td></tr><tr><td rowspan=1 colspan=1>其中：受限货币资金</td><td rowspan=1 colspan=1>33,994. 15</td><td rowspan=1 colspan=1>15,552.64</td><td rowspan=1 colspan=1>14,130.05</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>155, 869. 01</td><td rowspan=1 colspan=1>329,053.43</td><td rowspan=1 colspan=1>73,597.18</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>392, 689. 77</td><td rowspan=1 colspan=1>493,811.77</td><td rowspan=1 colspan=1>513,022.01</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动负债</td><td rowspan=1 colspan=1>74, 129. 00</td><td rowspan=1 colspan=1>184,802.86</td><td rowspan=1 colspan=1>179,235.19</td></tr><tr><td rowspan=1 colspan=1>租赁负债</td><td rowspan=1 colspan=1>920,326. 19</td><td rowspan=1 colspan=1>1,550,029.87</td><td rowspan=1 colspan=1>2,078,146.22</td></tr><tr><td rowspan=1 colspan=1>长期借款</td><td rowspan=1 colspan=1>81, 890. 00</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>34,988.98</td></tr></table>

报告期各期，公司现金流量情况如下表：  
单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流入小计</td><td rowspan=1 colspan=1>5,761, 271.95</td><td rowspan=1 colspan=1>7,517,334.41</td><td rowspan=1 colspan=1>8,761,828.77</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流出小计</td><td rowspan=1 colspan=1>5, 696,703.76</td><td rowspan=1 colspan=1>7,298,191.60</td><td rowspan=1 colspan=1>8,304,940.67</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>64, 568. 19</td><td rowspan=1 colspan=1>219,142.81</td><td rowspan=1 colspan=1>456,888.10</td></tr><tr><td rowspan=1 colspan=1>投资活动现金流入小计</td><td rowspan=1 colspan=1>3,830,075. 60</td><td rowspan=1 colspan=1>2,139,233.80</td><td rowspan=1 colspan=1>330,531.77</td></tr><tr><td rowspan=1 colspan=1>投资活动现金流出小计</td><td rowspan=1 colspan=1>3,781,223. 30</td><td rowspan=1 colspan=1>2,251,545.44</td><td rowspan=1 colspan=1>304,883.24</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>48,852.30</td><td rowspan=1 colspan=1>-112,311.64</td><td rowspan=1 colspan=1>25,648.53</td></tr><tr><td rowspan=1 colspan=1>筹资活动现金流入小计</td><td rowspan=1 colspan=1>480, 699. 17</td><td rowspan=1 colspan=1>530,520.63</td><td rowspan=1 colspan=1>628,019.10</td></tr><tr><td rowspan=1 colspan=1>筹资活动现金流出小计</td><td rowspan=1 colspan=1>708,583.24</td><td rowspan=1 colspan=1>823,753.34</td><td rowspan=1 colspan=1>1,285,213.80</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-227, 884. 07</td><td rowspan=1 colspan=1>-293,232.71</td><td rowspan=1 colspan=1>-657,194.69</td></tr></table>

2025 年度，发行人月均经营活动、投资活动和筹资活动流出金额为848,875.86 万元，公司营运资金规模较大，高于公司同期货币资金及交易性金融资产金额合计数，公司需要一定的借款以维持日常经营、投资和筹资活动。具

体而言，主要基于以下几个方面考虑：

## 1、保障运营稳定与资金安全

公司所处行业为超市行业，属于资金密集型行业，日常运营所需的资金投入较大，同时，公司正处于执行门店调改战略的关键阶段，需要投入大量资金进行调改门店建设。因此，公司在维持日常运营资金基础上，还需要保留一定的自有资金作为调改门店建设等事项的资金，出于满足日常资金周转、调改门店建设及其他潜在资金需求和兼顾资金安全性的考虑，公司在自有资金之外视需求通过增加短期有息负债来保持相对充足的现金流。

## 2、在建工程项目资金需求

除门店调改外，报告期内，公司根据经营规划等持续进行在建工程项目建设，在建工程项目建设需要资金投入，公司预留一定规模的银行贷款满足经营所需。随着报告期内在建工程逐步完工，对应的资金需求也逐渐减少。

## 3、维持多元融资渠道畅通

公司多年未进行股权融资，银行借款作为便捷高效的融资方式，其适度规模与授信额度的维持，有助于保障生产经营的流动性安全，防范突发资金需求可能带来的运营风险。

综上所述，出于保障运营稳定与资金安全、保证在建工程项目资金需求和维持多元融资渠道畅通等考量，报告期内公司维持货币资金及交易性金融资产的同时借入合理规模的有息负债的行为具有合理性和经济性。

## （三）公司货币资金使用受限情况分析

报告期内，发行人货币资金存在受限情况，均为司法冻结或保证金，且以司法冻结为主，受限资金明细具体如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>受限资金</td><td rowspan=1 colspan=1>33,994.15</td><td rowspan=1 colspan=1>15,552.64</td><td rowspan=1 colspan=1>14,130.05</td></tr><tr><td rowspan=1 colspan=1>其中：司法冻结</td><td rowspan=1 colspan=1>33,908.06</td><td rowspan=1 colspan=1>15,304.64</td><td rowspan=1 colspan=1>11,230.97</td></tr><tr><td rowspan=1 colspan=1>其中：保证金</td><td rowspan=1 colspan=1>86.09</td><td rowspan=1 colspan=1>248.00</td><td rowspan=1 colspan=1>2,899.08</td></tr></table>

报告期各期，公司受限资金金额分别为 14,130.05 万元、15,552.64 万元和33,994.15 万元，主要为司法冻结资金，各期金额分别为 11,230.97 万元、15,304.64万元和 33,908.06 万元。报告期内该金额呈现持续上升态势，主要系公司持续关闭门店引发诉讼相关的司法冻结所致，随着公司亏损门店的闭店逐步完成及相关诉讼进展，预计未来该金额不存在继续长期增加的可能。

报告期内，公司受限资金中的保证金减少，公司不存在长期大额缴纳保证金的情况，报告期内公司保证金总体金额较低。

四、结合产品保质期、过期产品处理方式、库龄情况、期后销售情况、存货跌价准备计提政策、同行业可比公司情况等说明未计提存货跌价准备的合理性，是否符合企业会计准则要求

报告期各期末，公司存货构成具体如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年12月31日</td><td rowspan=1 colspan=2>2024年12月31日</td><td rowspan=1 colspan=2>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>332, 357. 15</td><td rowspan=1 colspan=1>99.08%</td><td rowspan=1 colspan=1>700,163.63</td><td rowspan=1 colspan=1>99.20%</td><td rowspan=1 colspan=1>822,543.62</td><td rowspan=1 colspan=1>99.47%</td></tr><tr><td rowspan=1 colspan=1>其中：生鲜及加工</td><td rowspan=1 colspan=1>49,138. 64</td><td rowspan=1 colspan=1>14. 65%</td><td rowspan=1 colspan=1>69,568.44</td><td rowspan=1 colspan=1>9.86%</td><td rowspan=1 colspan=1>140,320.39</td><td rowspan=1 colspan=1>16.97%</td></tr><tr><td rowspan=1 colspan=1>食品用品（含服装）</td><td rowspan=1 colspan=1>283,218.53</td><td rowspan=1 colspan=1>84.43%</td><td rowspan=1 colspan=1>630,595.19</td><td rowspan=1 colspan=1>89.34%</td><td rowspan=1 colspan=1>682,223.23</td><td rowspan=1 colspan=1>82.50%</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>183. 64</td><td rowspan=1 colspan=1>0.05%</td><td rowspan=1 colspan=1>585.82</td><td rowspan=1 colspan=1>0.08%</td><td rowspan=1 colspan=1>1,172.22</td><td rowspan=1 colspan=1>0.14%</td></tr><tr><td rowspan=1 colspan=1>低值易耗品</td><td rowspan=1 colspan=1>2,902. 59</td><td rowspan=1 colspan=1>0.87%</td><td rowspan=1 colspan=1>5,088.87</td><td rowspan=1 colspan=1>0.72%</td><td rowspan=1 colspan=1>3,182.41</td><td rowspan=1 colspan=1>0.38%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>335,443.39</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>705,838.32</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>826,898.25</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

由上表可见，公司存货包括库存商品、原材料和低值易耗品，其中库存商品占各期存货金额的 99%以上，系存货最主要的组成部分。

从类别来看，库存商品主要分为生鲜及加工和食品用品（含服装）两大类，其中生鲜及加工包括烘焙熟食加工类、肉禽蛋类、蔬菜类、水产类、水果类等商品，食品用品（含服装）包括食品日配类、家百母婴类、烟酒类、服装类等商品。

结合公司商品的保质期特性、全链路效期管控与报损处理机制、库龄结构质量、期后销售变现能力以及存货跌价准备计提政策与同行业对比等分析，2023-2024 年公司未对存货计提存货跌价准备，2025 年公司对库存商品计提了

4,247.94 万元的存货跌价准备具备合理性，具体如下：

## （一）产品保质期

公司严格遵循《商品全链路效期管理办法》相关规定，对不同品类商品保质期实施分类效期管理，确保效期管控的针对性与有效性。报告期内各类库存商品的保质期情况如下：

<table><tr><td colspan="1" rowspan="1">大类</td><td colspan="1" rowspan="1">具体类别</td><td colspan="1" rowspan="1">保质期区间（天）</td><td colspan="1" rowspan="1">主要产品类别</td></tr><tr><td colspan="1" rowspan="5">生鲜及加工</td><td colspan="1" rowspan="1">蔬菜类</td><td colspan="1" rowspan="1">2-60</td><td colspan="1" rowspan="1">叶菜类、茄果瓜/番茄类、玉米类、调味类/汤料类、豆类/芽苗、结球/包菜类、根茎类、食用菌菇类、加工蔬菜类、有机蔬菜等</td></tr><tr><td colspan="1" rowspan="1">水果类</td><td colspan="1" rowspan="1">1-15</td><td colspan="1" rowspan="1">核果/干果、浆果/葡提、苹果/梨、桃/李/杏/枣、瓜类、柑橘橙柚、热带果、草莓/莓果/小番茄、加工水果等</td></tr><tr><td colspan="1" rowspan="1">烘焙熟食加工类</td><td colspan="1" rowspan="1">1-90</td><td colspan="1" rowspan="1">小火锅、酱卤类、烧腊类、酱泡菜、中式菜类、休闲小吃及季节性商品、烤制类、炸类、即食餐食、西式熟食、拌菜类、鲜制米面、即食面食小吃、豆制品类、烘焙（标品、现制类）等</td></tr><tr><td colspan="1" rowspan="1">肉禽蛋类</td><td colspan="1" rowspan="1">1-180</td><td colspan="1" rowspan="1">蛋品、猪肉、牛肉、羊肉、鸡/鸭/鹅/鸽等</td></tr><tr><td colspan="1" rowspan="1">水产类</td><td colspan="1" rowspan="1">1-365</td><td colspan="1" rowspan="1">鲜/冻虾类、鲜/冻蟹贝类、海藻海蜇、鲜鱼类、冻鱼类、水发制品、活鱼类、活虾活蟹类、鲍参软体类、活龟蛙类、活贝类、观赏水族等</td></tr><tr><td colspan="1" rowspan="2">食品用品</td><td colspan="1" rowspan="1">食品日配类</td><td colspan="1" rowspan="1">3-1825</td><td colspan="1" rowspan="1">冷藏鲜奶、冷藏发酵乳/乳酸菌、冷藏饮品甜品、冷藏奶酪制品、冷藏面点/即食、冷藏肉制品、冰品、日配季节性商品、冷冻面点、冷冻休闲食品、冷冻快手菜、软性饮料、常温乳品、奶粉、冲调品、早餐主食品、保健食品、粥粉类、花草果茶、肉脯/海产/素食、散装休闲食品、饼干糕点、膨化食品、糖果/巧克力/果冻布丁、坚果/蜜饯、休闲食品季节性商品、大米、杂粮、面粉杂粮粉、面类/米粉类、罐头食品、常温小菜类、速食品、火腿肠类、干货（标品）、裸/自包装干货、食用油类、调味酱汁、调味粉料等</td></tr><tr><td colspan="1" rowspan="1">家百母婴类</td><td colspan="1" rowspan="1">4-长期</td><td colspan="1" rowspan="1">家用清洁用品、卫生医用保健品、保养护肤用品、个人清洁品、卫生用品、剃须用品、彩妆用品、洗护用品、婴儿喂育用品、婴儿纺织品及配件、婴儿护理用品、婴幼儿尿裤、营养/辅食、母婴奶粉、年节饰品、湿巾、手帕纸、卫生纸、图书、礼品/节庆饰品、箱包类、园艺、玩具、学习办公文具、球类、宠物生活、一次性纺织用品、户外类、家用器皿、餐具及配件、锅具、厨房用具、</td></tr><tr><td colspan="1" rowspan="2"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">一次性用品、家庭清洁用品、家具/收纳整理、洗衣/干衣用品、雨伞/雨具、卫浴用品、香氛产品、大家电、五金/汽百、内衣/内裤、袜子、拖鞋/鞋配件、床上用品、毛巾、家庭纺织品/服饰配件、厨房小家电、生活小家电、个护健康、数码影音等</td></tr><tr><td colspan="1" rowspan="1">烟酒类</td><td colspan="1" rowspan="1">7-长期</td><td colspan="1" rowspan="1">酒、香烟及配套</td></tr></table>

注：对于库存商品中的服装类，公司不但在存货的管理和销售定价上有主导权，而且也享有合同约定的退货选择权，因此公司的服装类存货不存在存货跌价的风险，无需计提跌价准备。

报告期内，公司的存货实际周转天数均在保质期范围内。具体情况如下：
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>2025年营业成本(万元）</td><td rowspan=1 colspan=1>2025年平均存货 (万元)</td><td rowspan=1 colspan=1>2025年平均周转率</td><td rowspan=1 colspan=1>2025年平均周转天数（天）</td><td rowspan=1 colspan=1>最低保质期（天）</td><td rowspan=1 colspan=1>最高保质期 (天)</td><td rowspan=1 colspan=1>大类平均保质期（天）</td></tr><tr><td rowspan=1 colspan=1>蔬菜类</td><td rowspan=1 colspan=1>257, 677. 37</td><td rowspan=1 colspan=1>4, 167. 29</td><td rowspan=1 colspan=1>61. 83</td><td rowspan=1 colspan=1>5.90</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>60</td><td rowspan=1 colspan=1>2-60</td></tr><tr><td rowspan=1 colspan=1>水果类</td><td rowspan=1 colspan=1>497, 951. 80</td><td rowspan=1 colspan=1>9, 522. 72</td><td rowspan=1 colspan=1>52. 29</td><td rowspan=1 colspan=1>6.98</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>1-15</td></tr><tr><td rowspan=1 colspan=1>烘焙熟食加工类</td><td rowspan=1 colspan=1>384, 664. 46</td><td rowspan=1 colspan=1>11, 307. 48</td><td rowspan=1 colspan=1>34.02</td><td rowspan=1 colspan=1>10.73</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>90</td><td rowspan=1 colspan=1>1-90</td></tr><tr><td rowspan=1 colspan=1>肉禽蛋类</td><td rowspan=1 colspan=1>457, 534. 24</td><td rowspan=1 colspan=1>22,344. 32</td><td rowspan=1 colspan=1>20.48</td><td rowspan=1 colspan=1>17. 83</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>180</td><td rowspan=1 colspan=1>1-180</td></tr><tr><td rowspan=1 colspan=1>水产类</td><td rowspan=1 colspan=1>219, 924. 68</td><td rowspan=1 colspan=1>12, 247. 62</td><td rowspan=1 colspan=1>17. 96</td><td rowspan=1 colspan=1>20.33</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>365</td><td rowspan=1 colspan=1>1-365</td></tr><tr><td rowspan=1 colspan=1>食品日配类</td><td rowspan=1 colspan=1>1, 563, 017. 03</td><td rowspan=1 colspan=1>203,212. 54</td><td rowspan=1 colspan=1>7. 69</td><td rowspan=1 colspan=1>47. 45</td><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>1825</td><td rowspan=1 colspan=1>3-1,825</td></tr><tr><td rowspan=1 colspan=1>家百母婴类</td><td rowspan=1 colspan=1>603, 817. 55</td><td rowspan=1 colspan=1>115, 033. 03</td><td rowspan=1 colspan=1>5.25</td><td rowspan=1 colspan=1>69.54</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>长期</td><td rowspan=1 colspan=1>4-长期</td></tr><tr><td rowspan=1 colspan=1>烟酒类</td><td rowspan=1 colspan=1>269, 850. 26</td><td rowspan=1 colspan=1>127, 162. 78</td><td rowspan=1 colspan=1>2.12</td><td rowspan=1 colspan=1>172. 00</td><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>长期</td><td rowspan=1 colspan=1>7-长期</td></tr><tr><td rowspan=1 colspan=1>服装类</td><td rowspan=1 colspan=1>14, 592. 78</td><td rowspan=1 colspan=1> 11, 262. 62</td><td rowspan=1 colspan=1>1.30</td><td rowspan=1 colspan=1>281.70</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>4, 269,030. 18</td><td rowspan=1 colspan=1>516, 260. 39</td><td rowspan=1 colspan=1>8.27</td><td rowspan=1 colspan=1>44. 14</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

注：对于库存商品中的服装类，公司不但在存货的管理和销售定价上有主导权，而且也享有合同约定的退货选择权，因此公司的服装类存货不存在存货跌价的风险，无需计提跌价准备，下同。

（续）
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">2024年营业成本（万元）</td><td colspan="1" rowspan="1">2024年平均存货（万元）</td><td colspan="1" rowspan="1">2024年平均周转率</td><td colspan="1" rowspan="1">2024年平均周转天数（天）</td><td colspan="1" rowspan="1">最低保质期（天）</td><td colspan="1" rowspan="1">最高保质期（天）</td><td colspan="1" rowspan="1">大类平均保质期（天）</td></tr><tr><td colspan="1" rowspan="1">蔬菜类</td><td colspan="1" rowspan="1">355,797.27</td><td colspan="1" rowspan="1">5,281.12</td><td colspan="1" rowspan="1">67.37</td><td colspan="1" rowspan="1">5.34</td><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">60</td><td colspan="1" rowspan="1">2-60</td></tr><tr><td colspan="1" rowspan="1">水果类</td><td colspan="1" rowspan="1">525,561.77</td><td colspan="1" rowspan="1">9,55.90</td><td colspan="1" rowspan="1">55.00</td><td colspan="1" rowspan="1">6.55</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">15</td><td colspan="1" rowspan="1">1-15</td></tr><tr><td colspan="1" rowspan="1">烘焙熟食加工类</td><td colspan="1" rowspan="1">318,775.35</td><td colspan="1" rowspan="1">7,317.46</td><td colspan="1" rowspan="1">43.56</td><td colspan="1" rowspan="1">8.26</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">90</td><td colspan="1" rowspan="1">1-90</td></tr><tr><td colspan="1" rowspan="1">肉禽蛋类</td><td colspan="1" rowspan="1">663,637.37</td><td colspan="1" rowspan="1">35,769.50</td><td colspan="1" rowspan="1">18.55</td><td colspan="1" rowspan="1">19.40</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">180</td><td colspan="1" rowspan="1">1-180</td></tr><tr><td colspan="1" rowspan="1">水产类</td><td colspan="1" rowspan="1">319,713.42</td><td colspan="1" rowspan="1">15,548.37</td><td colspan="1" rowspan="1">20.56</td><td colspan="1" rowspan="1">17.51</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">365</td><td colspan="1" rowspan="1">1-365</td></tr><tr><td colspan="1" rowspan="1">食品日配类</td><td colspan="1" rowspan="1">2,108,463.51</td><td colspan="1" rowspan="1">332,710.75</td><td colspan="1" rowspan="1">6.34</td><td colspan="1" rowspan="1">56.81</td><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">1825</td><td colspan="1" rowspan="1">3-1825</td></tr><tr><td colspan="1" rowspan="1">家百母婴类</td><td colspan="1" rowspan="1">797,133.41</td><td colspan="1" rowspan="1">176,093.33</td><td colspan="1" rowspan="1">4.53</td><td colspan="1" rowspan="1">79.53</td><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">长期</td><td colspan="1" rowspan="1">4-长期</td></tr><tr><td colspan="1" rowspan="1">烟酒类</td><td colspan="1" rowspan="1">242,104.57</td><td colspan="1" rowspan="1">158,556.55</td><td colspan="1" rowspan="1">1.53</td><td colspan="1" rowspan="1">235.77</td><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">长期</td><td colspan="1" rowspan="1">7-长期</td></tr><tr><td colspan="1" rowspan="1">服装类</td><td colspan="1" rowspan="1">19,591.84</td><td colspan="1" rowspan="1">20,520.64</td><td colspan="1" rowspan="1">0.95</td><td colspan="1" rowspan="1">377.07</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">-</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">5,350,778.51</td><td colspan="1" rowspan="1">761,353.62</td><td colspan="1" rowspan="1">7.03</td><td colspan="1" rowspan="1">51.22</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>2023年营业成本（万元）</td><td rowspan=1 colspan=1>2023年平均存货（万元）</td><td rowspan=1 colspan=1>2023年平均周转率</td><td rowspan=1 colspan=1>2023年平均周转天数（天）</td><td rowspan=1 colspan=1>最低保质期(天）</td><td rowspan=1 colspan=1>最高保质期（天）</td><td rowspan=1 colspan=1>大类平均保质期（天）</td></tr><tr><td rowspan=1 colspan=1>蔬菜类</td><td rowspan=1 colspan=1>385,902.06</td><td rowspan=1 colspan=1>5,326.88</td><td rowspan=1 colspan=1>72.44</td><td rowspan=1 colspan=1>4.97</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>60</td><td rowspan=1 colspan=1>2-60</td></tr><tr><td rowspan=1 colspan=1>水果类</td><td rowspan=1 colspan=1>583,746.72</td><td rowspan=1 colspan=1>10.052.26</td><td rowspan=1 colspan=1>58.07</td><td rowspan=1 colspan=1>6.20</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>1-15</td></tr><tr><td rowspan=1 colspan=1>烘焙熟食加工类</td><td rowspan=1 colspan=1>334,538.47</td><td rowspan=1 colspan=1>7,768.84</td><td rowspan=1 colspan=1>43.06</td><td rowspan=1 colspan=1>8.36</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>90</td><td rowspan=1 colspan=1>1-90</td></tr><tr><td rowspan=1 colspan=1>肉禽蛋类</td><td rowspan=1 colspan=1>670,224.30</td><td rowspan=1 colspan=1>39,000.93</td><td rowspan=1 colspan=1>17.18</td><td rowspan=1 colspan=1>20.95</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>180</td><td rowspan=1 colspan=1>1-180</td></tr><tr><td rowspan=1 colspan=1>水产类</td><td rowspan=1 colspan=1>361,246.72</td><td rowspan=1 colspan=1>18,384.88</td><td rowspan=1 colspan=1>19.65</td><td rowspan=1 colspan=1>18.32</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>365</td><td rowspan=1 colspan=1>1-365</td></tr><tr><td rowspan=1 colspan=1>食品日配类</td><td rowspan=1 colspan=1>2,626,689.70</td><td rowspan=1 colspan=1>433,623.97</td><td rowspan=1 colspan=1>6.06</td><td rowspan=1 colspan=1>59.43</td><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>1825</td><td rowspan=1 colspan=1>3-1825</td></tr><tr><td rowspan=1 colspan=1>家百母婴类</td><td rowspan=1 colspan=1>919,762.25</td><td rowspan=1 colspan=1>223,343.80</td><td rowspan=1 colspan=1>4.12</td><td rowspan=1 colspan=1>87.42</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>长期</td><td rowspan=1 colspan=1>4-长期</td></tr><tr><td rowspan=1 colspan=1>烟酒类</td><td rowspan=1 colspan=1>256,408.53</td><td rowspan=1 colspan=1>173,763.45</td><td rowspan=1 colspan=1>1.48</td><td rowspan=1 colspan=1>243.97</td><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>长期</td><td rowspan=1 colspan=1>7-长期</td></tr><tr><td rowspan=1 colspan=1>服装类</td><td rowspan=1 colspan=1>29,445.75</td><td rowspan=1 colspan=1>20,985.35</td><td rowspan=1 colspan=1>1.40</td><td rowspan=1 colspan=1>256.56</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>6,167,964.50</td><td rowspan=1 colspan=1>932,250.36</td><td rowspan=1 colspan=1>6.62</td><td rowspan=1 colspan=1>54.41</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

## （二）过期产品处理方式

报告期内，公司不存在过期商品情况，通过建立并严格执行全链路效期管控体系，实现对临期商品的精准识别、及时处置，从源头杜绝商品过期情况发生，存货无因过期导致的跌价风险。

结合各类商品保质期特性，公司建立了覆盖“采购入库-仓储保管-门店销售-过期前处置”全链路的效期管控体系，严格遵循《商品全链路效期管理办法》《临近保质期食品管理制度》等内部制度规定，形成“预防预警-定期排查-临期处置-过期前销毁”的闭环管理流程，确保存货在保质期内实现顺利销售或完成处置，从流程管控层面防范因过期积压导致的存货跌价风险，具体管控措施如下：

## 1、源头预防与分级预警

公司建立严格的进货验收标准，明确所有商品标注日期不得晚于到货日期（严禁“早产”商品入库），同一 SKU 商品同一批次到货数量不超过 3 批次，从采购源头控制效期风险；同时，针对不同保质期商品设置分级效期预警机制，明确物流在库、门店在库等各环节预警阈值及禁售线标准，例如保质期≤3天的商品入库当日即触发预警，保质期＞365 天的商品剩余保质期≤90 天启动预警，确保临期商品及时识别。

## 2、定期排查与专区管控

门店按制度要求定期开展库存及货架商品效期排查，发现临近保质期食品立即撤离正常销售区域，在食品安全云网系统或纸质台账完整登记商品名称、条码、生产日期、保质期等关键信息，并设立“临近保质期食品销售专区”集中陈列，醒目张贴提示标识，安排专人每日清点管理；对于冷链等无法集中陈列的特殊商品，采用临保贴码方式单独标识提示。

针对生鲜及加工类易损耗商品，公司实行专项管控：各门店生鲜及加工商品采用实地盘存制。公司各门店于每月末对生鲜及加工存货进行全盘，盘点期间按实物数量进行盘点及称重，门店将盘点结果输入在 YHDOS系统中，系统根据盘点数量与账面库存数量生成盘点差异单据，SAP 系统根据移动加权平均价格及盘点差异进行账务处理，损耗直接计入主营业务成本。每次生鲜及加工盘点均有公司防损人员进行监盘，以保证盘点结果的准确性。对不易保存的水果、蔬菜执行每日清点、及时降价促销，若产生损失则直接计入当期损益。

## 3、临期处置与退换货管理

针对临近保质期商品，门店通过促销折价、买赠组合等方式加快出清，需调整售价的严格履行内部审批流程；对于采购协议约定可退换货的临期商品，及时办理退换货手续；对于系统标注不可退换的临期商品，由商品中心主动对接供应商协商处置方案或进行直接报损，确保临期商品妥善消化。

## 4、强制下架与规范报损销毁

公司严格执行无条件下架规则，明确标品下架时限标准如下：

保质期＞30天的商品到期前 7天下架，7天＜保质期≤30 天的商品到期前3天下架，3 天＜保质期≤7 天的商品到期前 1 天下架；生鲜及 3R 商品按专项管理规定执行下架流程。对于过期前未售出或未完成退换货的商品，严格按照报损流程处置，在指定区域采取捣碎、染色等破坏性方式销毁，并完成报损记录台账的记录，包括相关商品的名称、规格、数量、生产批号（或生产日期）、销毁时间和地点、销毁方式、承毁人、监销人等内容，相关资料按规定保存不少于 2年，确保过期商品不回流市场，保障处置流程合规可追溯。

## 5、不良库存专项处理

针对临保商品、高库存商品、60 天无周转商品等不良库存类型，建立每周常态化处理机制，由平台订单交易岗负责提取不良库存清单，买手团队审核确认处置方案，大区协同门店制定并执行消化计划，确保不良库存及时清零，避免形成长期积压。

上述全链路闭环管控流程的有效执行，确保报告期内所有商品过期前均得到规范处置，无违规流转情况。因此，公司效期管控体系具有有效性。

## （三）库龄情况

报告期各期末，公司库存商品的库龄情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="2">项目</td><td colspan="3" rowspan="1">2025年12月31日</td><td colspan="3" rowspan="1">2024年12月31日</td><td colspan="3" rowspan="1">2023年12月31日</td></tr><tr><td colspan="1" rowspan="1">1年内</td><td colspan="1" rowspan="1">1-2年</td><td colspan="1" rowspan="1">2年以上</td><td colspan="1" rowspan="1">1年内</td><td colspan="1" rowspan="1">1-2年</td><td colspan="1" rowspan="1">2年以上</td><td colspan="1" rowspan="1">1年内</td><td colspan="1" rowspan="1">1-2年</td><td colspan="1" rowspan="1">2年以上</td></tr><tr><td colspan="1" rowspan="1">蔬菜类</td><td colspan="1" rowspan="1">3, 143. 47</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5,191.10</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5,371.15</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">水果类</td><td colspan="1" rowspan="1">8,675. 69</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">10,369.75</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">8,742.05</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">烘焙熟食加工类</td><td colspan="1" rowspan="1">14, 142. 18</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">8,472.79</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">6,162.13</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">肉禽蛋类</td><td colspan="1" rowspan="1">14, 369. 86</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">30,318.79</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">41,220.22</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">水产类</td><td colspan="1" rowspan="1">8,807. 44</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">15,687.80</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">15,408.94</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">食品日配类</td><td colspan="1" rowspan="1">107, 080. 94</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">299,344.14</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">366,077.36</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">家百母婴类</td><td colspan="1" rowspan="1">75, 614. 65</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">154,451.40</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">197,735.26</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">服装类</td><td colspan="1" rowspan="1">3,257.01</td><td colspan="1" rowspan="1">17.70</td><td colspan="1" rowspan="1">17.55</td><td colspan="1" rowspan="1">9,840.56</td><td colspan="1" rowspan="1">9,392.42</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">10,332.88</td><td colspan="1" rowspan="1">11,475.41</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">烟酒类</td><td colspan="1" rowspan="1">87,790.06</td><td colspan="1" rowspan="1">9,108.16</td><td colspan="1" rowspan="1">332. 46</td><td colspan="1" rowspan="1">139,819.95</td><td colspan="1" rowspan="1">9,774.48</td><td colspan="1" rowspan="1">7,500.45</td><td colspan="1" rowspan="1">137,322.93</td><td colspan="1" rowspan="1">16,722.53</td><td colspan="1" rowspan="1">5,972.76</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">322, 881. 29</td><td colspan="1" rowspan="1">9,125.86</td><td colspan="1" rowspan="1">350.00</td><td colspan="1" rowspan="1">673,496.28</td><td colspan="1" rowspan="1">19,166.90</td><td colspan="1" rowspan="1">7,500.45</td><td colspan="1" rowspan="1">788,372.92</td><td colspan="1" rowspan="1">28,197.94</td><td colspan="1" rowspan="1">5,972.76</td></tr></table>

报告期各期末，公司库龄在1年以内的库存商品占比分别为95.85%、96.19%、97.15%，均在 95%以上，库龄结构整体良好。其中，生鲜及加工类以及部分食品用品类商品库龄均在 1 年以内，且多数为短期周转商品，与该类商品短保质期特性及高频管控要求相匹配，有效保障了商品新鲜度；库龄超过 1年的商品主要集中于烟酒、服装等品类，其中烟酒类商品因具备长期保存特性(白酒、香烟可长期保存，葡萄酒保质期长达 10 年)，即使库龄超过 1 年仍处于正常保质期，2025年酒类产品市场价格下降幅度较大，因此计提了减值；服装类商品因公司在存货管理与销售定价上具有主导权，而且也享有合同约定的退货选择权，存货跌价风险较低，公司基于会计政策按照成本与可变现净值孰低对成本高于可变现净值的存货计提存货跌价准备，2025年末计提的存货跌价准备金额为4,247.94万元。

因此，公司库存商品的库龄主要分布在 1年以内，存在少量商品库龄超过 1年，主要系其具有可长期保存等商品特性所致。

## （四）库存商品期后销售情况

报告期各期末，发行人库存商品期后结转情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>库存商品账面余额</td><td rowspan=1 colspan=1>339, 691. 32</td><td rowspan=1 colspan=1>700,163.63</td><td rowspan=1 colspan=1>822,543.62</td></tr><tr><td rowspan=1 colspan=1>期后结转金额</td><td rowspan=1 colspan=1>757, 072. 13</td><td rowspan=1 colspan=1>828,955.86</td><td rowspan=1 colspan=1>993,967.40</td></tr><tr><td rowspan=1 colspan=1>期后结转率</td><td rowspan=1 colspan=1>222. 87%</td><td rowspan=1 colspan=1>118.39%</td><td rowspan=1 colspan=1>120.84%</td></tr></table>

注:期后结转金额为期后两个月存货结转主营业务成本的金额。

如上表所示，报告期各期末，公司库存商品期后两个月结转比例分别为120.84%、118.39%和 222.87%，2025 年末库存商品期后结转比例较高，主要系2026 年春节时间较晚，期末备货的量比以往年度显著较低，报告期内，公司存货期后结转情况整体良好。

## （五）存货跌价准备计提政策及与同行业可比公司对比情况

根据同行业上市公司披露的年度报告，公司存货跌价准备计提政策与同行业上市公司对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>存货跌价准备的计提政策</td></tr><tr><td rowspan=1 colspan=1>家家悦</td><td rowspan=1 colspan=1>存货跌价准备一般按单个存货项目计提；对于单品数量繁多的存货，按存货类别计提。资产负债表日如果以前减记存货价值的影响因素已经消失，则减记的金额予以恢复，并在原已计提的存货跌价准备的金额内转回，转回的金额计入当期损益。</td></tr><tr><td rowspan=1 colspan=1>步步高</td><td rowspan=1 colspan=1>资产负债表日，同一项存货中一部分有合同价格约定、其他部分不存在合同价格的，分别确定其可变现净值，并与其对应的成本进行比较，分别确定存货跌价准备的计提或转回的金额。</td></tr><tr><td rowspan=1 colspan=1>红旗连锁</td><td rowspan=1 colspan=1>期末按照单个存货项目计提存货跌价准备；但对于数量繁多、单价较低的存货，按照存货类别计提存货跌价准备；与在同一地区生产和销售的产品系列相关、具有相同或类似最终用途或目的，且难以与其他项目分开计量的存货，则合并计提存货跌价准备。以前减记存货价值的影响因素已经消失的，减记的金额予以恢复，并在原已计提的存货跌价准备金额内转回，转回的金额计入当期损益。</td></tr><tr><td rowspan=1 colspan=1>三江购物</td><td rowspan=1 colspan=1>按单个存货项目计算的成本高于其可变现净值的差额，计提存货跌价准备，计入当期损益。</td></tr><tr><td rowspan=1 colspan=1>永辉超市</td><td rowspan=1 colspan=1>资产负债表日，存货成本高于其可变现净值的，计提存货跌价准备。公司通常按照类别存货项目计提存货跌价准备，资产负债表日，以前减记存货价值的影响因素已经消失的，存货跌价准备在原已计提的金额内转回。</td></tr></table>

公司存货跌价准备计提政策严格遵循《企业会计准则第 1 号——存货》要求，与同行业上市公司的计提政策不存在显著差异。

从实际计提比例来看，同行业上市公司中，红旗连锁报告期内亦未计提存货跌价准备，家家悦2025 年度存货跌价准备计提比例为 0.82%，计提比例均较低。因此，超市行业企业因存货周转效率高、管控体系成熟，普遍存在低计提或不计提存货跌价准备的行业惯例。公司对存货跌价准备的计提情况与同行业可比公司不存在显著差异。

（六）存货 2023-2024 年未计提跌价准备、2025 年度计提跌价准备的合理性

1、库存商品 2023-2024 年未计提跌价准备、2025 年度计提跌价准备的合理性

结合公司商品的保质期特性、全链路效期管控与报损处理机制、库龄结构质量、期后销售变现能力以及存货跌价准备计提政策与同行业对比等分析，2023-2024 年公司未对存货计提存货跌价准备，2025 年公司对库存商品计提了4,247.94 万元的存货跌价准备，具体如下：

（1）全链路效期管理消除存货跌价隐患。公司针对不同品类商品的保质期特性实施差异化分类管理，对于保质期较短的生鲜及加工类商品（1-365 天），建立“预防-排查-处理-销毁”全链路闭环管控流程，通过入库即预警、每日清点、临期促销等措施从源头规避过期积压风险；对于保质期较长的食品用品类商品（多数 1-3年及以上，烟酒类通常可长期保存），制定清晰的管理标准，保障库存价值稳定。报告期内，商品过期前均按制度规范销毁。从管控层面降低了存货跌价隐患。

（2）优良库龄结构反映公司库存商品质量可靠。报告期各期末，公司 1 年以内库龄的库存商品占比均保持在 95%以上，其中生鲜及加工类商品库龄均在 1年以内且周转天数约在 15 天以内，短期周转特性保障商品新鲜度；长库龄商品（1年以上）主要为烟酒等可长期保存品类，仍处于正常保质期内，2025 年酒类产品存在价格下降幅度较大的情况，已足额进行存货跌价准备的计提。公司整体库龄结构健康，提供了质量保障。

（3）期后销售情况良好，无滞销积压。报告期各期末，公司库存商品期后两个月结转率均超过 100%，期后销售流转顺畅。各类存货均展现出较强的变现能力：生鲜及加工类商品周转快、结转率高；食品用品类中长库龄烟酒商品因市场需求稳定可正常销售；服装类商品凭借合同退货选择权保障库存消化。

（4）公司存货跌价准备计提政策严格遵循企业会计准则要求，与同行业可比公司政策无显著差异；从行业惯例来看，超市行业普遍存在低计提或不计提存货跌价准备的情况，公司 2023-2024 年未计提跌价准备、2025 年度计提跌价准备的处理方式符合行业实践，且与自身库存管控水平、库存质量及变现能力相匹配，具备充分的政策合规性与行业合理性。

综上，公司报告期内对库存商品 2023-2024 年未计提跌价准备、2025 年度计提跌价准备具备合理性。

## 2、原材料未计提跌价准备的合理性

原材料主要为加工品的辅助包装材料，均根据近期订单采购，无明确的保质期，可储存时间较长，同时相关产品的销售毛利较高，售价不低于存货的成本加上估计的销售费用和相关税费后的金额，管理层评估相关存货可变现净值高于成本，不存在存货跌价风险，无需计提存货跌价准备。

## 3、低值易耗品未计提跌价准备的合理性

公司低值易耗品主要为门店零售的可降解购物袋，根据门店经营周期订单采购，使用量大且周转快，无明确的保质期，可储存时间较长，每月根据使用量直接进入成本，且购物袋为有偿使用，收取对价不低于存货的成本加上估计的销售费用和相关税费后的金额，管理层评估其可变现净值大于账面金额，低值易耗品未计提跌价准备具有合理性。

## （七）公司对存货跌价准备的会计处理符合企业会计准则要求

公司对存货跌价准备的会计处理符合《企业会计准则第 1 号——存货》的相关要求，具体原因如下：

1、公司存货以生鲜及加工、食品百货等为主，整体保质期较短，具备周转效率高、变现能力强的行业属性；

2、公司制定了合理的存货跌价准备计提政策，在存货成本高于其可变现净值时计提跌价准备，与同行业上市公司不存在显著差异；且超市行业企业因存货周转效率高、管控体系成熟，普遍存在低计提或不计提存货跌价准备的行业惯例，公司存货跌价准备的实际计提情况与同行业上市公司不存在显著差异；

3、通过全链路效期管控与规范的报损处理机制，有效规避了存货过期积压风险；

4、报告期内公司存货库龄结构良好、期后销售变现顺畅。

综上所述，公司基于存货品类保质期等特性建立的全链路效期管控体系有效防范了存货跌价风险，优良的库龄结构及较强的期后变现能力，反映公司存货计提存货跌价准备的风险较低，且与同行业可比公司的实践不存在显著差异。因此，公司存货 2023-2024 年未计提跌价准备、2025 年度计提跌价准备具备合理性，符合企业会计准则要求。

## 五、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构、申报会计师主要执行了以下核查程序：

1、查阅公司年度报告、定期报告，了解公司营业收入持续下降、连续亏损的原因，取得公司营业外支出等科目明细，对与连续亏损相关的重要科目进行了分析。查阅同行业可比公司年度报告、定期报告，与同行业可比公司在报告期内的经营业绩变化进行对比，分析相关变动趋势是否存在差异及合理性，分析相关因素对公司后续经营的影响，判断相关风险提示是否充分；

2、查阅公司公告，了解并分析报告期内公司资产减值损失计提的情况；取得计提长期股权投资减值损失相关的第三方评估报告，了解并分析报告期内公司长期股权投资减值损失变化的原因及背景；

3、取得公司门店资产组减值测试底稿，了解并分析报告期内公司长期资产减值损失计提的情况及变动原因；

4、查阅企业会计准则，判断公司各类主要资产减值测试的计算依据是否合理，了解并分析公司判断减值迹象的具体依据是否充分。了解并分析公司资产减值损失的确认时点与减值迹象发生时点是否具有匹配性，分析减值损失计提金额是否具有充分性；

5、查阅公司年度报告、定期报告，进行公开信息检索，了解并进行货币资金与利息收入的匹配性分析，了解并分析利息收入发生变化的原因。取得公司交易性金融资产中基金理财产品及结构性存款持有情况及各期收益情况，进行匹配

性分析；

6、了解并分析公司存在较多货币资金及交易性金融资产的同时借入大量有息负债的原因，判断相关行为是否具有合理性和经济性；

7、取得受限资金明细表，了解并对公司货币资金使用受限情况及变动原因进行分析；

8、取得报告期各期末库存商品库龄表、主要商品保质期明细表及存货周转情况明细表，查阅公司年度报告、定期报告以及《商品全链路效期管理办法》、《临近保质期食品管理制度》等内部制度，了解并分析公司产品的保质期情况、过期产品处理方式、存货周转情况及期后实现销售情况，了解并分析公司的存货管理政策，了解公司的存货跌价准备计提政策，查阅同行业可比公司年度报告、定期报告，结合同行业可比公司存货跌价准备计提政策情况分析公司存货2023-2024 年未计提跌价准备、2025 年度计提跌价准备的合理性，查阅企业会计准则，判断是否符合企业会计准则要求。

## （二）核查意见

经核查，保荐机构、申报会计师认为：

1、报告期内发行人受闭店及深度转型、行业竞争格局加剧、消费需求总体放缓和部分居民消费习惯改变等因素的影响较深，营业收入持续下降，叠加各年有较高的资产减值损失、公允价值变动损失和营业外支出的影响，且公司作为全国性的线下零售龙头经营业绩承压更为明显，因此亦呈现连续亏损的情况，与同行业可比公司的相关业绩变动趋势存在差异具有合理性。发行人闭店及门店调改工作主要集中在 2025年完成。2026年，由于发行人大部分闭店及门店调改工作已完成，调改店进入稳态经营状态，预期未来调改门店的营业收入和净利润较调改前将保持增长，因此公司 2026 年经营业绩进一步下滑的风险较低。同时，相关风险提示已在募集说明书中进行了充分的披露；

2、报告期内公司资产减值损失计提金额变化的原因系公司在 2023 年计提了较多的长期股权投资减值损失，2024 年未予计提所致。2025 年度，云金科技根据交易约定的价格显示其市场价格降低，公司对其计提了减值损失。公司对各类主要资产均进行了减值测试，公司在资产负债表日进行长期股权投资减值迹象分析，执行减值测试，并依据第三方评估师对长期股权投资出具的评估报告及市场价格等客观证据对长期股权投资计提相应的减值准备。公司对长期资产减值测试的计算依据为长期资产所在资产组的预计未来现金流量现值低于账面价值的部分，相关计算依据具有充分性和客观性。公司资产减值损失确认时点与减值迹象发生时点具有匹配性，计提金额充分；

3、报告期内，公司货币资金与利息收入具有匹配性，交易性金融资产与其收益具有匹配性。公司维持较多货币资金及交易性金融资产的同时借入大量有息负债主要系基于保障运营稳定与资金安全、在建工程项目资金需求和维持多元融资渠道畅通的考量，具有合理性。公司货币资金存在使用受限的情况，主要系公司持续关闭门店引发诉讼相关的司法冻结所致；

4、公司基于存货品类保质期等特性建立的全链路效期管控体系有效防范了存货跌价风险，优良的库龄结构及较强的期后变现能力反映公司存货计提存货跌价准备的风险较低，且与同行业可比公司的实践不存在显著差异。2025 年公司计提存货跌价准备的原因主要系酒类产品市场价格下降较大。综合考虑上述因素，公司存货 2023-2024 年未计提跌价准备、2025 年度计提跌价准备具备合理性，符合企业会计准则要求。

## 问题 3 其他

3.1 根据申报材料，1）公司持有福建华通银行股份有限公司 27.5%的股权，未认定为财务性投资；2）公司持有云金科技 35%的股权，云金科技开展保理业务和小额业务，发行人拟出售所持云金科技剩余股权，目前正在确定受让方。

请发行人说明：（1）自本次董事会决议日前六个月至今，公司实施或拟实施财务性投资（含类金融业务）的具体情况，相关财务性投资是否已从本次募集资金总额中扣除；（2）福建华通银行股份有限公司股权未认定为财务性投资的依据是否充分，最近一期末公司是否存在持有金额较大、期限较长的财务性投资（包括类金融业务）情形；（3）云金科技所从事业务的性质及合规性、经营情况及风险情况，股权处置的最新进展。

请保荐机构及申报会计师核查并发表明确意见。

回复：

一、自本次董事会决议日前六个月至今，公司实施或拟实施财务性投资（含类金融业务）的具体情况，相关财务性投资是否已从本次募集资金总额中扣除

## （一）再融资对财务性投资的相关政策要求

《上市公司证券发行注册管理办法》第九条规定，“除金融类企业外，最近一期末不存在金额较大的财务性投资”；《公开发行证券的公司信息披露内容与格式准则第 61号——上市公司向特定对象发行证券募集说明书和发行情况报告书》第八条规定，“截至最近一期末，不存在金额较大的财务性投资的基本情况”。《证券期货法律适用意见第 18 号》就上述法规补充以下适用意见：

“1、财务性投资包括不限于：投资类金融业务；非金融企业投资金融业务(不包括投资前后持股比例未增加的对集团财务公司的投资)；与公司主营业务无关的股权投资；投资产业基金、并购基金；拆借资金；委托贷款；购买收益波动大且风险较高的金融产品等；

2、围绕产业链上下游以获取技术、原料或渠道为目的的产业投资，以收购或整合为目的的并购投资，以拓展客户、渠道为目的的拆借资金、委托贷款，如符合公司主营业务及战略发展方向，不界定为财务性投资；

3、上市公司及其子公司参股类金融公司的，适用本条要求；经营类金融业务的不适用本条，经营类金融业务是指将类金融业务收入纳入合并报表；

4、基于历史原因，通过发起设立、政策性重组等形成且短期难以清退的财务性投资，不纳入财务性投资计算口径；

5、金额较大是指，公司已持有和拟持有的财务性投资金额超过公司合并报表归属于母公司净资产的百分之三十（不包含对合并报表范围内的类金融业务的投资金额）；

6、本次发行董事会决议日前六个月至本次发行前新投入和拟投入的财务性投资金额应当从本次募集资金总额中扣除。投入是指支付投资资金、披露投资意向或者签订投资协议等；

7、公司应当结合前述情况，准确披露截至最近一期末不存在金额较大的财务性投资的基本情况。”

关于类金融业务，根据《监管规则适用指引—发行类第7 号》，除人民银行、银保监会、证监会批准从事金融业务的持牌机构外，其他从事金融活动的机构为类金融机构。类金融业务包括但不限于：融资租赁、融资担保、商业保理、典当及小额贷款等业务。与公司主营业务发展密切相关，符合业态所需、行业发展惯例及产业政策的融资租赁、商业保理及供应链金融，暂不纳入类金融计算口径。

## （二）自本次董事会决议日前六个月至今，公司不存在实施或拟实施财务性投资（含类金融业务）的情况，无需扣减本次募集资金总额

公司于2025年7月31日召开第六届董事会第四次会议审议通过本次发行的相关议案，自本次发行的董事会决议日前六个月起至今，公司不存在实施或拟实施财务性投资（含类金融业务）的情况，具体如下：

## 1、投资类金融业务

自本次发行相关董事会决议日前六个月起至本回复出具之日，公司不存在新增投资融资租赁、融资担保、商业保理、典当及小额贷款等类金融业务的情形，亦无拟投资类金融业务的计划。本次募集资金不存在直接或变相用于类金融业务的情形。

## 2、非金融企业投资金融业务

自本次发行董事会决议日前六个月至本回复出具之日，公司不存在新增投资金融业务的情形，亦无拟投资金融业务的计划。

## 3、与公司主营业务无关的股权投资

自本次发行董事会决议日前六个月至本回复出具之日，公司不存在新增与主营业务无关的股权投资，亦无拟投资与公司主营业务无关的股权投资计划。

## 4、投资或设立产业基金、并购基金

自本次发行董事会决议日前六个月至本回复出具之日，公司不存在拟投资产业基金、并购基金的情况，亦无拟投资产业基金、并购基金的计划。

## 5、拆借资金

自本次发行相关董事会决议日前六个月起至本回复出具之日，公司不存在新增实施或拟实施拆借资金的情形。

## 6、委托贷款

自本次发行董事会决议日前六个月至本回复出具之日，公司不存在委托贷款的情况，亦无拟实施委托贷款的计划。

## 7、购买收益波动大且风险较高的金融产品

自本次发行相关董事会决议日前六个月起至本回复出具之日，公司不存在购买收益波动大且风险较高的金融产品的情形。

综上所述，根据前述法规要求，截至 2025 年 12 月 31 日，公司持有的财务性投资合计 8,081.12 万元，占归属于母公司净资产比例为 4.35%，且自本次董事会决议日前六个月至今，公司不存在实施或拟实施财务性投资（含类金融业务）的情况，符合再融资对财务性投资的相关规定，无需扣减本次募集资金总额。

二、福建华通银行股份有限公司股权未认定为财务性投资的依据是否充分，最近一期末公司是否存在持有金额较大、期限较长的财务性投资（包括类金融业务）情形

（一）关于公司发起设立银行所持有股权不纳入财务性投资计算口径合理性的说明

1、公司发起设立银行所持有股权不纳入财务性投资计算口径符合相关法律法规的规定

根据《上市公司证券发行注册管理办法》第九条之第五款规定，“（五）除金融类企业外，最近一期末不存在金额较大的财务性投资”。《证券期货法律适用意见第 18 号》就上述法规的适用意见，其中第一条之第四款规定“（四）基于历史原因，通过发起设立、政策性重组等形成且短期难以清退的财务性投资，不纳入财务性投资计算口径”。

公司投资华通银行系基于历史原因，通过发起设立形成且短期难以清退，符合上述监管规定所述的不纳入财务性投资计算口径的情形。以下从历史原因、发起设立及短期内难以清退三个方面予以说明。

## （1）历史原因

## 1）华通银行设立的政策背景

我国民营银行的发展历程是一个由国家政策推动，配合法律制度不断健全的过程，具有深远的历史原因。

2010 年 5 月 7 日，国务院颁发了《关于鼓励和引导民间投资健康发展的若干意见》（国发〔2010〕13 号），意见第五条明确提出：“鼓励和引导民间资本进入金融服务领域：（十八）允许民间资本兴办金融机构。在加强有效监管、促进规范经营、防范金融风险的前提下，放宽对金融机构的股比限制。支持民间资本以入股方式参与商业银行的增资扩股，参与农村信用社、城市信用社的改制工作。鼓励民间资本发起或参与设立村镇银行、贷款公司、农村资金互助社等金融机构，放宽村镇银行或社区银行中法人银行最低出资比例的限制。”

在国家层面政策的推动下，当时的银行业主管部门中国银监会于 2012 年 5月 26 日颁布了《关于鼓励和引导民间资本进入银行业的实施意见》（银监发〔2012〕27 号）。该意见明确指出，支持民间资本与其他资本按同等条件进入银行业。支持符合银行业行政许可规章相关规定，公司治理结构完善，社会声誉、诚信记录和纳税记录良好，经营管理能力和资金实力较强，财务状况、资产状况良好，入股资金来源真实合法的民营企业投资银行业金融机构。民营企业可通过发起设立、认购新股、受让股权、并购重组等多种方式投资银行业金融机构。该意见要求，各级银行业监督管理机构审核银行业金融机构投资入股许可申请，要审慎考虑投资者对拟投资银行业金融机构稳健经营可能产生的影响，避免公司治理结构存在明显缺陷，关联关系复杂、关联交易频繁且异常，核心主业不突出，现金流量受经济景气影响较大，资产负债率、财务杠杆率畸高的企业投资银行业金融机构。

在国务院和行业主管部门出台试点政策后，地方政府也作出了积极响应。2013年 7月16日，福建省人民政府办公厅发布了《福建省人民政府办公厅关于贯彻落实金融支持经济结构调整和转型升级政策措施的实施意见》（闽政办〔2013〕89 号），明确提出：“支持在平潭综合实验区、泉州市金融服务实体经济综合改革试验区、厦门和福州两岸区域性金融服务中心率先试点由民间资本发起设立自担风险的民营银行、金融租赁公司和消费金融公司等金融机构。”

2014 年 3 月，银监会公布首批 5 家民营银行试点（深圳前海微众银行股份有限公司、浙江网商银行股份有限公司、天津金城银行股份有限公司、温州民商银行股份有限公司、上海华瑞银行股份有限公司），同年 12 月微众银行正式开业。

2015 年 6 月，国务院办公厅转发《银监会关于促进民营银行发展指导意见的通知》（国办发〔2015〕49 号），该通知明确了民营银行的准入条件、股东遴选、风险自担等核心规则，规定了民营银行的筹建程序和审批机构，民营银行进入常态化设立通道。

2016 年至 2019 年，重庆富民银行股份有限公司、四川新网银行股份有限公司等 14 家民营银行相继获批开业。至 2019 年，全国累计开业 19 家民营银行，包括于 2016年获批设立、2017 年开业的华通银行。2019年之后，监管部门未再批准设立民营银行，对于民营银行的监管重点转向股东股权管理、关联交易控制、流动性风险与合规经营，出台多项细则强化风险隔离。此后，民营银行由批量开业进入了风险管控与深化转型阶段。

基于上述可知，华通银行的设立是在国家政策强力推动民间资本进入银行业的大背景下的产物，具有深厚的历史原因。

2）华通银行设立的具体过程

2015 年颁布的国办发〔2015〕49 号文件由国务院办公厅转发给各省政府，明确要求各省、自治区、直辖市人民政府，国务院各部委、各直属机构认真执行。因此，在上述通知颁布后至 2016 年 1 月，在中国银监会福建监管局的推动下，福建省人民政府开始筹建华通银行。

根据国办发〔2015〕49 号文件的相关规定及当时有效的《中国银监会中资商业银行行政许可事项实施办法（2015修订）》（中国银监会令 2015年第2号），民营银行的准入标准较高1，包括诸多合规性要求和财务指标要求等，因此能够符合民营银行股东资质的民营企业并不多。

福建省人民政府根据省内民营企业的经营规模、市场地位、主营业务、市场形象等遴选符合资质的民营企业参与设立民营银行。永辉超市作为福建省 100强民营企业、服务业头部企业，主营业务为关系民生的生鲜、食品销售，市场知名度高、声誉良好，是当时福建省内符合发起设立民营银行股东资质的最优质的民营企业之一。基于以上考量，福建省人民政府邀请永辉超市参与设立民营银行。

2016 年2月26日，福建省人民政府向中国银监会发函《福建省人民政府关于推荐福建华通银行股份有限公司发起人的函》（闽政函〔2016〕7 号）：“福建省委省政府高度重视民营银行筹备工作。在贵会的大力支持和指导下，华通银行已经完成尽职调查和论证工作，目前，华通银行已明确由永辉超市、阳光控股有限公司、三棵树涂料股份有限公司、福建盼盼生物科技股份有限公司、福建圣农食品有限公司等十家企业共同发起设立。上述发起人均为福建省内注册的纯中资民营企业。福建省人民政府推荐上述民营企业作为华通银行发起人。”

在此历史背景下，如公司退出参与设立民营银行，对华通银行的组建工作将产生重大不利影响。因此，为了响应政策号召，践行社会责任，公司参与发起设立华通银行。报告期内，华通银行经营情况正常，公司重视履行社会责任，亦派驻1名董事参与华通银行管理。

综上所述，在2010年至2019 年国家强力推动民营资本进入银行业的历史大背景下，公司作为华通银行的发起人参与设立华通银行。公司自成立以来一直专注发展主业，并无进入银行业的战略规划。由于国家政策的强力推动，加之公司作为福建省内为数不多的能够符合民营银行股东资格的优质民营企业，在福建省人民政府的要求下，公司参与设立了华通银行。因此，公司持有华通银行股权系基于历史原因，为响应政策号召形成的。

## （2）发起设立

## 1）发起设立的方式符合法律法规和政策的规定

截至目前全国范围内获批的 19 家民营银行均为股份有限公司。发起设立属于股份有限公司的设立方式之一，符合《公司法》的规定。根据当时有效的《公司法》（2013 年修订）第七十七条，股份有限公司的设立，可以采取发起设立或者募集设立的方式。发起设立，是指由发起人认购公司应发行的全部股份而设立公司。因此，公司参与发起设立华通银行符合法律法规的规定。

自 2010 至 2019 年，国务院、银监会及福建省的相关政策中均提及民营银行可以通过发起方式设立，包括：《关于鼓励和引导民间投资健康发展的若干意见》（国发〔2010〕13 号）：“鼓励民间资本发起或参与设立村镇银行„”；《关于鼓励和引导民间资本进入银行业的实施意见》（银监发〔2012〕27 号）：“民营企业可通过发起设立、认购新股、受让股权、并购重组等多种方式投资银行业金融机构。”；《福建省人民政府办公厅关于贯彻落实金融支持经济结构调整和转型升级政策措施的实施意见》（闽政办〔2013〕89 号）：“由民间资本发起设立自担风险的民营银行”。因此，发起设立民营银行符合相关政策的规定。

## 2）公司为华通银行的发起人，华通银行的发起设立已获得有权部门批准

根据 2016 年 2 月福建省人民政府向中国银监会发送的《福建省人民政府关于推荐福建华通银行股份有限公司发起人的函》，公司为华通银行发起人股东之

根据当时有效的《中华人民共和国商业银行法》（2015 修正）以及《银监会关于促进民营银行发展指导意见的通知》（国办发〔2015〕49 号），民营银行设立及开业的审批部门为当时的中国银监会。民营银行的筹建申请由发起人共同向拟设地银监局提交，拟设地银监局受理并初步审查，报银监会审查并决定。民营银行开业申请由筹建组向所在地银监局提交，由所在地银监局受理、审查并决定。民营银行在收到开业核准文件并按规定领取金融许可证后，根据工商行政管理部门的规定办理登记手续，领取营业执照。民营银行应当自领取营业执照之日起6个月内开业。

2016 年 11 月 28 日，公司收到福建华通银行筹备工作组转发的《中国银监会关于筹建福建华通银行股份有限公司的批复》（银监复[2016]388 号），批复内容包括：“一、同意在中国（福建）自由贸易试验区平潭片区筹建福建华通银行，银行类别为民营银行。二、同意永辉超市股份有限公司、阳光控股有限公司分别认购该行总股本 27.5%、26.25%股份的发起人资格。”

基于上述，公司为华通银行的发起人股东，华通银行系以发起方式设立。华通银行的发起设立已经获得了当时有权审批监管部门中国银监会的批准，符合当时的法律法规和国家政策的规定。

（3）短期内难以清退

公司持有的华通银行的股权在短期内难以清退为客观事实情况。主要原因有以下两个方面：1）银行主要股东被从严监管，股权转让法律限制多，退出极其困难。银行业为强监管行业，且华通银行属于非上市民营银行，相比有公开的股权转让市场的上市银行而言，非上市民营银行的股权流动性较差，且监管机构的监管倾向是保持主要股东的稳定性，以满足银行的资本充实及合规经营要求。银行 5%以上股东的股权转让均需取得监管机构的事先审批。实操中，监管机构对于 5%以上股东的股权转让从严审查，这客观上导致银行主要股东退出困难。2）股东资格要求高导致意向受让方稀缺，民营企业受让方尤其稀缺。由于相关法律法规对于银行的股东资格具有很高的要求，接盘股东需要满足诸多合规性要求和财务指标要求，这使得能够承接银行股权的受让方较为稀缺，民营企业作为接盘方则更为稀缺。

此外，华通银行相关股东因监管要求自 2021 年以来一直在积极接洽意向受让方，但并无积极进展，此为客观事实，足以证明华通银行股权在短期内难以清退。

具体说明如下：

1）银行主要股东被从严监管，股权转让法律限制多，退出极其困难，非上市民营银行亦不适用公开股权转让方式

根据现行有效的《商业银行股权管理暂行办法》，商业银行的主要股东是指持有或控制商业银行5%以上股份或表决权，或持有资本总额或股份总额不足5%但对商业银行经营管理有重大影响的股东。商业银行主要股东应当根据监管规定书面承诺在必要时向商业银行补充资本，并通过商业银行每年向银监会2或其派出机构报告资本补充能力。

商业银行 5%以上股东属于监管部门重点监管的对象，因为主要股东需要承担商业银行资本充实、债务承担等诸多责任。在实操中，除非发生不符合股东资格、监管要求或股东自身出现经营风险等严重影响商业银行经营的情形，商业银行 5%以上的股东不会轻易发生变动。这也符合监管机构以“股东稳定、风险隔离、存款人保护”为核心的监管目标。

因此，监管部门对于 5%以上股东的转让也秉持从严审核的监管倾向。根据现行有效的《中华人民共和国商业银行法》（2015 修正）、《中国银保监会中资商业银行行政许可事项实施办法》（2022 修正）的相关规定，商业银行 5%以上股东变更需经监管机构审批，属于事前审批事项。实操中，5%以上股东转让审批难度大，审批周期长，客观上导致商业银行 5%以上股东退出极其困难。

## 2）股东资格要求高导致意向受让方稀缺，民营企业受让方尤其稀缺

监管部门对于商业银行股权受让方的资格要求非常高，导致受让方稀缺。根据现行有效的《中国银保监会中资商业银行行政许可事项实施办法》（2022 修正），中资商业银行股权变更，其股东资格条件同第九至十三条规定的新设中资商业银行法人机构的发起人入股条件。该法第十二条规定，境内非金融机构作为中资商业银行法人机构发起人，应当符合以下条件：（一）依法设立，具有法人资格；（二）具有良好的公司治理结构或有效的组织管理方式；（三）具有良好的社会声誉、诚信记录和纳税记录，能按期足额偿还金融机构的贷款本金和利息；（四）具有较长的发展期和稳定的经营状况；（五）具有较强的经营管理能力和资金实力；（六）财务状况良好，最近 3个会计年度连续盈利；（七）年终分配后，净资产达到全部资产的 30％（合并会计报表口径）；（八）权益性投资余额原则上不超过本企业净资产的 50％（合并会计报表口径），国务院规定的投资公司和控股公司除外；（九）入股资金为自有资金，不得以委托资金、债务资金等非自有资金入股，法律法规另有规定的除外；（十）银保监会规章规定的其他审慎性条件。该法第十三条规定，有以下情形之一的企业不得作为中资商业银行法人机构的发起人：（一）公司治理结构与机制存在明显缺陷；（二）关联企业众多、股权关系复杂且不透明、关联交易频繁且异常；（三）核心主业不突出且其经营范围涉及行业过多；（四）现金流量波动受经济景气影响较大；（五）资产负债率、财务杠杆率高于行业平均水平；（六）代他人持有中资商业银行股权；（七）其他对银行产生重大不利影响的情况。

在实操中，民营企业需要符合上述诸多合规监管要求及财务指标要求则更为困难。因此对于民营银行而言，主要股东退出更为困难。近年民营银行股东退出的案例包括江西裕民银行股份有限公司、安徽新安银行股份有限公司和无锡锡商银行股份有限公司，该等案例显示，民营银行的民企股东多因自身经营危机被迫退出，且多由地方国资接盘，本质是风险处置而非市场化退出。市场化退出需同时满足监管合规、接盘方资质、估值达成一致三个条件，现实中难以同时满足。

3）华通银行相关股东因监管要求自 2021 年以来一直在积极接洽意向受让方，但并无积极进展，此为客观事实，足以证明华通银行股权在短期内难以清退

2021 年 6 月起，华通银行即开始向福建银保监局城市银行处汇报关于潜在投资人基本情况、与潜在投资人的接洽进度及其投资意愿的变化情况。

在 2022 年 5 月 9 日中国银保监会福建监管局出具的《福建银保监局关于福建华通银行 2021 年度经营管理情况的监管意见》（闽银保监发[2022]70 号）中提到，监管机构要求主要股东阳光控股有限公司转让相关股权。华通银行接洽了7名意向投资者，但未取得实质性进展。华通银行于 2022年 5月20日回函提到“我行正全力寻找符合条件的投资者，但受外部政策环境影响，2名意向投资者均处于观望阶段。”2022 年 8 月 5 日，华通银行全体股东向福建省地方金融监督管理局报告，请求该局协调、推荐省内外优质名企，推动福建华通银行引进新股东事宜。后续未有进一步进展。

2023 年4月21日中国银保监会福建监管局出具的《福建银保监局关于福建华通银行 2022 年度经营管理情况的监管意见》（闽银保监发[2023]60 号）要求华通银行进一步落实股权转让事项。华通银行于 2023年5月 12日回函提到“我行正全力寻找符合条件的投资者，通过路演、拜访等方式加速推动新股东引进工作。截至报告日，已接洽 8家意向投资单位，但受外部政策环境影响，意向投资者均处于观望阶段。”

经连续多年监管要求，华通银行持续推进股权转让事宜，但受民企、国企入股民营银行意愿不强等影响，目前尚未找到适格投资者承接股权。

2025 年 12 月 26 日，华通银行在《关于福建华通银行引进新股东事宜的报告》中提到，“自2021 年起，我行及股东已与 10家意向投资人接洽。截至目前，受宏观经济环境及政策变化等影响，我行引进新股东事宜尚未取得进一步进展”。

由上述事实可知，自 2021 年至今，华通银行一直在尝试寻求股权受让方或引入新股东，但并未取得进展。即使在请求地方监管机构协调、推荐的情况下，企业入股民营银行的意愿并不强烈。上述事实从客观上说明了民营银行股东难以在短期内处置其股权。公司作为华通银行的主要股东，也一直积极帮助华通银行接洽部分国资意向受让方，但由于“一参一控”的限制（即《商业银行股权管理暂行办法》第十四条规定的，同一投资人及其关联方、一致行动人作为主要股东参股商业银行的数量不得超过 2 家，或控股商业银行的数量不得超过 1家），相关国资股东不能再承接华通银行股权。

基于上述，公司持有的华通银行的股权在短期内难以清退，此为客观事实，上述情况足以证明。

## 2、结论

综上所述，公司对华通银行的投资是基于历史原因，响应政策号召，通过发起设立形成且短期难以清退的投资，非公司主动投资行为。并且，公司长期作为华通银行第一大股东持有相关股权，与一般的财务性投资以获取财务回报为目的、持有股权比例较低、持有期限较短等特征存在本质不同，亦与部分以积极态度形成财务性投资的市场案例存在本质差异。

因此，公司对华通银行的投资系基于历史原因，通过发起设立形成且短期难以清退的财务性投资，符合《证券期货法律适用意见第 18 号》第一条之第四款规定，不需纳入财务性投资计算口径的依据充分。

（二）公司最近一期末不存在持有金额较大的财务性投资，公司符合再融资关于财务性投资的相关政策要求

## 1、发行人最近一期末不存在持有金额较大的财务性投资

截至 2025年12月31日，发行人财务报表中可能与财务性投资（包括类金融）相关的科目情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>资产科目</td><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>纳入财务性投资计算口径金额</td><td rowspan=1 colspan=1>财务性投资占归属于母公司净资产比例</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>155, 869. 01</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>其他应收款</td><td rowspan=1 colspan=1>30,182. 58</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>其他流动资产</td><td rowspan=1 colspan=1>127,362. 20</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>长期股权投资</td><td rowspan=1 colspan=1>213, 227. 40</td><td rowspan=1 colspan=1>8,081. 12</td><td rowspan=1 colspan=1>4. 35%</td></tr><tr><td rowspan=1 colspan=1>-年内到期的非流动资产</td><td rowspan=1 colspan=1>690.96</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>二</td></tr><tr><td rowspan=1 colspan=1>长期应收款</td><td rowspan=1 colspan=1>1,905. 28</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>投资性房地产</td><td rowspan=1 colspan=1>27, 854. 65</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>其他非流动金融资产</td><td rowspan=1 colspan=1>305,100. 00</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td></tr></table>

## （1）交易性金融资产

截至2025年12月31日，公司交易性金融资产账面价值为155,869.01万元，主要系理财产品、结构性存款和权益投资。其中银行短期理财产品和结构性存款系正常资金管理需求，不属于财务性投资，权益投资为美股 Advantage SolutionsInc.其为全球顶尖零售供应商服务公司，公司对其投资属于围绕产业链上下游以获取技术和渠道为目的的产业投资，符合公司主营业务及战略发展方向，不属于

财务性投资。

对于公司而言，Advantage Solutions Inc.在零售供应商销售、自有品牌发展及销售和营销服务方面具有战略协同效应，双方在包括关于大供应商直供模式、营销服务、内容开发、数据分析服务等方面进行商业合作，自 2016 年起双方开展合作。2017 年起，公司收到 Advantage Solutions Inc.的换股吸收合并公司联营公司子公司达曼国际的要约，吸收合并完成后，公司成为其股东。2018 年，公司子公司富平云商供应链管理有限公司与 Advantage Solutions Inc.组建合资公司瑞零通营销服务（上海）有限公司，向零售商及品牌商提供店内零售营销陈列服务和顾客体验式营销服务。

报告期内，公司围绕自身主业向其采购人力资源、信息技术、品牌设计、项目管理等服务，2023至2024 年的交易金额分别为716.51万元和77.92万元。

## （2）其他应收款

截至 2025 年 12 月 31 日，公司其他应收款账面价值 30,182.58 万元，主要系应收各类保证金、押金、采购及门店备用金、应收合并范围外关联方款项及其他款项等。上述其他应收款均系公司经营活动形成，不属于财务性投资。

## （3）其他流动资产

截至 2025年12月31日，公司其他流动资产账面价值 127,362.20 万元，主要系待认证进项税、待抵扣进项税等，均系公司经营活动形成，不属于财务性投资。

## （4）长期股权投资

截至 2025年12月31日，公司长期股权投资账面价值213,227.40 万元，系对合营企业和联营企业的投资，具体如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">企业名称</td><td colspan="1" rowspan="1">投资金额</td><td colspan="1" rowspan="1">主营业务</td><td colspan="1" rowspan="1">是否纳入财务性投资口径</td></tr><tr><td colspan="4" rowspan="1">一、合营企业</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司</td><td colspan="1" rowspan="1">2, 989. 77</td><td colspan="1" rowspan="1">食品销售</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="4" rowspan="1">二、联营企业</td></tr><tr><td colspan="1" rowspan="1">成都红旗连锁股份有限公司</td><td colspan="1" rowspan="1">77, 857. 05</td><td colspan="1" rowspan="1">商业零售</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">福建华通银行股份有限公司</td><td colspan="1" rowspan="1">74, 591. 69</td><td colspan="1" rowspan="1">银行</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">福建闽威实业股份有限公司</td><td colspan="1" rowspan="1">12, 224. 42</td><td colspan="1" rowspan="1">食品制造</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">福建省星源农牧科技股份有限公司</td><td colspan="1" rowspan="1">1, 117. 21</td><td colspan="1" rowspan="1">农牧</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">北京友谊使者商贸有限公司</td><td colspan="1" rowspan="1">10,795. 18</td><td colspan="1" rowspan="1">商业贸易</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">四川永创耀辉供应链管理有限公司</td><td colspan="1" rowspan="1">6,021. 32</td><td colspan="1" rowspan="1">商业服务</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">一二三三国际供应链管理股份有限公司</td><td colspan="1" rowspan="1">19, 054. 71</td><td colspan="1" rowspan="1">租赁和商务服务</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">云达在线（深圳）科技发展有限公司</td><td colspan="1" rowspan="1">494.94</td><td colspan="1" rowspan="1">技术服务</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">上海轩辉商服科技有限公司</td><td colspan="1" rowspan="1">81.12</td><td colspan="1" rowspan="1">商业服务</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">永辉云金科技有限公司</td><td colspan="1" rowspan="1">8,000.00</td><td colspan="1" rowspan="1">技术服务</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">213, 227. 40</td><td colspan="1" rowspan="1">·</td><td colspan="1" rowspan="1">：</td></tr></table>

以上公司中，永辉云金科技有限公司主要从事商业保理、小额贷款等类金融业务，上海轩辉商服科技有限公司主要从事保洁服务，属于财务性投资。其他公司无需纳入财务性投资计算口径，具体如下：

## 1）永辉彩食鲜发展有限公司

永辉彩食鲜发展有限公司主要从事食材供应链业务，主要面向党政军、企事业单位、餐饮酒店等客户提供一站式食材供应解决方案。公司对其投资属于围绕产业链上下游以获取渠道为目的的产业投资，符合公司主营业务及战略发展方向，不属于财务性投资。

报告期内，公司与其合作开展生鲜及食品百货团购等业务，对其采购商品/接受劳务或出售商品/提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">关联方</td><td colspan="1" rowspan="1">关联交易内容</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024 年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司及其子公司</td><td colspan="1" rowspan="1">采购商品</td><td colspan="1" rowspan="1">66,053.84</td><td colspan="1" rowspan="1">115,850.50</td><td colspan="1" rowspan="1">146,915.62</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司及其子公司</td><td colspan="1" rowspan="1">接受劳务</td><td colspan="1" rowspan="1">669.80</td><td colspan="1" rowspan="1">331.26</td><td colspan="1" rowspan="1">14.57</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公</td><td colspan="1" rowspan="1">接受劳务-物</td><td colspan="1" rowspan="1">8.58</td><td colspan="1" rowspan="1">11.32</td><td colspan="1" rowspan="1">-</td></tr><tr><td colspan="1" rowspan="1">司及其子公司</td><td colspan="1" rowspan="1">业服务</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司及其子公司</td><td colspan="1" rowspan="1">采购固定资产</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">76.72</td><td colspan="1" rowspan="1">76.02</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司及其子公司</td><td colspan="1" rowspan="1">销售商品</td><td colspan="1" rowspan="1">14, 007. 62</td><td colspan="1" rowspan="1">6,598.59</td><td colspan="1" rowspan="1">6,272.54</td></tr><tr><td colspan="1" rowspan="1">永辉彩食鲜发展有限公司及其子公司</td><td colspan="1" rowspan="1">提供劳务</td><td colspan="1" rowspan="1">429. 48</td><td colspan="1" rowspan="1">596.75</td><td colspan="1" rowspan="1">1,693.68</td></tr></table>

## 2）成都红旗连锁股份有限公司

成都红旗连锁股份有限公司是中国西部地区最具规模的以连锁经营、物流配送为一体的商业连锁企业。2018 年 1 月 2 日，公司与成都红旗连锁股份有限公司、中民未来控股集团有限公司签订三方协议，约定在零售网点增值、零售模式创新、普惠金融和居家养老方面及社区物流方面协同合作。公司对其投资属于围绕产业链上下游以获取渠道为目的的产业投资，符合公司主营业务及战略发展方向，不属于财务性投资。

2023 年度，公司对红旗连锁接受劳务的关联交易金额为 11.07 万元。

## 3）福建华通银行股份有限公司

2016 年，公司通过参与发起设立华通银行方式持有华通银行的股权，相关无需纳入财务性投资计算口径，根据《证券期货法律适用意见第 18 号》，基于历史原因，通过发起设立、政策性重组等形成且短期难以清退的财务性投资，不纳入财务性投资计算口径。公司参与发起设立华通银行的历史背景、原因及经过等情况具体请见本题回复之“（一）关于公司发起设立银行所持有股权不纳入财务性投资计算口径合理性的说明”。

报告期内，发行人向华通银行出售商品/提供劳务及存放货币资金的关联交易具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">关联方</td><td colspan="1" rowspan="1">关联交易内容</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">福建华通银行股份有限公司</td><td colspan="1" rowspan="1">销售商品</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">1</td></tr><tr><td colspan="1" rowspan="1">福建华通银行股份有限公司</td><td colspan="1" rowspan="1">提供劳务</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">7.83</td><td colspan="1" rowspan="1">71.20</td></tr><tr><td colspan="1" rowspan="1">福建华通银行股份有限公司</td><td colspan="1" rowspan="1">存放关联方的货币资金</td><td colspan="1" rowspan="1">30,004.79</td><td colspan="1" rowspan="1">30,000.57</td><td colspan="1" rowspan="1">30,005.36</td></tr></table>

## 4）福建闽威实业股份有限公司

福建闽威实业有限公司（以下简称“闽威实业”）主要从事鲈鱼、大黄鱼等海水鱼类的育苗养殖与精深加工。公司主要从闽威实业采购鲈鱼，报告期内由于闽威实业的海鲈鱼价格要高于广东地区的淡水鲈鱼价格，因此公司报告期内主要从广东地区采购淡水鲈鱼，向闽威实业采购的海鲈鱼等产品金额较少。2025 年公司与闽威实业的产品进行选样，选取了剁椒鲈鱼、青花椒烤鲈鱼和开背海鲈鱼等品种，目前公司正在与闽威实业签署采购协议，计划 2026 年将从闽威实业采购1000-2000万元的商品。公司对其投资属于围绕产业链上下游以获取原料为目的的产业投资，符合公司主营业务，不属于财务性投资。

报告期内，发行人向其采购商品的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>福建闽威实业股份有限公司及其子公司</td><td rowspan=1 colspan=1>采购商品</td><td rowspan=1 colspan=1>0.60</td><td rowspan=1 colspan=1>7.92</td><td rowspan=1 colspan=1>15.35</td></tr></table>

## 5）福建省星源农牧科技股份有限公司

福建省星源农牧科技股份有限公司主要从事生猪养殖业务。公司对其投资属于围绕产业链上下游以获取原料为目的的产业投资，符合公司主营业务，不属于财务性投资。

报告期内，发行人向其采购商品、提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>福建省星源农牧科技股份有限公司及其子公司</td><td rowspan=1 colspan=1>采购商品</td><td rowspan=1 colspan=1>992.59</td><td rowspan=1 colspan=1>2,897.05</td><td rowspan=1 colspan=1>3,796.78</td></tr><tr><td rowspan=1 colspan=1>福建省星源农牧科技股份有限公司及其子公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>0.68</td><td rowspan=1 colspan=1>6.96</td><td rowspan=1 colspan=1>5.89</td></tr></table>

## 6）北京友谊使者商贸有限公司

北京友谊使者商贸有限公司系由公司、贵州茅台酒股份有限公司、深圳市国

茂源商贸有限公司共同出资设立，主要代理并销售贵州茅台酒等酒类产品。公司对其投资属于围绕产业链上下游以获取原料为目的的产业投资，符合公司主营业务，不属于财务性投资。

报告期内，发行人向其采购商品、提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>北京友谊使者商贸有限公司</td><td rowspan=1 colspan=1>采购商品</td><td rowspan=1 colspan=1>51, 837.87</td><td rowspan=1 colspan=1>65,893.59</td><td rowspan=1 colspan=1>57,006.75</td></tr><tr><td rowspan=1 colspan=1>北京友谊使者商贸有限公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>89.33</td><td rowspan=1 colspan=1>0.36</td><td rowspan=1 colspan=1>15.38</td></tr></table>

## 7）四川永创耀辉供应链管理有限公司

四川永创耀辉供应链管理有限公司主要从事采购酒类商品。公司对其投资属于围绕产业链上下游以获取原料为目的的产业投资，符合公司主营业务，不属于财务性投资。

报告期内，发行人向其采购商品/接受劳务、提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>四川永创耀辉供应链管理有限公司</td><td rowspan=1 colspan=1>采购商品</td><td rowspan=1 colspan=1>27, 887. 09</td><td rowspan=1 colspan=1>40,929.95</td><td rowspan=1 colspan=1>74,234.06</td></tr><tr><td rowspan=1 colspan=1>四川永创耀辉供应链管理有限公司</td><td rowspan=1 colspan=1>接受劳务</td><td rowspan=1 colspan=1>3.79</td><td rowspan=1 colspan=1>25.96</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>四川永创耀辉供应链管理有限公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>1, 141. 39</td><td rowspan=1 colspan=1>100.57</td><td rowspan=1 colspan=1>21.84</td></tr></table>

## 8）一二三三国际供应链管理股份有限公司

一二三三国际供应链管理股份有限公司主要从事通过数字化技术提供全球寻源、仓储物流等服务。因此，公司对其投资属于围绕产业链上下游以获取原料为目的的产业投资，符合公司主营业务及战略发展方向，不属于财务性投资。

报告期内，发行人向关联方采购商品/接受劳务及出售商品/提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>一二三三国际供应链管理股份有限公司及其子公司</td><td rowspan=1 colspan=1>采购商品</td><td rowspan=1 colspan=1>39,988. 63</td><td rowspan=1 colspan=1>85,173.90</td><td rowspan=1 colspan=1>97,891.96</td></tr><tr><td rowspan=1 colspan=1>一二三三国际供应链管理股份有限公司及其子公司</td><td rowspan=1 colspan=1>接受劳务</td><td rowspan=1 colspan=1>5,022. 23</td><td rowspan=1 colspan=1>2,916.98</td><td rowspan=1 colspan=1>1,752.83</td></tr><tr><td rowspan=1 colspan=1>一二三三国际供应链管理股份有限公司及其子公司</td><td rowspan=1 colspan=1>销售商品</td><td rowspan=1 colspan=1>21.66</td><td rowspan=1 colspan=1>479.72</td><td rowspan=1 colspan=1>141.73</td></tr><tr><td rowspan=1 colspan=1>一二三三国际供应链管理股份有限公司及其子公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>889.64</td><td rowspan=1 colspan=1>2.011.80</td><td rowspan=1 colspan=1>1,060.56</td></tr></table>

## 9）云达在线（深圳）科技发展有限公司

云达在线（深圳）科技发展有限公司主要为公司线上订单提供线下配送服务。公司对其投资属于围绕产业链上下游以获取技术为目的的产业投资，符合公司主营业务及战略发展方向，不属于财务性投资。

报告期内，发行人向关联方接受劳务、提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>云达在线（深圳）科技发展有限公司及其子公司</td><td rowspan=1 colspan=1>接受劳务</td><td rowspan=1 colspan=1>4,845. 11</td><td rowspan=1 colspan=1>10,759.81</td><td rowspan=1 colspan=1>11,634.11</td></tr><tr><td rowspan=1 colspan=1>云达在线（深圳）科技发展有限公司及其子公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr></table>

## 10）上海轩辉商服科技有限公司

上海轩辉商服科技有限公司主要为公司门店提供的保洁服务，认定为财务性投资。

报告期内，发行人向关联方接受、提供劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>上海轩辉商服科技有限公司及其子公司</td><td rowspan=1 colspan=1>接受劳务</td><td rowspan=1 colspan=1>4, 512. 09</td><td rowspan=1 colspan=1>8,856.52</td><td rowspan=1 colspan=1>14,951.78</td></tr><tr><td rowspan=1 colspan=1>上海轩辉商服科技有限公司及其子公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>14.15</td><td rowspan=1 colspan=1>14.15</td><td rowspan=1 colspan=1>14.15</td></tr></table>

## 11）永辉云金科技有限公司

永辉云金科技有限公司主要从事商业保理和小额贷款业务。报告期内，发行人向其提供服务及接受劳务的关联交易具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>永辉云金科技有限公司及其子公司</td><td rowspan=1 colspan=1>接受劳务</td><td rowspan=1 colspan=1>324. 61</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>永辉云金科技有限公司及其子公司</td><td rowspan=1 colspan=1>提供劳务</td><td rowspan=1 colspan=1>188. 68</td><td rowspan=1 colspan=1>225.73</td><td rowspan=1 colspan=1>1</td></tr></table>

注：根据云金股权转让协议之补充协议约定，转让前存量贷款相关的劳务费用由公司承担。

云金科技业务属于类金融业务，公司持有云金科技股权属于财务性投资，账面余额为 8,000.00 万元，该金额系永辉超市按权益比例确认对云金科技的净损益份额，同时按照拟处置协议对价计提减值准备人民币 9,088 万元后，调整长期股权投资账面价值的结果。

除云金科技和上海轩辉商服科技有限公司外，公司其他长期股权投资均不属于财务性投资。

## （5）一年内到期的非流动资产

截至 2025年12月31日，公司一年内到期的非流动资产账面价值 690.96万元，主要系一年内到期的应收融资租赁款，由公司正常经营活动产生，不属于财务性投资。

## （6）长期应收款

截至 2025年12月31日，公司长期应收款账面价值 1,905.28 万元，主要系融资租赁款，由公司正常经营活动产生，不属于财务性投资。

## （7）投资性房地产

截至 2025 年 12 月 31 日，公司投资性房地产账面价值 27,854.65 万元，主要系永辉城市生活广场、东展商业大楼对外租赁的部分，用于公司正常经营活动，不属于财务性投资。

## （8）其他非流动金融资产

截至 2025 年 12 月 31 日，公司其他非流动金融资产账面价值 305,100.00万元，均为以公允价值计量且其变动计入当期损益的金融资产，具体如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日账面价值</td><td rowspan=1 colspan=1>主营业务</td><td rowspan=1 colspan=1>是否纳入财务性投资计算口径</td></tr><tr><td rowspan=1 colspan=1>大连万达商业管理集团股份有限公司</td><td rowspan=1 colspan=1>305,100. 00</td><td rowspan=1 colspan=1>商业物业投资及运营管理</td><td rowspan=1 colspan=1>否</td></tr></table>

大连万达商业管理集团股份有限公司主要从事商业物业投资及运营管理。公司对其投资主要为了拓展优质商业物业，因此公司对其投资属于围绕产业链上下游以获取渠道为目的的产业投资，符合公司主营业务及战略发展方向，不属于财务性投资。

报告期内，公司对其支付商业物业的租金及物业费，金额具体如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024 年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>大连万达商业管理集团股份有限公司及其子公司</td><td rowspan=1 colspan=1>租金及物业费</td><td rowspan=1 colspan=1>41, 700. 30</td><td rowspan=1 colspan=1>62,102.54</td><td rowspan=1 colspan=1>67,003.45</td></tr></table>

## 2、公司符合再融资关于财务性投资的相关政策要求

综上所述，截至2025年12 月31日，公司持有的财务性投资合计8,081.12万元，占归属于母公司净资产比例为 4.35%，为公司向云金科技、上海轩辉商服科技有限公司的投资。因此，截至 2025 年 12 月 31 日，公司不存在持有金额较大、期限较长的财务性投资（包括类金融）的情形，符合再融资关于财务性投资的相关政策要求。

## 三、云金科技所从事业务的性质及合规性、经营情况及风险情况，股权处置的最新进展

## （一）云金科技所从事业务的性质及合规性

发行人于 2019 年 12 月 27 日设立云金科技，主要目的为便于统筹管理公司的供应链金融业务，逐步吸收合并公司已有的商业保理和小额贷款公司，通过对供应商生产提供资金支持，维护供应链关系。

其中，商业保理业务的开展已取得重庆市两江新区现代服务业局出具的文件，认可永辉青禾商业保理（重庆）有限公司符合重庆两江新区试点商业保理公司设立条件。小额贷款业务的开展已取得重庆市金融工作办公室出具的《重庆市金融工作办公室关于同意重庆永辉小额贷款有限公司开业的批复》（渝金〔2017109号）的主管部门批准。

云金科技在经营过程中，一直守法经营，以国家法律法规为指导，未出现违法、违规事项，报告期内，不存在因违反相关法律法规受到行政处罚的情形。且云金科技根据《重庆市小额贷款公司监管数据管理指引》等金融工作管理部门要求，定期向主管部门报告经营情况，其经营具备合规性。

因此，云金科技开展相关业务已经主管部门批准，且经营具有合法合规性。

## （二）云金科技经营情况及风险情况

云金科技目前主要业务为消费信贷、供应链金融服务。根据《重庆市小额贷款公司监管数据管理指引》等金融工作管理部门要求，云金科技定期向主管部门报告经营情况，报告期内未出现重大风险情况。总体而言，云金科技经营情况良好，不存在重大风险。

## （三）云金科技股权处置的最新进展及未来处置计划

公司自 2024 年以来即开始积极寻求退出云金科技业务，并经主管部门许可后，于 2024 年向上海派慧科技有限公司（以下简称“派慧科技”）转让 65%股权，截至 2025 年 6 月末，公司持有云金科技 35%的股权，云金科技不再纳入公司合并范围，对其投资的账面金额为 2.10亿元。

2025 年 9 月末，公司已按 2025 年 6 月 30 日云金科技的净资产定价，向其第一大股东派慧科技继续转让云金科技 6.9050%股权，已完成工商变更。

截至 2025 年 12 月末，公司持有云金科技 28.0950%的股权，对应的账面余额为 1.71 亿元。公司原计划通过重庆联合产权交易所挂牌转让所持有的云金科技 28.0950%的股权，后终止该挂牌程序并通过协议转让的方式向上海派慧科技有限公司出售公司持有的云金科技剩余股权。

2026 年 3 月 21 日，公司召开第六届董事会第十一次会议，审议通过《关于出售参股子公司永辉云金科技有限公司剩余股权的议案》，同意公司按与上海派慧科技有限公司协议约定的交易方案，以总价 8,000 万元人民币向其转让云金科技 28.095%的股权。本次股权转让协议已取得交易双方各自公司章程规定的内部批准或同意，协议约定的生效条件已全部成就，协议已生效。截至本回复出具日，交易各方已按照协议约定完成云金科技的工商变更。

本次交易完成后公司将不再持有云金科技股权，不再从事商业保理或小额贷款业务。

## 四、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构、申报会计师主要执行了以下核查程序：

1、查阅中国证监会关于财务性投资（含类金融业务）有关规定，了解财务性投资（含类金融业务）认定的要求；

2、了解自董事会决议日前六个月之日起至本回复出具日，公司是否存在新投入和拟投入财务性投资及类金融业务的情况；

3、查阅公司参与发起设立华通银行的政策背景及相关政府函件，对华通银行高管进行访谈，判断华通银行股权未认定为财务性投资的依据是否充分；

4、了解公司的对外投资与主营业务的关系，对外投资的主要目的等；

5、结合各项投资的目的背景、被投资企业的工商信息等，分析公司是否存在大额财务性投资；

6、查阅公司报告期内的定期财务报告和相关科目明细；

7、访谈云金科技负责人，了解云金科技主营业务及股权转让背景；

8、取得云金科技业务批准成立的批复文件及经营情况定期报告上传截图，分析其业务合规性、经营情况和风险情况；

9、了解云金科技股权处置的最新进展。

## （二）核查意见

经核查，保荐机构、申报会计师认为：

1、自本次董事会决议日前六个月至本回复出具之日，公司不存在实施或拟实施财务性投资（含类金融业务）的情况，本次募集资金总额不涉及需扣除相关财务性投资金额的情形；

2、公司对华通银行的投资是基于历史原因，响应政策号召，通过发起设立形成，非公司主动投资行为，且短期难以清退，不需纳入财务性投资计算口径的依据充分；

3、截至 2025 年 12 月 31 日，公司持有的财务性投资合计 8,081.12 万元，占归属于母公司净资产比例为 4.35%。不存在持有金额较大、期限较长的财务性投资（包括类金融业务）情形，符合再融资关于财务性投资的相关政策要求；

4、云金科技主营业务为消费信贷、供应链金融服务，相关业务的开展已取得主管部门的批复，经营具有合规性。云金科技定期向主管部门报告经营情况，其经营情况良好，不存在重大风险情况。目前，公司已与上海派慧科技有限公司签订关于云金科技股权的转让协议，交易各方已按照协议约定完成云金科技的工商变更。云金科技股权处置完毕后，公司全部剥离云金科技业务。

3.2 请发行人说明：（1）发行人及子公司是否经营广告业务、互联网业务，具体业务内容、经营模式、报告期各期的收入、利润规模及占比情况；（2）公司是否具有相关业务开展的资质，经营是否合法合规，是否存在被主管部门处罚的情况。

请保荐机构及发行人律师核查并发表明确意见。

回复：

一、发行人及子公司是否经营广告业务、互联网业务，具体业务内容、经营模式、报告期各期的收入、利润规模及占比情况

（一）广告业务

1、广告业务相关规定

广告业务，主要指为第三方提供广告服务业务。根据国家统计局《文化及相关产业分类（2018）》的规定，广告服务包括互联网广告服务、其他广告服务，其中互联网广告服务指提供互联网广告设计、制作、发布及其他互联网广告服务，其他广告服务指除互联网广告以外的广告服务。

## 2、公司涉及广告业务情况

公司为国内大型零售商超企业，主营业务为零售业，主营业务中不涉及广告业务。截至本回复出具之日，公司及部分控股子公司的经营范围中存在“广告服务”“广告设计、代理”“广告的设计、制作、代理和发行”等可能涉及广告业务的表述，相关主体并未实际开展该等业务，具体情况如下：

<table><tr><td rowspan=1 colspan=1>主体</td><td rowspan=1 colspan=1>经营范围描述</td><td rowspan=1 colspan=1>实际经营业务</td><td rowspan=1 colspan=1>是否实际开展广告业务</td></tr><tr><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>广告服务</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>福建永辉超市有限公司</td><td rowspan=1 colspan=1>广告设计、代理</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>广东百佳永辉超市有限公司</td><td rowspan=1 colspan=1>广告业务</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>安徽永辉超市有限公司</td><td rowspan=1 colspan=1>广告设计、代理</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>江苏永辉超市有限公司</td><td rowspan=1 colspan=1>广告的设计、制作、代理和发行</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>贵州永辉超市有限公司</td><td rowspan=1 colspan=1>广告设计、代理</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>福州闽侯永辉超市有限公司</td><td rowspan=1 colspan=1>广告设计、代理</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>永辉超市河南有限公司</td><td rowspan=1 colspan=1>广告发布；广告设计、代理</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>华东永辉物流有限公司</td><td rowspan=1 colspan=1>设计、制作、代理、发布国内广告</td><td rowspan=1 colspan=1>物流配送</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>山东永辉超市有限公司</td><td rowspan=1 colspan=1>国内广告业务</td><td rowspan=1 colspan=1>商业零售</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>安徽永辉物流有限公司</td><td rowspan=1 colspan=1>广告设计、代理</td><td rowspan=1 colspan=1>物流配送</td><td rowspan=1 colspan=1>否</td></tr></table>

注：上表列示公司及一级控股子公司情况。

经核查，报告期内，公司存在为超市的商品供应商提供广告资源位租赁服务情况，具体为：部分商品供应商出于推介其品牌产品的需要，向公司租赁线上APP 及线下超市门店自助收银机显示屏等广告资源位并提供所展示的广告内容。在该过程中，公司基于合作约定而向商品供应商提供广告资源位的租赁，不参与所展示广告的设计、制作、发布等服务，因此不属于国家统计局《文化及相关产业分类（2018）》中界定的广告服务业务。

综上，截至本回复出具之日，公司及控股子公司未实际开展广告业务。

## （二）互联网业务

## 1、互联网业务相关规定

互联网业务，主要指以互联网为基础，利用数字化的信息和网络实现商业目标的业务，主要包括电子商务等。根据《中华人民共和国电子商务法》第二条，电子商务是指通过互联网等信息网络销售商品或者提供服务的经营活动。根据《国务院反垄断委员会关于平台经济领域的反垄断指南》第二条，“互联网平台”是指通过网络信息技术，使相互依赖的双边或者多边主体在特定载体提供的规则下交互，以此共同创造价值的商业组织形态。

## 2、公司涉及互联网业务情况

报告期内，公司（含控股子公司，下同）主要涉及通过互联网进行线上零售业务，具体情况如下：

## （1）具体业务内容、经营模式

公司线上零售业务主要为通过自营的“永辉线上超市”APP、小程序及在淘宝、美团、抖音、京东等第三方电商平台开设线上店铺等方式向消费者销售商品，是公司线下门店端零售业务的有效补充。

公司线上零售业务的具体经营模式为：公司通过淘宝、美团、抖音、京东等第三方平台店铺或自有 APP、小程序向客户展示商品信息，客户通过公司在第三方平台上开设的店铺或公司自有 APP、小程序下单后，公司通过合作的物流商或者骑手将商品配送至客户，公司对于交易商品承担退、换货等售后责任。上述线上零售业务均以公司名义销售商品，不存在第三方商家入驻公司自有 APP、小程序并销售产品或服务的情形，也不存在撮合交易并收取费用情形。

截至本回复出具之日，公司参与运营的网站、APP、小程序及入驻的第三方电商平台的主要情况如下：

## 1）自有网站

截至本回复出具之日，公司正在运营的自有网站情况主要如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>域名</td><td rowspan=1 colspan=1>主营主体</td><td rowspan=1 colspan=1>主要用途/功能</td><td rowspan=1 colspan=1>增值电信业务许可/ICP 备案</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1> yonghui.com.cn</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>永辉超市官网</td><td rowspan=1 colspan=1>闽ICP备05003392号-1</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>yonghuivip.com</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>云创科技官网</td><td rowspan=1 colspan=1>沪ICP备16002352 号-1</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>yhcpos.cn</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>永辉线上超市活动页</td><td rowspan=1 colspan=1>闽ICP备05003392 号-9</td></tr></table>

## 2）自有 APP

截至本回复出具之日，公司正在运营的 APP 情况主要如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>运营主体</td><td rowspan=1 colspan=1>主要用途/功能</td><td rowspan=1 colspan=1>增值电信业务许可/ICP 备案</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>永辉线上超市</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>对外销售商品</td><td rowspan=1 colspan=1>《增值电信业务许可证》（合字B2-20210067）/沪 ICP备16002352号-4A</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>供零在线-生鲜</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（数字化操作平台）</td><td rowspan=1 colspan=1>闽ICP备05003392号-15A</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>永辉物流</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（物流数字化工具）</td><td rowspan=1 colspan=1>闽ICP备05003392 号-16A</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>供零在线（橙色）</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（数字化操作平台）</td><td rowspan=1 colspan=1>闽ICP备05003392 号-17A</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>供零在线</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（数字化操作平台）</td><td rowspan=1 colspan=1>闽ICP备05003392号-18A</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>YHDOS</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（数字化操作平台）</td><td rowspan=1 colspan=1>闽ICP备05003392号-19A</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>永辉数据</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（各门店经营情况）</td><td rowspan=1 colspan=1>闽ICP备05003392号-20A</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>永辉知云</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（员工培训、培育）</td><td rowspan=1 colspan=1>闽ICP备05003392号-21A</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>辉翔</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>供配送员接单、配送使用</td><td rowspan=1 colspan=1>沪ICP备16002352号-6A</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>大管家</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>公司内部管理使用（数字化操作平台）</td><td rowspan=1 colspan=1>沪ICP备16002352号-7A</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>店端WMS</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>公司门店管理使用</td><td rowspan=1 colspan=1>沪ICP备16002352号-8A</td></tr></table>

## 3）小程序

截至本回复出具之日，公司正在运营的小程序情况主要如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>运营主体</td><td rowspan=1 colspan=1>互联网载体</td><td rowspan=1 colspan=1>主要用途/功能</td><td rowspan=1 colspan=1>增值电信业务许可/ICP备案</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>永辉线上超市|原永辉生活</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>小程序-微信</td><td rowspan=1 colspan=1>对外销售商品</td><td rowspan=1 colspan=1>沪ICP备16002352 号-5X</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>永辉线上超市|原永辉生活</td><td rowspan=1 colspan=1>永辉云创科技有限公司</td><td rowspan=1 colspan=1>小程序-支付宝</td><td rowspan=1 colspan=1>对外销售商品</td><td rowspan=1 colspan=1>沪ICP备16002352号-10X</td></tr></table>

## 4）第三方电商平台

截至本回复出具之日，公司在第三方电商平台开设运营店铺情况主要如下：
<table><tr><td rowspan=1 colspan=1>序号第</td><td rowspan=1 colspan=1>三方电商平台</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>运营主体</td><td rowspan=1 colspan=1>主要用途/功能</td></tr><tr><td rowspan=2 colspan=1>1</td><td rowspan=2 colspan=1>京东</td><td rowspan=1 colspan=1>永辉超市官方旗舰店</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉线上超市（店名）</td><td rowspan=1 colspan=1>各控股子公司的分公司门店</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>美团</td><td rowspan=1 colspan=1>永辉超市（店名）</td><td rowspan=1 colspan=1>各控股子公司的分公司门店</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=4 colspan=1>3</td><td rowspan=4 colspan=1>抖音</td><td rowspan=1 colspan=1>永辉卖场</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉超市旗舰店</td><td rowspan=1 colspan=1>四川辉彭电子商务有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉超市甄选旗舰店</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉超市小时达</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=2 colspan=1>4</td><td rowspan=2 colspan=1>淘宝（含淘宝闪购）</td><td rowspan=1 colspan=1>永辉超市旗舰店</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉超市（店名）</td><td rowspan=1 colspan=1>各控股子公司的分公司门店</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>快手</td><td rowspan=1 colspan=1>永辉超市（店名）</td><td rowspan=1 colspan=1>各控股子公司的分公司门店</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=2 colspan=1>6</td><td rowspan=2 colspan=1>微信小店</td><td rowspan=1 colspan=1>永辉超市</td><td rowspan=1 colspan=1>四川辉彭电子商务有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr><tr><td rowspan=1 colspan=1>永辉甄选店</td><td rowspan=1 colspan=1>永辉超市股份有限公司</td><td rowspan=1 colspan=1>对外销售商品</td></tr></table>

## （2）收入、利润数据

报告期各期，公司线上零售业务分别实现销售收入 160.75 亿元、146.42 亿元及 100.92 亿元，占公司各期营业收入的比例分别为 20.44%、21.67%及 18.86%；公司线上零售业务分别实现利润总额-6.18 亿元、-3.80 亿元及-4.08 亿元，占公司各期利润总额的比例分别为 45.39%、23.14%及 14.88%。

## 二、公司是否具有相关业务开展的资质，经营是否合法合规，是否存在被主管部门处罚的情况

## （一）发行人通过互联网开展线上零售业务相应资质情况

发行人线上零售主要通过自营的“永辉线上超市”APP、小程序开展，“永辉线上超市”的运营主体是发行人控股子公司永辉云创科技有限公司（以下简称“永辉云创”）。永辉云创已取得《增值电信业务经营许可证》，业务种类为“在线数据处理与交易处理业务（仅限经营类电子商务）”、“信息服务业务（仅限互联网信息服务）”，有效期至 2030 年 12 月 12 日。发行人“永辉线上超市”APP、小程序均已取得相关 ICP 备案。

此外，发行人还通过入驻第三方电商平台的方式进行线上零售，根据《中华人民共和国电子商务法》等相关规定，发行人仅需遵守电商平台制定的平台规则，无需取得特殊资质。

发行人自有网站的主要功能是公司介绍、宣传及信息发布，不具有线上零售功能。根据《互联网信息服务管理办法》的规定，国家对经营性互联网信息服务实行许可制度，对非经营性互联网信息服务实行备案制度。非经营性互联网信息服务，是指通过互联网向上网用户无偿提供具有公开性、共享性信息的服务活动。发行人自有网站向用户无偿提供具有公开性、共享性信息的服务，属于从事非经营性互联网信息服务，不涉及经营性互联网信息服务，发行人自有网站已取得ICP 备案。

综上所述，发行人线上零售业务已取得相关资质。

## （二）通过互联网开展线上零售业务的合规经营情况

## 1、个人信息收集合规情况

（1）个人信息保护相关法律规定

根据《网络安全法》的有关规定，网络运营者收集、使用个人信息，应当遵循合法、正当、必要的原则，公开收集、使用规则，明示收集、使用信息的目的、方式和范围，并经被收集者同意。网络运营者不得收集与其提供的服务无关的个人信息。根据《个人信息保护法》的相关规定，个人信息是以电子或者其他方式记录的与已识别或者可识别的自然人有关的各种信息，不包括匿名化处理后的信息。收集个人信息应当具有明确、合理的目的；应当限于实现处理目的的最小范围，不得过度收集个人信息；应当遵循公开、透明原则，明示处理的目的、方式和范围。

## （2）发行人收集用户信息的合规性

发行人主要通过永辉线上超市 APP 和小程序开展线上零售业务。为开展前述业务，发行人需相应收集用户个人信息，包括：在用户注册阶段，用户必须填写的个人信息是手机号码；在下订单阶段，用户必须填写的个人信息包括收件人姓名（不强制要求实名）、收件地址、手机号码。除此之外，发行人还主要收集用户在使用 APP和小程序过程中产生的浏览搜索记录、交易记录等行为信息。

发行人收集的上述用户个人信息系为了验证用户身份有效性、交付商品，以满足永辉线上超市 APP 和小程序的核心功能——线上零售。发行人收集的上述用户个人信息的内容、范围、目的均包含在发行人的隐私权政策中，且已在用户注册时提示用户阅读并取得用户同意，并在永辉线上超市 APP 和小程序相关界面公示。

根据《永辉线上超市隐私权政策》的规定及发行人的确认，就用户个人信息的存储，发行人在境内运营中收集的个人信息存储在中国境内，且均存储于发行人本地，不存在存储在外部第三方的情况；就用户个人信息的保护，发行人采用符合业界标准的安全防护措施，包括建立合理的制度规范、安全技术，以防止用户个人信息遭到未经授权的访问使用、修改，避免相关数据的损坏或丢失；此外，用户可以按照隐私政策的规定删除部分个人信息。若用户主动注销个人账户，发行人会根据相关法律的规定对相关个人信息及时删除或匿名化处理。

除《永辉线上超市隐私权政策》之外，发行人制定了《信息安全审批管理制度》《第三方人员访问控制管理制度》《信息安全监督检查管理办法》《员工违反安全策略和规定惩处办法》《信息安全监控规范》《网络安全管理制度》《系统安全管理制度》《恶意代码防范管理制度》《密码管理制度》《系统变更管理制度》《信息安全事件报告和处置管理制度》《数据安全管理办法》等相关制度并遵照执行，以防止出现用户个人信息泄露的情况。

发行人收集用户个人信息的行为符合合理性、必要性及公开性的原则，且已取得用户的事先同意，不存在违反《中华人民共和国个人信息保护法》《中华人民共和国网络安全法》《中华人民共和国数据安全法》等相关法律法规规定的情形。最近三年发行人及其线上超市经营主体不存在个人信息保护相关的诉讼、仲裁案件或因违反个人信息保护相关规定而受到主管部门的行政处罚。

## 2、平台反垄断合规情况

根据《国务院反垄断委员会关于平台经济领域的反垄断指南》（以下简称“《平台经济反垄断指南》”）第二条的规定，“（一）平台，本指南所称平台为互联网平台，是指通过网络信息技术，使相互依赖的双边或者多边主体在特定载体提供的规则下交互，以此共同创造价值的商业组织形态。（二）平台经营者，是指向自然人、法人及其他市场主体提供经营场所、交易撮合、信息交流等互联网平台服务的经营者”。

发行人永辉线上超市 APP 和小程序仅销售发行人的商品，不涉及外部第三方入驻的情况，不属于《平台经济反垄断指南》中规定的“互联网平台”或“平台经营者”。

## 3、互联网业务相关行政处罚情况

根据发行人及其境内主要控股子公司取得的信用报告、国家企业信用信息公示系统、信用中国、企查查等公开渠道的查询结果以及发行人的确认，最近三年发行人及其线上超市经营主体不存在因通过互联网开展线上零售业务而受到相关行业主管部门行政处罚的情况。

综上，发行人通过互联网开展线上零售业务已取得相关资质。最近三年发行人及其线上超市经营主体不存在因通过互联网开展线上零售业务而受到相关行业主管部门行政处罚的情况。

根据《网络安全审查办法》第七条的规定，掌握超过 100 万用户个人信息的网络平台运营者赴国外上市，必须向网络安全审查办公室申报网络安全审查。发行人本次向特定对象发行股票事宜不涉及赴国外上市，因此，无需按照前述规定向网络安全审查办公室申报网络安全审查。

## 三、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构、发行人律师主要执行了以下核查程序：

1、查阅了《文化及相关产业分类（2018）》《中华人民共和国电子商务法》《国务院反垄断委员会关于平台经济领域的反垄断指南》等广告及互联网相关的法律法规及规范性文件，明确广告及互联网业务的定义及业务范畴；

2、通过国家企业信用信息公示系统、信用中国、企查查等公开渠道查询发行人及其控股子公司的经营范围；

3、访谈了发行人相关业务负责人，了解发行人及其控股子公司是否实际开展广告及互联网业务，以及相关业务的具体内容、经营模式；发行人互联网业务载体情况，个人信息收集及储存情况；

4、登录工信部网站查看发行人及其控股子公司自有网站、自有 APP、小程序的备案情况，登录该等网站、APP、小程序以了解其功能及运行情况、个人信息收集情况；

5、查阅发行人报告期内的定期报告及审计报告，确认发行人线上零售业务的收入及利润数据；

6、取得发行人及其主要控股子公司的信用报告，并通过国家企业信用信息公示系统、信用中国、企查查等公开渠道查询发行人及其线上超市经营主体是否因通过互联网开展线上零售业务而受到相关行业主管部门行政处罚情况、是否存在个人信息保护相关的诉讼、仲裁案件或因违反个人信息保护相关规定而受到主管部门的行政处罚；

7、查阅了发行人《永辉线上超市隐私权政策》《信息安全审批管理制度》《第三方人员访问控制管理制度》《信息安全监督检查管理办法》《员工违反安全策略和规定惩处办法》《信息安全监控规范》《网络安全管理制度》《系统安全管理制度》《恶意代码防范管理制度》《密码管理制度》《系统变更管理制度》《信息安全事件报告和处置管理制度》《数据安全管理办法》等制度，了解发行人关于用户个人信息保护的相关制度；

8、查阅了《网络安全审查办法》的规定，了解发行人本次发行是否需向网络安全审查办公室申报网络安全审查。

## （二）核查意见

经核查，保荐机构、发行人律师认为：

1、截至本回复出具之日，发行人及控股子公司未实际开展广告业务，涉及通过互联网进行线上零售业务情形，该线上零售业务主要为通过发行人自营的“永辉线上超市”APP、小程序及在淘宝、美团、抖音、京东等第三方电商平台开设线上店铺等方式向消费者销售商品；

2、发行人通过互联网开展线上零售业务已取得相关资质，最近三年发行人及其线上超市经营主体不存在因通过互联网开展线上零售业务而受到相关行业主管部门行政处罚的情况。

3.3 请发行人说明：2024年出售万达商管的交易对手方未能根据约定支付价款的原因，该笔交易的收入确认情况，诉讼案件的最新进展情况，万达商管估值是否发生变化，相关会计处理是否审慎合理。

请保荐机构、发行人律师及申报会计师核查并发表明确意见。

回复：

一、2024 年出售万达商管的交易对手方未能根据约定支付价款的原因，该笔交易的收入确认情况，诉讼案件的最新进展情况

（一）该笔交易的收入确认情况

2023 年12月，公司与大连御锦贸易有限公司（简称“大连御锦”）签署《永辉超市股份有限公司与大连御锦贸易有限公司关于大连万达商业管理集团股份有限公司之股权转让协议》，约定公司向大连御锦转让万达商管 388,699,998 股股份，转让价格为 4,530,059,250.07 元。2024 年 7 月，公司与大连御锦、王健林先生、孙喜双先生、大连一方集团有限公司签署《关于大连万达商业管理集团股份有限公司之股权转让协议之补充协议》，调整了购买方支付剩余股份转让价款的分期进度并补充王健林先生、孙喜双先生、大连一方集团有限公司为交易担保方。

最新支付安排情况如下：
<table><tr><td rowspan=1 colspan=1>支付期数</td><td rowspan=1 colspan=1>付款时间</td><td rowspan=1 colspan=1>股份转让价款（万元）</td><td rowspan=1 colspan=1>对应转让的股份数（股）</td></tr><tr><td rowspan=1 colspan=1>第一期第二期</td><td rowspan=1 colspan=1>2023年12月30日2024年3月31日</td><td rowspan=1 colspan=1>30.000.0039,097.02</td><td rowspan=1 colspan=1>26,925,67834,615,385</td></tr><tr><td rowspan=5 colspan=1>第三期第四期第五期第六期第七期</td><td rowspan=2 colspan=1>2024年6月30日2024年9月30日</td><td rowspan=1 colspan=1>20.000.00</td><td rowspan=5 colspan=1>17,043,57125,565,35642,608,92759,652,49865,174,615</td></tr><tr><td rowspan=1 colspan=1>30.000.0</td></tr><tr><td rowspan=3 colspan=1>2024年12月31日2025年3月31日2025年6月30日</td><td rowspan=1 colspan=1>50,000.00</td></tr><tr><td rowspan=1 colspan=1>70,000.00</td></tr><tr><td rowspan=1 colspan=1>76,480.00</td></tr><tr><td rowspan=2 colspan=1>第八期第九期</td><td rowspan=2 colspan=1>2025年9月30日2025年12月31日</td><td rowspan=1 colspan=1>67,900.00</td><td rowspan=2 colspan=1>57,862,92329,621,726</td></tr><tr><td rowspan=1 colspan=1>34,760.00</td></tr><tr><td rowspan=1 colspan=1>第十期</td><td rowspan=1 colspan=1>2026年3月31日</td><td rowspan=1 colspan=1>34,768.91</td><td rowspan=1 colspan=1>29,629,319</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>453,005.93</td><td rowspan=1 colspan=1>388,699,998</td></tr></table>

截至本回复出具之日，公司共收到第一期至第三期股权转让款 89,097.02 万元，并完成对应 78,584,634股万达商管股份的股权交割。在进行对应股权交割时，公司会根据交易价款与账面价值的差额确认投资收益。

2023 年至2025年，本次交易确认的投资收益情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>时间</td><td rowspan=1 colspan=1>股权转让款</td><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>投资收益(税前）</td></tr><tr><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>30.000.00</td><td rowspan=1 colspan=1>27,140.42</td><td rowspan=1 colspan=1>2,859.58</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>59,097.02</td><td rowspan=1 colspan=1>52,070.95</td><td rowspan=1 colspan=1>7,026.07</td></tr><tr><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>89,097.02</td><td rowspan=1 colspan=1>79,211.37</td><td rowspan=1 colspan=1>9,885.65</td></tr></table>

## （二）2024年出售万达商管的交易对手方未能根据约定支付价款的原因

2024 年出售万达商管的交易对手方未能根据约定支付价款，主要系交易对手方存在短期资金周转困难所致，其正积极处置资产以回笼资金，用以支付本次

交易股份转让价款。

## （三）诉讼案件的最新进展情况

由于后续款项并未按照协议安排进行支付，公司向上海国际经济贸易仲裁委员会提起仲裁申请，追究大连御锦、王健林先生、孙喜双先生、大连一方集团有限公司的法律责任。上海国际经济贸易仲裁委员会于 2024 年 10 月 12 日受理该案。2026 年 4 月，上海国际经济贸易仲裁委员会作出终局裁决，裁决：大连御锦向公司支付剩余股份转让价款 3,639,089,070.93 元、加速到期违约金218,345,344.26 元、律师费人民币 2,001,017.21 元、财产保全费 45,000 元及财产保全保险费 1,783,329.41 元；王健林先生、孙喜双先生、一方集团就大连御锦前述债务向公司承担连带保证责任；仲裁费 18,251,550 元，由大连御锦、王健林先生、孙喜双先生、一方集团共同承担。

截至本回复出具之日，该案仲裁裁决结果已生效，大连御锦、王健林先生、孙喜双先生、一方集团尚未向公司支付相关款项。

## 二、万达商管估值是否发生变化，相关会计处理是否审慎合理

## （一）万达商管估值是否发生变化

2023 年 12 月 31 日、2024 年 12 月 31 日，公司聘请评估机构上海东洲资产评估有限公司对于各年末持有的万达商管的股权价值进行评估，并以评估结果作为年末公允价值入账。2025 年 12 月 31 日，公司聘请评估机构北京国友大正资产评估有限公司对于年末持有的万达商管的股权价值进行评估，并以评估结果作为年末公允价值入账。

根据评估机构出具的估值或评估报告及公司执行的评估测试结果，2023 年12 月 31 日、2024 年 12 月 31 日、2025 年 12 月 31 日，万达商管股权采用市场法进行估值测算，具体估值情况如下：

<table><tr><td colspan="1" rowspan="1">时间</td><td colspan="1" rowspan="1">2025年12月31日</td><td colspan="1" rowspan="1">2024年12月31日</td><td colspan="1" rowspan="1">2023年12月31日</td></tr><tr><td colspan="1" rowspan="1">持股数量（股）</td><td colspan="1" rowspan="1">310, 115, 364</td><td colspan="1" rowspan="1">310,115,364</td><td colspan="1" rowspan="1">361,774,320</td></tr><tr><td colspan="1" rowspan="1">评估值 （万元）</td><td colspan="1" rowspan="1">305,100.00</td><td colspan="1" rowspan="1">312,600.00</td><td colspan="1" rowspan="1">364,700.00</td></tr><tr><td colspan="1" rowspan="1">评估值 (元/股)</td><td colspan="1" rowspan="1">9.84</td><td colspan="1" rowspan="1">10.08</td><td colspan="1" rowspan="1">10.08</td></tr><tr><td colspan="1" rowspan="1">账面价值（万元）</td><td colspan="1" rowspan="1">305,100.00</td><td colspan="1" rowspan="1">312,588.63</td><td colspan="1" rowspan="1">364,659.58</td></tr><tr><td colspan="1" rowspan="1">账面价值（元/股）</td><td colspan="1" rowspan="1">9.84</td><td colspan="1" rowspan="1">10.08</td><td colspan="1" rowspan="1">10.08</td></tr></table>

由上表可见，2023 年 12 月 31 日、2024 年 12 月 31 日，万达商管的估值未发生重大变化。2025 年 12 月 31 日，万达商管的估值由 2024 年 12 月 31 日的312,600.00 万元下降至 305,100.00 万元，每股评估值由 10.08 元降至 9.84 元，降幅为 2.38%，降幅较小，未发生重大变化。

## （二）相关会计处理是否审慎合理

公司就其持有的万达商管股权估值未发生重大变化，相关会计处理审慎、合理，主要原因如下：

1、依据评估报告的估值结果以及公司的评估测试结果，上述资产的估值在报告期内未发生重大变化

公司聘请评估机构上海东洲资产评估有限公司对于公司 2023 年12月31 日2024 年 12 月 31 日持有的万达商管的股权价值进行评估。公司聘请评估机构北京国友大正资产评估有限公司对于公司 2025年12月31日持有的万达商管的股权价值进行评估。依据估值或评估报告的评估结果，上述资产估值未发生重大变化。针对 2025 年12 月 31 日较前期的估值变动，公司已按照《企业会计准则第 39 号——公允价值计量》相关要求，按账面价值与评估值的差额确认公允价值变动损失，并相应调整万达商管股权的期末账面价值，符合会计准则相关规定，具有审慎性。

2、其他持有万达商管股权的股东对万达商管的股权资产估值未发生重大变化

根据公开信息，其他持有万达商管股权的股东对万达商管的股权资产估值未发生重大变化，包括苏宁易购集团股份有限公司（简称“苏宁易购”，股票代码为002024.SZ）等。根据苏宁易购的定期报告，苏宁易购将对万达商管的股权投资计入交易性金融资产科目，采用公允价值计量，2023年末、2024年末及2025年末，苏宁易购所持万达商管的账面价值分别为 121.78 亿元、121.64 亿元及

121.03 亿元，相对稳定，估值未发生重大变化。

因此，综合考虑评估机构出具的评估结果以及苏宁易购等市场案例情况，发行人对其持有的万达商管股权的会计处理审慎合理。

综上，2024 年出售万达商管的交易对手方未能根据约定支付价款，主要系交易对手方存在短期资金周转困难所致，其正积极处置资产以回笼资金，用以支付本次交易股份转让价款。针对已支付转让款且已完成交割的万达商管股权，公司根据交易价款与账面价值的差额确认投资收益。截至本回复出具之日，公司与大连御锦的仲裁裁决结果已生效，大连御锦、王健林先生、孙喜双先生、一方集团尚未向公司支付相关款项。报告期各期末，万达商管的估值未发生重大变化，公司已根据估值变动确认公允价值变动损失，并相应调整万达商管股权的期末账面价值。综合考虑评估机构出具的估值报告以及苏宁易购等市场案例情况，发行人对其持有的万达商管股权的会计处理审慎合理。

## 三、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构、发行人律师、申报会计师主要执行了以下核查程序：

（1）查阅发行人关于出售万达商管股权的相关协议及公告，了解交易对方未能根据约定支付价款的原因；

（2）查阅万达商管交易相关的资金流水、协议、公告等资料，复核处置损益的测算结果；

（3）查阅仲裁案件的仲裁申请书等相关资料并访谈发行人的财务负责人及仲裁案件律师，了解关于万达商管仲裁案件的最新进展；

（4）获取发行人对于万达商管股权于 2023 年末、2024 年末、2025 年末的估值或评估报告，复核万达商管估值是否存在重大变化。

（二）核查意见

经核查，保荐机构、发行人律师、申报会计师认为：

1、2024年出售万达商管的交易对手方未能根据约定支付价款，主要系交易对手方存在短期资金周转困难所致，其正积极处置资产以回笼资金用以支付本次交易股份转让价款。针对已支付转让款且已完成交割的万达商管股权，公司根据交易价款与账面价值的差额确认投资收益。截至本回复出具之日，发行人与大连御锦的仲裁裁决结果已生效，大连御锦、王健林先生、孙喜双先生、一方集团尚未向发行人支付相关款项；

2、报告期各期末，万达商管的估值未发生重大变化，公司已根据估值变动确认公允价值变动损失，并相应调整万达商管股权的期末账面价值。综合考虑评估机构出具的估值或评估报告以及苏宁易购等市场案例情况，发行人对其持有的万达商管股权的会计处理审慎合理。

3.4 请发行人说明：报告期内与关联方之间资金拆借产生的背景，相关业务是否合法合规，结合还款情况说明是否应计提预计负债，是否存在损害上市公司利益的情形。

请保荐机构、发行人律师及申报会计师核查并发表明确意见。

回复：

一、 报告期内与关联方之间资金拆借产生的背景，相关业务是否合法合规报告期内，公司关联方资金拆借发生情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">关联方</td><td colspan="1" rowspan="1">拆借金额</td><td colspan="1" rowspan="1">起始日</td><td colspan="1" rowspan="1">到期日</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="5" rowspan="1">拆入</td></tr><tr><td colspan="1" rowspan="1">百佳（中国）投资有限公司</td><td colspan="1" rowspan="1">4,625.00</td><td colspan="1" rowspan="1">2019/5/9</td><td colspan="1" rowspan="1">2023/5/8</td><td colspan="1" rowspan="1">借款</td></tr><tr><td colspan="1" rowspan="1">百佳（中国）投资有限公司</td><td colspan="1" rowspan="1">4,625.00</td><td colspan="1" rowspan="1">2023/5/9</td><td colspan="1" rowspan="1">2026/5/8</td><td colspan="1" rowspan="1">借款展期</td></tr><tr><td colspan="5" rowspan="1">拆出</td></tr><tr><td colspan="1" rowspan="1">福州颐玖叁叁豆制品有限公司及其子公司</td><td colspan="1" rowspan="1">1, 289. 13</td><td colspan="1" rowspan="1">2019/9/25</td><td colspan="1" rowspan="1">2025/5/17</td><td colspan="1" rowspan="1">借款</td></tr><tr><td colspan="1" rowspan="1">福建闽威实业股份有限公司</td><td colspan="1" rowspan="1">5,390.00</td><td colspan="1" rowspan="1">2022/5/31</td><td colspan="1" rowspan="1">2023/12/31</td><td colspan="1" rowspan="1">保理融资展期</td></tr><tr><td colspan="1" rowspan="1">福建闽威实业股份有限公司</td><td colspan="1" rowspan="1">1,542.68</td><td colspan="1" rowspan="1">2023/12/31</td><td colspan="1" rowspan="1">2024/12/31</td><td colspan="1" rowspan="1">保理融资展期</td></tr><tr><td colspan="1" rowspan="1">福建省星源农牧科技股份</td><td colspan="1" rowspan="1">2,597.14</td><td colspan="1" rowspan="1">2022/12/4</td><td colspan="1" rowspan="1">2023/6/14</td><td colspan="1" rowspan="1">保理融资</td></tr><tr><td colspan="1" rowspan="1">有限公司</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">展期</td></tr><tr><td colspan="1" rowspan="1">福建省星源农牧科技股份有限公司</td><td colspan="1" rowspan="1">1,410.90</td><td colspan="1" rowspan="1">2023/12/14</td><td colspan="1" rowspan="1">2024/12/31</td><td colspan="1" rowspan="1">保理融资展期</td></tr></table>

注 1：2019 年起，福州颐玖叁叁豆制品有限公司及其控股子公司从公司累计拆出资金合计人民币 12,891,340.91 元，前述借款最晚于 2025年 5 月17 日到期。福州颐玖叁叁豆制品有限公司及其控股子公司欠款已逾期，该公司目前已停业清算；

注 2：2021年度，福建闽威实业股份有限公司从公司取得保理融资 6,190.00 万元，年利率为 8.50%，2022 年到期后展期 5,390.00 万元；2023 年到期后展期 1,542.68 万元；

注 3：2021 年度，福建省星源农牧科技股份有限公司从公司取得保理融资 3,500.00 万元，年利率为 12.00%，2022 年到期后展期 2,597.14 万元；2023 年到期后展期 1,410.90 万元；

## （一）自百佳（中国）投资有限公司（以下简称“百佳中国”）借入资金

因公司实际控制的企业广州百佳永辉超市有限公司（简称“广州百佳永辉”）业务运营需要补充流动资金，百佳中国向广州百佳永辉提供借款 4,625 万元，广州百佳永辉按中国人民银行公布的同期贷款基准利率就该等借款支付利息，借款期限为 4年（即2023年5月8 日到期），未要求公司或广州百佳永辉提供担保。后双方签署《展期协议》，将前述借款展期 3 年，即延长至 2026 年 5 月 8 日到期。

广州百佳永辉原系百佳中国控制的企业。2018 年 10 月，公司与百佳中国等主体共同设立广东百佳永辉超市有限公司（以下简称“百佳永辉”），其中公司持股 50%、百佳中国持股 40%。公司通过董事会席位安排能够实际控制百佳永辉。由于百佳中国是以其持有的广州百佳永辉 96.67%股权及现金作为对百佳永辉的出资，因此 2019年3月起，百佳永辉成为广州百佳永辉持股 96.67%的股东。自此，发行人通过控制百佳永辉，从而间接控制广州百佳永辉。

综上所述，广州百佳永辉自百佳中国借入资金主要系为补充流动资金用于日常业务运营之目的，双方已就借款及展期事项签署合同。上述借款系企业之间发生的借贷行为，资金用于企业生产经营所需，符合相关法律法规的规定。

## （二）向福州颐玖叁叁豆制品有限公司（以下简称“颐玖叁叁”）及其控股子公司出借资金

2019 年起，公司向颐玖叁叁及其控股子公司成都北大荒豆制品有限公司、重庆北大荒豆制品有限公司累计出借资金 12,891,340.91 元，年利率为4.785%-4.875%，其中最晚的借款期限于 2025 年 5 月 17 日到期。截至本回复报告出具日，颐玖叁叁及其控股子公司的前述借款已逾期，且颐玖叁叁目前已停业清算，公司对前述逾期借款已全额计提减值准备。

颐玖叁叁系发行人参股子公司。北大荒食品集团哈尔滨豆制品有限公司（以下简称“北大荒”）与公司系颐玖叁叁第一大股东和第二大股东，分别持股 42%、40%。为满足建设自有工厂的资金需求，北大荒及公司向颐玖叁叁及其控股子公司提供借款，颐玖叁叁提供抵押担保。前述借款用于颐玖叁叁及其控股子公司工厂建设及偿还贷款。上述借款系企业之间发生的借贷行为，资金用于企业生产经营所需，符合相关法律法规的规定。

## （三）向福建闽威实业股份有限公司、福建省星源农牧科技股份有限公司提供商业保理服务

报告期内，发行人曾经的控股子公司永辉青禾商业保理（重庆）有限公司（以下简称“永辉青禾”）存在向发行人供应商福建闽威实业股份有限公司、福建省星源农牧科技股份有限公司提供商业保理服务的情况。

永辉青禾系经重庆两江新区现代服务业局批准设立的商业保理公司，其主营业务包括提供商业保理服务。因此，永辉青禾向福建闽威实业股份有限公司、福建省星源农牧科技股份有限公司提供商业保理服务已取得相关资质，符合其经营范围，符合相关法律法规的规定。

## 二、结合还款情况说明是否应计提预计负债，是否存在损害上市公司利益的情形

截至本回复出具之日，公司向福建闽威实业股份有限公司、福建省星源农牧科技股份有限公司提供的商业保理服务已结束，相关保理款已收回，因此不涉及计提预计负债。颐玖叁叁及其控股子公司逾期未偿还公司向其提供的借款，颐玖叁叁及其控股子公司成都北大荒豆制品有限公司目前已停业清算，重庆北大荒豆制品有限公司已于 2024年3月完成注销，公司对前述借款已全额计提减值准备。

公司对颐玖叁叁及其控股子公司借款主要系为其参股企业建设工厂、缓解偿债压力提供资金支持。公司对颐玖叁叁的实缴出资已完成，不存在经济利益很可能流出的现时义务，无需计提预计负债。

综上，公司对颐玖叁叁的实缴出资已完成，不存在经济利益很可能流出的现时义务，无需计提预计负债，亦不存在损害公司利益的情形。

## 三、中介机构核查程序及核查意见

## （一）核查程序

针对上述事项，保荐机构、发行人律师及申报会计师主要执行了以下核查程序：

1、查阅公司关联方报告期内相关借款合同或业务凭证；

2、通过企查查等公开信息渠道，查询关联方经营状态、股权结构等基本信息；

3、查阅永辉青禾商业保理业务相关资质文件。

## （二）核查意见

经核查，保荐机构、发行人律师及申报会计师认为：

报告期内，发行人与百佳中国、颐玖叁叁之间的资金拆借系企业之间发生的借贷行为，资金用于企业生产经营所需，符合相关法律法规的规定。发行人向其供应商提供的商业保理服务已取得相关资质，符合其经营范围，符合相关法律法规的规定。公司对颐玖叁叁的实缴出资已完成，不存在经济利益很可能流出的现时义务，无需计提预计负债，亦不存在损害公司利益的情形。

（本页无正文，为《关于永辉超市股份有限公司申请向特定对象发行股票的审核问询函的回复》之盖

![](images/4bb8fd3a3c0bef65884014e16f28f038d18457d0259d6d10130a24577c00734a.jpg)  
永辉超市股份有限究司 15010200

2026年4月30日

## 发行人董事长声明

本人已认真阅读《关于永辉超市股份有限公司申请向特定对象发行股票的审核问询函的回复》的全部内容，确认回复内容真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担相应的法律责任。

董事长：

张轩松

![](images/8541baf2351dbeeb3590033cf5a12010202aa22d74753e7f98e8d94096dec272.jpg)  
永辉超市股份有限公司 3501020036

年 月 日

（本页无正文，为《关于永辉超市股份有限公司申请向特定对象发行股票的审核问询函的回复》之签章页）

保荐代表人：

宏涛

朱宏涛

![](images/e6a73437313365495d7efc2cfadc06318e18768960ba15dff3b5dd10b4097929.jpg)

魏宏敏

![](images/9454e04ddb39398ce91213ff3c5e41a8fe74b66c9d5624c61d3693f94d373411.jpg)  
中信证券股份有限公司

## 保荐人董事长、法定代表人声

本人已认真阅读《关于永辉超市股份有限公司申请向特定对象发行股票的核问询函的回复》的全部内容，了解回复涉及问题的核查过程、本公司的内核风险控制流程，确认本公司按照勤勉尽责原则履行核查程序，审核问询函回复存在虚假记载、误导性陈述或者重大遗漏，并对上述文件的真实性、准确性、完整性、及时性承担相应法律责任。

保荐人董事长、法定代表人：

张佑君

![](images/48071782ced4b1c0aef1368814280ac01107a7fa6f136c8dc3403bc413fc12ab.jpg)  
中信证务股份有限公司