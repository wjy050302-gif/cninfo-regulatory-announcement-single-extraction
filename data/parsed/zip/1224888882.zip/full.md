证券代码：002586

# 浙江省围海建设集团股份有限公司关于深圳证券交易所关注函回复的公告

本公司及董事会全体成员保证公告内容真实、准确和完整，无虚假记载、误导性陈述或重大遗漏。

浙江省围海建设集团股份有限公司（以下简称“公司”、“上市公司”或“围海股份”）董事会于 2024 年 4 月 29 日收到深圳证券交易所上市公司管理一部下发的《关于对浙江省围海建设集团股份有限公司的关注函》（公司部关注函〔2024第72 号）（以下简称“关注函”）后高度重视，立即对关注函所涉及的相关问题进行了认真核查，形成如下书面回复并披露如下：

你公司 2022 年财务报告被出具无法表示意见的审计报告，无法表示意见基础为你公司子公司上海千年城市规划工程设计股份有限公司（以下简称“上海千年”）相关财务信息的真实性存疑。你公司在 2022 年年报披露后被实施退市风险警示。

你公司于 2023 年 12 月 29 日收到中国证监会宁波监管局（以下简称“宁波局”）出具的行政处罚事先告知书（以下简称“告知书”），涉及的事实主要包括：一是公司 2019 年度无合理依据对上海千年相关商誉全额计提商誉减值准备；二是部分工程项目会计处理存在问题，导致你公司虚增2021年度利润、虚减2022年度利润。

2024 年 1月31 日，你公司披露《关于前期会计差错更正及追溯调整的公告》（以下简称《会计差错更正公告》）称，你公司按照告知书内容更正工程项目相关会计差错，同时，根据自查结果，更正上海千年 2018 年至 2022 年收入、成本，并相应调整商誉减值、其他非流动资产减值、应收账款、信用减值损失等。你公司认为，对收购上海千年形成的商誉应在首次合并时（2018 年）作为投资损失确认，与告知书存在较大差异。

你公司《会计差错更正公告》表明会计差错更正事项导致你公司 2018 年由盈转亏，对 2021 年净利润影响比例达到 84.26%。根据《公开发行证券的公司信息披露编报规则第 19 号——财务信息的更正及相关披露（2020 年修订）》第五条规定，“如果会计差错更正事项对财务报表具有广泛性影响，或者该事项导致公司相关年度盈亏性质发生改变，会计师事务所应当对更正后财务报表进行全面审计并出具新的审计报告”，你公司应当聘请会计师事务所至少对2018年、2021 年等年份更正后的财务报表进行重新全面审计。截至目前，你公司尚未披露更正后的 2018 年至 2022 年财务报告。

我部同时关注到你公司董秘、财务总监已于 4 月17 日辞职；宁波局正在对你公司会计差错更正相关事项继续调查。

我部高度关注上述事项对你公司退市风险的影响，请你公司和你公司的年审会计师分别就以下事项进行核实说明：

问题 1、请你公司结合宁波局正在继续调查你公司会计差错更正相关事项的现状和相应年度需更正的财务报告的审计工作进展情况，对照我所《股票上市规则》等相关规定说明你公司是否存在重大违法退市风险。请你公司年审会计师说明在形成 2023 年度财务报告审计意见时是否充分考虑上述重大违法退市风险。

# 【公司回复】

一、请你公司结合宁波局正在继续调查你公司会计差错更正相关事项的现状和相应年度需更正的财务报告的审计工作进展情况，对照我所《股票上市规则》等相关规定说明你公司是否存在重大违法退市风险。

# （一）公司会计差错更正相关事项的现状和相应年度需更正的财务报告的审计工作进展情况

# 1、宁波局对于公司 2018 年度至 2022 年度会计差错更正事项的处罚决定

公司于2023年7月27日收到中国证券监督管理委员会（以下简称“证监会”）出具的《立案告知书》（证监立案字0222023005 号）后，积极配合证监会和中国证券监督管理委员会宁波监管局（以下简称“宁波局”）的调查工作，全面如实向证监会和宁波局反映汇报了公司的自查情况及差错更正情况。

公司于 2023 年 12 月 29 日收到宁波局出具的行政处罚事先告知书（甬证监告字[2023]4 号），涉及的事实主要包括：一是公司2019 年度无合理依据对上海千年相关商誉全额计提商誉减值准备；二是部分工程项目会计处理存在问题，导致你公司虚增 2021 年度利润、虚减 2022 年度利润。2024 年，宁波局在事先告知后，发现新增事实，并已补充调查完毕。公司于2025 年4月29 日收到宁波局出具的《行政处罚决定书》（[2025]2 号），认定公司2018 年、2019 年、2021 年、2022 年财务报告存在虚假记载的情况，涉及的事实主要包括：一是千年设计虚增收入、虚减成本导致公司相应年度报告存在虚假记载；二是公司部分工程项目未合理确认减值损失导致相应年度报告存在虚假记载。

根据宁波局《行政处罚决定书》及调查取证情况，公司在形成立案调查结论的基础上，进行了认真梳理及查证工作，对2018 年度至2022 年度的调整事项进行差错更正，并追溯调整各年度的财务报表。

2018 年度至 2022 年度，公司各年度会计差错更正事项对净利润的影响，均未出现盈亏性质发生变化的情形；除 2021 年度差错更正事项对当年度净利润的更正比例为 $1 1 3 . 9 9 \%$ 之外，其他年度差错更正事项对财务报表的影响均不具有重大且广泛性。各年度财务报表的调整情况具体列示如下：

（1）2018 年末/2018 年度

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>更正前金额</td><td rowspan=1 colspan=1>更正金额</td><td rowspan=1 colspan=1>更正后金额</td><td rowspan=1 colspan=1>更正比例</td></tr><tr><td rowspan=1 colspan=1>应收票据及应收账款</td><td rowspan=1 colspan=1>200,898.52</td><td rowspan=1 colspan=1>120.05</td><td rowspan=1 colspan=1>201,018.57</td><td rowspan=1 colspan=1>0.06%</td></tr><tr><td rowspan=1 colspan=1>递延所得税资产</td><td rowspan=1 colspan=1>4,477. 63</td><td rowspan=1 colspan=1>0.95</td><td rowspan=1 colspan=1>4,478.58</td><td rowspan=1 colspan=1>0.02%</td></tr><tr><td rowspan=1 colspan=1>应交税费</td><td rowspan=1 colspan=1>24,358.20</td><td rowspan=1 colspan=1>7.15</td><td rowspan=1 colspan=1>24,365.36</td><td rowspan=1 colspan=1>0.03%</td></tr><tr><td rowspan=1 colspan=1>其他应付款</td><td rowspan=1 colspan=1>56,062.91</td><td rowspan=1 colspan=1>19,281. 99</td><td rowspan=1 colspan=1>75, 344. 90</td><td rowspan=1 colspan=1>34.39%</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>74,296. 14</td><td rowspan=1 colspan=1>-16,854.96</td><td rowspan=1 colspan=1>57,441. 18</td><td rowspan=1 colspan=1>-22.69%</td></tr><tr><td rowspan=1 colspan=1>少数股东权益</td><td rowspan=1 colspan=1>18, 510. 65</td><td rowspan=1 colspan=1>-2,313.18</td><td rowspan=1 colspan=1>16,197. 48</td><td rowspan=1 colspan=1>-12.50%</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>353,978. 02</td><td rowspan=1 colspan=1>119.22</td><td rowspan=1 colspan=1>354, 097. 24</td><td rowspan=1 colspan=1>0.03%</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>298,679.23</td><td rowspan=1 colspan=1>7,244.06</td><td rowspan=1 colspan=1>305,923.29</td><td rowspan=1 colspan=1>2.43%</td></tr><tr><td rowspan=1 colspan=1>资产减值损失</td><td rowspan=1 colspan=1>-5,505.39</td><td rowspan=1 colspan=1>-6.32</td><td rowspan=1 colspan=1>-5, 511. 70</td><td rowspan=1 colspan=1>0.11%</td></tr><tr><td rowspan=1 colspan=1>所得税费用</td><td rowspan=1 colspan=1>8,109.37</td><td rowspan=1 colspan=1>-0.95</td><td rowspan=1 colspan=1>8,108.42</td><td rowspan=1 colspan=1>-0.01%</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>26,149.77</td><td rowspan=1 colspan=1>-7,130.21</td><td rowspan=1 colspan=1>19,019.56</td><td rowspan=1 colspan=1>-27.27%</td></tr></table>

# （2）2019 年末/2019 年度

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>更正前金额</td><td rowspan=1 colspan=1>更正金额</td><td rowspan=1 colspan=1>更正后金额</td><td rowspan=1 colspan=1>更正比例</td></tr><tr><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>239,809.07</td><td rowspan=1 colspan=1>-10,759. 50</td><td rowspan=1 colspan=1>229,049.57</td><td rowspan=1 colspan=1>-4.49%</td></tr><tr><td rowspan=1 colspan=1>商誉</td><td rowspan=1 colspan=1>50,575.17</td><td rowspan=1 colspan=1>-41.43</td><td rowspan=1 colspan=1>50,533.74</td><td rowspan=1 colspan=1>-0.08%</td></tr><tr><td rowspan=1 colspan=1>递延所得税资产</td><td rowspan=1 colspan=1>7,489.04</td><td rowspan=1 colspan=1>-83.95</td><td rowspan=1 colspan=1>7,405.09</td><td rowspan=1 colspan=1>-1.12%</td></tr><tr><td rowspan=1 colspan=1>应交税费</td><td rowspan=1 colspan=1>23,990.46</td><td rowspan=1 colspan=1>-10.19</td><td rowspan=1 colspan=1>23,980.28</td><td rowspan=1 colspan=1>-0. 04%</td></tr><tr><td rowspan=1 colspan=1>其他应付款</td><td rowspan=1 colspan=1>63,968. 60</td><td rowspan=1 colspan=1>26,344. 73</td><td rowspan=1 colspan=1>90,313.33</td><td rowspan=1 colspan=1>41.18%</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-56,682.32</td><td rowspan=1 colspan=1>-33, 556.73</td><td rowspan=1 colspan=1>-90,239.05</td><td rowspan=1 colspan=1>59.20%</td></tr><tr><td rowspan=1 colspan=1>归属母公司的所有者权益合计</td><td rowspan=1 colspan=1>405,049.81</td><td rowspan=1 colspan=1>-33, 556. 73</td><td rowspan=1 colspan=1>371,493.08</td><td rowspan=1 colspan=1>-8.28%</td></tr><tr><td rowspan=1 colspan=1>少数股东权益</td><td rowspan=1 colspan=1>20,721.50</td><td rowspan=1 colspan=1>-3,662. 69</td><td rowspan=1 colspan=1>17,058.81</td><td rowspan=1 colspan=1>-17. 68%</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>343,760. 41</td><td rowspan=1 colspan=1>-10, 797. 65</td><td rowspan=1 colspan=1>332, 962. 76</td><td rowspan=1 colspan=1>-3.14%</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>299,046.35</td><td rowspan=1 colspan=1>7,062. 74</td><td rowspan=1 colspan=1>306,109.09</td><td rowspan=1 colspan=1>2.36%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>14,863.21</td><td rowspan=1 colspan=1>630.52</td><td rowspan=1 colspan=1>15,493. 73</td><td rowspan=1 colspan=1>4.24%</td></tr><tr><td rowspan=1 colspan=1>信用减值损失</td><td rowspan=1 colspan=1>-90,149. 21</td><td rowspan=1 colspan=1>565.96</td><td rowspan=1 colspan=1>-89, 583. 25</td><td rowspan=1 colspan=1>-0.63%</td></tr><tr><td rowspan=1 colspan=1>资产减值损失</td><td rowspan=1 colspan=1>-30, 177. 23</td><td rowspan=1 colspan=1>-41.43</td><td rowspan=1 colspan=1>-30,218.67</td><td rowspan=1 colspan=1>0.14%</td></tr><tr><td rowspan=1 colspan=1>所得税费用</td><td rowspan=1 colspan=1>2,137. 35</td><td rowspan=1 colspan=1>84.89</td><td rowspan=1 colspan=1>2,222.24</td><td rowspan=1 colspan=1>3.97%</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>-111, 411. 50</td><td rowspan=1 colspan=1>-18,051.28</td><td rowspan=1 colspan=1>-129,462. 78</td><td rowspan=1 colspan=1>16.20%</td></tr></table>

# （3）2020 年末/2020 年度

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>更正前金额</td><td rowspan=1 colspan=1>更正金额</td><td rowspan=1 colspan=1>更正后金额</td><td rowspan=1 colspan=1>更正比例</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产</td><td rowspan=1 colspan=1>110, 781. 72</td><td rowspan=1 colspan=1>-41. 43</td><td rowspan=1 colspan=1>110, 740. 28</td><td rowspan=1 colspan=1>-0. 04%</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-125,906. 63</td><td rowspan=1 colspan=1>-41. 43</td><td rowspan=1 colspan=1>-125,948.06</td><td rowspan=1 colspan=1>0.03%</td></tr><tr><td rowspan=1 colspan=1>归母所有者权益</td><td rowspan=1 colspan=1>334,030. 74</td><td rowspan=1 colspan=1>-41.43</td><td rowspan=1 colspan=1>333,989. 31</td><td rowspan=1 colspan=1>-0.01%</td></tr></table>

# （4）2021 年末/2021 年度

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">更正前金额</td><td colspan="1" rowspan="1">更正金额</td><td colspan="1" rowspan="1">更正后金额</td><td colspan="1" rowspan="1">更正比例</td></tr><tr><td colspan="1" rowspan="1">应收账款</td><td colspan="1" rowspan="1">270,293.15</td><td colspan="1" rowspan="1">-18,408.02</td><td colspan="1" rowspan="1">251,885.12</td><td colspan="1" rowspan="1">-6.81%</td></tr><tr><td colspan="1" rowspan="1">存货</td><td colspan="1" rowspan="1">3,653.37</td><td colspan="1" rowspan="1">-3,501.88</td><td colspan="1" rowspan="1">151.50</td><td colspan="1" rowspan="1">-95.85%</td></tr><tr><td colspan="1" rowspan="1">合同资产</td><td colspan="1" rowspan="1">21,331. 13</td><td colspan="1" rowspan="1">1,346.64</td><td colspan="1" rowspan="1">22,677.77</td><td colspan="1" rowspan="1">6.31%</td></tr><tr><td colspan="1" rowspan="1">长期应收款</td><td colspan="1" rowspan="1">346,295.77</td><td colspan="1" rowspan="1">1,103.23</td><td colspan="1" rowspan="1">347,399.00</td><td colspan="1" rowspan="1">0.32%</td></tr><tr><td colspan="1" rowspan="1">商誉</td><td colspan="1" rowspan="1">25,171.74</td><td colspan="1" rowspan="1">-41.43</td><td colspan="1" rowspan="1">25,130.30</td><td colspan="1" rowspan="1">-0.16%</td></tr><tr><td colspan="1" rowspan="1">递延所得税资产</td><td colspan="1" rowspan="1">14,281. 96</td><td colspan="1" rowspan="1">-442.83</td><td colspan="1" rowspan="1">13,839.13</td><td colspan="1" rowspan="1">-3.10%</td></tr><tr><td colspan="1" rowspan="1">应付账款</td><td colspan="1" rowspan="1">206,625.09</td><td colspan="1" rowspan="1">4,227. 17</td><td colspan="1" rowspan="1">210,852.26</td><td colspan="1" rowspan="1">2.05%</td></tr><tr><td colspan="1" rowspan="1">合同负债</td><td colspan="1" rowspan="1">8,426.43</td><td colspan="1" rowspan="1">387.84</td><td colspan="1" rowspan="1">8,814.26</td><td colspan="1" rowspan="1">4.60%</td></tr><tr><td colspan="1" rowspan="1">应交税费</td><td colspan="1" rowspan="1">37,378.80</td><td colspan="1" rowspan="1">1,308.02</td><td colspan="1" rowspan="1">38,686.82</td><td colspan="1" rowspan="1">3.50%</td></tr><tr><td colspan="1" rowspan="1">其他应付款</td><td colspan="1" rowspan="1">77,871.05</td><td colspan="1" rowspan="1">42,845.47</td><td colspan="1" rowspan="1">120,716.52</td><td colspan="1" rowspan="1">55.02%</td></tr><tr><td colspan="1" rowspan="1">其他流动负债</td><td colspan="1" rowspan="1">1,808.12</td><td colspan="1" rowspan="1">23.27</td><td colspan="1" rowspan="1">1,831.39</td><td colspan="1" rowspan="1">1.29%</td></tr><tr><td colspan="1" rowspan="1">未分配利润</td><td colspan="1" rowspan="1">-102,282.46</td><td colspan="1" rowspan="1">-68,643.87</td><td colspan="1" rowspan="1">-170,926. 33</td><td colspan="1" rowspan="1">67.11%</td></tr><tr><td colspan="1" rowspan="1">归属母公司的所有者权益合计</td><td colspan="1" rowspan="1">357,726. 48</td><td colspan="1" rowspan="1">-68, 643.87</td><td colspan="1" rowspan="1">289,082.61</td><td colspan="1" rowspan="1">-19.19%</td></tr><tr><td colspan="1" rowspan="1">少数股东权益</td><td colspan="1" rowspan="1">14,273.11</td><td colspan="1" rowspan="1">-92.18</td><td colspan="1" rowspan="1">14,180.92</td><td colspan="1" rowspan="1">-0.65%</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">258,072.94</td><td colspan="1" rowspan="1">62.24</td><td colspan="1" rowspan="1">258,135.17</td><td colspan="1" rowspan="1">0.02%</td></tr><tr><td colspan="1" rowspan="1">营业成本</td><td colspan="1" rowspan="1">220,627.21</td><td colspan="1" rowspan="1">124.71</td><td colspan="1" rowspan="1">220,751.92</td><td colspan="1" rowspan="1">0.06%</td></tr><tr><td colspan="1" rowspan="1">投资收益</td><td colspan="1" rowspan="1">-940.24</td><td colspan="1" rowspan="1">675.31</td><td colspan="1" rowspan="1">-264.93</td><td colspan="1" rowspan="1">-71.82%</td></tr><tr><td colspan="1" rowspan="1">信用减值损失</td><td colspan="1" rowspan="1">-8,229.91</td><td colspan="1" rowspan="1">-874.60</td><td colspan="1" rowspan="1">-9,104.51</td><td colspan="1" rowspan="1">10.63%</td></tr><tr><td colspan="1" rowspan="1">资产减值损失</td><td colspan="1" rowspan="1">-15,739.30</td><td colspan="1" rowspan="1">-6,444.33</td><td colspan="1" rowspan="1">-22,183.63</td><td colspan="1" rowspan="1">40.94%</td></tr><tr><td colspan="1" rowspan="1">净利润</td><td colspan="1" rowspan="1">-5,882.88</td><td colspan="1" rowspan="1">-6,706.09</td><td colspan="1" rowspan="1">-12,588.97</td><td colspan="1" rowspan="1">113.99%</td></tr></table>

# （5）2022 年末/2022 年度

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>更正前金额</td><td rowspan=1 colspan=1>更正金额</td><td rowspan=1 colspan=1>更正后金额</td><td rowspan=1 colspan=1>更正比例</td></tr><tr><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>228,924.89</td><td rowspan=1 colspan=1>-17,630. 64</td><td rowspan=1 colspan=1>211, 294. 25</td><td rowspan=1 colspan=1>-7. 70%</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>3,385.18</td><td rowspan=1 colspan=1>1,578.66</td><td rowspan=1 colspan=1>4,963.84</td><td rowspan=1 colspan=1>46.63%</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>15,622.29</td><td rowspan=1 colspan=1>-4,181.56</td><td rowspan=1 colspan=1>11, 440.73</td><td rowspan=1 colspan=1>-26.77%</td></tr><tr><td rowspan=1 colspan=1>长期应收款</td><td rowspan=1 colspan=1>326,348.33</td><td rowspan=1 colspan=1>1,145.75</td><td rowspan=1 colspan=1>327,494. 08</td><td rowspan=1 colspan=1>0.35%</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产</td><td rowspan=1 colspan=1>21,829.49</td><td rowspan=1 colspan=1>-9,601.65</td><td rowspan=1 colspan=1>12,227.84</td><td rowspan=1 colspan=1>-43.98%</td></tr><tr><td rowspan=1 colspan=1>应付账款</td><td rowspan=1 colspan=1>209,870.33</td><td rowspan=1 colspan=1>-3,002.21</td><td rowspan=1 colspan=1>206,868.12</td><td rowspan=1 colspan=1>-1.43%</td></tr><tr><td rowspan=1 colspan=1>应交税费</td><td rowspan=1 colspan=1>37,572.53</td><td rowspan=1 colspan=1>1,279.59</td><td rowspan=1 colspan=1>38,852.12</td><td rowspan=1 colspan=1>3.41%</td></tr><tr><td rowspan=1 colspan=1>其他应付款</td><td rowspan=1 colspan=1>75,584.90</td><td rowspan=1 colspan=1>33,878.14</td><td rowspan=1 colspan=1>109,463.04</td><td rowspan=1 colspan=1>44.82%</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>-174, 480. 90</td><td rowspan=1 colspan=1>-60,889.67</td><td rowspan=1 colspan=1>-235,370. 56</td><td rowspan=1 colspan=1>34.90%</td></tr><tr><td rowspan=1 colspan=1>归属母公司的所有者权益合计</td><td rowspan=1 colspan=1>381, 174.01</td><td rowspan=1 colspan=1>-60,889.67</td><td rowspan=1 colspan=1>320,284.34</td><td rowspan=1 colspan=1>-15.97%</td></tr><tr><td rowspan=1 colspan=1>少数股东权益</td><td rowspan=1 colspan=1>10,050.64</td><td rowspan=1 colspan=1>44.70</td><td rowspan=1 colspan=1>10,095.34</td><td rowspan=1 colspan=1>0.44%</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>257, 344. 23</td><td rowspan=1 colspan=1>187. 14</td><td rowspan=1 colspan=1>257, 531.38</td><td rowspan=1 colspan=1>0.07%</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>238,939. 52</td><td rowspan=1 colspan=1>-9,261. 52</td><td rowspan=1 colspan=1>229,678.00</td><td rowspan=1 colspan=1>-3.88%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>15,169.90</td><td rowspan=1 colspan=1>10.01</td><td rowspan=1 colspan=1>15,179. 91</td><td rowspan=1 colspan=1>0.07%</td></tr><tr><td rowspan=1 colspan=1>信用减值损失</td><td rowspan=1 colspan=1>-13,612.30</td><td rowspan=1 colspan=1>1,019.45</td><td rowspan=1 colspan=1>-12,592.85</td><td rowspan=1 colspan=1>-7.49%</td></tr><tr><td rowspan=1 colspan=1>资产减值损失</td><td rowspan=1 colspan=1>-51,079.39</td><td rowspan=1 colspan=1>-3,009.83</td><td rowspan=1 colspan=1>-54,089.22</td><td rowspan=1 colspan=1>5.89%</td></tr><tr><td rowspan=1 colspan=1>所得税费用</td><td rowspan=1 colspan=1>7,511. 40</td><td rowspan=1 colspan=1>-442.83</td><td rowspan=1 colspan=1>7,068.57</td><td rowspan=1 colspan=1>-5.90%</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>-78,455.30</td><td rowspan=1 colspan=1>7,891.09</td><td rowspan=1 colspan=1>-70, 564. 21</td><td rowspan=1 colspan=1>-10.06%</td></tr></table>

备注：公司于 2020 年 5 月 15 日起对子公司上海千年丧失控制权，于 2021 年 12 月31 日重新取得控制权。上海千年 2020 年度、2021 年度的差错更正处于出表期间，因此对公司 2020 年度、2021 年度合并利润表不产生影响。

# 2、2018 年度至 2022 年度需更正的财务报告的审计工作进展情况

根据《公开发行证券的公司信息披露编报规则第19 号-财务信息的更正及相关披露》（2018 年修订）第五条的规定，“公司对已经公布的年度财务报表进行更正，需要聘请具有证券、期货相关业务资格的会计师事务所对更正后的财务报表进行全面审计或对相关更正事项进行专项鉴证。

（一）如果会计差错更正事项对财务报表具有广泛性影响，或者该事项导致公司相关年度盈亏性质发生改变，会计师事务所应当对更正后财务报表进行全面审计并出具新的审计报告;

（二）除上述情况外，会计师事务所可以仅对更正事项执行专项鉴证并出具专项鉴证报告。”

公司2018 至2022 年度的差错更正事项主要由于子公司上海千年的收入、成本调整事项所导致。公司各年度的差错更正均未导致公司合并及母公司净利润出现盈亏性质发生变化情形；除 2021 年度对净利润的更正比例为 $1 1 3 . 9 9 \%$ 之外，其他年度的差更事项对于合并报表的影响不具有重大且广泛性。

根据上述信息披露编报规则的相关规定，同时参照其他上市公司关于前期差错更正的披露情况，公司已聘请具有证券资质的会计师事务所对更正后的财务报表进行全面审计或对相关更正事项进行专项鉴证，其中：对公司更正后的2021年度财务报表进行全面审计并出具新的审计报告；对公司2018 年、2019 年、2020年、2022 年的更正事项执行专项鉴证并出具专项鉴证报告。

# （二）公司对照《股票上市规则（2024 年修订）》规定的重大违法退市情况的分析

在对 2018 年度至 2022 年度财务报表进行会计差错更正后，公司对各年度会计差错更正事项是否触及《股票上市规则（2024 年修订）》中的退市标准逐条进行了对照分析，公司不存在涉及重大违法退市的情况。

具体情况分析如下：

1、公司前期会计差错更正未涉及交易类强制退市情况、规范类强制退市情况，前期会计差错更正前后财务报表未触及财务类强制退市情况；

2、根据《行政处罚决定书》认定结果及公司的会计差错更正情况，在 2020年度及以后年度，公司涉及财务指标存在虚假记载的年度为 2021 年度、2022年度，不存在连续三年存在虚假记载的情况；

3、公司 2021 年度、2022 年度营业收入会计差错更正金额合计0.02亿元，不存在虚假记载的营业收入金额合计达到 5 亿元以上的情形；

4、公司 2021年度、2022年度净利润存在会计差错更正影响金额合计1.46亿元，不存在虚假记载的净利润金额合计达到 5 亿元以上的情形；

5、公司 2021 年度、2022 年度利润总额存在会计差错更正影响金额合计1.42 亿元，不存在虚假记载的利润总额金额合计达到 5 亿元以上的情形；

6、公司 2021 年度、2022 年度连续两年资产负债表会计差错更正金额合计 27.56 亿元，占披露的该两年度期末净资产合计金额的 $3 6 . 1 1 \%$ ，不存在公司披露的资产负债表连续两年均存在虚假记载，资产负债表虚假记载金额合计达到 5 亿元以上，且超过该两年披露的年度期末净资产合计金额的 $5 0 \%$ 的情形。

经对照分析，公司 2018 年度至 2022 年度会计差错更正事项均未触及《股票上市规则（2024 年修订）》中规定的重大违法退市标准。

# 【会计师回复】

# 一、请你公司年审会计师说明在形成 2023 年度财务报告审计意见时是否充分考虑上述重大违法退市风险。

关于公司是否存在上述重大违法退市风险，会计师执行了以下核查程序：

1、经向公司管理层了解，2023 年度年审会计师在对公司 2023 年报审计过程中已经充分考虑本关注函所述事项并实施了相关的审计程序，主要包括：

（1）了解立案调查期间公司配合调查情况及提供给监管部门的上海千年会计差错资料情况，对公司配合监管部门检查及提供上海千年会计差错证据和资料情况向公司相关高管实施访谈核查，详细了解公司及高管是否将自查结果和证据资料向监管全面如实汇报反映，是否存在遗漏和隐瞒。

（2）结合监管部门 2023 年 12 月下发的《行政处罚事先告知书》（甬证监告字[2023]4 号）和公司 2024 年 1 月 30 日公司董事会、监事会审议通过披露的《关于公司前期会计差错更正及追溯调整的议案》，检查公司就行政处罚事先告知书认定事项在 2023 年的账务调整情况，检查前期会计差错事项在2023 年的账务调整情况；同时向公司核实是否存在重大违法退市风险，并取得公司出具的相关分析说明。

（3）针对会计差错更正后的 2023 年财务报表期初财务数据，会计师按照《中国注册会计师审计准则第 1331 号——首次审计业务涉及的期初余额》(2019 年修订)对 2023 年期初余额的审计按照审计计划实施审计程序，取得充分适当的审计证据。

（4）检查公司 2023 年财务报表附注十四、其他重要事项中详细披露前期差错更正事项、信息披露违规被立案调查事项。

2、会计师结合 2025 年 4 月 29 宁波局出具的《行政处罚决定书》（[2025]2号），和公司董事会、监事会进行了沟通，对比监管部门 2023 年 12 月下发的《行政处罚事先告知书》（甬证监告字[2023]4 号）与 2025 年 4 月份下发的《行政处罚决定书》的差异情况，检查前期会计差错事项的最终更正情况；向公司核实最终的会计差错更正事项是否存在重大违法退市风险，并取得公司出具的相关分析说明。

3、根据公司最终会计差错更正的情况，对公司 2023 年财务报表期初数据进行复核，确认前期会计差错更正事项对公司 2023 年度财务报表不产生重大影响，不影响 2023 年审会计师对 2023 年度财务报告已发表的审计意见。

4、根据公司最终的会计差错更正情况，逐条对照《股票上市规则》中规定的退市标准，公司不存在触及重大违法退市风险的情况。

综上，会计师复核了 2023 年度会计师关于本关注函所述事项执行的审计程序，并进一步分析复核公司最终会计差错更正情况。根据宁波局的《行政处罚决定书》及公司最终的会计差错更正情况，公司并不存在重大违法退市风险；前期会计差错更正事项对公司 2023 年度财务报表不产生重大影响，不影响 2023 年审会计师对 2023 年度财务报告已发表的审计意见。

问题 2、请你公司年审会计师说明以前年度会计差错更正对 2023 年度期初数准确性的影响，详细说明针对 2023 年度期初数执行的审计程序，说明在 2018年至 2022 年财务报告更正及审计工作尚未完成的情形下，在形成 2023 年度财务报告审计意见时是否充分考虑期初数的错报风险。

# 【会计师回复】

# 一、请你公司年审会计师说明以前年度会计差错更正对 2023 年度期初数准确性的影响，详细说明针对 2023 年度期初数执行的审计程序。

针对以前年度会计差错更正对 2023 年财务报表期初数准确性的影响，会

计师实施了以下复核程序：

1、经向公司管理层了解，2023 年度年审会计师针对差错更正后的 2023年财务报表期初财务数据，按照《中国注册会计师审计准则第 1331 号——首次审计业务涉及的期初余额》（2019 年修订）对 2023 年期初余额实施了以下审计程序：

（1）在承接业务前后，通过信函、电话方式与前任会计师沟通并取得前任会计师的书面回函，沟通内容为第 1153 号准则第 9 条的内容；通过围海股份财务总监、财务经理获得了前任会计师对其前期财务报表审计确定的调整分录，了解前任会计师的审计程序实施情况、审计沟通有无分歧及保存的前期审计证据。

（2）对 2023 年初的资产负债、利润表项目，在实施本期的审计程序时，同步实施函证 2023 年会计科目的期初数据和上期发生额。

（3）检查前期重要资产、重要业务的会计凭证、原始附件、收付款记录及业务合同，与海关、税务及函证回函等外部证据分析核对。

（4）复核 2022 年期初的存货、固定资产的盘点记录及文件、检查上期存货交易记录或运用毛利百分比法等进行分析，获取有关本期期初存货余额的充分、适当的审计证据。

（5）获取并检查前任会计师的函证情况。

（6）取得围海股份收购上海千年的协议、收购时的审计评估报告，取得上海千年公司前期的审计报告、商誉评估报告，结合同行业上市公司的情况，分析上海千年公司前期重要财务报表和财务数据的合理性。

（7）检查 2023 年期初存货的盘点情况、固定资产盘点资料及相关资产的原始入账资料，检查前期存货、固定资产减值计提转销情况。

（8）检查上期财务报表的期初余额在本期的回款、支付及结转情况。

（9）检查其前期会计差错的更正底稿和报告，检查前期会计差错的更正处理情况。

通过实施上述审计程序，2023 年度年审会计师认为经过差错更正后，公司 2023 财务报表的期初余额在所有重大方面按照企业会计准则的规定编制并得到公允反映。

2、会计师按照《中国注册会计师审计准则第 1331 号——首次审计业务涉及的期初余额》（2019 年修订）的规定，对 2023 年度年审会计师执行的审计程序实施了必要的复核程序，未发现公司 2023 年度财务报表期初数存在重大错报风险。

# 二、说明在 2018 年至 2022 年财务报告更正及审计工作尚未完成的情形下，在形成 2023 年度财务报告审计意见时是否充分考虑期初数的错报风险。

1、会计师结合 2025 年 4 月 29 宁波局出具的《行政处罚决定书》（[2025]2号），和公司董事会、监事会进行了沟通。公司已根据宁波局出具的《行政处罚决定书》及调查取证情况，对 2018 年度至2022 年度经调查取证的调整事项进行差错更正，并追溯调整各年度的财务报表。

2、会计师按照《企业会计准则第 28 号——会计政策、会计估计变更和差错更正》的规定，复核公司与上述年度会计差错事项相关的差错更正及会计处理情况。经会计师复核确认，公司前期差错更正对2023 年度财务报表期初净资产的影响比例为 $1 , 6 3 \%$ ，对2023 年度期初数的准确性未产生重大影响。

通过执行上述复核程序，会计师认为，公司已根据宁波局出具的《行政处罚决定书》及调查取证情况，进行了认真梳理及核对工作。对2018 年度至2022年度经调查取证的调整事项进行差错更正，并追溯调整各年度的财务报表。经过前期差错更正后，公司 2023 财务报表的期初余额不存在重大错报风险；前期会计差错更正事项亦不影响2023年审会计师对2023年度财务报告已发表的审计意见。

问题 3、请你公司年审会计师详细说明针对董秘、财务总监离职可能揭示的潜在舞弊风险执行的审计程序，说明在形成 2023 年度财务报告审计意见时是否充分考虑前述关键人员的离职风险。

# 【会计师回复】

一、请你公司年审会计师详细说明针对董秘、财务总监离职可能揭示的潜在舞弊风险执行的审计程序，说明在形成 2023 年度财务报告审计意见时是否充分考虑前述关键人员的离职风险。

针对公司董秘、财务总监离职事项，会计师执行的主要审计程序如下：

1、了解 2023 年年审会计师所执行的审计程序和审计结论：

2023 年度年审会计师向公司核实了相关高管人员离职的原因及工作交接情况，向公司了解新任（兼任）董秘、财务总监岗位接替、工作交接、资料交接保管情况，未发现潜在舞弊风险及其他异常风险情况。

2023 年度年审会计师认为，在形成 2023 年度财务报告审计意见时，已经充分考虑前述关键人员离职风险的影响。

2、会计师向公司管理层、独立董事了解两人辞职的真实原因及工作交接情况，了解交接后公司各项生产经营、财务核算、信息披露等工作的开展情况。

3、会计师向公司现任董秘、财务总监了解工作具体交接情况及交接后的履职情况，了解交接后公司财务核算、信息披露等工作的开展情况。

4、针对公司可能存在的潜在舞弊风险，会计师执行以下审计程序：

（1）了解公司的业务性质、组织结构、经营活动及其相关的风险，以便识别和评估舞弊风险；

（2）评估公司管理层凌驾于控制之上的风险，并考虑是否存在舞弊的动机和机会；

（3）运用比较财务数据的趋势、比率和关系，以及与预期结果进行比较的分析程序识别异常或不一致的情况，考虑是否存在舞弊的迹象；

（4）复核会计估计是否存在不合理，并评价产生这种不合理的环境是否表明存在由于舞弊导致的重大错报风险；

（5）询问管理层和公司内部的其他人员是否存在或可能存在舞弊。

（6）评估公司前期差错更正事项是否存在潜在舞弊风险。

通过执行上述审计程序，会计师未发现公司存在潜在舞弊风险。

综上，通过实施上述程序并根据获得的审计证据，会计师认为，2024年4月17日公司前任董秘、财务总监离职后，新任（兼任）董秘、财务总监处于正常履职状态，公司的各项生产经营、财务核算、信息披露等工作均正常开展，未发现公司存在重大舞弊风险或其他异常风险情况。因此，前任董秘、财务总监的离职并不影响2023年度年审会计师对2023年度财务报告已发表的审计意见。

特此公告。

# 浙江省围海建设集团股份有限公司

董事会

二〇二五年十二月二十日