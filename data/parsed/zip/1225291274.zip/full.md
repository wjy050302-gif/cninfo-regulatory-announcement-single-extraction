# 关于深圳安培龙科技股份有限公司申请向特定对象发行股票的审核问询函的回复

保荐机构（主承销商）

华泰联合证券有限责任公司HUATAI UNITED SECURITIES CO.,LTD.

（深圳市前海深港合作区南山街道桂湾五路128号前海深港基金小镇B7栋401）

深圳证券交易所：

深圳安培龙科技股份有限公司（以下简称“公司”、“发行人”或“安培龙”）收到贵所于2026 年3月11 日下发的《关于深圳安培龙科技股份有限公司申请向特定对象发行股票的审核问询函》（审核函〔2026〕020020 号）（以下简称“《问询函》”），公司已会同华泰联合证券有限责任公司（以下简称“华泰联合证券”、“保荐机构”）、广东信达律师事务所（以下简称“发行人律师”）、中审众环会计师事务所（特殊普通合伙）（以下简称“发行人会计师”）进行了认真研究和落实，并按照问询函的要求对所涉及的事项进行了资料补充和问题回复，现提交贵所，请予以审核。

除非文义另有所指，本问询函回复中的简称与《深圳安培龙科技股份有限公司向特定对象发行股票并在创业板上市募集说明书（申报稿）》（以下简称“募集说明书”）中的释义具有相同涵义。

本问询函回复的字体说明如下：

<table><tr><td rowspan=1 colspan=1>问询函所列问题</td><td rowspan=1 colspan=1>黑体</td></tr><tr><td rowspan=1 colspan=1>对问询函所列问题的回复</td><td rowspan=1 colspan=1>宋体</td></tr><tr><td rowspan=1 colspan=1>对募集说明书的补充披露、修改</td><td rowspan=1 colspan=1>楷体、加粗</td></tr></table>

本问询函回复部分表格中单项数据加总数与表格合计数可能存在微小差异，均因计算过程中的四舍五入所形成。

## 目 录

目 录 .....  
问题 1 ......  
问题 2 ...... 52  
其他问题.. 137

## 问题1

申报材料显示，报告期内，发行人营业收入为62,550.34 万元、74,657.09 万元、94,016.42 万元和 86,210.26 万元，呈上升趋势，其中发行人热敏电阻及温度传感器收入分别为 35,972.44 万元、36,942.47 万元、45,440.38 万元和 36,584.82万元，占主营业务收入的 57.54%、49.55%、48.37%和 42.45%；发行人压力传感器收入分别为 24,741.41 万元、35,410.24 万元、46,800.21 万元和 48,173.72 万元，占主营业务收入的 39.58%、47.49%、49.82%和 55.90%；发行人氧传感器类及其他收入分别为 1,798.82 万元、2,203.67 万元、1,704.89 万元和 1,415.37 万元，占主营业务收入的 2.88%、2.96%、1.81%和1.64%。报告期内，发行人扣非归母净利润分别为 7,007.57 万元、7,313.62 万元、7,459.53 万元和 6,498.14 万元，发行人主营业务毛利率分别为 33.29%、31.57%、32.20%和 28.43%，其中压力传感器业务毛利率分别为 34.92%、30.81%、31.61 和 28.37%，呈下降趋势，氧传感器类及其他业务毛利率分别为 11.97%、21.10%、23.02%和 7.03%，存在较大波动。

报告期内，公司境外销售收入分别为 9,750.62 万元、10,671.10 万元、14,331.52万元和 12,999.04 万元，占主营业务收入比例分别为 15.60%、14.31%、15.26%和15.08%；公司外销业务主要采用以美元为主的外币进行结算，各期汇兑损益金额分别为-246.30 万元、-130.77 万元、-121.08 万元和 56.04 万元。

报告期各期末，发行人应收账款账面余额分别为28,592.06 万元、32,454.25万元、41,472.83 万元及 45,809.15 万元，呈上升趋势；发行人其他应收款余额分别为 748.24 万元、1,060.76 万元、715.84 万元和 1,053.28 万元，账龄 1 年以内的占比分别为 73.20%、56.61%、28.83%和 53.43%，最近三年呈下降趋势，主要系保证金的账龄随时间的推移有所增加。报告期各期末，发行人存货账面价值分别为 19,831.55 万元、19,965.88 万元、29,482.24 万元和 30,087.35 万元，存货跌价准备分别为 1,293.39 万元、1,544.09 万元、2,292.79 万元和 2,554.37 万元。

报告期各期末，发行人在建工程账面价值分别为 54,190.86 万元、4,906.41万元、2,706.15 万元和 6,282.79 万元，占非流动资产的比例分别为 66.96%、5.43%、2.68%和 5.74%；发行人固定资产账面价值分别为 13,729.98 万元、73,654.19 万元、80,617.13 万元和 83,704.38 万元，占非流动资产的比例分别为 16.97%、81.46%、79.83%和 76.47%，主要由房屋及建筑物和机器设备构成；报告期内，氧传感器

的产能利用率保持较低水平。

报告期内，发行人存在行政处罚事项。本次发行相关的董事会决议日前六个月至募集说明书签署日，发行人投资鼎汇创新中心，出资 300.00 万元，鼎汇创新中心主要从事具身智能机器人相关数据生态、操作系统、核心零部件及应用场景等方向的研发。

## 请发行人：

（1）区分业务板块说明报告期内增收不增利、毛利率呈下降趋势的原因及合理性,是否与同行业可比公司存在较大差异，是否存在业绩下滑的风险；说明报告期内氧传感器类及其他主营业务收入及毛利率存在较大波动的原因及合理性，是否与同行业可比公司同类业务可比。

（2）结合主要外销国家地区的贸易政策变动情况等,说明相关国家或地区贸易政策变动、汇率变动对公司经营的影响,汇兑损益与发行人相关业务规模及汇率波动情况是否匹配,公司应对汇率波动、贸易政策等相关风险的措施。

（3）说明其他应收款具体内容及账龄，交易对方与发行人是否存在关联关系；结合前述情况以及公司业绩情况等，说明应收款项规模与占比变动的原因及合理性，各期末坏账准备计提是否充分。

（4）结合公司经营、存货结构和库龄、期后结转情况、跌价计提政策等，说明存货规模及占比变动是否合理，跌价准备计提是否充分，与同行业可比公司是否存在较大差异。

（5）结合报告期内行政处罚等情况及相关法律法规的具体规定，说明发行人最近三年是否存在严重损害投资者合法权益或社会公众利益的重大违法行为，是否符合《注册办法》第十一条及《证券期货法律适用意见第 18 号》的相关规定。

（6）结合报告期内发行人房屋建筑物和设施使用情况、在建工程建设进展情况,说明公司固定资产减值计提是否充分,在建工程转固是否及时,相关会计处理是否符合《企业会计准则》的相关规定；说明氧传感器及其他产品产能利用率较低的原因及合理性，说明原有产能是否存在闲置风险，相关资产是否存在减值风险。

（7）列示可能涉及财务性投资的相关会计科目明细，包括账面价值、具体内容、是否属于财务性投资、占最近一期末归母净资产比例等；结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形；自本次发行相关董事会前六个月至今，公司已实施或拟实施的财务性投资的具体情况，说明是否涉及募集资金扣减情形。

请发行人补充披露相关风险。

请保荐人核查并发表明确意见，请会计师核查（1）-（4）（6）（7）并发表明确意见，请发行人律师核查（5）（7）并发表明确意见。

回复：

## 一、发行人说明

（一）区分业务板块说明报告期内增收不增利、毛利率呈下降趋势的原因及合理性，是否与同行业可比公司存在较大差异，是否存在业绩下滑的风险；说明报告期内氧传感器类及其他主营业务收入及毛利率存在较大波动的原因及合理性，是否与同行业可比公司同类业务可比

1、区分业务板块说明报告期内增收不增利、毛利率呈下降趋势的原因及合理性，是否与同行业可比公司存在较大差异，是否存在业绩下滑的风险

（1）公司报告期内营业收入增速大于净利润增速，主要受毛利率变动、期间费用率变动、信用减值损失和资产减值损失等因素影响，具有合理性

报告期内，公司利润表主要财务指标情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="2">项目</td><td colspan="2" rowspan="1">2025年度</td><td colspan="2" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">金额/比率</td><td colspan="1" rowspan="1">变动比例</td><td colspan="1" rowspan="1">金额/比率</td><td colspan="1" rowspan="1">变动比例</td><td colspan="1" rowspan="1">金额/比率</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">118, 347. 76</td><td colspan="1" rowspan="1">25. 88%</td><td colspan="1" rowspan="1">94,016.42</td><td colspan="1" rowspan="1">25.93%</td><td colspan="1" rowspan="1">74,657.09</td></tr><tr><td colspan="1" rowspan="1">毛利润</td><td colspan="1" rowspan="1">34, 390. 77</td><td colspan="1" rowspan="1">13. 45%</td><td colspan="1" rowspan="1">30,312.62</td><td colspan="1" rowspan="1">28.24%</td><td colspan="1" rowspan="1">23,637.79</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1">29. 06%</td><td colspan="1" rowspan="1">下降3.18个百分点</td><td colspan="1" rowspan="1">32.24%</td><td colspan="1" rowspan="1">增加0.58个百分点</td><td colspan="1" rowspan="1">31.66%</td></tr><tr><td colspan="1" rowspan="1">期间费用</td><td colspan="1" rowspan="1">24, 980. 77</td><td colspan="1" rowspan="1">33. 43%</td><td colspan="1" rowspan="1">18,721.42</td><td colspan="1" rowspan="1">33.10%</td><td colspan="1" rowspan="1">14,065.31</td></tr><tr><td colspan="1" rowspan="1">期间费用率</td><td colspan="1" rowspan="1">21.11%</td><td colspan="1" rowspan="1">增加1.20个百分点</td><td colspan="1" rowspan="1">19.91%</td><td colspan="1" rowspan="1">增加1.07个百分点</td><td colspan="1" rowspan="1">18.84%</td></tr><tr><td colspan="1" rowspan="1">信用减值损失</td><td colspan="1" rowspan="1">-302. 07</td><td colspan="1" rowspan="1">-80.15%</td><td colspan="1" rowspan="1">-1,521.50</td><td colspan="1" rowspan="1">272.39%</td><td colspan="1" rowspan="1">-408.58</td></tr><tr><td colspan="1" rowspan="1">资产减值损失</td><td colspan="1" rowspan="1">-953.38</td><td colspan="1" rowspan="1">-17. 64%</td><td colspan="1" rowspan="1">-1,157.64</td><td colspan="1" rowspan="1">52.75%</td><td colspan="1" rowspan="1">-757.86</td></tr><tr><td colspan="1" rowspan="1">净利润</td><td colspan="1" rowspan="1">9,070. 37</td><td colspan="1" rowspan="1">9.76%</td><td colspan="1" rowspan="1">8,263.76</td><td colspan="1" rowspan="1">3.44%</td><td colspan="1" rowspan="1">7,989.15</td></tr><tr><td colspan="1" rowspan="1">扣非归母净利润</td><td colspan="1" rowspan="1">8, 091. 58</td><td colspan="1" rowspan="1">8.47%</td><td colspan="1" rowspan="1">7,459.53</td><td colspan="1" rowspan="1">2.00%</td><td colspan="1" rowspan="1">7,313.62</td></tr></table>

报告期内，公司营业收入、扣非归母净利润持续增长，但扣非归母净利润增速小于营业收入增速，主要与毛利率变动、期间费用变动、信用减值损失和资产减值损失等因素有关，具有合理性。具体分析如下：

## ①2024 年度

2024 年度，发行人营业收入同比增长 25.93%，扣非归母净利润同比增长2.00%，营业收入增速大于扣非归母净利润增速，主要系期间费用率增长、信用减值损失及资产减值损失金额增长所致。

2024 年度，发行人期间费用率为 19.91%，同比增长1.07 个百分点；期间费用同比增长 33.10%，增长幅度大于营业收入增长幅度。主要原因为：（1）随着公司业绩增长和规模扩张，公司职工薪酬有所增加；（2）安培龙智能传感器产业园于 2023 年 10 月验收转固，2024 年度固定资产折旧金额增加；（3）公司为增强技术实力和行业竞争力，新增研发项目使得研发直接投入增加，具有合理性。

2024 年度，公司信用减值损失（损失以“-”号填列）为-1,521.50 万元，净损失增长较大，主要针对预计无法收回的盐城兵泽汽车零部件有限公司和盐城埃泰柯汽车零部件有限公司应收款项，单项计提坏账所致，具有合理性。2024 年度，公司资产减值损失（损失以“-”号填列）为-1,157.64 万元，净损失增长较大，主要系存货跌价损失随存货规模增长而增长所致，具有合理性。

综上，公司 2024 年度营业收入增速大于扣非归母净利润增速，主要是期间费用率增加、信用减值损失及资产减值损失金额增长所致。

## ②2025 年度

2025 年度，发行人营业收入同比增长 25.88%，扣非归母净利润同比增长

8.47%，增收幅度大于增利幅度，主要系毛利率下降、期间费用率增长所致。毛利率下降原因及合理性详见本题回复之“一/（一）/1/（1）/（2）公司分业务板块的毛利率变动主要受原材料价格变动、定价策略优化等因素影响，具有合理性”。

2025 年度，发行人期间费用率为 21.11%，同比增长 1.20 个百分点；期间费用同比增长 33.43%，增长幅度大于营业收入增长幅度。主要原因为：（1）随着公司业绩增长和规模扩张，公司销售人员、管理人员、研发人员均有所扩招，职工薪酬有所增加，同时差旅会议费、业务招待费均有所增长；（2）为增强技术实力和行业竞争力，公司新增研发项目及在研项目试产对应的研发直接投入增加，同时委托研发费用增加；（3）为提升公司产品境外市场竞争力，公司境外市场拓展咨询费用增加所致；（4）美元汇率下调，汇兑收益转为汇兑损失。

综上，公司2025年度营业收入增速大于扣非归母净利润增速，主要是毛利率下降、期间费用率增加所致。

（2）公司分业务板块的毛利率变动主要受原材料价格变动、定价策略优化等因素影响，具有合理性

报告期内，发行人主营业务区分业务板块的毛利率构成及变动情况如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td></tr><tr><td rowspan=1 colspan=1>热敏电阻及温度传感器</td><td rowspan=1 colspan=1>29. 43%</td><td rowspan=1 colspan=1>-3.72</td><td rowspan=1 colspan=1>33.15%</td><td rowspan=1 colspan=1>0.22</td><td rowspan=1 colspan=1>32.93%</td></tr><tr><td rowspan=1 colspan=1>压力传感器</td><td rowspan=1 colspan=1>29. 25%</td><td rowspan=1 colspan=1>-2.36</td><td rowspan=1 colspan=1>31.61%</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>30.81%</td></tr><tr><td rowspan=1 colspan=1>氧传感器类及其他</td><td rowspan=1 colspan=1>11. 20%</td><td rowspan=1 colspan=1>-11. 82</td><td rowspan=1 colspan=1>23.02%</td><td rowspan=1 colspan=1>1.92</td><td rowspan=1 colspan=1>21.10%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>29. 02%</td><td rowspan=1 colspan=1>-3.18</td><td rowspan=1 colspan=1> 32.20%</td><td rowspan=1 colspan=1>0.63</td><td rowspan=1 colspan=1>31.57%</td></tr></table>

报告期内，发行人主营业务毛利率分别为 31.57%、32.20%和29.02%，整体较为稳定，2025 年度有所下降。公司主要毛利由热敏电阻及温度传感器、压力传感器产品构成，合计占比分别为 98.02%、98.70%和99.36%。分产品板块分析具体如下：

①热敏电阻及温度传感器毛利率变动具有合理性

报告期内，发行人热敏电阻及温度传感器毛利率分别为32.93%、33.15%和29.43%。2023年度至2024 年度，公司热敏电阻及温度传感器毛利率整体较为平稳；2025 年度，发行人热敏电阻及温度传感器较上一年度减少3.72 个百分点，主要原因为：（1）因铜、银等大宗金属材料上涨导致公司的上游原材料价格上涨，公司产品原材料成本增加；（2）PTC 热敏电阻等部分产品销量减少导致单位产品分摊的成本增加。

因此，报告期内，发行人热敏电阻及温度传感器毛利率具有合理性。

②压力传感器毛利率变动具有合理性

报告期内，发行人压力传感器毛利率分别为 30.81%、31.61%和29.25%，总体略有下降。公司压力传感器主要服务于汽车产业链客户，下游客户通常执行“年降”的价格政策，平均单价整体呈下降趋势；结合下游客户单价下调情况，供应商战略配合降价，单位成本整体也呈下降趋势。

2024 年度，压力传感器毛利率回升0.80 个百分点，相对较为平稳。

2025 年度，压力传感器毛利率下降2.36 个百分点，主要是平均单价降幅大于单位成本降幅影响。（1）平均单价方面：2025 年度，在“年降”的价格政策背景下，为进一步增强市场竞争力，提升市场份额，发行人优化定价策略，下调了部分产品价格，部分主要客户价格下降幅度较大；（2）单位成本方面：2025年度，在金等大宗金属材料价格上涨背景下，发行人压力传感器单位成本有所下降，主要是公司结合下游客户单价下调情况，积极采取降本措施，供应商战略配合降价所致，但单位成本降幅低于单价降幅。

因此，报告期内压力传感器毛利率变动具有合理性。

综上，报告期内，公司出现增收幅度大于增利幅度的情形，主要与毛利率变动、期间费用变动、信用减值损失和资产减值损失等因素有关，具有合理性。

（3）公司毛利率水平、业绩趋势与同行业可比公司不存在较大差异

1）公司毛利率与同行业可比公司不存在重大差异

报告期内，发行人主营业务毛利率与可比公司比较情况如下：

<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">24. 46%</td><td colspan="1" rowspan="1">25.70%</td><td colspan="1" rowspan="1">23.99%</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">49.83%</td><td colspan="1" rowspan="1">49.64%</td><td colspan="1" rowspan="1">51.53%</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">19. 28%</td><td colspan="1" rowspan="1">22.76%</td><td colspan="1" rowspan="1">14.90%</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">17. 55%</td><td colspan="1" rowspan="1">17.10%</td><td colspan="1" rowspan="1">20.67%</td></tr><tr><td colspan="1" rowspan="1">平均值</td><td colspan="1" rowspan="1">27. 78%</td><td colspan="1" rowspan="1">28.80%</td><td colspan="1" rowspan="1">27.77%</td></tr><tr><td colspan="1" rowspan="1">可比公司范围</td><td colspan="1" rowspan="1">17. 55%-49.83%</td><td colspan="1" rowspan="1">17.10%-49.64%</td><td colspan="1" rowspan="1">14.90%-51.53%</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">29.02%</td><td colspan="1" rowspan="1">32.20%</td><td colspan="1" rowspan="1">31.57%</td></tr></table>

注：可比公司毛利率分别选取其可比业务毛利率。其中华工科技数据为根据其年报数据计算的敏感元器件类产品的毛利率；开特股份数据为根据其年报数据计算的传感器类产品的毛利率；苏奥传感数据为根据其年报数据计算的传感器及配件类产品的毛利率；保隆科技数据为根据其年报数据计算的传感器类产品的毛利率。

最近三年，公司主营业务毛利率基本稳定；同行业可比公司可比产品毛利率平均值分别为 27.77%、28.80%、27.78%，基本稳定；发行人主营业务毛利率处于同行业可比上市公司可比产品毛利率范围内，且略高于行业平均，主营业务毛利率变动趋势与同行业可比上市公司可比产品毛利率不存在重大差异。

2）公司营业收入、净利润变动情况与同行业可比公司整体趋势不存在较大差异

报告期内，公司营业收入变动情况与同行业可比公司情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>公司名称</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>增速</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>增速</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>华工科技</td><td rowspan=1 colspan=1>1, 435,476. 05</td><td rowspan=1 colspan=1>22.59%</td><td rowspan=1 colspan=1>1,170,917.55</td><td rowspan=1 colspan=1>14.70%</td><td rowspan=1 colspan=1>1,020,827.40</td></tr><tr><td rowspan=1 colspan=1>开特股份</td><td rowspan=1 colspan=1>112, 947. 23</td><td rowspan=1 colspan=1>36.68%</td><td rowspan=1 colspan=1>82,636.29</td><td rowspan=1 colspan=1>26.50%</td><td rowspan=1 colspan=1>65,326.86</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>229,448. 36</td><td rowspan=1 colspan=1>37.43%</td><td rowspan=1 colspan=1>166,956.64</td><td rowspan=1 colspan=1>48.87%</td><td rowspan=1 colspan=1>112,146.74</td></tr><tr><td rowspan=1 colspan=1>保隆科技</td><td rowspan=1 colspan=1>874,727.88</td><td rowspan=1 colspan=1>24.52%</td><td rowspan=1 colspan=1>702,486.83</td><td rowspan=1 colspan=1>19.12%</td><td rowspan=1 colspan=1>589,746.49</td></tr><tr><td rowspan=1 colspan=1>平均数</td><td rowspan=1 colspan=1>663,149.88</td><td rowspan=1 colspan=1>30.31%</td><td rowspan=1 colspan=1>530,749.33</td><td rowspan=1 colspan=1>27.30%</td><td rowspan=1 colspan=1> 447,011.87</td></tr><tr><td rowspan=1 colspan=1>中位数</td><td rowspan=1 colspan=1>552, 088. 12</td><td rowspan=1 colspan=1>30. 60%</td><td rowspan=1 colspan=1>434,721.74</td><td rowspan=1 colspan=1>22.81%</td><td rowspan=1 colspan=1>350,946.62</td></tr><tr><td rowspan=1 colspan=1>安培龙</td><td rowspan=1 colspan=1>118, 347. 76</td><td rowspan=1 colspan=1>25.88%</td><td rowspan=1 colspan=1>94,016.42</td><td rowspan=1 colspan=1>25.93%</td><td rowspan=1 colspan=1>74,657.09</td></tr></table>

报告期内，公司扣非归母净利润变动情况与同行业可比公司情况如下：  
单位：万元

<table><tr><td colspan="1" rowspan="2">公司名称</td><td colspan="2" rowspan="1">2025年度</td><td colspan="2" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">增速</td><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">增速</td><td colspan="1" rowspan="1">金额</td></tr><tr><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">118,746. 16</td><td colspan="1" rowspan="1">32.32%</td><td colspan="1" rowspan="1">89,742.89</td><td colspan="1" rowspan="1">9.02%</td><td colspan="1" rowspan="1">82,317.54</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">17, 058. 74</td><td colspan="1" rowspan="1">32.85%</td><td colspan="1" rowspan="1">12,841.01</td><td colspan="1" rowspan="1">22.89%</td><td colspan="1" rowspan="1">10,449.22</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">8,953.93</td><td colspan="1" rowspan="1">-3. 71%</td><td colspan="1" rowspan="1">9,299.36</td><td colspan="1" rowspan="1">21.72%</td><td colspan="1" rowspan="1">7,640.00</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">13,528. 95</td><td colspan="1" rowspan="1">-46. 40%</td><td colspan="1" rowspan="1">25,241.63</td><td colspan="1" rowspan="1">-14.00%</td><td colspan="1" rowspan="1">29,351.59</td></tr><tr><td colspan="1" rowspan="1">平均数</td><td colspan="1" rowspan="1">39,571.94</td><td colspan="1" rowspan="1">3.76%</td><td colspan="1" rowspan="1">34,281.22</td><td colspan="1" rowspan="1">9.91%</td><td colspan="1" rowspan="1">32,439.59</td></tr><tr><td colspan="1" rowspan="1">中位数</td><td colspan="1" rowspan="1">15,293. 85</td><td colspan="1" rowspan="1">14.30%</td><td colspan="1" rowspan="1">19,041.32</td><td colspan="1" rowspan="1">15.37%</td><td colspan="1" rowspan="1">19,900.41</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">8,091. 58</td><td colspan="1" rowspan="1">8. 47%</td><td colspan="1" rowspan="1">7,459.53</td><td colspan="1" rowspan="1">2.00%</td><td colspan="1" rowspan="1">7,313.62</td></tr></table>

由上表可知，报告期内，发行人收入、扣非归母净利润均呈现增长趋势，与同行业整体趋势不存在较大差异。

发行人收入增速水平整体与同行业中位数水平较为一致；同行业可比公司扣非归母净利润增速差异较大，主要是发行人、各同行业可比公司在业务种类、业务规模、区域布局等方面均存在差异，各公司之间可比性较弱：（1）在业务种类方面，同行业可比公司的可比业务收入占其营业收入的比例均不超过 40%，各公司在重点业务布局及行业地位方面亦存在差异，因此各公司之间整体净利润水平及变动情况可比性较弱；（2）在业务规模方面，发行人、各可比公司发展阶段存在一定差异，发行人与部分可比同行业公司在整体营业收入、净利润体量规模方面差异较大，可比性较弱；（3）在区域布局方面，各公司整体布局存在一定差异，部分同行业可比公司如保隆科技报告期外销收入占比达到 45%左右，与发行人存在一定差异。公司与可比公司在业务种类、业务规模、区域布局等方面具体差异如下：

<table><tr><td colspan="1" rowspan="2">公司名称</td><td colspan="2" rowspan="1">业务种类</td><td colspan="1" rowspan="2">业务规模</td><td colspan="1" rowspan="2">区域布局</td></tr><tr><td colspan="1" rowspan="1">收入结构</td><td colspan="1" rowspan="1">重点业务及行业地位</td></tr><tr><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">主营业务产品包括激光加工装备及智能制造产线、激光全息膜类系列产品、光电器件系列产品、敏感元器件、租赁及其他等产品。其中可比业务板块敏感元器件2025年度营业收入占比28.05%。</td><td colspan="1" rowspan="1">智能制造业务：中国最大的激光装备制造商之一；联接业务：全球光模块厂商排名中位列全球第八;感知业务：全球新能源汽车热管理和多功能传感器技术领导地位。</td><td colspan="1" rowspan="1">2025年营业收入143.55亿元；归母净利润14.71亿元。</td><td colspan="1" rowspan="1">公司总部位于湖北省武汉市。国内设立六大核心生产制造及研创基地，在华中、华南、华东、华北四大战略区域设立了 60余个办事处及40余个销售服务中心；同时通过13家海外子公司开展本地化运营。</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">主营业务产品包括传感器类、控制器类、执行器类、其他等产品。其中可比业务板块传感器类2025年度营业收入占比29.06%。</td><td colspan="1" rowspan="1">国内知名的汽车热系统产品提供商，国家级专精特新小巨人企业。</td><td colspan="1" rowspan="1">2025年营业收入11.29亿元；归母净利润1.73亿元。</td><td colspan="1" rowspan="1">公司总部位于湖北省武汉市。并在苏州、孝感等地设有子公司。</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">主营业务产品包括汽车传感器及配件、汽车燃油系统附件、汽车内饰件、新能源部件、车联网产品、汽车热管理系统零部件、其他等产品。其中可比业务板块汽车传感器及配件2025年度营业收入占比11.67%。</td><td colspan="1" rowspan="1">国内最大的汽车油位传感器生产厂家之一，国家专精特新小巨人企业。</td><td colspan="1" rowspan="1">2025年营业收入22.94亿元；归母净利润1.20亿元。</td><td colspan="1" rowspan="1">公司总部位于江苏省扬州市。并在武汉、烟台、常州、福州、芜湖等多地设有子公司。</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">主营业务产品包括气门嘴及配件、汽车金属管件、TPMS 及配件和工具、传感器、智能悬架、其他等产品。其中可比业务板块传感器2025年度营业收入占比9.00%。</td><td colspan="1" rowspan="1">气门嘴、平衡块、排气管、胎压监测系统、智能悬架等细分领域的全球领先供应商之一，是中国汽车供应链百强、上海市制造业五十强企业。</td><td colspan="1" rowspan="1">2025年营业收入87.47亿元；归母净利润2.13亿元。</td><td colspan="1" rowspan="1">公司总部位于上海市。公司在上海松江、上海临港、安徽宁国、安徽合肥、江苏高邮、湖北武汉和美国、德国、波兰和匈牙利等地有生产园区或研发、销售中心。2023年度、2024年度和2025年度，公司外销主营业务收入占比分别为52.14%、46.17%和41. 45%。</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">主营业务产品为热敏电阻及传感器。</td><td colspan="1" rowspan="1">国内少有能够实现压力传感器及氧传感器产业化的企业，国家级专精特新“小巨人”企业。</td><td colspan="1" rowspan="1">2025年营业收入11.83亿元，归母净利润0.91亿元。</td><td colspan="1" rowspan="1">公司总部位于深圳市，并在东莞、郴州、上海、重庆、武汉和中国香港、比利时、德国、泰国等地设有子公司。</td></tr></table>

综上，报告期内，发行人收入、扣非归母净利润均呈现增长趋势，与同行业整体趋势不存在较大差异；发行人及同行业可比公司之间净利润增速差异较大，主要是各公司在业务种类、业务规模、区域布局等存在差异所致，整体可比性较弱。

## （4）是否存在业绩下滑的风险

报告期内，公司实现营业收入 74,657.09 万元、94,016.42 万元和 118,347.76万元，实现扣非归母净利润 7,313.62 万元、7,459.53 万元和 8,091.58 万元，公司业绩呈现逐年增长趋势，预计未来业绩大幅下滑的风险较低，具体如下：

## 1）下游需求扩张、应用范围拓展，为公司业绩增长提供持续增长动力

报告期内，发行人产品主要应用于汽车、家电、储能等领域，下游市场稳中向好发展。在汽车领域，根据工信部数据，2025 年，我国汽车产量为3,451.1 万辆，同比增长10.4%；随着汽车智能化和电动化的发展，车身感知传感器的应用场景将更加丰富，其精度、可靠性和集成化程度也将不断提高，为汽车的安全性、舒适性和智能化提供更有力的支持。在家电领域，随着居民消费水平的不断提升，消费者对传统家电产品的关注点向品质化、高端化升级和一些新品类的快速成长也为市场注入新的活力，为传感器发展也迎来更广阔的市场空间。在储能领域，在全球可再生能源发展、储能成本下探、数据中心需求提升等因素驱动下，全球储能市场需求持续增长。同时，随着以人工智能、5G 通信、大数据等为代表的智能化时代到来，传感器作为重要的元件，应用范围日益广泛，在汽车电子、智能家居、智慧医疗、智慧工业等物联网各细分领域有着广泛应用，下游需求不断扩张。

## 2）发行人具备优质客户资源

凭借产品性能及质量、服务响应速度上的优势，公司与国内外知名品牌及其供应链企业建立了稳定的合作关系。在家电应用领域，公司合作的客户包括美的集团、格力电器、海尔智家、海信家电、方太、TCL、绿山咖啡、雀巢咖啡、东芝、三星等国内外知名家电终端品牌商；在汽车应用领域，公司的合作客户包括比亚迪、北美某知名新能源汽车客户、上汽集团、Stellantis、东风日产、长城汽车、东风汽车、长安汽车、奇瑞汽车、广汽埃安、理想、小鹏、赛力斯等，合作的汽车零部件厂商包括法雷奥、麦格纳、捷温、李尔、拓普集团、三花智控、万里扬、银轮股份等众多国内外知名客户。

优质客户的深度合作既为经营业绩提供坚实保障，又助力公司在行业领域建立品牌声誉。通过长期战略协作，公司在研发管理能力、生产组织能力、质量控制体系等核心环节实现显著提升，持续增强企业综合竞争力，为拓展新兴应用领域及开发优质客户资源奠定了坚实基础。

## 3）发行人技术水平领先，产品矩阵持续丰富，产品竞争力持续提升

公司始终坚持以技术创新为核心驱动力，致力于智能传感器领域的研发及应用，丰富产品矩阵，拓宽下游应用领域，不断提升产品的技术含量及产品附加值。基于敏感陶瓷材料以及MEMS 技术的深入研究，公司已开发出了高性能的PTC热敏电阻器、NTC 热敏电阻器、温度传感器、陶瓷电容式压力传感器、MEMS压力传感器、玻璃微熔压力传感器、氧传感器、氮氧传感器、力传感器等丰富产品矩阵，以满足不同市场需求。公司依托敏感陶瓷技术、MEMS 技术及IC 设计技术平台，在产品布局方面重点关注行业应用趋势及下游客户需求，培育出一系列具备竞争力的细分领域传感器产品，丰富公司产品品类，为未来公司的可持续发展奠定良好的业务基础。

综上所述，报告期内，公司营业收入、扣非归母净利润水平呈现增长趋势，受下游需求增长驱动，得益于发行人优质丰富的客户资源、领先的技术水平和富有竞争力的产品，发行人未来业绩大幅下滑的风险较低。

## 2、说明报告期内氧传感器类及其他主营业务收入及毛利率存在较大波动的原因及合理性，是否与同行业可比公司同类业务可比

报告期内，发行人氧传感器类及其他主营业务收入分别为 2,203.67 万元、1,704.89 万元和 1,964.52 万元，占主营业务收入的 2.96%、1.81%和 1.66%，规模和占比均较小。其中，公司其他主营业务收入主要为应部分客户需求代购的产品、试制样品、陶瓷基板、配件及其他传感器等，其收入、毛利规模和占比均较小，存在波动主要系其业务规模较小所致。

## （1）氧传感器类产品收入及毛利率存在波动具有合理性

报告期内，发行人氧传感器类业务收入、成本和毛利率如下：

单位：万元、万个

<table><tr><td colspan="1" rowspan="2">项目</td><td colspan="2" rowspan="1">2025年度</td><td colspan="2" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">数额</td><td colspan="1" rowspan="1">变动</td><td colspan="1" rowspan="1">数额</td><td colspan="1" rowspan="1">变动</td><td colspan="1" rowspan="1">数额</td></tr><tr><td colspan="1" rowspan="1">销售收入</td><td colspan="1" rowspan="1">937.74</td><td colspan="1" rowspan="1">5. 76%</td><td colspan="1" rowspan="1">886.71</td><td colspan="1" rowspan="1">-42.42%</td><td colspan="1" rowspan="1">1,539.93</td></tr><tr><td colspan="1" rowspan="1">毛利润</td><td colspan="1" rowspan="1">-141. 66</td><td colspan="1" rowspan="1">-375. 15%</td><td colspan="1" rowspan="1">51.48</td><td colspan="1" rowspan="1">-72.42%</td><td colspan="1" rowspan="1">186.68</td></tr><tr><td colspan="1" rowspan="1">销量</td><td colspan="1" rowspan="1">56.72</td><td colspan="1" rowspan="1">36. 13%</td><td colspan="1" rowspan="1">41.67</td><td colspan="1" rowspan="1">-25.69%</td><td colspan="1" rowspan="1">56.07</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1">-15. 11%</td><td colspan="1" rowspan="1">下降 20.91个百分点</td><td colspan="1" rowspan="1">5.81%</td><td colspan="1" rowspan="1">下降6.32个百分点</td><td colspan="1" rowspan="1">12.12%</td></tr></table>

报告期内，发行人氧传感器类业务收入分别为 1,539.93 万元、886.71 万元和937.74 万元，占主营业务收入的 2.07%、0.94%和 0.79%，规模和占比均较小。报告期内，发行人氧传感器类业务毛利率分别为12.12%、5.81%和-15.11%。

目前氧传感器类产品主要由国外厂商占据，处于国产替代进程中，公司市场拓展取得实质成效仍需一定的时间，客户结构、产品结构波动较大，因此销售收入和毛利率存在一定波动。

2024 年度，公司氧传感器类营业收入同比下降幅度较大，主要系发行人终止与部分风险客户的合作所致。

2025 年度，公司氧传感器类业务毛利率为负，主要系：（1）2025 年度，氧传感器类产品规模较小，单位成本相对较高；（2）氧传感器类产品中氧传感器芯体主要应用于售后服务市场，该市场竞争较为激烈，发行人为维持市场份额，单价有一定下调；（3）因铂等大宗金属材料上涨导致公司的上游原材料价格上涨，公司产品原材料成本增加。

## （2）氧传感器类产品不存在同行业可比公司同类业务数据可比

氧传感器类产品目前尚无公开可比的毛利率数据。除发行人外，国内厂商常州联德电子有限公司亦生产氧传感器类产品，但其未上市，未披露氧传感器毛利率相关数据；国内厂商四方光电（688665.SH）、云意电气（300304.SZ）亦生产氧传感器类产品，但其未披露氧传感器毛利率相关数据。氧传感器类产品国外主要厂商包括博世和日本特殊陶业株式会社，其生产的氧传感器配套用于发动机管理系统，未单独披露氧传感器毛利率相关数据。因此，氧传感器不存在同行业可比公司的毛利率相关数据。

传感器产品在业务规模较小时存在毛利率波动符合行业特点，如万创科技披露“公司的模块、传感器产品陆续从 2019 年开始研发和试产，尚处于样品和小批量生产销售阶段，销售规模较小，由于受特定产品及客户的毛利率影响，毛利率波动较大”。

综上，发行人氧传感器类及其他主营业务收入及毛利率存在较大波动具有合理性，不存在同行业可比公司公开数据。

## 3、公司已披露相关风险

公司已在募集说明书“重大事项提示”之“二、重大风险提示”之“（四）毛利率下降风险”和“第七节 与本次发行相关的风险因素”之“三、财务相关风险”之“1、毛利率下降风险”中披露毛利率下降相关风险，主要内容如下：

“报告期内，公司主营业务毛利率分别为 31.57%、32.20%和29.02%，公司主营业务毛利率受客户结构、产品结构、产品价格、原材料价格、人力成本、规模效应等因素影响，如果未来上述因素发生不利变化，将对公司的毛利率水平和盈利能力产生负面影响，公司面临主营业务毛利率下降的风险。”

公司已在募集说明书“重大事项提示”之“二、重大风险提示”之“（五）业绩下滑风险”和“第七节 与本次发行相关的风险因素”之“三、财务相关风险”之“5、业绩下滑风险”中披露业绩下滑相关风险，主要内容如下：

## “（五）业绩下滑风险

2023 年度、2024 年度、2025 年度及 2026 年 1-3 月，公司营业收入分别为74,657.09 万元、94,016.42 万元、118,347.76 万元和 26,176.62 万元，归属于上市公司股东的净利润分别为 7,989.15 万元、8,263.76 万元、9,074.52 万元和 309.18 万元。2026 年 1-3 月，公司归属于上市公司股东的净利润同比下降84.82%，主要系研发投入增加、毛利率下降、厂房搬迁的报废支出阶段性增加、汇兑损失和利息支出增加等因素的综合影响所致。未来，若宏观经济、产业政策、市场环境等发生重大不利变化，公司所处行业竞争加剧、市场开拓成效不佳、销售收入增长缓慢、原材料价格上涨、毛利率恢复不及预期，上述因素叠加会在未来对公司经营业绩造成较大不利影响。”

（二）结合主要外销国家地区的贸易政策变动情况等,说明相关国家或地区贸易政策变动、汇率变动对公司经营的影响,汇兑损益与发行人相关业务规模及汇率波动情况是否匹配,公司应对汇率波动、贸易政策等相关风险的措施

1、结合主要外销国家地区的贸易政策变动情况等，说明相关国家或地区贸易政策变动对公司经营的影响，公司应对贸易政策变动风险的措施

（1）报告期内主要外销国家地区的贸易政策变动情况及其对公司经营的影响

报告期内，公司境外销售收入金额分别为10,671.10 万元、14,331.52 万元和16,941.82 万元，占主营业务收入的比例分别为 14.31%、15.26%和 14.32%。

报告期内，公司外销收入的主要国家或地区情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>地区</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=2>2023年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>比例</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>比例</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>比例</td></tr><tr><td rowspan=1 colspan=1>中国香港</td><td rowspan=1 colspan=1>3,266.94</td><td rowspan=1 colspan=1>19.28%</td><td rowspan=1 colspan=1>3,915.29</td><td rowspan=1 colspan=1>27.32%</td><td rowspan=1 colspan=1>2,255.28</td><td rowspan=1 colspan=1>21.13%</td></tr><tr><td rowspan=1 colspan=1>泰国</td><td rowspan=1 colspan=1>1,704. 32</td><td rowspan=1 colspan=1>10.06%</td><td rowspan=1 colspan=1>1,497.09</td><td rowspan=1 colspan=1>10.45%</td><td rowspan=1 colspan=1>1,952.96</td><td rowspan=1 colspan=1>18.30%</td></tr><tr><td rowspan=1 colspan=1>马来西亚</td><td rowspan=1 colspan=1>2, 656.95</td><td rowspan=1 colspan=1>15. 68%</td><td rowspan=1 colspan=1>2,554.99</td><td rowspan=1 colspan=1>17.83%</td><td rowspan=1 colspan=1>1,400.57</td><td rowspan=1 colspan=1>13.12%</td></tr><tr><td rowspan=1 colspan=1>美国</td><td rowspan=1 colspan=1>1,218. 13</td><td rowspan=1 colspan=1>7.19%</td><td rowspan=1 colspan=1>1,403.54</td><td rowspan=1 colspan=1>9.79%</td><td rowspan=1 colspan=1>1,317.43</td><td rowspan=1 colspan=1>12.35%</td></tr><tr><td rowspan=1 colspan=1>越南</td><td rowspan=1 colspan=1>2, 262. 45</td><td rowspan=1 colspan=1>13.35%</td><td rowspan=1 colspan=1>979.97</td><td rowspan=1 colspan=1>6.84%</td><td rowspan=1 colspan=1>563.42</td><td rowspan=1 colspan=1>5.28%</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>5,833. 03</td><td rowspan=1 colspan=1>34. 43%</td><td rowspan=1 colspan=1>3,980.63</td><td rowspan=1 colspan=1>27.78%</td><td rowspan=1 colspan=1>3,181.45</td><td rowspan=1 colspan=1>29.81%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>16, 941. 82</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>14,331.52</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>10,671.10</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

报告期内，公司外销收入主要涉及中国香港、泰国、马来西亚、美国、越南等国家或地区。根据商务部官网等渠道公开检索结果显示，报告期内，除美国外，发行人主要境外销售客户所涉国家或地区贸易政策未发生重大影响。

报告期各期，公司对美国出口销售收入分别为1,317.43 万元、1,403.54 万元和 1,218.13 万元，占公司营业收入的比例分别为 1.76%、1.49%和 1.03%，规模和占比均较小。2025 年以来，美国对中国贸易政策发生多轮次变化。截至本回复出具日，美国对中国贸易政策仍存在不确定性。发行人已采取多项应对措施应对贸易政策变动的风险，且由于公司对美国出口业务规模较小，预计不会对发行人产生重大不利影响。

综上，报告期内，公司主要外销国家地区的贸易政策波动未对公司经营构成重大不利影响，公司境外经营具有稳定性、可持续性。

## （2）公司应对贸易政策变动风险的措施

针对贸易政策变化等潜在的境外经营风险，公司已制定并执行多维度的风险防范与应对措施：

（1）持续加大全球化布局，通过泰国基地（预计于2026 年投产）和欧洲研发中心，构建海外本土化供应能力，规避单一产地贸易政策波动风险；

（2）健全客户沟通协同机制，密切关注贸易政策变动情况，遇政策调整及时与客户友好协商、妥善应对，全力维护公司合法权益；

（3）强化合规管控能力，持续跟踪主要外销国家及地区法律法规与政策动态，严格保障境外业务全流程合规运营；

（4）深耕国内市场开拓，依托国内下游产业发展优势，加大国内客户拓展力度，优化国内外市场业务结构，有效对冲国际贸易政策变动带来的经营风险。

2、汇率变动对公司经营的影响，汇兑损益与发行人相关业务规模及汇率波动情况是否匹配，公司应对汇率波动风险的措施

## （1）汇率变动对公司经营的影响

报告期内，汇率变动对汇兑损益和利润总额的影响如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>汇兑收益（“-”表示损失）</td><td rowspan=1 colspan=1>-164. 02</td><td rowspan=1 colspan=1>121.08</td><td rowspan=1 colspan=1>130.77</td></tr><tr><td rowspan=1 colspan=1>利润总额</td><td rowspan=1 colspan=1>9,139. 19</td><td rowspan=1 colspan=1>8,964.17</td><td rowspan=1 colspan=1>8,866.41</td></tr><tr><td rowspan=1 colspan=1>汇兑损益占利润总额的比例</td><td rowspan=1 colspan=1>-1.79%</td><td rowspan=1 colspan=1>1.35%</td><td rowspan=1 colspan=1>1.47%</td></tr></table>

报告期内，公司汇兑收益分别为130.77 万元、121.08 万元和-164.02 万元，汇兑收益占利润总额的比例分别为 1.47%、1.35%和-1.79%，整体影响比例较小。因此，报告期内，汇率变动未对公司经营业绩产生重大不利影响。

## （2）汇兑损益与发行人相关业务规模及汇率波动情况是否匹配

公司境外销售主要采用美元为主要币种的外币进行结算。报告期内，公司汇

兑损益、外销收入规模及美元兑人民币汇率匹配情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>境外销售收入</td><td rowspan=1 colspan=1>16, 941. 82</td><td rowspan=1 colspan=1>14,331.52</td><td rowspan=1 colspan=1>10,671.10</td></tr><tr><td rowspan=1 colspan=1>汇兑收益（“-”表示损失）</td><td rowspan=1 colspan=1>-164. 02</td><td rowspan=1 colspan=1>121.08</td><td rowspan=1 colspan=1>130.77</td></tr><tr><td rowspan=1 colspan=1>本期美元兑人民币汇率波动幅度</td><td rowspan=1 colspan=1>-2. 22%</td><td rowspan=1 colspan=1>1.49%</td><td rowspan=1 colspan=1>1.70%</td></tr><tr><td rowspan=1 colspan=1>本期美元兑人民币平均汇率</td><td rowspan=1 colspan=1>7. 1429</td><td rowspan=1 colspan=1>7.1217</td><td rowspan=1 colspan=1>7.0467</td></tr></table>

注 1：数据来源于中国外汇交易中心的美元兑人民币汇率中间价；  
注 2：本期美元兑人民币平均汇率为当期汇率的算数平均值  
注 3：本期美元兑人民币汇率波动幅度=本期末美元兑人民币汇率中间价/上期末美元兑人民币汇率中间价-1。

2023 年度、2024 年度，美元兑人民币汇率上升幅度整体收窄，因此当年公司汇兑收益有所回落；2025 年度，美元平均汇率虽高于2024 年度平均汇率，但汇率整体呈下降趋势，使得 2025 年度产生部分汇兑损失。

因此，报告期内，发行人汇兑损益与外销业务规模及汇率波动情况相匹配。

## （3）公司应对汇率波动风险的措施

为了降低汇率波动对公司外销业务带来的影响，公司采取了一系列积极应对措施，具体如下：

1）综合历史汇率波动特征与市场汇率预判，建立实时动态的汇率检测体系，依据外汇市场变动趋势及公司资金使用计划，择机开展结汇操作，切实缓释汇率波动风险；

2）结合业务资金需求、客户回款等实际经营情况，对外币货币性项目实施统筹管控，优化资金配置效率，有效规避临时结汇产生的汇兑损失；

3）密切跟踪汇率变动带来的外汇风险敞口，持续强化管理层及财务人员汇率波动分析研判能力与外汇风险管理专业水平，夯实汇率风险防控能力。

## 3、公司已披露相关风险

公司已在募集说明书 “第七节 与本次发行相关的风险因素”之“一、行业与市场风险”之“3、国际贸易政策风险”中披露国际贸易政策相关风险，主要内容如下：

“报告期内，公司境外销售收入分别为 10,671.10 万元、14,331.52 万元和

16,941.82 万元，占主营业务收入比例分别为 14.31%、15.26%和 14.32%。目前全球产业格局不断调整，经济仍处于周期性波动当中。在此背景下，不同国家和地区之间的经济竞争加剧，以中美贸易摩擦为代表的国际贸易保护主义事件频发，对我国制造业的出口造成了一定不利影响，若此等情况进一步恶化，可能会对公司产品的销售产生不利影响，进而影响到公司未来的经营业绩。”

公司已在募集说明书 “第七节 与本次发行相关的风险因素”之“三、财务相关风险”之“4、汇率波动风险”中披露汇率波动相关风险，主要内容如下：

“报告期内，公司境外销售收入分别为 10,671.10 万元、14,331.52 万元和16,941.82 万元，占主营业务收入比例分别为 14.31%、15.26%和 14.32%。公司外销业务主要采用以美元为主的外币进行结算，各期汇兑损益金额分别为-130.77万元、-121.08 万元和164.02 万元。若未来汇率发生较大波动，且公司未能采取有效措施规避汇率风险，则将对公司经营业绩产生一定的不利影响。”

（三）说明其他应收款具体内容及账龄，交易对方与发行人是否存在关联关系；结合前述情况以及公司业绩情况等，说明应收款项规模与占比变动的原因及合理性，各期末坏账准备计提是否充分

1、说明其他应收款具体内容及账龄，交易对方与发行人是否存在关联关系报告期各期末，公司其他应收款按款项余额性质分类如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年末</td><td rowspan=1 colspan=2>2024年末</td><td rowspan=1 colspan=2>2023年末</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>押金/保证金</td><td rowspan=1 colspan=1>1,352. 01</td><td rowspan=1 colspan=1>79. 12%</td><td rowspan=1 colspan=1>557.70</td><td rowspan=1 colspan=1>77.91%</td><td rowspan=1 colspan=1>608.32</td><td rowspan=1 colspan=1>57.35%</td></tr><tr><td rowspan=1 colspan=1>应收非关联方往来款项</td><td rowspan=1 colspan=1>181. 47</td><td rowspan=1 colspan=1>10. 62%</td><td rowspan=1 colspan=1>158.15</td><td rowspan=1 colspan=1>22.09%</td><td rowspan=1 colspan=1>262.21</td><td rowspan=1 colspan=1>24.72%</td></tr><tr><td rowspan=1 colspan=1>应收出口退税</td><td rowspan=1 colspan=1>175. 33</td><td rowspan=1 colspan=1>10. 26%</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>190.23</td><td rowspan=1 colspan=1>17.93%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1,708.80</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>715.84</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>1,060.76</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

报告期各期末，发行人其他应收款余额分别为1,060.76 万元、715.84 万元和1,708.80 万元。公司其他应收款主要为押金/保证金。押金/保证金主要为履约保证金、房屋租赁押金等，其中履约保证金系行业惯例。2023 年末，发行人其他应收款规模较大，主要原因系应收非关联方往来款项及出口退税金额有所增加，应收非关联方往来款项增长主要系新增客户因其自身原因暂停合作项目应付给公司用于补偿公司项目支出的赔偿款。2025 年末，发行人其他应收款有所增加，主要原因系履约保证金增加、新增融资租赁保证金所致。2025 年，公司将一批生产设备以协议价款5,550.00万元的价格售后回租给远东国际融资租赁有限公司，应收其融资租赁保证金 550.00 万元。

报告期各期末，公司其他应收款账龄情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年末</td><td rowspan=1 colspan=2>2024年末</td><td rowspan=1 colspan=2>2023年末</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1,169.95</td><td rowspan=1 colspan=1>68. 47%</td><td rowspan=1 colspan=1>206.36</td><td rowspan=1 colspan=1>28.83%</td><td rowspan=1 colspan=1>600.52</td><td rowspan=1 colspan=1>56.61%</td></tr><tr><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>71. 98</td><td rowspan=1 colspan=1>4. 21%</td><td rowspan=1 colspan=1>98.44</td><td rowspan=1 colspan=1>13.75%</td><td rowspan=1 colspan=1>365.44</td><td rowspan=1 colspan=1>34.45%</td></tr><tr><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>83. 64</td><td rowspan=1 colspan=1>4.89%</td><td rowspan=1 colspan=1>343.54</td><td rowspan=1 colspan=1>47.99%</td><td rowspan=1 colspan=1>44.21</td><td rowspan=1 colspan=1>4.17%</td></tr><tr><td rowspan=1 colspan=1>3-4年</td><td rowspan=1 colspan=1>325. 47</td><td rowspan=1 colspan=1>19. 05%</td><td rowspan=1 colspan=1>16.91</td><td rowspan=1 colspan=1>2.36%</td><td rowspan=1 colspan=1>18.11</td><td rowspan=1 colspan=1>1.71%</td></tr><tr><td rowspan=1 colspan=1>4-5年</td><td rowspan=1 colspan=1>16.91</td><td rowspan=1 colspan=1>0. 99%</td><td rowspan=1 colspan=1>18.11</td><td rowspan=1 colspan=1>2.53%</td><td rowspan=1 colspan=1>13.48</td><td rowspan=1 colspan=1>1.27%</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>40.85</td><td rowspan=1 colspan=1>2.39%</td><td rowspan=1 colspan=1>32.48</td><td rowspan=1 colspan=1>4.54%</td><td rowspan=1 colspan=1>19.00</td><td rowspan=1 colspan=1>1.79%</td></tr><tr><td rowspan=1 colspan=1>账面余额</td><td rowspan=1 colspan=1>1,708.80</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>715.84</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>1,060.76</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>坏账准备</td><td rowspan=1 colspan=2>299. 54</td><td rowspan=1 colspan=2>144.29</td><td rowspan=1 colspan=2>114.25</td></tr><tr><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=2>1, 409. 27</td><td rowspan=1 colspan=2>571.55</td><td rowspan=1 colspan=2>946.51</td></tr></table>

2023 年以来，公司 1年以上其他应收款账龄有所增加，主要系押金/保证金的账龄随时间的推移有所增加。截至报告期末，发行人账龄为3-4 年的其他应收款余额为 325.47 万元，均为押金/保证金，包括对海尔、TCL 等客户的履约保证金和对深圳市名扬物业管理有限公司等的租赁押金等，公司与相关交易对手合作关系持续存续，上述款项对应的交易尚在进行。

截至报告期末，公司其他应收款均与公司经营直接相关，与交易对象的往来均有合理的商业背景，与其他应收款交易对手不存在关联关系。

综上，公司其他应收款核算内容主要系押金/保证金，公司与交易对手不存在关联关系，其他应收款余额及账龄结构变动具有合理性。

2、结合前述情况以及公司业绩情况等，说明应收款项规模与占比变动的原因及合理性，各期末坏账准备计提是否充分

（1）发行人应收款项（不含其他应收款）规模与占比变动具有合理性

报告期内，公司应收款项（不含其他应收款）与收入变动情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年度/2025年末</td><td rowspan=1 colspan=2>2024年度/2024年末</td><td rowspan=1 colspan=2>2023年度/2023年末</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>39,050. 28</td><td rowspan=1 colspan=1>76.11%</td><td rowspan=1 colspan=1>38,089.79</td><td rowspan=1 colspan=1>80.38%</td><td rowspan=1 colspan=1>30,526.45</td><td rowspan=1 colspan=1>77.98%</td></tr><tr><td rowspan=1 colspan=1>应收票据</td><td rowspan=1 colspan=1>7,919. 36</td><td rowspan=1 colspan=1>15.44%</td><td rowspan=1 colspan=1>6,624.93</td><td rowspan=1 colspan=1>13.98%</td><td rowspan=1 colspan=1>6,228.57</td><td rowspan=1 colspan=1>15.91%</td></tr><tr><td rowspan=1 colspan=1>应收款项融资</td><td rowspan=1 colspan=1>4,335. 04</td><td rowspan=1 colspan=1>8.45%</td><td rowspan=1 colspan=1>2,673.68</td><td rowspan=1 colspan=1>5.64%</td><td rowspan=1 colspan=1>2,391.33</td><td rowspan=1 colspan=1>6.11%</td></tr><tr><td rowspan=1 colspan=1>应收款项合计</td><td rowspan=1 colspan=1>51,304. 68</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>47,388.40</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>39,146.36</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>118, 347. 76</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>94,016.42</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>74,657.09</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>应收款项占营业收入的比例</td><td rowspan=1 colspan=1>43.35%</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>50.40%</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1> 52.43%</td><td rowspan=1 colspan=1>-</td></tr></table>

报告期内，公司应收款项（不含其他应收款）分别为39,146.36 万元、47,388.40万元和 51,304.68 万元，主要系公司对主要客户一般采用赊销的销售政策，货款的结算周期一般在1-4 个月，结算方式包括银行承兑汇票、商业承兑汇票、应收账款债权凭证、银行转账等。报告期内，随着公司营业收入规模的不断提高，应收款项规模也随之增加。

报告期内，应收款项与收入的变动方向基本一致，占营业收入的比例分别为52.43%、50.40%和43.35%，占比基本稳定，应收账款增长与营业收入匹配。

综上所述，发行人应收款项规模增长主要系随营业收入规模的不断提高而增长所致，应收款项占营业收入的比例基本稳定，应收账款增长与营业收入匹配，具有合理性。

## （2）发行人其他应收款规模变动具有合理性

报告期内，发行人其他应收款余额分别为 1,060.76 万元、715.84 万元和1,708.80 万元，主要由押金/保证金、应收非关联方往来款项等构成，其他应收款规模变动具有合理性，参见本题之“一/（三）/1、说明其他应收款具体内容及账龄，交易对方与发行人是否存在关联关系”。

## （3）发行人应收款项各期末坏账准备计提充分

## 1）应收票据及应收款项融资

公司应收票据、应收款项融资主要系与客户部分货款采用票据结算所结存的余额。报告期各期末，公司应收票据、应收款项融资的构成情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=1 colspan=1>应收票据账面余额</td><td rowspan=1 colspan=1>8,042. 20</td><td rowspan=1 colspan=1>6,719.35</td><td rowspan=1 colspan=1>6,287.86</td></tr><tr><td rowspan=1 colspan=1>其中：银行承兑汇票</td><td rowspan=1 colspan=1>5, 585. 42</td><td rowspan=1 colspan=1>4,871.39</td><td rowspan=1 colspan=1>5,102.12</td></tr><tr><td rowspan=1 colspan=1>商业承兑汇票</td><td rowspan=1 colspan=1>2, 456. 78</td><td rowspan=1 colspan=1>1,847.96</td><td rowspan=1 colspan=1>1,185.74</td></tr><tr><td rowspan=1 colspan=1>减：商业承兑汇票坏账准备</td><td rowspan=1 colspan=1>122. 84</td><td rowspan=1 colspan=1>94.42</td><td rowspan=1 colspan=1>59.29</td></tr><tr><td rowspan=1 colspan=1>应收票据账面价值</td><td rowspan=1 colspan=1>7,919. 36</td><td rowspan=1 colspan=1>6,624.93</td><td rowspan=1 colspan=1>6,228.57</td></tr><tr><td rowspan=1 colspan=1>应收款项融资</td><td rowspan=1 colspan=1>4, 335. 04</td><td rowspan=1 colspan=1>2,673.68</td><td rowspan=1 colspan=1>2,391.33</td></tr><tr><td rowspan=1 colspan=1>其中：银行承兑汇票</td><td rowspan=1 colspan=1>4, 335. 04</td><td rowspan=1 colspan=1>2,673.68</td><td rowspan=1 colspan=1>2,391.33</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>12, 254. 41</td><td rowspan=1 colspan=1>9,298.61</td><td rowspan=1 colspan=1>8,619.91</td></tr></table>

报告期内，公司应收票据列报信用等级较低的银行承兑汇票和财务公司承兑汇票，应收款项融资列报信用等级较高的银行承兑汇票。报告期内，应收票据和应收款项融资的管理情况良好，所有已到期票据均已完成兑付或终止确认，票据的流动性较高，未出现兑付违约的情形。

①同行业可比公司对应收票据坏账计提的处理如下：

<table><tr><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">应收票据坏账准备计提方法</td><td colspan="1" rowspan="1">具体处理</td></tr><tr><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">银行承兑汇票组合：除存在客观证据表明无法收回外，不计提信用减值准备。商业承兑汇票组合：与应收账款账龄组合相同。</td><td colspan="1" rowspan="1">银行承兑汇票未计提坏账准备商业承兑汇票参考应收账款账龄组合</td></tr><tr><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">银行承兑汇票组合：本公司认为所持有的银行承兑汇票不存在重大的信用风险，不会因银行或其他出票人违约而产生重大损失。商业承兑汇票组合：按出票人的信用优质程度分级，视同应收账款评估预期信用损失。</td><td colspan="1" rowspan="1">银行承兑汇票未计提坏账准备商业承兑汇票参考应收账款计提</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">银行承兑票据组合：参考历史信用损失经验，结合当前状况以及对未来经济状况的预测，通过违约风险口和整个存续期预期信用损失率，计算预期信用损失。商业承兑汇票组合：参照应收账款，按账龄与整个存续期预期信用损失率对照表计提。</td><td colspan="1" rowspan="1">银行承兑汇票未计提坏账准备商业承兑汇票参考应收账款账龄组合</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">参考历史信用损失经验，结合当前状况及对未来」</td><td colspan="1" rowspan="1">银行承兑汇票未计提坏账</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">经济状况的预测，通过违约风险口和整个存续期预期信用损失率，计算预期信用损失。</td><td colspan="1" rowspan="1">准备报告期内无商业承兑汇票</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">按照相当于整个存续期内的预期信用损失金额计量损失准备。</td><td colspan="1" rowspan="1">银行承兑汇票按5%计提坏账准备报告期内无商业承兑汇票</td></tr></table>

与同行业可比公司相比，公司应收票据坏账准备计提方法和具体处理不存在重大差异，公司计提坏账准备的政策谨慎且合理。其中，发行人商业承兑汇票参考应收账款账龄组合计提坏账准备，公司应收账款账龄组合计提坏账准备比例与同行业公司不存在重大差异，详见本题回复“一/（三）/2/（3）发行人应收款项各期末坏账准备计提充分”之“2）应收账款”。

②公司应收款项融资核算自初始确认日起到期期限在一年内（含一年）的以公允价值计量且其变动计入其他综合收益的应收票据和应收账款。根据《企业会计准则第22 号——金融工具确认和计量》第四十六条规定：“分类为以摊余成本计量的金融资产和以公允价值计量且其变动计入其他综合收益的金融资产以预计信用损失为基础进行减值会计处理并确认损失准备。”报告期内，公司应收款项融资核算的内容为信用级别较高的银行承兑汇票，该类票据在背书或贴现后予以终止确认，期末结存的余额系公司在手的票据，该类银行承兑汇票信用等级高，到期延付、遭拒付而被追索的风险较小，信用风险不会显著增加。因此，公司应收款项融资未计提坏账准备合理。

综上所述，发行人应收票据及应收款项融资坏账准备计提充分，符合《企业会计准则》的相关规定。

## 2）应收账款

报告期各期末，发行人应收账款坏账准备计提情况如下：

单位：万元、%

<table><tr><td colspan="1" rowspan="2">类别</td><td colspan="2" rowspan="1">账面余额</td><td colspan="2" rowspan="1">坏账准备</td><td colspan="1" rowspan="2">账面价值</td></tr><tr><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">比例</td><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">计提比例</td></tr><tr><td colspan="6" rowspan="1">2025年12月31日</td></tr><tr><td colspan="1" rowspan="1">单项计提坏账准备的应收账款</td><td colspan="1" rowspan="1">1,019. 44</td><td colspan="1" rowspan="1">2.41</td><td colspan="1" rowspan="1">1,019.44</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">1</td></tr><tr><td colspan="1" rowspan="1">按组合计提坏账准备的应收账款</td><td colspan="1" rowspan="1">41, 222. 20</td><td colspan="1" rowspan="1">97.59</td><td colspan="1" rowspan="1">2,171.92</td><td colspan="1" rowspan="1">5.27</td><td colspan="1" rowspan="1">39,050.28</td></tr><tr><td colspan="1" rowspan="1">其中：账龄组合</td><td colspan="1" rowspan="1">41, 222. 20</td><td colspan="1" rowspan="1">97.59</td><td colspan="1" rowspan="1">2,171.92</td><td colspan="1" rowspan="1">5.27</td><td colspan="1" rowspan="1">39,050.28</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">42,241. 64</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">3,191.36</td><td colspan="1" rowspan="1">7.56</td><td colspan="1" rowspan="1">39,050.28</td></tr><tr><td colspan="6" rowspan="1">2024年12月31日</td></tr><tr><td colspan="1" rowspan="1">单项计提坏账准备的应收账款</td><td colspan="1" rowspan="1">1,283.85</td><td colspan="1" rowspan="1">3.10</td><td colspan="1" rowspan="1">1,283.85</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">1</td></tr><tr><td colspan="1" rowspan="1">按组合计提坏账准备的应收账款</td><td colspan="1" rowspan="1">40,188.98</td><td colspan="1" rowspan="1">96.90</td><td colspan="1" rowspan="1">2,099.20</td><td colspan="1" rowspan="1">5.22</td><td colspan="1" rowspan="1">38,089.79</td></tr><tr><td colspan="1" rowspan="1">其中：账龄组合</td><td colspan="1" rowspan="1">40,188.98</td><td colspan="1" rowspan="1">96.90</td><td colspan="1" rowspan="1">2,099.20</td><td colspan="1" rowspan="1">5.22</td><td colspan="1" rowspan="1">38,089.79</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">41,472.83</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">3,383.05</td><td colspan="1" rowspan="1">8.16</td><td colspan="1" rowspan="1">38,089.79</td></tr><tr><td colspan="6" rowspan="1">2023年12月31日</td></tr><tr><td colspan="1" rowspan="1">单项计提坏账准备的应收账款</td><td colspan="1" rowspan="1">151.31</td><td colspan="1" rowspan="1">0.47</td><td colspan="1" rowspan="1">151.31</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">-</td></tr><tr><td colspan="1" rowspan="1">按组合计提坏账准备的应收账款</td><td colspan="1" rowspan="1">32,302.94</td><td colspan="1" rowspan="1">99.53</td><td colspan="1" rowspan="1">1,776.49</td><td colspan="1" rowspan="1">5.50</td><td colspan="1" rowspan="1">30,526.45</td></tr><tr><td colspan="1" rowspan="1">其中：账龄组合</td><td colspan="1" rowspan="1">32,302.94</td><td colspan="1" rowspan="1">99.53</td><td colspan="1" rowspan="1">1,776.49</td><td colspan="1" rowspan="1">5.50</td><td colspan="1" rowspan="1">30,526.45</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">32,454.25</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">1,927.80</td><td colspan="1" rowspan="1">5.94</td><td colspan="1" rowspan="1">30,526.45</td></tr></table>

如上表所示，公司应收账款主要采用按组合计提的方式计提坏账准备，少量预计难以收回的应收账款采取单项计提方式。  
①单项计提坏账准备的应收账款情况  
单位：万元

<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>账面余额</td><td rowspan=1 colspan=1>坏账准备</td><td rowspan=1 colspan=1>计提比例</td><td rowspan=1 colspan=1>计提理由</td></tr><tr><td rowspan=1 colspan=5>2025年12月31日</td></tr><tr><td rowspan=1 colspan=1>盐城兵泽汽车零部件有限公司</td><td rowspan=1 colspan=1>643.53</td><td rowspan=1 colspan=1>643.53</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>盐城埃泰柯汽车零部件有限公司</td><td rowspan=1 colspan=1>375. 91</td><td rowspan=1 colspan=1>375. 91</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1,019. 44</td><td rowspan=1 colspan=1>1,019. 44</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=5>2024年12月31日</td></tr><tr><td rowspan=1 colspan=1>盐城兵泽汽车零部件有限公司</td><td rowspan=1 colspan=1>643.53</td><td rowspan=1 colspan=1>643.53</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>盐城埃泰柯汽车零部件有限公司</td><td rowspan=1 colspan=1>375.91</td><td rowspan=1 colspan=1>375.91</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>SHOWNOW（HK)TECHNOLOGYLIMITED</td><td rowspan=1 colspan=1>113.10</td><td rowspan=1 colspan=1>113.10</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>佛山市中格威电子有限公司</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1,283.85</td><td rowspan=1 colspan=1>1,283.85</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=5>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>佛山市中格威电子有限公司</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>预计难以收回</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1>151.31</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

报告期内，公司单项计提坏账准备的应收账款，主要系对方未履行回款义务，

公司预计难以收回款项，对其全额计提减值准备，坏账准备计提充分。

②按组合计提坏账准备的应收账款情况

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>账面余额</td><td rowspan=1 colspan=1>计提比例</td><td rowspan=1 colspan=1>坏账准备</td></tr><tr><td rowspan=1 colspan=4>2025年12月31日</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>40, 723. 27</td><td rowspan=1 colspan=1>5.00%</td><td rowspan=1 colspan=1>2,036. 16</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>370.79</td><td rowspan=1 colspan=1>10.00%</td><td rowspan=1 colspan=1>37.08</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>35. 67</td><td rowspan=1 colspan=1>20.00%</td><td rowspan=1 colspan=1>7.13</td></tr><tr><td rowspan=1 colspan=1>3至4年</td><td rowspan=1 colspan=1>1. 85</td><td rowspan=1 colspan=1>50.00%</td><td rowspan=1 colspan=1>0.93</td></tr><tr><td rowspan=1 colspan=1>4至5年</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>80.00%</td><td rowspan=1 colspan=1>二</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>90. 62</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>90. 62</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>41, 222. 20</td><td rowspan=1 colspan=1>5. 27%</td><td rowspan=1 colspan=1>2,171.92</td></tr><tr><td rowspan=1 colspan=4>2024年12月31日</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>39,757.19</td><td rowspan=1 colspan=1>5.00%</td><td rowspan=1 colspan=1>1,987.86</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>323.94</td><td rowspan=1 colspan=1>10.00%</td><td rowspan=1 colspan=1>32.39</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>13.08</td><td rowspan=1 colspan=1>20.00%</td><td rowspan=1 colspan=1>2.62</td></tr><tr><td rowspan=1 colspan=1>3至4年</td><td rowspan=1 colspan=1>0.31</td><td rowspan=1 colspan=1>50.00%</td><td rowspan=1 colspan=1>0.16</td></tr><tr><td rowspan=1 colspan=1>4至5年</td><td rowspan=1 colspan=1>91.44</td><td rowspan=1 colspan=1>80.00%</td><td rowspan=1 colspan=1>73.15</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>3.02</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>3.02</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>40,188.98</td><td rowspan=1 colspan=1>5.22%</td><td rowspan=1 colspan=1>2,099.20</td></tr><tr><td rowspan=1 colspan=4>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>31,425.24</td><td rowspan=1 colspan=1>5.00%</td><td rowspan=1 colspan=1>1,571.26</td></tr><tr><td rowspan=1 colspan=1>1至2年</td><td rowspan=1 colspan=1>535.54</td><td rowspan=1 colspan=1>10.00%</td><td rowspan=1 colspan=1>53.55</td></tr><tr><td rowspan=1 colspan=1>2至3年</td><td rowspan=1 colspan=1>68.20</td><td rowspan=1 colspan=1>20.00%</td><td rowspan=1 colspan=1>13.64</td></tr><tr><td rowspan=1 colspan=1>3至4年</td><td rowspan=1 colspan=1>270.43</td><td rowspan=1 colspan=1>50.00%</td><td rowspan=1 colspan=1>135.22</td></tr><tr><td rowspan=1 colspan=1>4至5年</td><td rowspan=1 colspan=1>3.52</td><td rowspan=1 colspan=1>80.00%</td><td rowspan=1 colspan=1>2.82</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>32,302.94</td><td rowspan=1 colspan=1>5.50%</td><td rowspan=1 colspan=1>1,776.49</td></tr></table>

报告期各期末，发行人应收账款账龄主要在一年以内，账龄结构良好。公司的主要客户为家电、汽车及汽车零配件等领域的知名企业，信用状况良好，出现大规模坏账的风险较低。

报告期内，公司与同行业可比公司应收账款按账龄分析法计提比例，具体比

较如下：

<table><tr><td rowspan=2 colspan=1>账龄</td><td rowspan=1 colspan=4>账龄分析法计提比例（%)</td></tr><tr><td rowspan=1 colspan=1>发行人</td><td rowspan=1 colspan=1>开特股份</td><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>保隆科技</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>5.00</td><td rowspan=1 colspan=1>5.00</td><td rowspan=1 colspan=1>5.00</td><td rowspan=1 colspan=1>1-6个月：07-12个月：5.00</td></tr><tr><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>10.00</td><td rowspan=1 colspan=1>10.00</td><td rowspan=1 colspan=1>10.00</td><td rowspan=1 colspan=1>15.00</td></tr><tr><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>20.00</td><td rowspan=1 colspan=1>20.00</td><td rowspan=1 colspan=1>20.00</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>3-4年</td><td rowspan=1 colspan=1>50.00</td><td rowspan=1 colspan=1>50.00</td><td rowspan=1 colspan=1>50.00</td><td rowspan=1 colspan=1>50.00</td></tr><tr><td rowspan=1 colspan=1>4-5年</td><td rowspan=1 colspan=1>80.00</td><td rowspan=1 colspan=1>80.00</td><td rowspan=1 colspan=1>50.00</td><td rowspan=1 colspan=1>80.00</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>100.00</td></tr></table>

注：华工科技未按照账龄计提坏账准备。

报告期内，公司与同行业可比公司应收账款按账龄分析法计提比例不存在重大差异，公司应收账款计提坏账准备政策谨慎合理，计提比例充分。

综上，公司应收账款坏账准备的计提比例与同行业可比公司相比不存在重大差异，公司计提坏账准备的政策谨慎且合理。针对长期未收回且经营异常等存在减值迹象的应收款项，发行人已单项全额计提坏账准备。因此，发行人对各期末应收账款计提的坏账准备充分。

## 3）其他应收款

报告期内，公司与同行业可比公司其他应收款坏账准备/信用损失计提比例的比较情况如下：

<table><tr><td rowspan=2 colspan=1>账龄</td><td rowspan=1 colspan=2>账龄分析法计提比例（%）</td></tr><tr><td rowspan=1 colspan=1>发行人</td><td rowspan=1 colspan=1>苏奥传感</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>5</td></tr><tr><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>10</td></tr><tr><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>20</td></tr><tr><td rowspan=1 colspan=1>3-4年</td><td rowspan=1 colspan=1>50</td><td rowspan=1 colspan=1>50</td></tr><tr><td rowspan=1 colspan=1>4-5年</td><td rowspan=1 colspan=1>80</td><td rowspan=1 colspan=1>50</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>100</td><td rowspan=1 colspan=1>100</td></tr></table>

注：其他可比公司（保隆科技、开特股份）未披露账龄组合的分账龄坏账计提比例。

公司其他应收款坏账准备的计提比例与同行业可比公司不存在重大差异，公司计提坏账准备的政策谨慎且合理。

报告期各期末，公司账龄 1 年以上其他应收款余额占比分别为 43.39%、71.17%和 31.53%，明细如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=1 colspan=1>押金/保证金</td><td rowspan=1 colspan=1>513.78</td><td rowspan=1 colspan=1>484.48</td><td rowspan=1 colspan=1>460.24</td></tr><tr><td rowspan=1 colspan=1>应收非关联方往来款项</td><td rowspan=1 colspan=1>25. 07</td><td rowspan=1 colspan=1>25.00</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>538. 85</td><td rowspan=1 colspan=1>509.48</td><td rowspan=1 colspan=1>460.24</td></tr></table>

报告期各期末，账龄超过一年的其他应收款主要由押金和保证金构成，主要为客户要求预留的履约保证金。鉴于发行人与相关客户的业务合作关系持续存续，上述款项所对应的交易尚在进行，因此押金及保证金的账龄相对较长，发生坏账的可能性较低，预期信用损失风险较低，坏账准备计提充分。

综上，公司其他应收款坏账准备的计提比例与同行业可比公司相比不存在重大差异，公司计提坏账准备的政策谨慎且合理；公司其他应收款主要为押金保证金，押金及保证金的账龄相对较长具有合理性。因此，发行人对各期末其他应收款计提的坏账准备充分。

综上，报告期各期末，发行人应收款项坏账准备计提充分。

## 3、公司已披露相关风险

公司已在募集说明书 “第七节 与本次发行相关的风险因素”之“三、财务相关风险”“2、应收账款回收风险”中披露应收账款回收相关风险，主要内容如下：

“报告期各期末，公司应收账款余额分别为32,454.25 万元、41,472.83 万元和42,241.64 万元，应收账款规模较大，且呈现增长态势。未来随着经营业绩持续增长，公司的应收账款仍将维持在较大的规模。如果公司主要客户的经营状况发生重大不利变化，导致公司的应收账款不能按期收回甚至无法回收，公司发生坏账损失的可能性将增加，将对公司财务状况和经营成果产生不利影响。”

（四）结合公司经营、存货结构和库龄、期后结转情况、跌价计提政策等，说明存货规模及占比变动是否合理，跌价准备计提是否充分，与同行业可比公司是否存在较大差异

1、发行人存货规模及占比变动具有合理性，与同行业可比公司不存在较大差异

报告期各期末，发行人存货构成情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>期间</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>账面余额</td><td rowspan=1 colspan=1>跌价准备</td><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=8 colspan=1>2025年末</td><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>16,207. 97</td><td rowspan=1 colspan=1>1,530. 42</td><td rowspan=1 colspan=1>14, 677.55</td><td rowspan=1 colspan=1>42. 23%</td></tr><tr><td rowspan=1 colspan=1>发出商品</td><td rowspan=1 colspan=1>7,693. 08</td><td rowspan=1 colspan=1>243.79</td><td rowspan=1 colspan=1>7,449. 29</td><td rowspan=1 colspan=1>21. 43%</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>5, 841.75</td><td rowspan=1 colspan=1>367.78</td><td rowspan=1 colspan=1>5,473.97</td><td rowspan=1 colspan=1>15.75%</td></tr><tr><td rowspan=1 colspan=1>在产品</td><td rowspan=1 colspan=1>3,273. 25</td><td rowspan=1 colspan=1>81.43</td><td rowspan=1 colspan=1>3,191.82</td><td rowspan=1 colspan=1>9.18%</td></tr><tr><td rowspan=1 colspan=1>自制半成品</td><td rowspan=1 colspan=1>2, 883.69</td><td rowspan=1 colspan=1>348.40</td><td rowspan=1 colspan=1>2,535.29</td><td rowspan=1 colspan=1>7. 29%</td></tr><tr><td rowspan=1 colspan=1>委外加工物资</td><td rowspan=1 colspan=1>948.23</td><td rowspan=1 colspan=1>10.38</td><td rowspan=1 colspan=1>937. 85</td><td rowspan=1 colspan=1>2.70%</td></tr><tr><td rowspan=1 colspan=1>低值易耗品</td><td rowspan=1 colspan=1>494.51</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>494.51</td><td rowspan=1 colspan=1>1. 42%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>37, 342. 48</td><td rowspan=1 colspan=1>2,582. 21</td><td rowspan=1 colspan=1>34,760. 27</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=8 colspan=1>2024年末</td><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>11,415.79</td><td rowspan=1 colspan=1>1,433.43</td><td rowspan=1 colspan=1>9,982.35</td><td rowspan=1 colspan=1>33.86%</td></tr><tr><td rowspan=1 colspan=1>发出商品</td><td rowspan=1 colspan=1>8,801.16</td><td rowspan=1 colspan=1>183.43</td><td rowspan=1 colspan=1>8,617.73</td><td rowspan=1 colspan=1>29.23%</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>5,103.12</td><td rowspan=1 colspan=1>394.06</td><td rowspan=1 colspan=1>4,709.06</td><td rowspan=1 colspan=1>15.97%</td></tr><tr><td rowspan=1 colspan=1>在产品</td><td rowspan=1 colspan=1>3,228.77</td><td rowspan=1 colspan=1>35.11</td><td rowspan=1 colspan=1>3,193.66</td><td rowspan=1 colspan=1>10.83%</td></tr><tr><td rowspan=1 colspan=1>自制半成品</td><td rowspan=1 colspan=1>2,594.03</td><td rowspan=1 colspan=1>246.76</td><td rowspan=1 colspan=1>2,347.26</td><td rowspan=1 colspan=1>7.96%</td></tr><tr><td rowspan=1 colspan=1>委外加工物资</td><td rowspan=1 colspan=1>331.14</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>331.14</td><td rowspan=1 colspan=1>1.12%</td></tr><tr><td rowspan=1 colspan=1>低值易耗品</td><td rowspan=1 colspan=1>301.03</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>301.03</td><td rowspan=1 colspan=1>1.02%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>31,775.04</td><td rowspan=1 colspan=1>2,292.79</td><td rowspan=1 colspan=1>29,482.24</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=8 colspan=1>2023年末</td><td rowspan=1 colspan=1>库存商品</td><td rowspan=1 colspan=1>8,843.67</td><td rowspan=1 colspan=1>1,085.13</td><td rowspan=1 colspan=1>7,758.54</td><td rowspan=1 colspan=1>38.86%</td></tr><tr><td rowspan=1 colspan=1>发出商品</td><td rowspan=1 colspan=1>4,332.28</td><td rowspan=1 colspan=1>141.86</td><td rowspan=1 colspan=1>4,190.41</td><td rowspan=1 colspan=1>20.99%</td></tr><tr><td rowspan=1 colspan=1>原材料</td><td rowspan=1 colspan=1>3,600.94</td><td rowspan=1 colspan=1>131.77</td><td rowspan=1 colspan=1>3,469.17</td><td rowspan=1 colspan=1>17.38%</td></tr><tr><td rowspan=1 colspan=1>在产品</td><td rowspan=1 colspan=1>1,520.71</td><td rowspan=1 colspan=1>26.47</td><td rowspan=1 colspan=1>1,494.24</td><td rowspan=1 colspan=1>7.48%</td></tr><tr><td rowspan=1 colspan=1>自制半成品</td><td rowspan=1 colspan=1>2,576.07</td><td rowspan=1 colspan=1>157.30</td><td rowspan=1 colspan=1>2,418.77</td><td rowspan=1 colspan=1>12.11%</td></tr><tr><td rowspan=1 colspan=1>委外加工物资</td><td rowspan=1 colspan=1>294.02</td><td rowspan=1 colspan=1>1.56</td><td rowspan=1 colspan=1>292.46</td><td rowspan=1 colspan=1>1.46%</td></tr><tr><td rowspan=1 colspan=1>低值易耗品</td><td rowspan=1 colspan=1>342.29</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>342.29</td><td rowspan=1 colspan=1>1.71%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>21,509.97</td><td rowspan=1 colspan=1>1,544.09</td><td rowspan=1 colspan=1>19,965.88</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

报告期各期末，发行人存货构成基本保持稳定，主要由库存商品、发出商品、原材料构成，三项合计占存货总额的比例在75%以上。

公司主要采取“以销定产、适量备货”的采购与生产模式，为保证成品交付客户的及时性，公司根据采购和生产计划，保持适当的原材料库存水平，同时根据已有和预计订单量进行生产，保证产成品安全库存。报告期内，发行人存货余额主要随着发行人业务规模扩大而增加。报告期各期末，发行人存货账面价值分别为 19,965.88 万元、29,482.24 万元和 34,760.27 万元，呈现快速增长趋势。

报告期各期末，公司存货账面价值、在手订单金额（不含税）及其与存货账面价值比例情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>时间</td><td rowspan=1 colspan=1>存货账面价值</td><td rowspan=1 colspan=1>在手订单金额(不含税)</td><td rowspan=1 colspan=1>在手订单金额（不含税）/存货账面价值</td></tr><tr><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>34, 760. 27</td><td rowspan=1 colspan=1>20, 097. 75</td><td rowspan=1 colspan=1>57.82%</td></tr><tr><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>29,482.24</td><td rowspan=1 colspan=1>20,614.68</td><td rowspan=1 colspan=1>69.92%</td></tr><tr><td rowspan=1 colspan=1>2023年末</td><td rowspan=1 colspan=1>19,965.88</td><td rowspan=1 colspan=1>13,259.23</td><td rowspan=1 colspan=1>66.41%</td></tr></table>

注：在手订单包含根据客户采购计划，需在 6 个月内交付的备货订单。

报告期内，公司存货快速增长，主要是客户订单量增长驱动的结果。报告期内，公司主要产品生产交付周期在1个月左右。同时，公司春节假期受人员流动及招工难的影响，一季度短期产能有一定波动，为保证及时完成交货，公司需要在12 月末储备较多的存货，因此备货相对较多。2024 年末，公司存货账面价值快速增加，主要系在手订单金额持续增长，存货账面价值随之持续增长所致，具有合理性。2025 年末，公司存货账面价值快速增加，主要为库存商品账面价值增加，系随公司收入结构变化、存货结构变化，单价较高、在手订单覆盖周期较短的压力传感器等产品于 2025 年末库存商品备货占比及规模增加，但在手订单总额与上一年度相当所致，具有合理性。

报告期内，公司与同行业可比上市公司的存货价值、营业收入变动情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">2025年度/2025年末</td><td colspan="1" rowspan="1">2024年度/2024年末</td><td colspan="1" rowspan="1">2023年度/2023年末</td></tr><tr><td colspan="1" rowspan="2">存货账面价值</td><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">358, 124. 17</td><td colspan="1" rowspan="1">262,134.61</td><td colspan="1" rowspan="1">188,907.18</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">25,145.99</td><td colspan="1" rowspan="1">21,837.06</td><td colspan="1" rowspan="1">17,385.42</td></tr><tr><td colspan="1" rowspan="3"></td><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">27,133. 94</td><td colspan="1" rowspan="1">26,572.48</td><td colspan="1" rowspan="1">15,955.24</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">248, 144. 25</td><td colspan="1" rowspan="1">218,143.97</td><td colspan="1" rowspan="1">169,860.31</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">34,760. 27</td><td colspan="1" rowspan="1">29,482.24</td><td colspan="1" rowspan="1">19,965.88</td></tr><tr><td colspan="1" rowspan="5">营业收入</td><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">1,435, 476. 05</td><td colspan="1" rowspan="1">1,170,917.55</td><td colspan="1" rowspan="1">1,020,827.40</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">112, 947. 23</td><td colspan="1" rowspan="1">82,636.29</td><td colspan="1" rowspan="1">65,326.86</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">229,448. 36</td><td colspan="1" rowspan="1">166,956.64</td><td colspan="1" rowspan="1">112,146.74</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">874,727. 88</td><td colspan="1" rowspan="1">702,486.83</td><td colspan="1" rowspan="1">589,746.49</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">118, 347.76</td><td colspan="1" rowspan="1">94,016.42</td><td colspan="1" rowspan="1">74,657.09</td></tr><tr><td colspan="1" rowspan="7">存货账面价值占营业收入的比例</td><td colspan="1" rowspan="1">华工科技</td><td colspan="1" rowspan="1">24.95%</td><td colspan="1" rowspan="1">22.39%</td><td colspan="1" rowspan="1">18.51%</td></tr><tr><td colspan="1" rowspan="1">开特股份</td><td colspan="1" rowspan="1">22. 26%</td><td colspan="1" rowspan="1">26.43%</td><td colspan="1" rowspan="1">26.61%</td></tr><tr><td colspan="1" rowspan="1">苏奥传感</td><td colspan="1" rowspan="1">11. 83%</td><td colspan="1" rowspan="1">15.92%</td><td colspan="1" rowspan="1">14.23%</td></tr><tr><td colspan="1" rowspan="1">保隆科技</td><td colspan="1" rowspan="1">28.37%</td><td colspan="1" rowspan="1">31.05%</td><td colspan="1" rowspan="1">28.80%</td></tr><tr><td colspan="1" rowspan="1">平均值</td><td colspan="1" rowspan="1">21.85%</td><td colspan="1" rowspan="1">23.95%</td><td colspan="1" rowspan="1">22.04%</td></tr><tr><td colspan="1" rowspan="1">可比公司范围</td><td colspan="1" rowspan="1">11. 83%-28. 37%</td><td colspan="1" rowspan="1">15.92%-31.05%</td><td colspan="1" rowspan="1">14.23%-28.80%</td></tr><tr><td colspan="1" rowspan="1">安培龙</td><td colspan="1" rowspan="1">29.37%</td><td colspan="1" rowspan="1">31.36%</td><td colspan="1" rowspan="1">26.74%</td></tr></table>

报告期各期末，公司存货规模逐年增加，存货价值占公司当期营业收入的比例分别为 26.74%、31.36%和 29.37%，整体与同行业可比公司变动趋势基本一致，具有合理性。

因此，公司在报告期内存货结构基本稳定，存货规模增长较快，主要系在手订单金额持续增长，存货账面价值随之持续增长所致，变动趋势与同行业可比公司基本一致，具有合理性。

## 2、发行人存货跌价准备计提充分，与同行业可比公司不存在较大差异

报告期各期末，发行人存货跌价准备分别为1,544.09 万元、2,292.79 万元和2,582.21 万元，占存货余额的比例分别为 7.18%、7.22%和 6.91%，存货跌价准备计提充分。具体如下：

## （1）发行人存货库龄主要分布在 1年以内

报告期各期末，公司存货库龄分布情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年12月31日</td><td rowspan=1 colspan=2>2024年12月31日</td><td rowspan=1 colspan=2>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>32, 765. 22</td><td rowspan=1 colspan=1>87.74%</td><td rowspan=1 colspan=1>27,784.10</td><td rowspan=1 colspan=1>87.44%</td><td rowspan=1 colspan=1>17,897.34</td><td rowspan=1 colspan=1>83.20%</td></tr><tr><td rowspan=1 colspan=1>1年以上</td><td rowspan=1 colspan=1>4, 577. 26</td><td rowspan=1 colspan=1>12. 26%</td><td rowspan=1 colspan=1>3,990.94</td><td rowspan=1 colspan=1>12.56%</td><td rowspan=1 colspan=1>3,612.63</td><td rowspan=1 colspan=1>16.80%</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>37, 342. 48</td><td rowspan=1 colspan=1>100. 00%</td><td rowspan=1 colspan=1>31,775.04</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>21,509.97</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

报告期内，公司存货库龄主要集中在 1年以内，占比分别为83.20%、87.44%和 87.74%，存货库龄整体较短，公司存货库龄情况良好。库龄 1 年以上的存货主要为温度传感器、NTC 热敏电阻的库存商品及部分原材料，公司已按照存货跌价计提政策对长库龄存货计提跌价准备，存货跌价准备计提充分。

## （2）期后结转情况良好

截至报告期末，公司发出商品和库存商品余额为23,901.05 万元，截至2026年3月末，实现结转的发出商品和库存商品金额15,101.31 万元，期后实现销售的比例为 63.18%，存货期后结转充分。期后暂未实现销售的存货主要是公司对向家电客户销售的温度传感器、可用于生产温度传感器或直接对外销售的 NTC热敏电阻、单价较高的压力传感器等产品进行了一定的提前备货，具有合理性。

## （3）发行人存货跌价计提政策符合会计准则

报告期内，公司按照存货跌价计提政策，对于库龄较长的存货，充分考虑了长库龄可能导致的存货报废、滞销等影响存货价值的可能性，存货跌价准备计提充分。公司存货主要类别的跌价准备计提政策如下：

<table><tr><td>类别</td><td>跌价准备计提政策 公司为生产而持有的原材料，其生产的产成品的可变现净值高于成本的，该材</td></tr><tr><td>原材料</td><td>料仍然应当按照成本计量；材料价格的下降表明产成品的可变现净值低于成本 的，该材料应当按照可变现净值计量。对于库龄二年以内的原材料，公司主要 取最近采购单价作为判断减值迹象的参考，期末原材料成本相较最近采购单价 波动未超过20%，不计提跌价准备；期末原材料成本相较最近采购单价波动超 过20%，公司按成本与可变现净值敦低计提存货跌价准备。 原材料(不包含生产PTC 热敏电阻和NTC 热敏电阻的原材料)库龄超过二年的， 认定为呆滞物料，全额计提跌价准备；库龄未超过二年但无参考采购价的，全 额计提跌价准备。PTC 热敏电阻和NTC 热敏电阻原材料主要为化工材料，如碳 酸钡、二氧化钛、四氧化三钴等，不因库龄较长而降低使用价值，不参考库龄</td></tr><tr><td>库存商品</td><td>计提跌价准备。 库存商品的可变现净值以订单价格或同类产品最近销售价格作为可变现净值参 考值。温度传感器、氧传感器和压力传感器库存商品库龄超过一年的，按废品 价格计提跌价准备；库龄未超过一年的，按成本与可变现净值敦低原则计提跌</td></tr><tr><td colspan="1" rowspan="1">类别</td><td colspan="1" rowspan="1">跌价准备计提政策</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">价准备。PTC 热敏电阻和NTC 热敏电阻库存商品库龄超过二年的，按废品价格计提跌价准备；库龄未超过两年的，按成本与可变现净值敦低原则计提跌价准备。</td></tr><tr><td colspan="1" rowspan="1">发出商品</td><td colspan="1" rowspan="1">发出商品的可变现净值以订单价格作为可变现净值参考值，按成本与可变现净值敦低原则计提跌价准备。</td></tr></table>

发行人存货跌价准备计提政策符合会计准则规定。

## （4）发行人存货跌价计提情况与同行业可比公司对比不存在重大差异

公司存货跌价准备占比与A 股同行业可比公司对比情况如下：

<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=1 colspan=1>华工科技</td><td rowspan=1 colspan=1>4. 69%</td><td rowspan=1 colspan=1>4.60%</td><td rowspan=1 colspan=1>4.95%</td></tr><tr><td rowspan=1 colspan=1>开特股份</td><td rowspan=1 colspan=1>10. 61%</td><td rowspan=1 colspan=1>9.55%</td><td rowspan=1 colspan=1>15.32%</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>7.91%</td><td rowspan=1 colspan=1>6.28%</td><td rowspan=1 colspan=1>3.12%</td></tr><tr><td rowspan=1 colspan=1>保隆科技</td><td rowspan=1 colspan=1>3. 68%</td><td rowspan=1 colspan=1>2.82%</td><td rowspan=1 colspan=1>3.50%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1>6.72%</td><td rowspan=1 colspan=1>5.81%</td><td rowspan=1 colspan=1>6.72%</td></tr><tr><td rowspan=1 colspan=1>可比公司范围</td><td rowspan=1 colspan=1>3. 68%-10. 61%</td><td rowspan=1 colspan=1>2.82%-9.55%</td><td rowspan=1 colspan=1>3.12%-15.32%</td></tr><tr><td rowspan=1 colspan=1>安培龙</td><td rowspan=1 colspan=1>6.91%</td><td rowspan=1 colspan=1>7.22%</td><td rowspan=1 colspan=1>7.18%</td></tr></table>

注：同行业可比公司的数据均根据其当期定期报告数据计算所得。

报告期各期末，公司存货跌价准备整体计提比处于同行业可比上市公司范围内，与同行业可比公司不存在较大差异。

因此，公司按照存货跌价计提政策，对于库龄较长的存货，充分考虑了长库龄可能导致的存货报废、滞销等影响存货价值的可能性，存货跌价准备计提充分，与同行业可比公司不存在较大差异，具有合理性。

综上，公司在报告期内存货结构基本稳定，存货规模增长较快主要系在手订单金额持续增长，存货账面价值随之持续增长所致，变动趋势与同行业可比公司基本一致，具有合理性；存货库龄整体较短，库龄结构良好，存货期后结转充分，跌价计提政策充分考虑了长库龄存货跌价情形，存货跌价准备计提充分，与同行业可比公司不存在较大差异，具有合理性。

## 3、公司已披露相关风险

公司已在募集说明书“第七节 与本次发行相关的风险因素”之“三、财务相关风险”之“3、存货余额较高的风险”中披露存货余额较高的相关风险，主

要内容如下：

“报告期各期末，公司存货账面余额分别为21,509.97 万元、31,775.04 万元和37,342.48 万元，账面余额较大且持续增加，主要与公司采取的经营模式及行业特点有关。为保证成品交付客户的及时性，公司主要采取“以销定产、适量备货”的采购与生产模式，在实际订单以及预计订单的基础上适当生产保证安全库存。另外，公司的产品规格型号众多，生产工艺相对复杂，生产周期较长，且在春节假期受人员流动及招工难的影响，一季度短期产量有一定波动，因此公司需在各年末制备较多的原材料、库存商品等存货以保障及时供应客户。报告期各期末公司存货余额较高，占用了较多的营运资金。如果发生存货滞销或新增订单不足预期的情形，公司存货周转率和营运资金周转效率将降低，同时面临存货的可变现净值降低、存货跌价损失增加的风险，对公司经营业绩产生不利影响。”

（五）结合报告期内行政处罚等情况及相关法律法规的具体规定，说明发行人最近三年是否存在严重损害投资者合法权益或社会公众利益的重大违法行为，是否符合《注册办法》第十一条及《证券期货法律适用意见第 18 号》的相关规定

根据发行人及其境内子公司主管部门开具的合规证明或企业信用报告（无违法违规证明版）、相关行政处罚决定书，发行人报告期内行政处罚情况如下：

2024 年 7 月 3 日，东莞市市场监督管理局对东莞安培龙作出《行政处罚决定书》（东市监处罚[2024]160703071 号），东莞安培龙使用未经消毒的餐具、饮具的违法行为决定责令立即改正并给予警告。

根据《中华人民共和国食品安全法》第一百二十六条第一款第（五）项“违反本法规定，有下列情形之一的，由县级以上人民政府食品安全监督管理部门责令改正，给予警告；拒不改正的，处五千元以上五万元以下罚款；情节严重的，责令停产停业，直至吊销许可证：......（五）餐具、饮具和盛放直接入口食品的容器，使用前未经洗净、消毒或者清洗消毒不合格，或者餐饮服务设施、设备未按规定定期维护、清洗、校验......”的规定。

根据东莞市市场监督管理局《关于不合格食品核查处置情况的通告》，鉴于东莞安培龙积极配合检查调查、主动纠错、积极改正，符合《东莞市市场监督管理局行政处罚自由裁量权适用规则》第十条规定的情形，决定对东莞安培龙上述违法行为作一般处罚。

根据《证券期货法律适用意见第 18 号》的相关规定，重大违法行为是指违反法律、行政法规或者规章，受到刑事处罚或者情节严重行政处罚的行为。有以下情形之一且中介机构出具明确核查结论的，可以不认定为重大违法行为：

“（1）违法行为轻微、罚款金额较小；

（2）相关处罚依据未认定该行为属于情节严重的情形；

（3）有权机关证明该行为不属于重大违法行为。

违法行为导致严重环境污染、重大人员伤亡或者社会影响恶劣等的除外”。

综上，东莞安培龙上述行政处罚为一般处罚，相关处罚依据未认定该行为属于情节严重的情形。东莞安培龙上述违法行为不属于重大违法违规行为，不属于严重损害投资者合法权益或者社会公共利益的重大违法行为，发行人符合《注册办法》第十一条及《证券期货法律适用意见第18 号》的相关规定。

（六）结合报告期内发行人房屋建筑物和设施使用情况、在建工程建设进展情况,说明公司固定资产减值计提是否充分,在建工程转固是否及时,相关会计处理是否符合《企业会计准则》的相关规定；说明氧传感器及其他产品产能利用率较低的原因及合理性，说明原有产能是否存在闲置风险，相关资产是否存在减值风险

1、结合报告期内发行人房屋建筑物和设施使用情况、在建工程建设进展情况，说明公司固定资产减值计提是否充分，在建工程转固是否及时，相关会计处理是否符合《企业会计准则》的相关规定

（1）结合报告期内发行人固定资产使用情况，说明发行人固定资产减值计提是否充分，相关会计处理是否符合《企业会计准则》的相关规定

1）报告期内发行人固定资产使用情况

报告期内，发行人主要的固定资产包括房屋建筑物、房屋建筑物装修、机器设备、运输设备、仪器仪表及办公设备。报告期各期末，公司主要固定资产情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>期间</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>账面原值</td><td rowspan=1 colspan=1>累计折旧</td><td rowspan=1 colspan=1>减值准备</td><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=7 colspan=1>2025年末</td><td rowspan=1 colspan=1>房屋建筑物</td><td rowspan=1 colspan=1>58,943. 30</td><td rowspan=1 colspan=1>3,229.99</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>55,713.31</td><td rowspan=1 colspan=1>65.94%</td></tr><tr><td rowspan=1 colspan=1>房屋建筑物装修</td><td rowspan=1 colspan=1>4,844.91</td><td rowspan=1 colspan=1>1, 231. 46</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>3,613. 44</td><td rowspan=1 colspan=1>4.28%</td></tr><tr><td rowspan=1 colspan=1>机器设备</td><td rowspan=1 colspan=1>33, 812. 21</td><td rowspan=1 colspan=1>10, 051.95</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>23,760. 26</td><td rowspan=1 colspan=1>28.12%</td></tr><tr><td rowspan=1 colspan=1>运输设备</td><td rowspan=1 colspan=1>587.91</td><td rowspan=1 colspan=1>391.53</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>196.39</td><td rowspan=1 colspan=1>0. 23%</td></tr><tr><td rowspan=1 colspan=1>仪器仪表</td><td rowspan=1 colspan=1>1, 792. 43</td><td rowspan=1 colspan=1>1, 265. 47</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>526.96</td><td rowspan=1 colspan=1>0. 62%</td></tr><tr><td rowspan=1 colspan=1>办公设备</td><td rowspan=1 colspan=1>1, 512. 02</td><td rowspan=1 colspan=1>829.32</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>682. 70</td><td rowspan=1 colspan=1>0.81%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>101, 492. 79</td><td rowspan=1 colspan=1>16,999. 73</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>84,493.06</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=7 colspan=1>2024年末</td><td rowspan=1 colspan=1>房屋建筑物</td><td rowspan=1 colspan=1>58,943.30</td><td rowspan=1 colspan=1>1,957.03</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>56,986.27</td><td rowspan=1 colspan=1>70.69%</td></tr><tr><td rowspan=1 colspan=1>房屋建筑物装修</td><td rowspan=1 colspan=1>2,762.41</td><td rowspan=1 colspan=1>482.50</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>2,279.91</td><td rowspan=1 colspan=1>2.83%</td></tr><tr><td rowspan=1 colspan=1>机器设备</td><td rowspan=1 colspan=1>27,912.17</td><td rowspan=1 colspan=1>7,702.72</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>20,209.45</td><td rowspan=1 colspan=1>25.07%</td></tr><tr><td rowspan=1 colspan=1>运输设备</td><td rowspan=1 colspan=1>476.14</td><td rowspan=1 colspan=1>344.40</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>131.75</td><td rowspan=1 colspan=1>0.16%</td></tr><tr><td rowspan=1 colspan=1>仪器仪表</td><td rowspan=1 colspan=1>1,525.09</td><td rowspan=1 colspan=1>991.25</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>533.84</td><td rowspan=1 colspan=1>0.66%</td></tr><tr><td rowspan=1 colspan=1>办公设备</td><td rowspan=1 colspan=1>1,074.54</td><td rowspan=1 colspan=1>598.63</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>475.91</td><td rowspan=1 colspan=1>0.59%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>92,693.65</td><td rowspan=1 colspan=1>12,076.52</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>80,617.13</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=7 colspan=1>2023年末</td><td rowspan=1 colspan=1>房屋建筑物</td><td rowspan=1 colspan=1>58,943.30</td><td rowspan=1 colspan=1>684.08</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>58,259.22</td><td rowspan=1 colspan=1>79.10%</td></tr><tr><td rowspan=1 colspan=1>房屋建筑物装修</td><td rowspan=1 colspan=1>1,693.79</td><td rowspan=1 colspan=1>35.94</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1,657.85</td><td rowspan=1 colspan=1>2.25%</td></tr><tr><td rowspan=1 colspan=1>机器设备</td><td rowspan=1 colspan=1>18,596.37</td><td rowspan=1 colspan=1>5,869.14</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>12,727.23</td><td rowspan=1 colspan=1>17.28%</td></tr><tr><td rowspan=1 colspan=1>运输设备</td><td rowspan=1 colspan=1>418.67</td><td rowspan=1 colspan=1>301.68</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>116.98</td><td rowspan=1 colspan=1>0.16%</td></tr><tr><td rowspan=1 colspan=1>仪器仪表</td><td rowspan=1 colspan=1>1,359.11</td><td rowspan=1 colspan=1>672.61</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>686.51</td><td rowspan=1 colspan=1>0.93%</td></tr><tr><td rowspan=1 colspan=1>办公设备</td><td rowspan=1 colspan=1>683.51</td><td rowspan=1 colspan=1>477.12</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>206.40</td><td rowspan=1 colspan=1>0.28%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>81,694.75</td><td rowspan=1 colspan=1>8,040.57</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>73,654.19</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

截至报告期末，公司主要房屋建筑物、生产设备等固定资产处于正常使用状态。此外，公司存在因规划预留部分固定资产暂时闲置情形。具体情况如下：  
单位：万元

<table><tr><td rowspan=1 colspan=2>项目</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=4 colspan=1>闲置的房屋建筑物</td><td rowspan=1 colspan=1>账面原值</td><td rowspan=1 colspan=1>15, 632. 22</td><td rowspan=1 colspan=1>23,363.07</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>累计折旧</td><td rowspan=1 colspan=1>715. 03</td><td rowspan=1 colspan=1>575.42</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>减值准备</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>14, 917. 19</td><td rowspan=1 colspan=1>22,787.64</td><td rowspan=1 colspan=1></td></tr></table>

报告期内，公司暂时闲置的固定资产主要为房屋建筑物，位于深圳安培龙智能传感器产业园。报告期各期末，闲置的固定资产账面价值占固定资产账面价值的比例分别为0%、28.27%和17.65%。安培龙智能传感器产业园于2023 年10 月完成建设并通过竣工验收转固，公司结合生产经营布局与长期发展规划，对园区各楼层进行统一功能规划与统筹安排，主要用于生产制造、行政管理、员工宿舍及餐饮配套等，部分区域用于对外经营性租赁。

截至报告期末，产业园主体楼层已按规划投入使用，部分楼层暂时闲置系公司基于业务发展节奏与中长期规划的合理安排，相关闲置楼层均已明确后续使用计划，资产状态良好、不存在损坏或处置计划，未发现减值情形，因此未计提资产减值准备，相关会计处理符合企业会计准则的要求，具有合理性。

## 2）发行人固定资产减值计提充分，相关会计处理符合《企业会计准则》的相关规定

报告期各期末，公司按照《企业会计准则第8 号——资产减值》的规定判断期末固定资产是否存在发生减值的迹象。如存在减值迹象，则估计其可收回金额，进行减值测试。减值测试结果表明资产的可收回金额低于其账面价值的，按其差额计提减值准备并计入减值损失。可收回金额为资产的公允价值减去处置费用后的净额与资产预计未来现金流量的现值两者之间的较高者。

公司将《企业会计准则》规定的可能存在减值迹象的情况与公司实际情况逐项进行比对，具体情况如下：

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">《企业会计准则》的规定</td><td colspan="1" rowspan="1">公司实际情况</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">资产的市价当期大幅度下跌，其跌幅明显高于因时间推移或者正常使用而预计的下跌。</td><td colspan="1" rowspan="1">报告期内，除部分闲置资产外，公司房屋建筑物以及相应机器设备相关资产均在正常使用，固定资产的市价不存在大幅下跌的情况</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">企业经营所处的经济、技术或者法律等环境以及资产所处的市场在当期或者将在近期发生重大变化，从而对企业产生不利影响。</td><td colspan="1" rowspan="1">公司经营所处的经济、技术或者法律等环境以及上述固定资产所处的市场在报告期内未发生重大不利变化</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">市场利率或者其他市场投资报酬率在当期已经提高，从而影响企业计算资产预计未来现金流量现值的折现率，导致资产可收回金额大幅度降低。</td><td colspan="1" rowspan="1">报告期内，市场利率或者其他市场投资报酬率未发生显著波动</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">有证据表明资产已经陈旧过时或者其实体已经损坏。</td><td colspan="1" rowspan="1">公司根据实际使用情况对固定资产进行维修、养护，设备运转状态良好，不存在已经陈旧过时或者其实体已经损坏的情形</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">资产已经或者将被闲置、终止使用或者计划提前处置。</td><td colspan="1" rowspan="1">公司主体建筑即深圳安培龙智能传感器产业园因业务发展节奏及中长期规划存在部分楼层尚未正式投入使用，但均已明确后续使用计</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">划且稳步推进，不存在减值迹象，未计提减值</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">企业内部报告的证据表明资产的经济绩效已经低于或者将低于预期，如资产所创造的净现金流量或者实现的营业利润(或者亏损)远远低于（或者高于）预计金额等。</td><td colspan="1" rowspan="1">公司固定资产主要为房屋建筑物和生产设备，其他固定资产金额相对较低，相关机器设备的经济效益达到预期水平，不存在经济绩效已经低于或者将低于预期的情形</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">其他表明资产可能已经发生减值的迹象。</td><td colspan="1" rowspan="1">公司不存在其他表明资产可能已经发生减值的迹象</td></tr></table>

报告期内，公司的机器设备等生产经营设备中，不存在减值迹象，无需计提减值准备。报告期内，公司房屋建筑物状态良好，除部分楼层因规划预留暂未正式投入使用外，均处于正常使用状态，不存在减值迹象；因业务发展节奏及中长期规划尚未正式投入使用的部分楼层，经公司评估，该类房屋建筑物已明确后续使用计划且稳步推进，不存在减值迹象，因此未计提资产减值准备，相关会计处理符合企业会计准则的要求，具备合理性。

因此，报告期内，发行人主要固定资产均处于正常使用状态，其中部分因规划预留暂未正式投入使用的房屋建筑物已明确后续使用计划且稳步推进，不存在减值迹象。公司固定资产减值计提充分。

（2）发行人在建工程建设进展情况，在建工程转固是否及时，相关会计处理是否符合《企业会计准则》的相关规定

1）发行人在建工程建设进展及转固情况

报告期内各期末，公司在建工程情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td></tr><tr><td rowspan=1 colspan=1>待安装设备</td><td rowspan=1 colspan=1>5,270. 08</td><td rowspan=1 colspan=1>1,960.18</td><td rowspan=1 colspan=1>4,731.21</td></tr><tr><td rowspan=1 colspan=1>在制设备</td><td rowspan=1 colspan=1>4,139. 30</td><td rowspan=1 colspan=1>745.96</td><td rowspan=1 colspan=1>175.20</td></tr><tr><td rowspan=1 colspan=1>其中：全自动产线</td><td rowspan=1 colspan=1>2,975. 38</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>东莞安培龙工业大厦</td><td rowspan=1 colspan=1>213. 05</td><td rowspan=1 colspan=1>213.05</td><td rowspan=1 colspan=1>213.05</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>9, 622. 43</td><td rowspan=1 colspan=1>2,919.19</td><td rowspan=1 colspan=1>5,119.46</td></tr><tr><td rowspan=1 colspan=1>减值准备</td><td rowspan=1 colspan=1>213. 05</td><td rowspan=1 colspan=1>213.05</td><td rowspan=1 colspan=1>213.05</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>9,409. 38</td><td rowspan=1 colspan=1>2,706.15</td><td rowspan=1 colspan=1>4,906.41</td></tr></table>

报告期内，企业重要在建工程为安培龙智能传感器产业园项目、东莞安培龙工业大厦项目、在制设备-全自动产线项目。报告期内，发行人在建工程建设进展顺利，转固及时；其中，重要在建工程建设进展及转固情况如下：

①安培龙智能传感器产业园

单位：万元

<table><tr><td rowspan=1 colspan=1>时期</td><td rowspan=1 colspan=1>期初余额</td><td rowspan=1 colspan=1>本期增加</td><td rowspan=1 colspan=1>本期转入固定资产</td><td rowspan=1 colspan=1>其他减少</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2023年度</td><td rowspan=1 colspan=1>47,960.16</td><td rowspan=1 colspan=1>10,732.73</td><td rowspan=1 colspan=1>58,692.88</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr></table>

安培龙智能传感器产业园为公司 IPO 的募集资金投资项目，2021 年开始发行人先行使用自筹资金开工建设，并于2023 年10 月建设完成并竣工验收转固，建设周期合理且已及时转固。

②东莞安培龙工业大厦

单位：万元

<table><tr><td rowspan=1 colspan=1>时期</td><td rowspan=1 colspan=1>期初余额</td><td rowspan=1 colspan=1>本期增加</td><td rowspan=1 colspan=1>本期转入固定资产</td><td rowspan=1 colspan=1>其他减少</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>213. 05</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>213. 05</td></tr><tr><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>213.05</td><td rowspan=1 colspan=1>&quot;</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>&quot;</td><td rowspan=1 colspan=1>213.05</td></tr><tr><td rowspan=1 colspan=1>2023年度</td><td rowspan=1 colspan=1>213.05</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>213.05</td></tr></table>

东莞安培龙工业大厦为公司拟建设的生产和研发用的厂区，公司在2018-2019 年完成了厂房设计、勘察、报建咨询等前期工作，公司将此类必要支出计入在建工程。2020 年12 月，公司通过招拍挂确认将在深圳市坪山区取得一块工业用地，并计划在深圳市坪山区实施IPO 募集资金投资项目，东莞安培龙工业大厦将延期开工；2020 年末，公司对东莞安培龙工业大厦计提减值，减值准备金额为 121.16 万元。基于谨慎性考虑，截至2022 年末，公司将可能过期的前期成果对应的投入全额计提了减值，减值准备金额为 213.05 万元。公司对东莞安培龙工业大厦进行全额计提减值具有合理性，不存在建设周期较长、未及时转固的情形。

③在制设备-全自动产线项目

单位：万元

<table><tr><td rowspan=1 colspan=1>时期</td><td rowspan=1 colspan=1>期初余额</td><td rowspan=1 colspan=1>本期增加</td><td rowspan=1 colspan=1>本期转入固定资产</td><td rowspan=1 colspan=1>其他减少</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>2,975.38</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>2,975. 38</td></tr></table>

在制设备-全自动产线项目系结合客户需求建立的全自动化产线，于2025 年1 月正式投入建设。截止本回复出具日，该项目仍在建设中，尚不满足转固条件，尚未转固。

## 2）发行人在建工程转固及时，相关会计处理符合《企业会计准则》的相关规定

公司各类别在建工程具体转固标准和时点如下：

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>转固时点和标准</td></tr><tr><td rowspan=1 colspan=1>房屋及建筑物</td><td rowspan=1 colspan=1>（1）主体建设工程及配套工程已实质上完工；（2）建造工程在达到预定设计要求，经勘察、设计、施工、监理等单位完成验收；（3）经消防、国土、规划等外部部门验收；（4）建设工程达到预定可使用状态但尚未办理竣工决算的，自达到预定可使用状态之日起，根据工程实际造价按照预估价值转入固定资产。</td></tr><tr><td rowspan=1 colspan=1>在制设备/待安装设备</td><td rowspan=1 colspan=1>（1）相关设备及其他配套设施已安装完毕；（2）设备经过调试可在一段时间内保持正常稳定运行；（3）设备能够在一段时间内稳定产出合格产品；（4）设备经过资产管理人员、设备使用部门等相关人员验收。</td></tr></table>

公司关于在建工程转入固定资产的时点判断合理，在建工程转固及时，符合会计准则要求。

综上，报告期内，发行人主要固定资产均处于正常使用状态，其中部分因规划预留暂未正式投入使用的房屋建筑物已明确后续使用计划且稳步推进，不存在减值迹象；对部分因拟淘汰而存在减值迹象的固定资产依据《企业会计准则》进行了减值测试并计提相应的减值准备，公司固定资产减值计提充分；发行人在建工程转固及时，不存在未及时转固的情形，相关会计处理符合《企业会计准则》的相关规定。

## 2、说明氧传感器及其他产品产能利用率较低的原因及合理性，说明原有产能是否存在闲置风险，相关资产是否存在减值风险

## （1）氧传感器及其他产能利用率较低具有合理性

报告期内，发行人氧传感器类及其他主营业务收入分别为 2,203.67 万元、1,704.89 万元和 1,964.52 万元，占主营业务收入的 2.96%、1.81%和 1.66%，规模和占比均较小。其中，公司其他主营业务收入主要为应部分客户需求代购的产品、试制样品、陶瓷基板、配件及其他传感器等；发行人氧传感器收入分别为

1,539.93 万元、886.71 万元和 937.74 万元，占主营业务收入的 2.07%、0.94%和  
0.79%，规模和占比均较小。

报告期内，发行人氧传感器业务尚处于市场开拓阶段，产能利用率较低，氧传感器产能、产量及产能利用率如下：

单位：万个

<table><tr><td rowspan=1 colspan=1>年度</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>3.50</td><td rowspan=1 colspan=1>3.73</td><td rowspan=1 colspan=1>14.87</td></tr><tr><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>147. 72</td><td rowspan=1 colspan=1>116.41</td><td rowspan=1 colspan=1>113.65</td></tr><tr><td rowspan=1 colspan=1>利用率</td><td rowspan=1 colspan=1>2. 37%</td><td rowspan=1 colspan=1>3.20%</td><td rowspan=1 colspan=1>13.09%</td></tr></table>

报告期内，发行人氧传感器业务规模较小，产能利用率较低，主要系氧传感器产品主要由国外厂商占据，公司市场拓展取得实质成效仍需一定的时间；同时，公司需建设一定规模的氧传感器产能以满足市场开拓和下游客户及潜在客户供应商准入要求。因此，现阶段，公司产能利用率较低具有合理性。

（2）氧传感器下游国产替代需求迫切、前景广阔，订单储备进展良好，原 有产能闲置风险较低，相关资产减值风险较低

①氧传感器国产替代需求迫切，下游市场空间广阔

国内汽车用氧传感器国产替代需求迫切、前景广阔。根据工信部数据，2025年，我国汽车产量为 3451.1 万辆，同比增长 10.4%。假设未来 5-10 年汽车产量仍保持增长趋势，纯电动汽车的渗透率达到50%，那么仍至少有1,700 万辆非纯电汽车（含燃油及混动），按照平均每辆汽车至少 2个氧传感器测算，我国新车配套市场氧传感器的需求量约 3,400 万个。按照每个50\~70 元计算，每年我国氧传感器的市场规模为 17\~24 亿元，仍具有较大的市场空间。但长期以来，国内汽车用的氧传感器市场被德国博世、日本特殊陶业株式会社等国外品牌占据，进口依赖度较大，国产替代需求迫切，具备较为广阔的市场前景。

②发行人在氧传感器领域已建立客户储备

公司积极拓展氧传感器及其他业务下游客户，相关业务具备较为明朗的发展前景，订单储备进展良好。产品研发方面，经过多年氧传感器的研究开发和技术积累，发行人已掌握了氧传感器核心制备技术，所生产的氧传感器在起燃时间、抗热冲击性能、绝缘性等关键指标与国际龙头企业同类产品接近。客户拓展方面，公司自 2023 年起与东风汽车共同研发攻关前装氧传感器，推进氧传感器国产突破，主要产品已通过主机厂配套验证测试。2024 年下半年至今，公司陆续向东风汽车批量供应前装氧传感器，截至本回复出具日，公司已向东风汽车量产供应氧传感器。此外，公司正在开发印度HERO、北汽集团、重庆奥易克斯等客户，进展顺利。截至2025 年12 月31 日，公司拥有氧传感器在手订单 377.28 万元，订单储备进展良好。

## ③氧传感器产线账面价值较低，减值风险较小

截至 2025 年 12 月 31 日，公司氧传感器产线资产设备账面原值合计1,892.05万元，账面价值合计 743.02 万元，已折旧比例较高，账面价值较低。公司氧传感器产线资产设备包括专用于氧传感器的资产设备和可用于其他产品生产的资产设备，其中可用于其他传感器生产的设备为可直接或更换模具后用于热敏电阻及温度传感器、压力传感器等其他产品相似生产环节的设备。截至2025 年12 月31 日，公司专用于氧传感器的资产设备账面原值占比为57.75%，相对较低。现有专用于氧传感器的资产设备主要为东风汽车项目等新开拓的氧传感器项目相关设备，原有产能闲置风险较低，相关资产减值风险较低。

综上所述，因公司氧传感器尚处于市场开拓阶段，相关产线产能利用率较低。但随着未来与东风汽车等下游客户合作的进一步加深，公司氧传感器及其他业务发展前景较为明朗，预计未来产能利用率将得到进一步提升，原有产能闲置风险将进一步降低。

## （3）公司已补充披露相关风险

公司已在募集说明书“第七节 与本次发行相关的风险因素”之“二、经营风险”之“6、氧传感器产能利用率不足和相关资产减值风险”中披露氧传感器产能闲置和相关资产减值相关风险，主要内容如下：

## “6、氧传感器产能利用率不足和相关资产减值风险

公司生产及研发的氧传感器主要应用于汽车、家电等领域，处于国产替代进程中。当前，公司氧传感器尚处于市场开拓阶段，若未来公司氧传感器客户拓展不及预期或下游市场需求放缓，可能导致公司氧传感器产能利用率不足，对公司经营效率及盈利能力产生不利影响，并可能导致公司相关固定资产出现减值的风险。”

综上，氧传感器市场空间较为广阔，国产替代需求迫切，虽然目前因进口依赖度较大、进入门槛高，产能利用率较低，但公司氧传感器产品技术领先、客户拓展进展顺利，订单储备进展良好，仍具备较为明朗的发展前景，原有产能闲置风险较低，相关资产减值风险较低。

（七）列示可能涉及财务性投资的相关会计科目明细，包括账面价值、具体内容、是否属于财务性投资、占最近一期末归母净资产比例等；结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形；自本次发行相关董事会前六个月至今，公司已实施或拟实施的财务性投资的具体情况，说明是否涉及募集资金扣减情形

1、列示可能涉及财务性投资的相关会计科目明细，包括账面价值、具体内容、是否属于财务性投资、占最近一期末归母净资产比例等

截至2025 年末，公司可能涉及财务性投资（包括类金融业务）的相关报表科目余额情况如下表所示：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>会计科目</td><td rowspan=1 colspan=1>账面价值</td><td rowspan=1 colspan=1>占最近一期末归母净资产比例</td><td rowspan=1 colspan=1>主要内容</td><td rowspan=1 colspan=1>财务性投资</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>其他应收款</td><td rowspan=1 colspan=1>1,409. 27</td><td rowspan=1 colspan=1>1. 11%</td><td rowspan=1 colspan=1>押金保证金、应收出口退税款、应收非关联方往来款项</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>其他流动资产</td><td rowspan=1 colspan=1>1,253. 26</td><td rowspan=1 colspan=1>0.99%</td><td rowspan=1 colspan=1>待抵扣增值税、预交所得税、预付费用</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>其他权益工具投资</td><td rowspan=1 colspan=1>900.00</td><td rowspan=1 colspan=1>0.71%</td><td rowspan=1 colspan=1>系对瑞知微、鼎汇创新中心的股权投资，为围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，不构成财务性投资</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=2 colspan=1>其他非流动资产</td><td rowspan=1 colspan=1>1, 773. 21</td><td rowspan=2 colspan=1>4.13%</td><td rowspan=1 colspan=1>预付长期资产款</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>3,460.26</td><td rowspan=1 colspan=1>系对西博安泰的投资及其投资收益，为围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，不构成财务性投资</td><td rowspan=1 colspan=1>否</td></tr></table>

截至报告期末，公司不存在财务性投资，具体分析如下：

## （1）其他应收款

截至报告期末，公司其他应收款按款项余额性质分类如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>款项性质</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>押金/保证金</td><td rowspan=1 colspan=1>1,352. 01</td></tr><tr><td rowspan=1 colspan=1>应收非关联方往来款项</td><td rowspan=1 colspan=1>181. 47</td></tr><tr><td rowspan=1 colspan=1>应收出口退税</td><td rowspan=1 colspan=1>175. 33</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1, 708. 80</td></tr></table>

截至报告期末，公司其他应收款主要为与公司经营相关的保证金、押金及应收非关联方往来款项及应收出口退税款，不属于财务性投资。

## （2）其他流动资产

截至报告期末，公司其他流动资产按款项余额性质分类如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>款项性质</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>待抵扣增值税</td><td rowspan=1 colspan=1>152. 31</td></tr><tr><td rowspan=1 colspan=1>预交所得税</td><td rowspan=1 colspan=1>89. 05</td></tr><tr><td rowspan=1 colspan=1>预付费用</td><td rowspan=1 colspan=1>1, 011. 90</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1, 253. 26</td></tr></table>

截至报告期末，公司其他流动资产主要为与公司经营相关的待抵扣增值税、预交所得税、预付费用，不属于财务性投资。

## （3）其他权益工具投资

截至报告期末，公司其他权益工具投资账面价值为 900.00 万元，系对瑞知微、鼎汇创新中心的投资：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>瑞知微</td><td rowspan=1 colspan=1>600.00</td></tr><tr><td rowspan=1 colspan=1>鼎汇创新中心</td><td rowspan=1 colspan=1>300.00</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>900. 00</td></tr></table>

2025 年 4 月，公司战略投资无锡瑞知微电子有限公司；2025 年10 月，公司出资参与设立江苏鼎汇具身智能机器人创新中心有限公司。瑞知微、鼎汇创新中心不构成财务性投资，详见本题回复之“一/（七）/2、结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形”。

## （4）其他非流动资产

截至报告期末，公司其他非流动资产按款项余额性质分类如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>款项性质</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>预付长期资产款</td><td rowspan=1 colspan=1>1,773. 21</td></tr><tr><td rowspan=1 colspan=1>对西博安泰的投资</td><td rowspan=1 colspan=1>3,460. 26</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>5, 233. 47</td></tr></table>

截至报告期末，公司其他非流动资产主要为包括预付长期资产款和对西博安泰的投资。

发行人预付长期资产款主要包括预付装修工程款、预付设备款，均与公司主营业务相关，不属于财务性投资。

发行人对西博安泰的投资不构成财务性投资，详见本题回复之“一/（七）/2、结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形”。

综上所述，公司最近一期末不存在财务性投资。

2、结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形

截至报告期末，公司持有的对外股权投资情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>公司会计核算科目</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>是否构成财务性投资</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>无锡瑞知微电子有限公司</td><td rowspan=1 colspan=1>其他权益工具投资</td><td rowspan=1 colspan=1>600.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>深圳市西博安泰创业投资合伙企业（有限合伙）</td><td rowspan=1 colspan=1>其他非流动资产</td><td rowspan=1 colspan=1>3,460. 26</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>江苏鼎汇具身智能机器人创新中心有限公司</td><td rowspan=1 colspan=1>其他权益工具投资</td><td rowspan=1 colspan=1>300.00</td><td rowspan=1 colspan=1>否</td></tr></table>

公司投资上述企业的基本情况如下：

## （1）无锡瑞知微电子有限公司

<table><tr><td rowspan=1 colspan=1>企业名称</td><td rowspan=1 colspan=1>无锡瑞知微电子有限公司</td></tr><tr><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>2024年10月14日</td></tr><tr><td rowspan=1 colspan=1>截至报告期末账面价值</td><td rowspan=1 colspan=1>600.00万元</td></tr><tr><td rowspan=1 colspan=1>发行人持股比例</td><td rowspan=1 colspan=1>12.00%</td></tr><tr><td rowspan=1 colspan=1>认缴金额</td><td rowspan=1 colspan=1>68.1818万元</td></tr><tr><td rowspan=1 colspan=1>实缴金额</td><td rowspan=1 colspan=1>68.1818万元</td></tr><tr><td rowspan=1 colspan=1>投资时间</td><td rowspan=1 colspan=1>2025年4月23日</td></tr><tr><td rowspan=1 colspan=1>主营业务</td><td rowspan=1 colspan=1>新一代磁传感器的研发与制造</td></tr><tr><td rowspan=1 colspan=1>与公司产业链合作情况及协同效应</td><td rowspan=1 colspan=1>瑞知微主要从事磁传感芯片研发与制造，在磁传感芯片领域具有一定的技术积累。目前，瑞知微尚处于产品开发阶段，与公司尚未开展具体合作。未来，在产业链合作方面，公司拟与瑞知微就新型高端磁传感技术领域进行深度协同研发，共同推动新型高端磁传感芯片研发及智能化应用。在产业协同方面，安培龙可依托产业化能力和全球渠道，助力瑞知微磁传感技术的市场化转化；而瑞知微在磁传感技术领域的积累可为发行人进一步补充产品矩阵，双方可共同拓展低空经济、风电等新兴场景，共同推动国产高端传感器的自主可控与全球化布局。因此，公司将在未来有效整合瑞知微在磁传感器领域的前沿技术，填补公司在磁传感器方向的技术空白，进一步完善智能传感器产业链布局，强化公司竞争力。</td></tr><tr><td rowspan=1 colspan=1>后续处置计划</td><td rowspan=1 colspan=1>公司基于战略投资，计划长期持有，后续公司将根据未来发展规划以及业务情况确定处置计划</td></tr><tr><td rowspan=1 colspan=1>是否构成财务性投资</td><td rowspan=1 colspan=1>否</td></tr></table>

瑞知微主要从事磁传感芯片研发与制造。公司投资瑞知微旨在对新型高端磁传感技术领域进行深度协同研发，共同推动新型高端磁传感芯片研发及智能化应用，拓展传感器产品在低空经济、风电等新兴场景，共同推动国产高端传感器的自主可控与全球化布局。因此，公司对瑞知微的投资，该笔投资与公司所处产业密切相关、属于围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，未认定为财务性投资的依据充分。

（2）深圳市西博安泰创业投资合伙企业（有限合伙）
<table><tr><td rowspan=1 colspan=1>企业名称</td><td rowspan=1 colspan=1>深圳市西博安泰创业投资合伙企业（有限合伙)</td></tr><tr><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>2024年6月28日</td></tr><tr><td rowspan=1 colspan=1>截至报告期末账面价值</td><td rowspan=1 colspan=1>3,460.26万元</td></tr><tr><td rowspan=1 colspan=1>发行人持股比例</td><td rowspan=1 colspan=1>23.6486%</td></tr><tr><td rowspan=1 colspan=1>认缴金额</td><td rowspan=1 colspan=1>3,500.00万元</td></tr><tr><td rowspan=1 colspan=1>实缴金额</td><td rowspan=1 colspan=1>3,500.00万元</td></tr><tr><td rowspan=1 colspan=1>投资时间</td><td rowspan=1 colspan=1>2024年9月30日</td></tr><tr><td rowspan=1 colspan=1>主营业务</td><td rowspan=1 colspan=1>创业投资，投资标的为森世泰，森世泰是国内氮氧传感器的领先企业（西博安泰实收资本合计1.48亿元，已全部投资于森世泰；西博安泰不存在其他投资计划，不会新增除森世泰的其他投资标的）</td></tr><tr><td rowspan=1 colspan=1>与公司产业链合作情况及协同效应</td><td rowspan=1 colspan=1>西博安泰投资标的森世泰系国内氮氧传感器的领先企业，专业从事传感器的研发、生产、销售和服务，目前主要产品包括氮氧等各类传感器。森世泰主营业务与公司高度相关，在氮氧传感器领域国内技术领先，具备陶瓷芯片、传感器的研发制造能力以及软硬件系统研发能力，拥有稳定的柴油车客户资源。而氮氧传感器是公司战略布局的细分产品类型，因此双方在产品技术开发、客户资源拓展方面有较强的协同性。</td></tr><tr><td rowspan=1 colspan=1>后续处置计划</td><td rowspan=1 colspan=1>公司基于战略投资，计划长期持有，后续公司将根据未来发展规划以及业务情况确定处置计划</td></tr><tr><td rowspan=1 colspan=1>是否构成财务性投资</td><td rowspan=1 colspan=1>否</td></tr></table>

西博安泰投资标的为森世泰，森世泰系国内氮氧传感器的领先企业，其主营业务与公司高度相关，双方在产品技术开发、客户资源拓展方面有较强的协同性。因此，公司对西博安泰的投资，与公司所处产业密切相关、属于围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，未认定为财务性投资的依据充分。

## （3）江苏鼎汇具身智能机器人创新中心有限公司

<table><tr><td rowspan=1 colspan=1>企业名称</td><td rowspan=1 colspan=1>江苏鼎汇具身智能机器人创新中心有限公司</td></tr><tr><td rowspan=1 colspan=1>成立时间</td><td rowspan=1 colspan=1>2025年10月20日</td></tr><tr><td rowspan=1 colspan=1>截至报告期末账面价值</td><td rowspan=1 colspan=1>300.00万元</td></tr><tr><td rowspan=1 colspan=1>发行人持股比例</td><td rowspan=1 colspan=1>5. 00%</td></tr><tr><td rowspan=1 colspan=1>认缴金额</td><td rowspan=1 colspan=1>300.00万元</td></tr><tr><td rowspan=1 colspan=1>实缴金额</td><td rowspan=1 colspan=1>300.00万元</td></tr><tr><td rowspan=1 colspan=1>投资时间</td><td rowspan=1 colspan=1>2025年10月20日</td></tr><tr><td rowspan=1 colspan=1>主营业务</td><td rowspan=1 colspan=1>具身智能机器人相关数据生态、操作系统、核心零部件及应用场景等方向的研发</td></tr><tr><td rowspan=1 colspan=1>与公司产业链合作情况及协同效应</td><td rowspan=1 colspan=1>鼎汇创新中心从事具身智能机器人相关技术研究，与公司主要产品之一力传感器的主要应用场景高度契合。鼎汇创新中心由工业机器人头部企业埃斯顿（002747.SZ;02715.HK)、南京市江宁开发区牵头，联合亨通光电(600487.SH)旗下线缆供应商亨通线缆、机器人核心零部件供应商绿的谐波(688017.SH)、汽车零部件供应商泉峰汽车（603982.SH)、传感器供应商安培龙（301413.SZ，发行人）等行业内重点企业共同组建成立。鼎汇创新中心旨在依托埃斯顿等龙头股东牵头，联合产学研用组成产业创新联盟，加强具身智能机器人关键技术和产品攻关，带动江苏省乃至全国人形机器人技术发展，提升我国人形机器人影响力。目前，鼎汇创新中心尚处于初创阶段，与公司尚未开展具体合作。未来，公司作为鼎汇创新中心股东单位，将优先享受中心研发成果和平台资源、优先参与技术标准化和行业生态建设机会，中心和牵头单位将优先选用公司等股东单位产品服务应用于相关具身智能机器人研发和产业化应用中。鼎汇创新中心将有助于公司把握具身智能机器人产业的战略发展机遇，协助公司拓宽力传感器等相关产品在具身智能机器人领域的应用场景，提高公司综合竞争力，与公司具备协同效应。</td></tr><tr><td rowspan=1 colspan=1>后续处置计划</td><td rowspan=1 colspan=1>公司基于战略投资，计划长期持有，后续公司将根据未来发展规划以及业务情况确定处置计划</td></tr><tr><td rowspan=1 colspan=1>是否构成财务性投资</td><td rowspan=1 colspan=1>否</td></tr></table>

鼎汇创新中心主要从事具身智能机器人相关数据生态、操作系统、核心零部件及应用场景等方向的研发。发行人投资鼎汇创新中心，旨在把握具身智能机器人产业的战略发展机遇，有助于公司拓宽力传感器等相关产品在具身智能机器人领域的应用场景，提高公司综合竞争力。因此，公司对鼎汇创新中心的投资，与公司所处产业密切相关、属于围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，未认定为财务性投资的依据充分。

综上，公司最近一期末持有的对外股权投资，均为围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资。截至最近一期末，公司不存在持有较大的财务性投资（包括类金融业务）的情形。

## 3、自本次发行相关董事会前六个月至今，公司已实施或拟实施的财务性投资的具体情况，说明是否涉及募集资金扣减情形

本次发行相关的董事会决议日为第四届董事会第十二次会议决议日（2026年 1 月 7 日）。本次发行相关的董事会决议日前六个月至本问询回复出具日，发行人不存在已实施或拟实施的财务性投资的情形。

本次发行相关的董事会决议日前六个月至本问询回复出具日，发行人对外股权投资情况为对江苏鼎汇具身智能机器人创新中心有限公司的投资（投资金额300.00 万元）和对博思发科技（深圳）有限公司（投资金额800.00 万元）的投资，均不属于财务性投资，具体情况如下：

## （1）江苏鼎汇具身智能机器人创新中心有限公司

公司投资鼎汇创新中心相关情况详见本题回复之“一/（七）/2、结合最近一期期末对外股权投资情况，包括公司名称、账面价值、持股比例、认缴金额、实缴金额、投资时间、主营业务、是否属于财务性投资、与公司产业链合作具体情况、后续处置计划等，说明公司最近一期末是否存在持有较大的财务性投资（包括类金融业务）的情形”，未认定为财务性投资的依据充分。

## （2）博思发科技（深圳）有限公司

<table><tr><td colspan="1" rowspan="1">企业名称</td><td colspan="1" rowspan="1">博思发科技（深圳）有限公司</td></tr><tr><td colspan="1" rowspan="1">成立时间</td><td colspan="1" rowspan="1">2018年10月22日</td></tr><tr><td colspan="1" rowspan="1">发行人持股比例</td><td colspan="1" rowspan="1">2. 45%</td></tr><tr><td colspan="1" rowspan="1">认缴金额</td><td colspan="1" rowspan="1">29.5215万元</td></tr><tr><td colspan="1" rowspan="1">实缴金额</td><td colspan="1" rowspan="1">29.5215万元</td></tr><tr><td colspan="1" rowspan="1">投资时间</td><td colspan="1" rowspan="1">2026年4月16日</td></tr><tr><td colspan="1" rowspan="1">主营业务</td><td colspan="1" rowspan="1">流量传感器、风速计和真空传感器的研发生产和销售</td></tr><tr><td colspan="1" rowspan="1">与公司产业链合作情况及协同效应</td><td colspan="1" rowspan="1">博思发是一家专注于高性能、低成本传感器及解决方案的高新技术企业，核心业务是为医疗设备、新能源、数据中心管理等领域提供流量传感器、风速计和真空传感器等产品。博思发主营业务与公司高度相关，在流量传感器等领域技术领先。依托双方在传感器领域的技术优势，公司与博思发拟在完成投资后，就应用于发动机传感器的MAF芯片达成战略合作，博思发在同等条件下优先向公司供应MAF芯片。此外，博思发有望协助公司布局消费电子产品、暖通空调、医疗设备和数据中心管理等市场，为公司开辟新的增长点，提高公司综合竞争力，与公司有较强的协同性。</td></tr><tr><td>后续处置计划</td><td>公司基于战略投资，计划长期持有，后续公司将根据未来发展规 划以及业务情况确定处置计划</td></tr><tr><td>是否构成财务性投资</td><td>否</td></tr></table>

博思发是一家专注于高性能、低成本传感器及解决方案的高新技术企业，核心业务是为医疗设备、新能源、数据中心管理等领域提供流量传感器、风速计和真空传感器等产品。公司投资博思发，有利于切入流量传感器、风速计和真空传感器等细分领域，布局消费电子产品、暖通空调、医疗设备和数据中心管理等市场，为公司开辟新的增长点，提高公司综合竞争力。因此，公司对博思发的投资，与公司所处产业密切相关、属于围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，未认定为财务性投资的依据充分。

因此，本次发行相关的董事会决议日前六个月至本回复出具日，发行人对外投资均为围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，不存在实施或拟实施的财务性投资及类金融业务，不涉及募集资金扣减的情形。

因此，本次发行相关的董事会决议日前六个月至本回复出具日，发行人对外投资均为围绕产业链上下游以获取技术、原料或者渠道为目的的产业投资，不存在实施或拟实施的财务性投资及类金融业务，不涉及募集资金扣减的情形。

## 二、核查程序及核查意见

（一）核查程序

保荐人履行了如下核查程序：

1、获取发行人报告期内定期财务报告，分析营业收入及利润波动的原因；获取同行业可比公司年度报告、定期报告等财务信息分析发行人与同行业可比公司业绩变化趋势情况表现是否一致；取得公司关于增收幅度大于增利幅度的具体原因、各业务板块毛利率变动原因及经营发展情况的相关说明；

2、取得发行人外销收入明细表，通过商务部等网站检索查询主要外销国家地区的贸易政策变动情况；查询美元兑人民币汇率变动趋势，分析汇率波动对发行人经营业绩的影响，分析汇兑损益与发行人相关业务规模及汇率波动情况是否匹配；取得公司关于报告期内公司主要外销国家地区的贸易政策变动情况、对公司经营的影响以及采取的措施、发行人应对汇率波动风险的措施等情况的说明；

3、取得发行人的往来及账龄明细表，分析各往来单位对应的应收款项的具体内容和账龄；取得发行人关联方清单，核对其他应收款交易对方与发行人是否存在关联关系；取得发行人收入明细表，分析比较应收款项规模变动的原因及合理性；取得公司关于其他应收款的具体内容及各应收款项规模变动的主要原因等情况的说明；获取发行人的应收票据台账，核对票据余额的准确性并分析应收票据变动原因；查阅同行业可比公司对应应收款项坏账的计提政策并与发行人进行比较，分析公司坏账计提的充分性；

4、取得发行人存货余额明细表，分析存货规模及占比变动的合理性；取得发行人在手订单情况，与存货变动情况对比，分析存货规模变动的合理性；取得公司关于存货规模及占比变动的合理性等情况的说明；取得公司存货库龄明细表，分析期后结转情况；了解公司存货主要类别的跌价准备计提政策，分析其合理性；整理同行业可比公司的存货规模变动情况、存货跌价计提情况，与公司情况进行对比以分析合理性；

5、查阅发行人及其境内子公司主管部门开具的合规证明或企业信用报告（无违法违规证明版）；查阅东莞安培龙相关行政处罚决定书；查阅了东莞市市场监督管理局关于不合格食品核查处置情况的通告；

6、取得发行人固定资产折旧明细表，统计房屋建筑物及设施的账面情况并了解对应资产的使用情况；将《企业会计准则》规定的可能存在减值迹象的情况与发行人实际情况逐项进行比对，分析发行人是否存在具有减值迹象的固定资产，收集各报告期内的资产减值测算表；取得发行人在建工程余额明细表及重要在建工程的变动明细，了解公司在建工程的具体核算方式及转固政策；取得氧传感器相关设备明细表、氧传感器在手订单；取得公司关于重要在建工程的建设进展、氧传感器业务发展等情况的说明，评估氧传感器业务发展前景及产能闲置风险情况；

7、取得发行人可能涉及财务性投资的相关会计科目明细，了解其主要内容，分析其是否属于财务性投资；查阅发行人对外股权投资各被投资企业的营业执照、投资协议、投资决策资料；取得公司关于发行人对外股权投资的背景、产业链协同情况、已实施和拟实施的财务性投资情况的说明。

## （二）核查意见

经核查，保荐人认为：

1、报告期内，发行人出现增收幅度大于增利幅度的情形，主要与毛利率变动、期间费用变动、信用减值损失和资产减值损失等因素有关，具有合理性；发行人各主要业务板块毛利率变动具有合理性；发行人毛利率水平、业绩趋势与同行业可比公司不存在较大差异；受下游需求增长驱动，得益于发行人优质丰富的客户资源、领先的技术水平和富有竞争力的产品，发行人未来业绩大幅下滑的风险较低；

2、报告期内，发行人主要外销国家地区的贸易政策波动未对发行人经营构成重大不利影响，发行人境外经营具有稳定性、可持续性；汇率变动对发行人经营影响较小，汇率变动未对发行人经营业绩产生重大不利影响；发行人汇兑损益与外销业务规模及汇率波动情况相匹配；发行人应对汇率波动、贸易政策等相关风险已采取积极措施；

3、报告期内，发行人其他应收款核算内容主要系保证金押金，主要交易对手与发行人不存在关联关系，其他应收款余额及账龄结构变动具有合理性；发行人应收款项规模增长主要系随营业收入规模的不断提高而增长所致，应收款项增长与营业收入匹配，具有合理性；发行人应收款项坏账准备计提政策与同行业可比公司相比不存在重大差异，各期末坏账准备计提充分；

4、报告期内，发行人存货结构基本稳定，存货规模增长较快主要系在手订单金额持续增长，存货账面价值随之持续增长所致，变动趋势与同行业可比公司基本一致，具有合理性；存货库龄整体较短，库龄结构良好，存货期后结转充分，跌价计提政策合理，存货跌价准备计提充分，与同行业可比公司不存在较大差异，具有合理性；

5、发行人最近三年不存在严重损害投资者合法权益或社会公众利益的重大违法行为，符合《注册办法》第十一条及《证券期货法律适用意见第 18 号》的相关规定；

6、报告期内，发行人主要固定资产均处于正常使用状态，其中部分因规划预留暂未正式投入使用的房屋建筑物已明确后续使用计划且稳步推进，不存在减值迹象；发行人固定资产减值计提充分；发行人在建工程转固及时，不存在未及时转固的情形，相关会计处理符合《企业会计准则》的相关规定；氧传感器市场空间较为广阔，国产替代需求迫切，虽然目前因进口依赖度较大、进入门槛高，产能利用率较低，但发行人氧传感器产品技术领先、客户拓展进展顺利，订单储备进展良好，仍具备较为明朗的发展前景，原有产能闲置风险较低，相关资产减值风险较低；

7、公司最近一期末不存在持有较大的财务性投资（包括类金融业务）的情形；自本次发行相关董事会前六个月至今，公司不存在已实施或拟实施的财务性投资，不涉及募集资金扣减情形。

## 问题2

申报材料显示，发行人本次向特定对象发行股票拟募集资金不超过 54,440万元，主要用于压力传感器扩产项目（以下简称项目一）、陶瓷电容式压力传感器产线升级项目（以下简称项目二）、力传感器产线建设项目（以下简称项目三）、MEMS 传感器芯片研发及产业化项目（以下简称项目四）和补充流动资金。

项目一建成投产后将新增2,800 万个压力传感器产能，计划通过购置生产设备，扩大压力传感器产能，具体产品包括陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器，主要应用于汽车、商用空调、储能产品。项目一达产后预计毛利率为 30.86%，报告期内发行人压力传感器业务毛利率分别为34.92%、30.81%、31.61 和 28.37%，呈下降趋势。

项目二拟对现有陶瓷压力传感器产线进行技术升级改造，提升产线自动化水平。项目二假设升级后产线投产新增产能当年都能进行销售，新增产能 686.07万个/年，达产后预计毛利率为 36.41%。

项目三计划通过购置生产设备，新增年产约 50 万个力传感器产能，将分别采用金属应变片工艺与 MEMS 硅基应变片工艺进行力传感器生产，项目产品涉及拉压力传感器、力矩传感器、六维力传感器。项目三达产后预计毛利率为37.77%，高于报告期内公司毛利率水平。

项目四计划通过 2 年时间开展 MEMS 压力传感器感压芯片、单桥压力接口芯片、双桥压力接口芯片、玻璃微熔压力传感器用 MEMS 半导体应变片以及力传感器用MEMS 半导体应变片等芯片的技术研发工作，并实现MEMS 压力传感器芯片模组的产业化，项目实施后公司将形成年产逾 500 万个 MEMS 压力传感器芯片模组的产能规模，全部用于内部供应。在本次募投项目实施前，公司传感器产品所用芯片均为对外采购。项目四税后内部收益率为13.93%。

发行人 2023 年首次公开发行股票并在创业板上市募集资金净额为5.44亿元，主要用于安培龙智能传感器产业园项目-压力传感器建设项目、温度传感器建设项目、智能传感器研发中心建设项目和补充流动资金等，另外超募资金的5,064.02万元其中 4,130.70 万元用于新一代智能驾驶刹车系统用力传感器建设项目，933.32 万元用于贴片式 NTC 热敏电阻研发及产业化建设项目。部分前次募投项目存在延期，将温度传感器建设项目达到预定可使用状态日期延长至 2025 年 6月 30 日，将智能传感器研发中心建设项目达到预定可使用状态日期延长至 2024年6月30 日。报告期内，公司采取自主生产为主，委外加工为辅的生产模式。

请发行人：

（1）分项目说明各募投项目的具体建设内容和主要产品，列示说明与公司主营业务及前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别和联系，是否存在重复建设，是否在前述方面具有协同性，向产业链上下游扩展的必要性；本次募投项目新产品所需研发技术、所处研发阶段，是否存在试生产环节，并结合发行人具体技术掌握、研发进度、人员和客户储备等情况，说明本次募投项目的实施是否存在重大不确定性，是否符合募集资金投向主业的要求。

（2）说明项目四将传感器所用芯片从对外采购转为自行研发生产的原因及合理性；结合现有陶瓷压力传感器产线的使用情况、项目二的具体升级内容、是否涉及前次募投项目所投入设备，说明在前次募投项目建成时间较短的情况下对产线进行升级的原因及合理性，说明本次募投项目的实施是否具有必要性。

（3）分项目结合产品构成、销量及销售价格、成本、毛利率、净利润的具体计算过程及相关关键参数的选取，说明在报告期内发行人毛利率呈下降趋势的情况下项目一、项目二、项目三预计毛利率高于发行人现有业务毛利率的原因及合理性，项目四内部收益率是否与同行业可比公司情况相符，效益测算是否谨慎、合理，是否与公司现有同类业务及同行业可比公司情况存在较大差异。

（4）结合报告期内委外加工具体情况、本次各募投项目的新增产能情况、扩产倍数、行业竞争格局、下游行业发展前景及市场需求情况、在手订单或意向性协议、公司现有产品产能利用率情况、前次募投项目的产能情况、同行业可比公司扩产情况等，说明本次募投项目新增产能的必要性及具体产能消化措施，是否存在产能消化风险。

（5）结合本次各募投项目的具体设备购置内容、价格和作用等情况，说明拟购置设备是否为公司目前相关资产的更新或升级，相关投入规模是否合理，测算并说明募集资金投入的经济性；结合现有固定资产、在建工程情况，量化分析本次募投项目、拟建及在建项目等新增折旧摊销对发行人未来盈利能力及经营业绩的影响。

（6）说明本次募投项目是否已取得开展所需的相关资质、认证、许可及备案，是否存在重大不确定性或实质性障碍；项目四使用租赁土地的原因及合理性，土地的用途、使用年限、租用年限、租金及到期后对土地的处置计划。

（7）结合报告期内关联交易的具体情况，说明本次募投项目的实施是否新增关联交易，如是，新增关联交易价格的公允性及保证公平的相关措施，是否符合《注册办法》第十二条的相关规定。

（8）说明项目四研发费用的主要内容、技术可行性、研发预算及时间安排、目前研发投入及进展、已取得或预计可取得的研发成果等，是否存在较大的研发失败风险，研发投入中拟资本化部分是否符合项目实际情况、是否符合《企业会计准则》的相关规定；结合报告期内发行人同类项目、同行业公司可比项目的资本化情况，说明本次募投项目中拟资本化金额的合理性。

（9）结合本次募投项目的投资明细和募集资金拟投入情况，投入产出比测算等情况，说明本次融资必要性，量化测算并说明补充流动资金的规模合理性，本次补充流动资金占比是否符合《证券期货法律适用意见第18 号》相关规定。

（10）前次募投项目延期的原因及合理性,相关变更情况是否已按规定履行相关审议程序与披露义务,相关影响因素是否持续,是否对本次募投项目实施造成重大不利影响。

请发行人补充披露相关风险。

请保荐人核查并发表明确意见，请会计师核查（3）（4）（5）（8）（9）并发表明确意见，请发行人律师核查（1）（2）（6）-（10）并发表明确意见。

回复：

## 一、发行人说明

（一）分项目说明各募投项目的具体建设内容和主要产品，列示说明与公司主营业务及前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别和联系，是否存在重复建设，是否在前述方面具有协同性，向产业链上下游扩展的必要性；本次募投项目新产品所需研发技术、所处研发阶段，是否存在试生产环节，并结合发行人具体技术掌握、研发进度、人员和客户储备等情况，说明本次募投项目的实施是否存在重大不确定性，是否符合募集资金投向主业的要求

## 1、分项目说明各募投项目的具体建设内容和主要产品

除补充流动资金外，各募投项目的具体建设内容和主要产品如下表：

<table><tr><td>产线类别</td><td>具体建设内容</td><td>主要产品</td></tr><tr><td>压力传感器扩 产项目</td><td>公司计划通过购置全新生产设备，扩大压力传感器产能， 具体产品包括陶瓷电容式压力传感器、MEMS压力传感器、 玻璃微熔压力传感器，主要应用于汽车、商用空调、储能 产品、消费电子等领域。本项目建成投产后，公司将新增 超2,800万个压力传感器产能，有效满足公司大力拓展下 游应用领域市场的业务需求，为夯实公司市场地位、保障 公司未来业绩持续增长奠定基础</td><td>压力传感器， 具体产品包括 陶瓷电容式压 力传感器、 MEMS压力传 感器、玻璃微 熔压力传感器</td></tr><tr><td>陶瓷电容式压 力传感器产线 升级项目</td><td>公司计划对现有陶瓷压力传感器产线进行技术升级改造， 提升产线自动化水平，助力公司降本增效、提升产能、优 化生产工序、提升产品工艺精度，技术升级改造完成后现 有陶瓷电容式压力传感器产能提升686万个，为巩固陶瓷 压力传感器产品市场份额，实现自身可持续发展奠定基础</td><td>陶瓷电容式压 力传感器</td></tr><tr><td>力传感器产线 建设项目</td><td>公司计划通过购置全新生产设备，新增年产约50万个力传 感器产能。本项目将分别采用金属应变片工艺与MEMS 硅 基应变片工艺进行力传感器生产，项目产品涉及拉压力传 感器、力矩传感器、六维力传感器。本项目的实施有助于 丰富公司产品体系，巩固公司在行业内的领先地位</td><td>力传感器，具 体产品包括拉 压力传感器、 力矩传感器、 六维力传感器</td></tr><tr><td>MEMS传感器 芯片研发及产 业化项目</td><td>公司计划通过2年时间进一步开展MEMS压力传感器感压 芯片、单桥压力接口芯片、双桥压力接口芯片、玻璃微熔 压力传感器用MEMS半导体应变片以及力传感器用 MEMS 半导体应变片等芯片的技术研发工作，并实现 MEMS 压力传感器芯片模组的产业化。项目实施后，公司</td><td>MEMS压力传 感器芯片模组</td></tr><tr><td></td><td>将形成年产逾500万个MEMS压力传感器芯片模组的产能 规模，全部用于自供，充分满足公司MEMS压力传感器芯 片模组对于MEMS 压力传感器的自产需求。一方面，本项 目建设有助于公司MEMS压力传感器芯片模组由原来的外 采转变为自主供应为主，可较大程度降低MEMS压力传感 器的生产成本，提升公司盈利能力，增强市场竞争力。另 一方面，在下游应用场景逐渐丰富与MEMS压力传感器技 术不断革新的背景下，本项目建设有利于确保MEMS 压力 传感器的质量稳定性与协同性，对公司加快新技术、新产 品的产业化落地具有积极意义</td><td></td></tr></table>

2、列示说明与公司主营业务及前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别和联系，是否存在重复建设，是否在前述方面具有协同性，向产业链上下游扩展的必要性

发行人是一家专业从事热敏电阻及温度传感器、压力传感器、氧传感器、力传感器的研发、生产和销售的第一批国家级专精特新“小巨人”企业。基于长期的技术积累以及产业化经验，目前，公司已构建了涵盖热敏电阻及温度传感器、陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器、氧传感器、氮氧传感器、力传感器等多层次产品矩阵，以满足不同市场需求。

依托公司在传感器领域现有技术和业务基础，本次募投项目围绕主营业务展开，旨在进一步扩大陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器产能，同时实现力传感器的量产交付，加快实现上述产品国产替代和自主可控，进一步完善公司传感器产品体系，为客户提供更加丰富的传感器品类选择，提升公司盈利能力和核心竞争力。

本次募投项目不存在重复建设，与前次募投项目的区别、联系及协同情况如下：

## （1）压力传感器扩产项目

除补充流动资金外，发行人前次募投项目（IPO 募投项目及超募资金投资项目）具体情况如下：

<table><tr><td colspan="1" rowspan="1">产线类别</td><td colspan="1" rowspan="1">产品及产能</td></tr><tr><td colspan="1" rowspan="1">压力传感器建设项目</td><td colspan="1" rowspan="1">年产1,500 万只压力传感器产品（均为陶瓷电容式压力传感器）</td></tr><tr><td colspan="1" rowspan="1">温度传感器建设项目</td><td colspan="1" rowspan="1">年产10,500万只温度传感器产品，其中非汽车综合用温度传感器10,000万只，汽车用温度传感器 500万只</td></tr><tr><td colspan="1" rowspan="1">智能传感器研发中心建设项目</td><td colspan="1" rowspan="1">研发项目，未新增产品及产能</td></tr><tr><td colspan="1" rowspan="1">新一代智能驾驶刹车系统用力传感器建设项目</td><td colspan="1" rowspan="1">年产超150万只 EMB力传感器</td></tr><tr><td colspan="1" rowspan="1">贴片式NTC热敏电阻研发及产业化建设项目</td><td colspan="1" rowspan="1">年产约32 亿个贴片式NTC 热敏电阻的产能</td></tr></table>

报告期内，公司压力传感器的生产规模和收入规模整体呈现上升趋势。报告期内，公司压力传感器的生产情况如下：

单位：万个

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>压力传感器</td><td rowspan=1 colspan=1>2,451. 75</td><td rowspan=1 colspan=1>1, 691. 53</td><td rowspan=1 colspan=1>1,018. 17</td></tr></table>

报告期内，公司压力传感器的收入情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>压力传感器</td><td rowspan=1 colspan=1>67, 431. 69</td><td rowspan=1 colspan=1>46, 800. 21</td><td rowspan=1 colspan=1>35,410. 24</td></tr></table>

压力传感器扩产项目与公司前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别、联系及协同如下：

<table><tr><td colspan="1" rowspan="1">产线类别</td><td colspan="1" rowspan="1">压力传感器扩产项目</td><td colspan="1" rowspan="1">前次募投项目</td><td colspan="1" rowspan="1">区别、联系及协同</td></tr><tr><td colspan="1" rowspan="1">生产产品</td><td colspan="1" rowspan="1">压力传感器，具体产品包括陶瓷电容式压力传感器、MEMS压力传感器、玻璃微熔压力传感器</td><td colspan="1" rowspan="1">压力传感器中的陶瓷电容式压力传感器、温度传感器；智能驾驶刹车系统用（EMB）力传感器；贴片式NTC 热敏电阻</td><td colspan="1" rowspan="1">生产产品都包含陶瓷电容式压力传感器，但整体产品结构存在差异，新增了MEMS 压力传感器、玻璃微熔压力传感器；基于在传感器领域的技术积累及业务基础，发行人持续扩大传感器产品品类，丰富产品体系，提升公司核心竞争力</td></tr><tr><td colspan="1" rowspan="1">所需原材料</td><td colspan="1" rowspan="1">通常包含五金塑胶、电子类材料、陶瓷玻璃、封装胶料，部分陶瓷电容式压力传感器还需要线材、电极与焊接类材料、套管等</td><td colspan="1" rowspan="1">通常包含五金塑胶、线材、电子类材料、电极与焊接类材料、陶瓷玻璃、封装胶料、套管等</td><td colspan="1" rowspan="1">原材料大部分共同；MEMS 压力传感器、玻璃微熔压力传感器有部分差异，基本不需要用到线材、套管等</td></tr><tr><td colspan="1" rowspan="1">应用领域及下游客户</td><td colspan="1" rowspan="1">主要应用于汽车、商用空调、储能、消费电子等领域</td><td colspan="1" rowspan="1">陶瓷电容式压力传感器、EMB力传感器主要用于汽车领域，温度传感器主要用于家用</td><td colspan="1" rowspan="1">由原有的汽车及家电应用领域持续扩展至储能产品、消费电子等；下游客户同样不断拓展，公司</td></tr><tr><td></td><td></td><td>电器及汽车领域，贴片 式 NTC 热敏电阻主要 用于消费电子、汽车电 子、家用电器等领域</td><td>已进入比亚迪、北美某知名新 能源汽车客户、Stellantis、上 汽集团、长城汽车、东风汽车 等汽车主机厂供应链，美的、 格力、海尔、绿山咖啡等家电 领域供应链，并已形成了较为 稳定的合作关系</td></tr><tr><td>主要技术参数</td><td>新增了MEMS 技 术及玻璃微熔技 术；陶瓷电容式压 力传感器的后段 制造全部采用自 动化技术</td><td>NTC 热敏电阻、温度传 感器与压力传感器、力 传感器、MEMS 压力传 感器芯片模组技术参 数基本不同； EMB 力传感器主要技 术参数包括额定力、最 大承受力、破坏力、精 度、功能安全要求、汽 车领域各项测试要求 等； 同属陶瓷电容式压力 传感器部分技术参数 基本相同，但前次募投 项目后段制造未采用 自动化技术</td><td>不同产品的技术参数有所不 同； 同样的陶瓷电容式压力传感 器，本次募投项目采用了自动 化技术，可进一步提升自身生 产能力、优化生产效率以及产 品一致性等，而前次募投项目 未采用</td></tr></table>

综上，本次募投项目之一的压力传感器扩产项目与前次募投项目系属于互相独立的投资项目，在生产产品、应用领域、下游客户、主要技术参数等方面具有协同性，既有一定联系，亦存在明显差异，不存在重复建设的情形；本次募投项目之一的压力传感器扩产项目不存在向产业链上下游扩展的情形。

## （2）陶瓷电容式压力传感器产线升级项目

陶瓷电容式压力传感器产线升级项目与公司前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别、联系及协同如下：

<table><tr><td>产线类别</td><td>陶瓷电容式压 力传感器产线 升级项目</td><td>前次募投项目</td><td>区别、联系及协同</td></tr><tr><td>生产产品</td><td>压力传感器中 的陶瓷电容式 压力传感器</td><td>压力传感器中的陶瓷电容 式压力传感器、温度传感 器； 智能驾驶刹车系统用 （EMB）力传感器； 贴片式NTC 热敏电阻</td><td>生产产品都包含陶瓷电容 式压力传感器，所需原材 料亦基本相同，但建设性 质存在差异，前次募投项 目系新建项目，本次募投</td></tr><tr><td>所需原材料</td><td>通常包含五金 塑胶、线材、电</td><td>通常包含五金塑胶、线材、 电子类材料、电极与焊接类</td><td>项目系对公司所有陶瓷电 容式压力传感器产线进行 技术升级改造，以提升产</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">子类材料、电极与焊接类材料、陶瓷玻璃、封装胶料、套管等</td><td colspan="1" rowspan="1">材料、陶瓷玻璃、封装胶料、套管等</td><td colspan="1" rowspan="1">线自动化水平，助力公司降本增效、提升产能、优化生产工序、提升产品工艺精度以及产品一致性</td></tr><tr><td colspan="1" rowspan="1">应用领域及下游客户</td><td colspan="1" rowspan="1">陶瓷电容式压力传感器主要用于汽车、空调、储能等领域</td><td colspan="1" rowspan="1">陶瓷电容式压力传感器、EMB力传感器主要用于汽车领域，温度传感器主要用于家用电器及汽车领域，贴片式 NTC 热敏电阻主要用于消费电子、汽车电子、家用电器等领域</td><td colspan="1" rowspan="1">陶瓷电容式压力传感器应用领域未改变；在产品技术升级改造后可以更好地满足下游客户需求，助力公司拓展更多更优质客户</td></tr><tr><td colspan="1" rowspan="1">主要技术参数</td><td colspan="1" rowspan="1">本次升级改造陶瓷电容式压力传感器的后段制造全部采用自动化技术</td><td colspan="1" rowspan="1">NTC 热敏电阻、温度传感器与压力传感器、力传感器、MEMS压力传感器芯片模组技术参数基本不同;EMB力传感器主要技术参数包括额定力、最大承受力、破坏力、精度、功能安全要求、汽车领域各项测试要求等；同属陶瓷电容式压力传感器部分技术参数基本相同，但前次募投项目后段制造未采用自动化技术</td><td colspan="1" rowspan="1">同样的陶瓷电容式压力传感器，本次募投项目采用了自动化技术，可进一步提升自身生产能力、优化生产效率以及产品一致性等，而前次募投项目未采用</td></tr></table>

综上，本次募投项目之一的陶瓷电容式压力传感器产线升级项目系对公司现有的陶瓷电容式压力传感器进行技术升级改造，与前次募投项目在生产产品、应用领域、下游客户、主要技术参数等方面基本相同，具有协同性，但建设性质存在差异，前次募投项目系新建项目，本次募投项目系对公司所有陶瓷电容式压力传感器产线进行技术升级改造，以提升产线自动化水平，助力公司降本增效、提升产能、优化生产工序、提升产品工艺精度以及产品一致性，因此不存在重复建设的情形；本次募投项目之一的陶瓷电容式压力传感器产线升级项目不存在向产业链上下游扩展的情形。

## （3）力传感器产线建设项目

力传感器产线建设项目与公司前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别、联系及协同如下：

<table><tr><td>产线类别</td><td>力传感器产线建 设项目</td><td>前次募投项目</td><td>区别、联系及协同</td></tr><tr><td>生产产品</td><td>力传感器，具体产 品包括拉压力传 感器、力矩传感 器、六维力传感器</td><td>压力传感器中的陶瓷电容 式压力传感器、温度传感 器； 智能驾驶刹车系统用 （EMB）力传感器； 贴片式NTC 热敏电阻</td><td>同样包含力传感器，但 应用不同，本次募投项 目力传感器主要应用于 机器人领域，但智能驾 驶刹车系统用（EMB） 力传感器主要应用于刹 车系统</td></tr><tr><td>所需原材料</td><td>通常包含五金塑 胶、线材、电子类 材料、封装胶料等</td><td>通常包含五金塑胶、线材、 电子类材料、电极与焊接 类材料、陶瓷玻璃、封装 胶料、套管等</td><td>力传感器所需原材料与 陶瓷电容式压力传感器 大部分相同，部分电子 类材料不同</td></tr><tr><td>应用领域及下 游客户</td><td>工业自动化、机器 人领域及相关领 域客户</td><td>陶瓷电容式压力传感器、 EMB 力传感器主要用于 汽车领域，温度传感器主 要用于家用电器及汽车领 域，贴片式NTC 热敏电 阻主要用于消费电子、汽 车电子、家用电器等领域</td><td>应用领域及下游客户不 同，本次募投项目有助 于公司拓展下游应用及 客户</td></tr><tr><td>主要技术参数</td><td>量程、准确度、轴 间串扰、采样率、 分辨率等</td><td>NTC 热敏电阻、温度传感 器与压力传感器、力传感 器、MEMS 压力传感器芯 片模组技术参数基本不 同； 压力传感器主要技术参数 为量程、准确度、采样率、 分辨率等； EMB 力传感器主要技术 参数包括额定力、最大承 受力、破坏力、精度、功 能安全要求、汽车领域各 项测试要求等</td><td>力传感器与压力传感器 的主要技术参数类似， 其中轴间串扰系力传感 器特有的技术参数，但 两类产品的量程不同， 力传感器主要是测量直 接受力或力矩，其单位 是N(牛顿)或N·M(牛 顿·米），而压力传感 器主要是测量流体力， 是单位面积的受力，其 单位是Pa（帕）； 机器人力传感器与EMB 力传感器因为应用不 同，主要技术参数也存 在差异，EMB力传感器 技术参数重点关注汽车 应用的安全及各项汽车 相关的测试要求</td></tr></table>

综上，本次募投项目之一的力传感器产线建设项目与前次募投项目中的其他产品基本不同，与EMB 力传感器具有联系，亦存在差异，应用不同，有助于公司在产品体系、产品品类方面进行协同，有利于拓展下游应用及客户，不存在重复建设的情形；本次募投项目之一的力传感器产线建设项目不存在向产业链上下游扩展的情形。

## （4）MEMS 传感器芯片研发及产业化项目

MEMS 传感器芯片研发及产业化项目与公司前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别、联系及协同如下：

<table><tr><td rowspan=1 colspan=1>产线类别</td><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>前次募投项目</td><td rowspan=1 colspan=1>区别、联系及协同</td></tr><tr><td rowspan=1 colspan=1>生产产品</td><td rowspan=1 colspan=1>MEMS 压力传感器芯片模组</td><td rowspan=1 colspan=1>压力传感器中的陶瓷电容式压力传感器、温度传感器；智能驾驶刹车系统用（EMB）力传感器；贴片式NTC 热敏电阻</td><td rowspan=3 colspan=1>本次募投项目新增的MEMS压力传感器芯片模组属于向MEMS 压力传感器产业链上游的扩展，有助于公司MEMS 压力传感器芯片模组由原来的外采转变为自主供应为主，可较大程度降低MEMS压力传感器的成本，提升公司盈利能力，增强市场竞争力；有利于确保MEMS压力传感器的质量稳定性与协同性，对公司加快新技术、新产品的产业化落地具有积极意义。因此，本次募投项目之一的MEMS传感器芯片研发及产业化项目向产业链上游扩展具有必要性</td></tr><tr><td rowspan=1 colspan=1>所需原材料</td><td rowspan=1 colspan=1>通常包含五金塑胶、电子类材料、电极与焊接类材料、陶瓷玻璃、封装胶料等</td><td rowspan=1 colspan=1>通常包含五金塑胶、线材、电子类材料、电极与焊接类材料、陶瓷玻璃、封装胶料、套管等</td></tr><tr><td rowspan=1 colspan=1>应用领域及下游客户</td><td rowspan=1 colspan=1>用于发行人内部生产MEMS 压力传感器，不对外销售</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器、EMB力传感器主要用于汽车领域，温度传感器主要用于家用电器及汽车领域，贴片式 NTC 热敏电阻主要用于消费电子、汽车电子、家用电器等领域</td></tr><tr><td rowspan=1 colspan=1>主要技术参数</td><td rowspan=1 colspan=3>MEMS压力传感器芯片模组系生产MEMS压力传感器的原材料，产品、应用及客户与陶瓷电容式压力传感器、温度传感器、EMB力传感器、NTC热敏电阻均存在差异，技术参数亦不同；MEMS 压力传感器芯片模组的技术储备详见下文分析</td></tr></table>

报告期内，公司应用于汽车领域的 MEMS 压力传感器芯片模组为外采，拟通过本次募投项目转变为自主供应为主。

公司本次 MEMS 传感器芯片研发及产业化项目将形成年产约 537.30 万个MEMS 压力传感器芯片模组的产能规模（预计2028 年投产，当年达产率 50%，2030年达产率 100%），预计均将应用于公司 MEMS 压力传感器的生产，占公司 MEMS 压力传感器现有产能约 93.57%，保守预计占 2030 年传感器产量约 76.76%，充分满足公司 MEMS 压力传感器芯片模组对于 MEMS 压力传感器的自产需求。

综上，本次募投项目之一的 MEMS 传感器芯片研发及产业化项目与前次募投项目存在明显差异，不存在重复建设的情形；该项目向产业链上游扩展具有必要性，有助于公司 MEMS 压力传感器芯片模组由原来的外采转变为自主供应为主，可较大程度降低 MEMS 压力传感器的成本，提升公司盈利能力，增强市场竞争力；发行人自研的 MEMS 传感器芯片模组的设计指标参数优于外购模组参数，满足汽车领域 MEMS 压力传感器的应用，具有小尺寸、成本低的优势，其中，MEMS 晶圆设计同时采用多晶硅屏蔽层、 $\mathrm { S i O } _ { 2 }$ 与 SiN 双钝化层，以及铂金或者铝的双金属互联可选，采用自主可控的工艺测试与工艺改进，以满足自身产品的质量要求，有利于确保 MEMS 压力传感器的质量稳定性与协同性，对公司加快新技术、新产品的产业化落地具有积极意义。

3、本次募投项目新产品所需研发技术、所处研发阶段，是否存在试生产环节，并结合发行人具体技术掌握、研发进度、人员和客户储备等情况，说明本次募投项目的实施是否存在重大不确定性，是否符合募集资金投向主业的要求

基于长期的技术积累以及产业化经验，目前，公司已构建了涵盖热敏电阻及温度传感器、陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器、氧传感器、氮氧传感器、力传感器等多层次产品体系，以满足不同市场需求。报告期内，陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器均有规模化的量产销售，因此本次募投项目中的压力传感器扩产项目及陶瓷电容式压力传感器产线升级项目均不涉及新产品；报告期内，发行人持续投入对力传感器的研发，截至目前，力传感器产线建设项目涉及的力传感器产品已有小规模量产销售并取得客户一的批量订单进行批量生产，因此，力传感器产线建设项目不涉及新产品；MEMS 传感器芯片研发及产业化项目所形成的 MEMS 压力传感器芯片模组全部自用于生产 MEMS 压力传感器，不对外销售，该项目已形成相关技术储备及人员储备。

综上，本次募投项目的实施不存在重大不确定性，符合募集资金投向主业的要求。涉及力传感器产线建设项目、MEMS 传感器芯片研发及产业化项目的具体情况如下：

## （1）力传感器产线建设项目

①力传感器建设项目所需研发技术、所处研发阶段等情况

力传感器建设项目所需研发技术、所处研发阶段等情况如下：

<table><tr><td colspan="1" rowspan="1">主要产品</td><td colspan="1" rowspan="1">所需研发技术</td><td colspan="1" rowspan="1">所处研发阶段</td><td colspan="1" rowspan="1">是否存在试生产环节</td></tr><tr><td colspan="1" rowspan="1">拉压力传感器</td><td colspan="1" rowspan="1">CAE 有限元分析技术（模拟」</td><td colspan="1" rowspan="1">左述满足生产相关|</td><td colspan="1" rowspan="1">存在试生产环节且已</td></tr><tr><td colspan="1" rowspan="1">力矩传感器</td><td colspan="1" rowspan="1">设计技术）、弹性体制造技术（热处理技术、表面处理技术）、传感器组装封测技术（应变计及贴片技术或玻璃微熔贴片技术、温度补偿技术、标定校准技术、密封技术等）、软硬件信号处理技术</td><td colspan="1" rowspan="1">技术均已研发完成，均属发行人掌握的具体技术</td><td colspan="1" rowspan="1">完成，可小规模量产及销售，部分客户已取得批量订单进入批量生产阶段，待本次募投建设项目完成后可进行大规模量产</td></tr><tr><td colspan="1" rowspan="1">六维力传感器</td><td colspan="1" rowspan="1">CAE有限元分析技术（模拟设计技术）、弹性体制造技术（热处理技术、表面处理技术）、传感器组装封测技术（应变计及贴片技术或玻璃微熔贴片技术、温度补偿技术、标定校准技术、密封技术等）、软硬件信号处理技术、六维解耦技术（结构结耦、算法解耦)</td><td colspan="1" rowspan="1">金属应变片工艺：左述满足生产相关技术均已研发完成，均属发行人掌握的具体技术MEMS硅基应变片工艺：目前已开发出样机，正在提升精度和量产化工艺阶段</td><td colspan="1" rowspan="1">金属应变片工艺：试生产环节且已完成，可小规模量产，待本次募投建设项目完成后可进行大规模量产MEMS硅基应变片工艺：存在并处于试生产环节</td></tr></table>

②结合发行人具体技术掌握、研发进度、人员和客户储备等情况，说明本次募投项目的实施是否存在重大不确定性，是否符合募集资金投向主业的要求

如前文所述，发行人已掌握生产力传感器的相关技术，包括 CAE 有限元分析技术、弹性体制造技术、传感器组装封测技术等，在此基础上，根据市场发展趋势、下游应用及客户需求变化，发行人持续进行针对不同应用、不同定制化需求的技术研发，主要相关研发项目储备及其研发进度如下：

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">储备研发项目名称</td><td colspan="1" rowspan="1">研发的具体内容</td><td colspan="1" rowspan="1">目前的进展</td><td colspan="1" rowspan="1">当前实验验证情况</td><td colspan="1" rowspan="1">预计取得研发成果</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">钛合金轻量化力传感器</td><td colspan="1" rowspan="1">传感器整机轻量化研发，弹性体采用钛合金材质，实现轻量化和高刚度的均衡</td><td colspan="1" rowspan="1">已完成模拟仿真,弹性体加工已投产,数字采集解耦电路已完成设计</td><td colspan="1" rowspan="1">设计完成，第一版样品制作中</td><td colspan="1" rowspan="1">完成更适合于精确控制及抗冲击强的轻量化六维力传感器</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">高精度高分辨率六维力传感器</td><td colspan="1" rowspan="1">升级研发六维力力学结构、应变片结构、采集电路和解耦算法，提高六维力传感器的分辨率（1/5000）及串扰性能（0.1%），进入医疗、军工、科研等细分领域</td><td colspan="1" rowspan="1">已启动开发，样机制作</td><td colspan="1" rowspan="1">第一版样品制作中</td><td colspan="1" rowspan="1">高分辨率，高精度的六维力传感器</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">MEMS 硅基应变片六维力传感器开发</td><td colspan="1" rowspan="1">用MEMS硅应变片作为应变感应元件制作六维力传感器，解决双面贴片解耦技术和温漂补偿技术。</td><td colspan="1" rowspan="1">已试制出样机，正在性能改进和工艺优化</td><td colspan="1" rowspan="1">第一版样机已验证完成，正在改进</td><td colspan="1" rowspan="1">高刚度、小形变、强抗过载的六维力技术</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">基于 SOI工艺</td><td colspan="1" rowspan="1">研发基于 SOI工艺力传感</td><td colspan="1" rowspan="1">SOI芯片方</td><td colspan="1" rowspan="1">正在设计</td><td colspan="1" rowspan="1">基于 SOI工</td></tr><tr><td></td><td>的力传感器用 硅基芯片开发</td><td>器用硅基芯片并实现最终 量产应用，通过全性能试验 以保证产品的功能和测试， 有完整产品试验报告，各项 指标符合设计要求</td><td>案正在设计</td><td>第一版方 案</td><td>艺力传感器 用硅基芯片 开发完成 后，可提升 硅基力传感 器的性能</td></tr></table>

针对前述研发项目，公司共配备了研发总监1名、项目经理1名、研发经理1名、工艺经理 1名、电子工程师4名、软件工程师4名、机械工程师2名、结构工程师 2名、仿真工程师 2 名、工艺工程师 2名，合计 20 名主要研发人员储备。

除技术储备及人员储备外，发行人亦有较多的客户储备。目前公司力传感器已有相应的客户，部分主要客户如下：

<table><tr><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>应用领域</td><td rowspan=1 colspan=1>销售情况</td></tr><tr><td rowspan=1 colspan=1>客户一</td><td rowspan=1 colspan=1>人形机器人</td><td rowspan=1 colspan=1>批量生产及销售（2026年4月订单约2,000个力传感器）</td></tr><tr><td rowspan=1 colspan=1>客户二</td><td rowspan=1 colspan=1>人形机器人及机器人协作臂</td><td rowspan=1 colspan=1>小规模量产及销售</td></tr><tr><td rowspan=1 colspan=1>客户三</td><td rowspan=1 colspan=1>机器人协作臂</td><td rowspan=1 colspan=1>小规模量产及销售</td></tr><tr><td rowspan=1 colspan=1>客户四</td><td rowspan=1 colspan=1>人形机器人</td><td rowspan=1 colspan=1>试产验证</td></tr><tr><td rowspan=1 colspan=1>客户五</td><td rowspan=1 colspan=1>人形机器人</td><td rowspan=1 colspan=1>试产验证</td></tr><tr><td rowspan=1 colspan=1>客户六</td><td rowspan=1 colspan=1>人形机器人</td><td rowspan=1 colspan=1>试产验证</td></tr><tr><td rowspan=1 colspan=1>客户七</td><td rowspan=1 colspan=1>人形机器人</td><td rowspan=1 colspan=1>试产验证</td></tr></table>

根据工信部、国家发展改革委于 2024 年 1月印发《制造业中试创新发展实施意见》，中试是把处在试制阶段的新产品转化到生产过程的过渡性试验。公司本次力传感器建设项目的力传感器产品为已实现小规模量产及销售且取得部分客户批量订单进入批量生产的产品，不属于上述试制阶段或实验室阶段的新产品，虽不涉及上述“中试”程序，但连续生产及对部分下游客户的连续批量供应状态，表明公司本次力传感器建设项目产品已超过“中试”或同等状态。

综上，发行人在力传感器方面已积累相关技术储备及客户储备，力传感器系发行人传感器产品体系的重要组成部分；力传感器产线建设项目不涉及新产品，力传感器已有小规模量产销售并取得部分客户的批量订单进行批量生产；力传感器建设项目的实施不存在重大不确定性，符合募集资金投向主业的要求。

## （2）MEMS 传感器芯片研发及产业化项目

发行人具备 MEMS 压力传感器芯片模组相关的技术储备及人员储备，目前处于持续投入研发中，MEMS 传感器芯片研发及产业化项目的实施不存在重大不确定性；其系 MEMS 压力传感器向上游的扩展，用于保障原材料自主供应，有利于确保公司主要产品 MEMS 压力传感器的质量稳定性与协同性，符合募集资金投向主业的要求。具体如下：

## ① 发行人具备MEMS 压力传感器芯片模组相关技术储备

MEMS 压力传感器采用类似集成电路的设计技术和制造工艺，核心技术主要体现在硅压阻芯片的设计与制造、封装等。现阶段在汽车领域，公司 MEMS压力传感器使用的硅压阻芯片主要从外部采购，公司正在推进硅压阻芯片自主设计的开发工作。目前，公司主要是在封装环节拥有自主的核心技术，具备实施上述募投项目的技术积累，具体如下：

<table><tr><td rowspan=1 colspan=1>核心工艺环节</td><td rowspan=1 colspan=1>核心技术平台</td><td rowspan=1 colspan=1>核心技术及其技术先进性</td></tr><tr><td rowspan=1 colspan=1>芯片设计</td><td rowspan=1 colspan=1>MEMS 压力芯片设计</td><td rowspan=1 colspan=1>采用基于单层或双层 SOI技术，应用离子注入等工艺构建压阻敏感器件，引入屏蔽层，钝化层，金属互联等结构提高其稳定性与适用性。</td></tr><tr><td rowspan=1 colspan=1>封装</td><td rowspan=1 colspan=1>预塑封封装技术</td><td rowspan=1 colspan=1>1、MEMS压力传感器的芯片基材为硅，如果贴装的基板选择不合适，在温度发生变化时，不同材料热膨胀系数的差异会导致传感器产生温度漂移的现象。由于陶瓷基板与硅材质的热膨胀系数较为接近，将其作为贴装基板是解决低压MEMS传感器温度漂移的市场主流方案。公司凭借多年陶瓷材料应用技术的研究，是国内少数具备自主生产陶瓷基板的传感器企业之一；2、公司自主集成开发带有MEMS 系统的全自动封装、标定、组装生产线，特别在自动标定环节，采用特殊的驱潮技术，解决产品进入低温区结霜结冰进而导致产品接触不良的问题，极大提高生产效率。</td></tr></table>

②公司 MEMS 压力传感器芯片模组部分技术的研发进度及人员储备情况

公司MEMS 压力传感器芯片模组部分技术的研发进度及人员储备情况如下：

<table><tr><td>序 号</td><td>储备研发项目 名称</td><td>研发的具体内容</td><td>目前的进展</td><td>现有核心技术 人员储备情况</td></tr><tr><td>1</td><td>MEMS压力传 感器感压芯片 研发（绝压）</td><td>研发用于汽车以及消费类电子用 MEMS 绝压感压芯体，实现0-5bar 气压的测量，其中汽车用产品使用铂 金工艺实现耐腐蚀要求</td><td>设计完成,工 艺仿真完成</td><td rowspan="2">现有研发人员 5人，并将通过 招聘逐步构建 形成7个人的 研发团队</td></tr><tr><td>2</td><td>MEMS压力传</td><td>沿用汽车以及消费类电子用MEMS</td><td>设计完成，工</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">感器感压芯片研发（表压）</td><td colspan="1" rowspan="1">表压感压芯体，实现0-5bar气压的测量，其中汽车用产品使用铂金工艺实现耐腐蚀要求</td><td colspan="1" rowspan="1">艺仿真完成</td><td colspan="1" rowspan="3"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">MEMS三轴加速感应芯片</td><td colspan="1" rowspan="1">研发用于汽车以及工业领域用MEMS 三轴加速度感应芯片，量程覆盖±2g，±4g，±6g，±8g，±12g，±16g.用于公司加速度传感器的研发与生产</td><td colspan="1" rowspan="1">设计完成，工艺仿真进行中</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">MEMS三轴陀螺仪感应芯片</td><td colspan="1" rowspan="1">研发用于汽车以及工业领域用MEMS三轴陀螺仪感应芯片。量程覆盖±100%s 至 ±400%s。用于公司加陀螺仪的研发与生产</td><td colspan="1" rowspan="1">项目可行性分析完成，设计预研中</td></tr></table>

（二）说明项目四将传感器所用芯片从对外采购转为自行研发生产的原因及合理性；结合现有陶瓷压力传感器产线的使用情况、项目二的具体升级内容、是否涉及前次募投项目所投入设备，说明在前次募投项目建成时间较短的情况下对产线进行升级的原因及合理性，说明本次募投项目的实施是否具有必要性

## 1、将传感器所用芯片从对外采购转为自行研发生产的原因及合理性

MEMS 传感器芯片研发及产业化项目形成的MEMS压力传感器芯片模组产能全部用于自供，可充分满足公司 MEMS 压力传感器芯片模组对于MEMS 压力传感器的自产需求。

（1）将传感器所用芯片从对外采购转为自行研发生产可较大程度降低MEMS 压力传感器的生产成本，提升公司盈利能力

公司 MEMS 压力传感器芯片模组由原来的外采转变为自主供应为主，可较大程度降低 MEMS 压力传感器的生产成本，提升公司盈利能力，增强市场竞争力。

参考市场价格（即本募投项目各产品预计平均单价），测算假设本项目建成后将会减少的芯片模组采购金额（即下表中节约的营业成本）。本项目实施后净节约营业成本情况已申请豁免披露。

对于上市公司整体而言，原本由外部 MEMS 压力传感器芯片模组供应商享有的净利润将留存在上市公司体内，即上表中所述的“净节约的生产成本”，根据测算，将传感器所用芯片从对外采购转为自行研发生产可较大程度降低MEMS压力传感器的生产成本。

## （2）自行研发生产 MEMS 芯片模组有利于公司产品质量稳定性

在下游应用场景逐渐丰富与 MEMS 压力传感器技术不断革新的背景下，自行研发生产MEMS 芯片模组建设有利于确保MEMS 压力传感器的质量稳定性，对公司加快新技术、新产品的产业化落地具有积极意义。

发行人 MEMS 传感器芯片研发及产业化项目的设计指标参数主要对标国际先进水平，满足汽车领域 MEMS 压力传感器的应用，具有小尺寸、成本低的优势。其中，MEMS 晶圆设计同时采用多晶硅屏蔽层、 $\mathrm { S i O } _ { 2 }$ 与 SiN 双钝化层，以及铂金或者铝的双金属互联可选，采用自主可控的工艺测试与工艺改进，以满足自身产品的质量要求。发行人自产 MEMS 芯片模组与外购模组具体指标参数比较如下：

<table><tr><td rowspan=2 colspan=1>指标</td><td rowspan=1 colspan=2>自产参数</td><td rowspan=1 colspan=2>外购参数</td><td rowspan=2 colspan=1>单位</td><td rowspan=2 colspan=1>主要优势</td></tr><tr><td rowspan=1 colspan=1>最小</td><td rowspan=1 colspan=1>最大</td><td rowspan=1 colspan=1>最小</td><td rowspan=1 colspan=1>最大</td></tr><tr><td rowspan=1 colspan=1>尺寸</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>0.8x0.8</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1x1</td><td rowspan=1 colspan=1>mm</td><td rowspan=1 colspan=1>国内现有供应商的尺寸主要是1x1，自产尺寸优于外购参数</td></tr><tr><td rowspan=1 colspan=1>额定压力</td><td rowspan=1 colspan=1>200</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>200</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>kPa</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>满量程输出，S</td><td rowspan=1 colspan=1>40</td><td rowspan=1 colspan=1>50</td><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>30</td><td rowspan=1 colspan=1>mV/V</td><td rowspan=1 colspan=1>灵敏度优于外购模组</td></tr><tr><td rowspan=1 colspan=1>桥组</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>kΩ</td><td rowspan=1 colspan=1>:</td></tr><tr><td rowspan=1 colspan=1>压力非线性，NL</td><td rowspan=1 colspan=1>-0.4</td><td rowspan=1 colspan=1>0.4</td><td rowspan=1 colspan=1>-0.5</td><td rowspan=1 colspan=1>0.5</td><td rowspan=1 colspan=1>%FS</td><td rowspan=1 colspan=1>线性程度优于外购模组</td></tr><tr><td rowspan=1 colspan=1>零点漂移，0</td><td rowspan=1 colspan=1>-10</td><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>-35</td><td rowspan=1 colspan=1>35</td><td rowspan=1 colspan=1>mV/V</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>量程温度系数，TCS</td><td rowspan=1 colspan=1>-0.24</td><td rowspan=1 colspan=1>-0.11</td><td rowspan=1 colspan=1>-0.24</td><td rowspan=1 colspan=1>0.155</td><td rowspan=1 colspan=1>%FS/C</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>偏移温度系数，TCO</td><td rowspan=1 colspan=1>-0.04</td><td rowspan=1 colspan=1>0.04</td><td rowspan=1 colspan=1>-0.07</td><td rowspan=1 colspan=1>0.07</td><td rowspan=1 colspan=1>%FS/C</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>桥路电阻温度系数，TCR</td><td rowspan=1 colspan=1>0.3</td><td rowspan=1 colspan=1>0.4</td><td rowspan=1 colspan=1>0.18</td><td rowspan=1 colspan=1>0.33</td><td rowspan=1 colspan=1>%FS/C</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>桥路电阻压力系数，PCR</td><td rowspan=1 colspan=1>-2</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>-2</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>%</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>共模电压</td><td rowspan=1 colspan=1>46</td><td rowspan=1 colspan=1>54</td><td rowspan=1 colspan=1>45</td><td rowspan=1 colspan=1>55</td><td rowspan=1 colspan=1>%</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>供电电压</td><td rowspan=1 colspan=1>0</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>工作温度单 SOI/双SOI</td><td rowspan=1 colspan=1>-40</td><td rowspan=1 colspan=1>150/200</td><td rowspan=1 colspan=1>-40</td><td rowspan=1 colspan=1>150</td><td rowspan=1 colspan=1>℃</td><td rowspan=1 colspan=1>最大工作温度优于外购模组</td></tr><tr><td rowspan=1 colspan=1>存储温度</td><td rowspan=1 colspan=1>-55</td><td rowspan=1 colspan=1>175/200</td><td rowspan=1 colspan=1>-55</td><td rowspan=1 colspan=1>150</td><td rowspan=1 colspan=1>℃</td><td rowspan=1 colspan=1>最大存储温度优于外购模组</td></tr><tr><td rowspan=1 colspan=1>耐压</td><td rowspan=1 colspan=1>500</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>kPa</td><td rowspan=1 colspan=1>最小耐压优于外购模组</td></tr><tr><td rowspan=1 colspan=1>爆破压</td><td rowspan=1 colspan=1>900</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>800</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>kPa</td><td rowspan=1 colspan=1>最小爆破压优于外购模组</td></tr></table>

从参数指标角度，发行人 MEMS 芯片模组设计指标参数在尺寸、满量程输出等多个关键参数方面优于目前外购模组参数，有利于公司产品质量稳定性。

（3）将 MEMS 传感器所用芯片从对外采购转为自行研发生产符合产业趋势

公司 MEMS 压力传感器芯片模组由原来的外采转变为自主供应为主，实现产业链的向上延伸，符合传感器行业趋势，如华培动力、士兰微、康斯特等企业都有相关公告其在传感器领域做垂直产业链的规划和目标。

<table><tr><td rowspan=1 colspan=1>公司</td><td rowspan=1 colspan=1>传感器相关主营业务/产品</td><td rowspan=1 colspan=1>披露信息</td></tr><tr><td rowspan=1 colspan=1>华培动力</td><td rowspan=1 colspan=1>主要产品涵盖全压力量程范围的压力传感器、速度位置传感器、温度传感器、尿素品质传感器等多品类传感器及部分核心芯片</td><td rowspan=1 colspan=1>公司通过设立全资子公司盛美芯和参股中科阿尔法两家芯片设计公司，使得公司具备部分核心车规级芯片的自主设计、封装测试的能力，可为公司目前已批量生产的MEMS压力传感器、速度位置传感器等产品精准提供车规级的核心敏感芯片，为公司的传感器降本增效的同时保证产品质量,增强了公司在客户端的核心竞争力。报告期内，盛美芯已完成多款车规级MEMS芯片的设计流片，成功投产的封装测试产线,为公司传感器产品的规模化生产提供了强有力的支撑。</td></tr><tr><td rowspan=1 colspan=1>士兰微</td><td rowspan=1 colspan=1>MEMS 传感器</td><td rowspan=1 colspan=1>士兰集昕正在加快推进8英寸 MEMS 传感器芯片制造能力的提升</td></tr><tr><td rowspan=1 colspan=1>康斯特</td><td rowspan=1 colspan=1>高端检测仪器仪表</td><td rowspan=1 colspan=1>公司高端压力传感器采用硅压阻技术路线，综合指标优于0.01%F.S。目前正在按计划分阶段实现国产化，后续会根据传感器的量产进度推进芯片自主</td></tr></table>

综上，发行人 MEMS 芯片模组由对外采购转为自行研发生产有利于降低MEMS 压力传感器的生产成本，提升公司盈利能力，增强市场竞争力，同时有利于确保 MEMS 压力传感器的质量稳定性与协同性，符合行业发展趋势，具备合理性。

2、项目二的具体升级内容、是否涉及前次募投项目所投入设备，说明在前次募投项目建成时间较短的情况下对产线进行升级的原因及合理性，说明本次募投项目的实施是否具有必要性

## （1）现有陶瓷压力传感器产线的使用情况

2024 年以来，发行人陶瓷电容式压力传感器产能利用率保持在较高水平。报告期内，发行人陶瓷电容式压力传感器产能利用率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>单位</td><td rowspan=1 colspan=3>2025年度</td><td rowspan=1 colspan=3>2024年度</td><td rowspan=1 colspan=3>2023年度</td></tr><tr><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器</td><td rowspan=1 colspan=1>万个</td><td rowspan=1 colspan=1>2,108.87</td><td rowspan=1 colspan=1>2,245.32</td><td rowspan=1 colspan=1>93.92%</td><td rowspan=1 colspan=1>1,589.59</td><td rowspan=1 colspan=1>1,995.84</td><td rowspan=1 colspan=1>79.65%</td><td rowspan=1 colspan=1>1,005.53</td><td rowspan=1 colspan=1>1,605.24</td><td rowspan=1 colspan=1>62.64%</td></tr></table>

2023 年，公司陶瓷电容式压力传感器产能利用率下滑，主要系其为 IPO 募投项目之一，于2023 年度开始投产，产能由2022 年度的791.68 万个提升至2023年度的 1,605.24 万个，产能逐步爬坡，因此，自 2023 年度后，压力传感器产能利用率逐步提升。报告期内，公司陶瓷电容式压力传感器不断斩获国内外知名汽车主机厂及一级零部件供应商的重要客户新项目定点以及订单，新客户新项目主要涉及飞行汽车热管理系统、新能源汽车及燃油汽车热泵系统、空调管路系统、发动机系统、变速箱系统，商用车刹车系统、商用车冷却机组系统，储能系统，氢燃料电池系统等领域，基本实现了国内主流自主品牌主机厂及造车新势力的全覆盖，进一步夯实了市场基础及行业地位。凭借强大的研发技术能力以及广泛的市场影响力，公司陶瓷电容式压力传感器产品获得深圳市工业和信息化局评选的第二批“制造业单项冠军企业”荣誉。报告期内，公司陶瓷电容式压力传感器除在汽车应用领域继续取得高速增长外，在商用空调以及储能领域均取得较大突破。因此，2023 年至今，公司陶瓷电容式压力传感器产能利用率不断提升。

## （2）项目二的具体升级内容、是否涉及前次募投项目所投入设备

项目二“陶瓷电容式压力传感器产线升级项目”将对现有 13 条陶瓷电容式压力传感器产线进行技术升级改造（其中2 条为配套线），提升公司现有产线的标准化及自动化程度，助力公司扩充产能、降本增效、优化生产工序、提升产品工艺精度。具体升级改造内容为：

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">升级改造内容</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">1号产线升级改造：开发新手工标定设备</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">2号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">3号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">4号产线升级改造：检测测试环节升级</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">5 号产线升级改造：检测测试环节升级</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">6号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">7号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">8号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">9号产线升级改造：后段自动化升级</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">11号产线升级改造：检测测试环节升级</td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">T1产线升级改造：铆接、氮检升级改造</td></tr><tr><td colspan="1" rowspan="1">12</td><td colspan="1" rowspan="1">精度测试线升级改造：自动化升级</td></tr><tr><td colspan="1" rowspan="1">13</td><td colspan="1" rowspan="1">电容产线升级改造：自动化升级</td></tr></table>

本次募投升级涉及的新增设备主要包括手工标定设备、功能测试设备、氦检测试设备、点胶设备、终检设备等。本次募投项目主要集中于后段自动化的升级改造，包括工序精简及结构优化，不涉及前段产线部分。同时本项目涉及对前次募投所投入少量设备拆除，主要涉及振动测试机设备（账面原值约210 万元，账面净值约为153 万元），该部分设备拆除后将作为产线补充测试设备使用。

（3）说明在前次募投项目建成时间较短的情况下对产线进行升级的原因及合理性，说明本次募投项目的实施是否具有必要性

本次升级涉及的陶瓷电容式压力传感器产线自 2021 年开始投建，自动化程度有限，本次升级有利于提升产线自动化水平，进一步扩充产能，实现降本增效，提升公司盈利能力，具有合理性和必要性。具体如下：

①原陶瓷电容式压力传感器产线自 2021 年开始投建，本次升级顺应行业发展趋势，有利于提升产线自动化水平

此次升级改造虽涉及部分 IPO 募投项目，但前次 IPO 募投项目相关产线自2021 年已开始陆续建设，在发行人上市之后完成相关募集资金置换。该部分产线自动化程度有限，而传感器所在行业技术发展较快，精益制造能力快速迭代，对陶瓷电容式压力传感器产线进行升级具有合理性。

同时，随着发行人不断拓展业务领域和优质客户，部分下游优质客户如特斯拉对发行人产线的精益生产和自动化要求较高，为应对行业发展趋势，发行人对陶瓷电容式压力传感器产线进行升级具有必要性。

②本次升级改造有利于公司进一步扩充产能，简化生产工序，实现显著降本

“陶瓷电容式压力传感器产线升级项目”一方面能够进一步扩充发行人产能，

亦可以实现降本增效，长远看有利于提升公司盈利能力。具体的升级改造包括：

a.“穿孔式”结构：在陶瓷电容式压力传感器的陶瓷基体上直接打孔，使热敏电阻引线穿过，省去柔性电路板、转接件及多个密封圈；

b.“鱼眼”连接端子：替代传统插针，实现免焊接直插PCB。上述改进大幅简化生产工序，节省人工，自动化水平显著提升，且产品因省去焊接、折弯及部分结构件，整体降本成果显著。

根据测算，本次升级改造后每年可节省人工费用超1,000 万元，产线技改前后对比如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>产线情况</td><td rowspan=1 colspan=1>技改前UPH（个/小时）</td><td rowspan=1 colspan=1>技改后UPH（个/小时）</td><td rowspan=1 colspan=1>技改前单线配置人员</td><td rowspan=1 colspan=1>技改后单线配置人员</td><td rowspan=1 colspan=1>人均薪酬（万元/月）</td><td rowspan=1 colspan=1>技改后节省薪酬（万元/年）</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1号产线升级改造：开发新手工标定设备</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>50</td><td rowspan=1 colspan=1>46</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>33.60</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>2号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>38</td><td rowspan=1 colspan=1>26</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>100.80</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>3号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>58</td><td rowspan=1 colspan=1>50</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>67.20</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>4号产线升级改造：检测测试环节升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>38</td><td rowspan=1 colspan=1>36</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>16.80</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>5号产线升级改造：检测测试环节升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>38</td><td rowspan=1 colspan=1>36</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>16.80</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>6号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>36</td><td rowspan=1 colspan=1>22</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>117.60</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>7号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>38</td><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>151.20</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>8号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>56</td><td rowspan=1 colspan=1>42</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>117.60</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>9号产线升级改造：后段自动化升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>48</td><td rowspan=1 colspan=1>30</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>151.20</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>11号产线升级改造：检测测试环节升级</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>26</td><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>50.40</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>T1产线升级改造：铆接、氮检升级改造</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>33</td><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>109.20</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>精度测试线升级改造：自动化升级</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>87</td><td rowspan=1 colspan=1>47</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>336.00</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>电容产线升级改造：自动化升级</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>169</td><td rowspan=1 colspan=1>102</td><td rowspan=1 colspan=1>0.70</td><td rowspan=1 colspan=1>562.80</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>715</td><td rowspan=1 colspan=1>497</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1,831.20</td></tr></table>

注 1：12-13 号线系配套产线，不增加产能，其中精度测试线主要是对压力传感器进行标定后的不同温度和压力条件下的精度进行检测；电容产线为陶瓷电容式压力传感器全自动组装线提供陶瓷芯体，属于该自动线的前道工序；

注 2：UPH，units per hour：每小时产量，主要用于衡量生产线、设备或系统在单位时

间内的生产能力,是评估生产效率的核心指标。

综上所述，“陶瓷电容式压力传感器产线升级项目”实施有利于提升产线自动化水平，并进一步扩充产能、实现降本增效，因此具备合理性和必要性。

（三）分项目结合产品构成、销量及销售价格、成本、毛利率、净利润的具体计算过程及相关关键参数的选取，说明在报告期内发行人毛利率呈下降趋势的情况下项目一、项目二、项目三预计毛利率高于发行人现有业务毛利率的原因及合理性，项目四内部收益率是否与同行业可比公司情况相符，效益测算是否谨慎、合理，是否与公司现有同类业务及同行业可比公司情况存在较大差异

## 1、项目一效益测算谨慎、合理，与公司现有同类业务及同行业可比公司情况未存在较大差异

压力传感器扩产项目建成达产后，预估年营业收入 80,951.72 万元，达产年净利润 7,246.39 万元，综合毛利率为 30.86%，净利率为 8.95%。项目预计税后内部收益率为 15.24%，税后静态投资回收期为 7.94 年。项目效益预测的假设条件及主要计算过程如下：

## （1）项目效益测算过程，产品单价和销量数据的合理性

本项目中，陶瓷电容式压力传感器、MEMS 压力传感器产品销售单价参照最近三年市场供货价格平均值估算；玻璃微熔压力传感器暂未大规模量产，因此参考主要客户定点报价。同时，上述产品在保持谨慎性的情况下考虑价格有所下降，至达产年后保持价格稳定。

发行人应用于汽车行业的压力传感器产品（包括陶瓷电容式压力传感器产线升级项目涉及的陶瓷电容式压力传感器）相关价格降幅已考虑汽车零部件行业常见的降价因素。一方面，传感器在终端整车价值量占比较低，通常情况下整车厂商并未对传感器产品提出明确的年降政策要求，每年年末或次年初，主要客户会提出下年产品年降的预期目标，发行人结合原材料价格变动情况、产品的业务量等因素综合评估产品年降的可行性以及可年降幅度，并与客户进行协商确定年降比例，年降比例也是衡量发行人对客户的议价能力的体现；另一方面，年降通常针对新量产的产品，量产后第一年是年降第一个节点，年降周期一般在3年左右，发行人本次扩产的以陶瓷电容式压力传感器为主的压力传感器已是成熟、稳定的产品，但基于谨慎性考虑，进行效益预测时于产能爬坡阶段考虑了年降因素，稳定期后价格趋于稳定。

在进行效益测算及销量预测时，发行人将产能释放进度与行业未来市场需求、客户开拓的进度结合。本项目建设期2年，分两期投产。第一期于T+2 年投产，产能利用率为 80%，期间处于产能提升阶段并逐渐放量，于 T+3 年产能利用率为 100%；第二期于 T+3 年投产，产能利用率为 80%，于 T+4 年产能利用率为100%。此外，本项目假设投产产能当年都能进行销售，项目销量、产能爬坡、效益预测具有谨慎性和合理性。

<table><tr><td rowspan=1 colspan=1>产品类型</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1年</td><td rowspan=1 colspan=1>T+2年</td><td rowspan=1 colspan=1>T+3年</td><td rowspan=1 colspan=1>T4 年-T10年各年</td></tr><tr><td rowspan=3 colspan=1>陶瓷电容式压力传感器-压力传感器</td><td rowspan=1 colspan=1>营收 （万元）</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>7,849.64</td><td rowspan=1 colspan=1>16,778.60</td><td rowspan=1 colspan=1>15,939.67</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量（万个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=3 colspan=1>陶瓷电容式压力传感器-温度压力传感器</td><td rowspan=1 colspan=1>营收 （万元）</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>10,011.13</td><td rowspan=1 colspan=1>21,398.80</td><td rowspan=1 colspan=1>25,975.76</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量（万个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=3 colspan=1>MEMS 压力传感器</td><td rowspan=1 colspan=1>营收 （万元）</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>11,369.39</td><td rowspan=1 colspan=1>24,302.08</td><td rowspan=1 colspan=1>25,652.19</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量（万个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=3 colspan=1>玻璃微熔压力传感器</td><td rowspan=1 colspan=1>营收（万元）</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>5,574.38</td><td rowspan=1 colspan=1>12,291.51</td><td rowspan=1 colspan=1>13,384.09</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个)</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量(万个)</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=2>合计收入(万元)</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>34,804.55</td><td rowspan=1 colspan=1>74,770.99</td><td rowspan=1 colspan=1>80,951.72</td></tr></table>

## （2）项目成本费用估算及其谨慎性、合理性

本项目成本费用测算主要包括营业成本、销售费用、管理费用和研发费用等。

## ①营业成本

营业成本主要包括原材料、直接人工、制造费用、委外费用。A、直接原材料成本主要结合项目产品的计划BOM 成本及材料价格变动趋势进行预计，进入稳定期后保持不变。B、直接人工费用根据发行人同类人员薪资水平和本项目所需的生产人员人数进行估算。C、制造费用主要为折旧摊销费用，折旧摊销费用系根据本项目固定资产投入及发行人现有折旧政策进行测算。D、委外成本主要结合项目产品的计划 BOM 成本及变动趋势进行预计，进入稳定期后保持不变。

本项目达产年的成本结构与公司报告期成本结构比对如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=4>成本结构</td></tr><tr><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>本次募投项目</td></tr><tr><td rowspan=1 colspan=1>直接材料</td><td rowspan=1 colspan=1>57.24%</td><td rowspan=1 colspan=1>58.18%</td><td rowspan=1 colspan=1>59.20%</td><td rowspan=1 colspan=1>68.42%</td></tr><tr><td rowspan=1 colspan=1>直接人工</td><td rowspan=1 colspan=1>17.14%</td><td rowspan=1 colspan=1>15.30%</td><td rowspan=1 colspan=1>12. 63%</td><td rowspan=1 colspan=1>7.44%</td></tr><tr><td rowspan=1 colspan=1>制造费用</td><td rowspan=1 colspan=1>16.93%</td><td rowspan=1 colspan=1>15.85%</td><td rowspan=1 colspan=1>15.52%</td><td rowspan=1 colspan=1>17.53%</td></tr><tr><td rowspan=1 colspan=1>委外加工费</td><td rowspan=1 colspan=1>7.24%</td><td rowspan=1 colspan=1>8.77%</td><td rowspan=1 colspan=1>10. 11%</td><td rowspan=1 colspan=1>6.61%</td></tr></table>

由上表可知，本次募投项目中直接材料、制造费用占比高于报告期，直接人工占比低于报告期，主要原因系为：一方面，募投项目中引入的生产设备自动化程度更高，节约了人工，平均单位成本中直接人工占比下降、制造费用占比提升；另一方面，募投项目规划的UPH 产能（由每小时产量300 个大幅提升至400 个）占比高于报告期，单个产品的人工占比进一步下降、制造费用占比略有下滑。综合两个因素，直接人工占比下降较多，制造费用占比略有提升。

## ②期间费用

本项目建成投产后涉及的期间费用主要是销售费用、管理费用、研发费用及财务费用。销售费用、管理费用、研发费用金额参考公司2022 至2024 年各项费用构成占当期营业收入比重的平均值进行估算。本项目假设考虑债务融资为前提，计算财务费用。2022 至2024 年，公司销售费用、管理费用、研发费用费率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>费用占营业收入比例</td><td rowspan=2 colspan=1>均值</td><td rowspan=2 colspan=1>项目取值</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>2.99%</td><td rowspan=1 colspan=1>2.47%</td><td rowspan=1 colspan=1>2.55%</td><td rowspan=1 colspan=1>2.67%</td><td rowspan=1 colspan=1>2.67%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>8.60%</td><td rowspan=1 colspan=1>8.11%</td><td rowspan=1 colspan=1>9.54%</td><td rowspan=1 colspan=1>8.76%</td><td rowspan=1 colspan=1>8.76%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>6.59%</td><td rowspan=1 colspan=1>6.36%</td><td rowspan=1 colspan=1>6.66%</td><td rowspan=1 colspan=1>6.54%</td><td rowspan=1 colspan=1>6.54%</td></tr></table>

成本费用估算主要采用全要素法，结合产品实际成本构成和费用发生情况进行预测，具有合理性，相对谨慎。

## （3）项目毛利率情况

本项目达产后，毛利率为 30.86%，与公司报告期相比，不存在显著差异；由于同业上市公司的产品结构不同，部分公司差异较大，具有合理性。整体上，本项目收入和成本的预测符合公司和行业发展的实际情况，毛利率水平处于合理水平。

项目一建设内容为压力传感器，公司压力传感器主要可比公司为境外公司森萨塔、境内公司苏奥传感和保隆科技。2023-2025 年，压力传感器同行业可比上市公司主营业务毛利率情况如下：

<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>森萨塔</td><td rowspan=1 colspan=1>29. 27%</td><td rowspan=1 colspan=1>29.39%</td><td rowspan=1 colspan=1>31. 11%</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>19. 28%</td><td rowspan=1 colspan=1>22.76%</td><td rowspan=1 colspan=1>14.90%</td></tr><tr><td rowspan=1 colspan=1>保隆科技</td><td rowspan=1 colspan=1>17. 55%</td><td rowspan=1 colspan=1>17.10%</td><td rowspan=1 colspan=1>20.67%</td></tr><tr><td rowspan=1 colspan=1>项目一毛利率</td><td rowspan=1 colspan=3>30.86%</td></tr></table>

注：可比公司毛利率分别选取其可比业务毛利率。其中苏奥传感数据为根据其年报数据计算的传感器及配件类产品的毛利率；保隆科技数据为根据其年报数据计算的传感器类产品的毛利率。

公司项目一毛利率与可比公司对比情况具体如下：

①项目一毛利率与森萨塔接近。森萨塔主营传感器及解决方案业务，压力传感器是其重要的产品，其是全球最大的陶瓷电容式压力传感器厂商，是公司在压力传感器领域最主要的竞争对手。项目一产品结构与森萨塔接近，因此，项目一毛利率与森萨塔 2023-2025年毛利率较为接近，具有合理性。

②项目一毛利率与苏奥传感和保隆科技有差异，主要系产品结构不同。苏奥传感的传感器及配件类产品主要为液位传感器、压力传感器、排温传感器等，其中液位传感器是其发展最早的产品，收入占比较高，其产品结构与项目一有明显差异。保隆科技的传感器产品包括压力、光雨量、速度、位置、加速度和电流类等传感器，种类较多，产品结构与项目一差异较大。由于产品结构存在明显差异，公司项目一的毛利率与苏奥传感的传感器及配件类产品毛利率、保隆科技的传感器类产品毛利率相比有一定差异，具有合理性。

（4）项目一预计毛利率高于发行人现有业务毛利率的原因及合理性

报告期内，发行人压力传感器毛利率及变动情况如下：

<table><tr><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td></tr><tr><td rowspan=1 colspan=1>29. 25%</td><td rowspan=1 colspan=1>-2. 36</td><td rowspan=1 colspan=1>31.61%</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>30.81%</td></tr></table>

2025 年，发行人压力传感器毛利率较上一年度下降 2.36个百分点，主要系压力传感器主要产品价格下调（其中一主要客户 2024 年提出的年降要求较高所影响，但该年度的年降因素具有特殊性，预计不是长期持续的）和五金零件、金浆等主要原材料价格随市场价格上涨而上涨所致，对前三季度尤其是上半年的压力传感器毛利率影响较大。

此外，发行人本次压力传感器产线建设项目将提升自动化、提高生产效率，能够很好的降本增效，从成本端保障产品毛利率的稳定。

综上，发行人 2025 年毛利率的下滑主要是受客户端及上游原材料端短期波动影响，上述因素预计不会长期持续，叠加新产线带来的降本增效，本次压力传感器产线建设项目预计将能够保持略优于 2025 年的毛利率水平，该预估具有可实现性及合理性。

## （5）项目效益与现有同类业务及同行业可比公司情况

对于项目内部收益率和投资回收期的测算，均为基于现金流入和流出而进行的测算。本项目税后内部收益率为 15.24%，静态投资回收期为 7.94 年（税后，含建设期）。本项目与同行业公司募投项目内部收益率、投资回收期的对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>融资类型</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>建设期(年)</td><td rowspan=1 colspan=1>内部收益率</td><td rowspan=1 colspan=1>回收期（税后）(年）</td></tr><tr><td rowspan=1 colspan=1>安培龙</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>项目一</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>15.24%</td><td rowspan=1 colspan=1>7.94</td></tr><tr><td rowspan=1 colspan=1>华工科技</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>物联网用新型传感器产业化项目</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>18.87%</td><td rowspan=1 colspan=1>6.47</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>汽车传感器产品智能化生产线建设项目</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>18.25%</td><td rowspan=1 colspan=1>6.36</td></tr><tr><td rowspan=1 colspan=3>平均</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>18.56%</td><td rowspan=1 colspan=1>6.42</td></tr></table>

注：开特股份、保隆科技未有公开的传感器项目相关数据。

由上表可知，本项目的内部收益率低于同行业可比上市公司，投资回收期高于同行业可比上市公司，效益测算水平略有不同系不同公司产品结构差异所致，符合行业特征，效益测算合理。

## 2、项目二效益测算谨慎、合理，与公司现有同类业务及同行业可比公司情况未存在较大差异

陶瓷电容式压力传感器产线升级项目建成达产后，预估年营业收入19,211.24万元，年净利润2,619.34 万元，综合毛利率为36.41%，净利率为13.63%。项目预计税后内部收益率为 21.12%，税后静态投资回收期为6.41 年。项目效益预测的假设条件及主要计算过程如下：

## （1）项目效益测算过程，产品单价和销量数据的合理性

本项目中，陶瓷电容式压力传感器产品销售单价参照最近三年市场供货价格平均值估算。同时，产品在保持谨慎性的情况下考虑汽车年降政策等因素影响价格有所下降（每年5%降幅），至达产年后保持价格稳定。

在进行效益测算及销量预测时，发行人将产能释放进度与产线技改的进度相结合。本项目建设期 2 年，分两期对产线进行技术升级改造。第一期产线改造后于 T+2 年投产，产能利用率为 80%，期间处于产能提升阶段并逐渐放量，于T+3年产能利用率为100%；第二期产线改造于T+3 年投产，产能利用率为80%，于T+4 年产能利用率为 100%。此外，本项目假设技改后产线投产新增产能当年都能进行销售，新增产能 686.07 万个/年。项目销量、产能爬坡、效益预测具有谨慎性和合理性。

<table><tr><td rowspan=1 colspan=1>产品类型</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>T+1年</td><td rowspan=1 colspan=1>T+2年</td><td rowspan=1 colspan=1>T+3年</td><td rowspan=1 colspan=1>T4年-T10年各年</td></tr><tr><td rowspan=3 colspan=1>陶瓷电容式压力传感器-压力传感器</td><td rowspan=1 colspan=1>营收 （万元）</td><td rowspan=1 colspan=1>：</td><td rowspan=1 colspan=1>6,312.09</td><td rowspan=1 colspan=1>7,923.23</td><td rowspan=1 colspan=1>7,305.68</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量(万个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=3 colspan=1>陶瓷电容式压力传感器-温度压力传感器</td><td rowspan=1 colspan=1>营收（万元）</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>6,174.15</td><td rowspan=1 colspan=1>10,104.99</td><td rowspan=1 colspan=1>11,905.56</td></tr><tr><td rowspan=1 colspan=1>未税单价（元/个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=1>数量（万个）</td><td rowspan=1 colspan=4>已申请豁免披露</td></tr><tr><td rowspan=1 colspan=2>合计收入 (万元)</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>12,486.25</td><td rowspan=1 colspan=1>18,028.22</td><td rowspan=1 colspan=1>19,211.24</td></tr></table>

## （2）项目成本费用估算及其谨慎性、合理性

本项目成本费用测算主要包括营业成本、销售费用、管理费用和研发费用等。

①营业成本

营业成本主要包括原材料、直接人工、制造费用、委外费用。A、直接原材料成本主要结合项目产品的计划BOM 成本及材料价格变动趋势进行预计，进入稳定期后保持不变。B、直接人工费用根据发行人同类人员薪资水平和本项目所需的生产人员人数进行估算。C、制造费用主要为折旧摊销费用，折旧摊销费用系根据本项目固定资产投入及发行人现有折旧政策进行测算。D、委外成本主要结合项目产品的计划BOM 成本及变动趋势进行预计，进入稳定期后保持不变。

本项目达产年的成本结构与公司报告期成本结构比对如下：
<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=4>成本结构</td></tr><tr><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>本次募投项目</td></tr><tr><td rowspan=1 colspan=1>直接材料</td><td rowspan=1 colspan=1>57.24%</td><td rowspan=1 colspan=1>58.18%</td><td rowspan=1 colspan=1>59.20%</td><td rowspan=1 colspan=1>68.42%</td></tr><tr><td rowspan=1 colspan=1>直接人工</td><td rowspan=1 colspan=1>17.14%</td><td rowspan=1 colspan=1>15.30%</td><td rowspan=1 colspan=1>12. 63%</td><td rowspan=1 colspan=1>7.44%</td></tr><tr><td rowspan=1 colspan=1>制造费用</td><td rowspan=1 colspan=1>16.93%</td><td rowspan=1 colspan=1>15.85%</td><td rowspan=1 colspan=1>15. 52%</td><td rowspan=1 colspan=1>17.53%</td></tr><tr><td rowspan=1 colspan=1>委外加工费</td><td rowspan=1 colspan=1>7.24%</td><td rowspan=1 colspan=1>8.77%</td><td rowspan=1 colspan=1>10. 11%</td><td rowspan=1 colspan=1>6.61%</td></tr></table>

由上表可知，本次募投项目中直接材料占比高于报告期，直接人工、制造费用占比低于报告期，主要原因系为：一方面，募投项目中引入的生产设备自动化程度更高，节约了人工的同时提升了设备生产效率，平均单位成本中直接人工占比下降；另一方面，募投项目规划的UPH（由每小时产量300 个提升至400 个）占比高于报告期，单个产品的人工和制造费用占比进一步下降。

## ②期间费用

本项目建成投产后涉及的期间费用主要是销售费用、管理费用、研发费用及财务费用。销售费用、管理费用、研发费用金额参考公司2022 至2024 年各项费用构成占当期营业收入比重的平均值进行估算。本项目假设考虑债务融资为前提，计算财务费用。2022 至2024 年，公司销售费用、管理费用、研发费用费率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>费用占营业收入比例</td><td rowspan=2 colspan=1>均值</td><td rowspan=2 colspan=1>项目取值</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>2.99%</td><td rowspan=1 colspan=1>2.47%</td><td rowspan=1 colspan=1>2.55%</td><td rowspan=1 colspan=1>2.67%</td><td rowspan=1 colspan=1>2.67%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>8.60%</td><td rowspan=1 colspan=1>8.11%</td><td rowspan=1 colspan=1>9.54%</td><td rowspan=1 colspan=1>8.76%</td><td rowspan=1 colspan=1>8.76%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>6.59%</td><td rowspan=1 colspan=1>6.36%</td><td rowspan=1 colspan=1>6.66%</td><td rowspan=1 colspan=1>6.54%</td><td rowspan=1 colspan=1>6.54%</td></tr></table>

成本费用估算主要采用全要素法，结合产品实际成本构成和费用发生情况进

行预测，具有合理性，相对谨慎。

## （3）项目毛利率情况

本项目达产后，毛利率为 36.41%，与公司报告期及同行业公司相比，有一定提升系本项目测算的是新增产能（686.07 万个/年）部分的毛利率，属于产线优化后的增量效益，不存在显著差异。整体上，本项目收入和成本的预测符合公司和行业发展的实际情况，毛利率水平处于合理水平。

2023-2025 年，同行业可比上市公司主营业务毛利率情况如下：

<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>华工科技</td><td rowspan=1 colspan=1>24. 46%</td><td rowspan=1 colspan=1>25.70%</td><td rowspan=1 colspan=1>23.99%</td></tr><tr><td rowspan=1 colspan=1>开特股份</td><td rowspan=1 colspan=1>49.83%</td><td rowspan=1 colspan=1>49.64%</td><td rowspan=1 colspan=1>51.53%</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>19. 28%</td><td rowspan=1 colspan=1>22.76%</td><td rowspan=1 colspan=1>14.90%</td></tr><tr><td rowspan=1 colspan=1>保隆科技</td><td rowspan=1 colspan=1>17. 55%</td><td rowspan=1 colspan=1>17.10%</td><td rowspan=1 colspan=1>20.67%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1>27.78%</td><td rowspan=1 colspan=1>28.80%</td><td rowspan=1 colspan=1>27.77%</td></tr><tr><td rowspan=1 colspan=1>可比公司范围</td><td rowspan=1 colspan=1>17.55%-49.83%</td><td rowspan=1 colspan=1>17.10%-49.64%</td><td rowspan=1 colspan=1>14.90%-51.53%</td></tr><tr><td rowspan=1 colspan=1>项目一毛利率</td><td rowspan=1 colspan=3> 36.41%</td></tr></table>

注：可比公司毛利率分别选取其可比业务毛利率。其中华工科技数据为根据其年报数据计算的敏感元器件类产品的毛利率；开特股份数据为根据其年报数据计算的传感器类产品的毛利率；苏奥传感数据为根据其年报数据计算的传感器及配件类产品的毛利率；保隆科技数据为根据其年报数据计算的传感器类产品的毛利率。

## （4）项目二预计毛利率高于发行人现有业务毛利率的原因及合理性

报告期内，发行人陶瓷电容式压力传感器的毛利率及变动情况如下：

<table><tr><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>变动百分点</td><td rowspan=1 colspan=1>毛利率</td></tr><tr><td rowspan=1 colspan=1>29.34%</td><td rowspan=1 colspan=1>-2. 94</td><td rowspan=1 colspan=1>32.28%</td><td rowspan=1 colspan=1>0.09</td><td rowspan=1 colspan=1>32.19%</td></tr></table>

2025 年，发行人陶瓷电容式压力传感器毛利率较上一年度下降2.94 个百分点，主要系该产品价格下调（其中一主要客户 2024 年提出的年降要求较高所影响，但该年度的年降因素具有特殊性，预计不是长期持续的）和五金零件、金浆等主要原材料价格随市场价格上涨而上涨所致，对前三季度尤其是上半年的陶瓷电容式压力传感器毛利率影响较大。

此外，发行人本次陶瓷电容式压力传感器产线升级项目的毛利率较报告期内毛利率有所提升（接近报告期初毛利率），主要系：一方面，本募投项目将提升自动化、提高生产效率，同时提升单线产能，规模化效应更显著，能够很好的降本增效，从成本端保障产品毛利率的稳定；另一方面，陶瓷电容式压力传感器的产品结构将发生变化，高毛利率的温度-压力传感器占比将大幅提升，陶瓷电容式压力传感器分常规陶瓷电容式压力传感器与温度-压力传感器两类，报告期内以毛利率较低的常规陶瓷电容式压力传感器为主，毛利率达到38%左右的温度-压力传感器占比约30%，本募投项目预计将温度-压力传感器占比提升至超40%，更优的产品结构将有效提升本募投项目的毛利率。

综上，发行人 2025 年毛利率的下滑主要是受客户端及上游原材料端短期波动影响，上述因素预计不会长期持续，叠加新产线带来的降本增效及产品结构优化，本次陶瓷电容式压力传感器产线升级项目预计将能够保持优于报告期内的毛利率水平，该预估具有可实现性及合理性。

## （5）项目效益与现有同类业务及同行业可比公司情况

对于项目内部收益率和投资回收期的测算，均为基于现金流入和流出而进行的测算。本项目税后内部收益率为 21.12%，静态投资回收期为 6.41 年（税后，含建设期），略优于同行业公司系同行业类似的募投项目案例均为扩产产线，不属于升级产线，该差异处于合理范围内。本项目与同行业公司募投项目内部收益率、投资回收期的对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>融资类型</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>建设期(年)</td><td rowspan=1 colspan=1>内部收益率</td><td rowspan=1 colspan=1>回收期（税后）(年）</td></tr><tr><td rowspan=1 colspan=1>安培龙</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>项目一</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>21.12%</td><td rowspan=1 colspan=1>6.41</td></tr><tr><td rowspan=1 colspan=1>华工科技</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>物联网用新型传感器产业化项目</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>18.87%</td><td rowspan=1 colspan=1>6.47</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>汽车传感器产品智能化生产线建设项目</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>18.25%</td><td rowspan=1 colspan=1>6.36</td></tr><tr><td rowspan=1 colspan=3>平均</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>18.56%</td><td rowspan=1 colspan=1>6.42</td></tr></table>

注：开特股份、保隆科技未有公开的传感器项目相关数据。

华工科技的物联网用新型传感器产业化项目主要开发PM2.5 传感器、PWM 控制系统和薄膜型 NTC 温度传感器三大类产品，产品类型与项目二不同，但同属传感器类产品。

苏奥传感的汽车传感器产品智能化生产线建设项目建设内容为提升 MEMS微压传感器、空调压力/温度传感器、LPS 按需供油传感器、BPS 电池压力传感器、机油压力传感器、刹车助力传感器等产品的产能，个别产品与项目二相同，主要为空调压力传感器。

本项目的内部收益率高于同行业可比上市公司，投资回收期同行业可比上市公司基本接近，效益测算水平略有不同系不同公司产品结构差异所致，符合行业特征，效益测算合理。

## 3、项目三效益测算谨慎、合理，与公司现有同类业务及同行业可比公司情况未存在较大差异

力传感器产线建设项目具备良好的经济效益。项目建成达产后，预估年营业收入 13,907.63 万元，年净利润 2,144.35 万元，综合毛利率为 38.43%，净利率为15.42%。项目预计税后内部收益率为19.23%，税后静态投资回收期为6.74 年。项目效益预测的假设条件及主要计算过程如下：

## （1）项目效益测算过程，产品单价和销量数据的合理性

本项目中，力传感器暂未实现大批量生产，因此其销售单价参照最近一年市场供货价格平均值估算。同时，产品在保持谨慎性的情况下考虑价格有 5%的降幅，至达产年后保持价格稳定。本项目将分别采用金属应变片工艺与 MEMS 硅基应变片工艺进行力传感器生产，项目产品涉及拉压力传感器、力矩传感器、六维力传感器，主要应用于机器人领域，不涉及汽车零部件降价政策。

在进行效益测算及销量预测时，发行人将产能释放进度与行业未来市场需求、客户开拓的进度结合。本项目建设期 2年，分两期投产。第一期于T+2 年投产，产能利用率为 50%，期间处于产能提升阶段并逐渐放量，于 T+4 年产能利用率为 100%；第二期于 T+3 年投产，产能利用率为 50%，于 T+5 年产能利用率为100%。此外，本项目假设投产产能当年都能进行销售，项目销量、产能爬坡、效益预测具有谨慎性和合理性。

<table><tr><td colspan="1" rowspan="1">产品类型</td><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">T+1年</td><td colspan="1" rowspan="1">T+2年</td><td colspan="1" rowspan="1">T+3年</td><td colspan="1" rowspan="1">T+4年</td><td colspan="1" rowspan="1">T5年-T10年各年</td></tr><tr><td colspan="1" rowspan="3">拉压力传感器-MEMS</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">428.31</td><td colspan="1" rowspan="1">976.55</td><td colspan="1" rowspan="1">1,314.27</td><td colspan="1" rowspan="1">1,468.89</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="3">拉压力传感器-金属</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">428.31</td><td colspan="1" rowspan="1">569.65</td><td colspan="1" rowspan="1">773.10</td><td colspan="1" rowspan="1">734.45</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个)</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="3">力矩传感器-MEMS</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1,561.55</td><td colspan="1" rowspan="1">3,560.33</td><td colspan="1" rowspan="1">4,791.62</td><td colspan="1" rowspan="1">5,355.33</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个)</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="3">力矩传感器-金属</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">1,561.55</td><td colspan="1" rowspan="1">2,076.86</td><td colspan="1" rowspan="1">2,818.60</td><td colspan="1" rowspan="1">2,677.67</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个)</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="3">六维力传感器-MEMS</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1,189.75</td><td colspan="1" rowspan="1">2,712.64</td><td colspan="1" rowspan="1">3,650.75</td><td colspan="1" rowspan="1">4,080.26</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个)</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="3">六维力传感器-金属</td><td colspan="1" rowspan="1">营收(万元)</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1,189.75</td><td colspan="1" rowspan="1">1,582.37</td><td colspan="1" rowspan="1">2,147.50</td><td colspan="1" rowspan="1">2,040.13</td></tr><tr><td colspan="1" rowspan="1">未税单价（元/个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="1" rowspan="1">数量(万个）</td><td colspan="5" rowspan="1">已申请豁免披露</td></tr><tr><td colspan="2" rowspan="1">合计收入(万元)</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">6,359.23</td><td colspan="1" rowspan="1">11,478.40</td><td colspan="1" rowspan="1">15,495.84</td><td colspan="1" rowspan="1">16,356.72</td></tr></table>

## （2）项目成本费用估算及其谨慎性、合理性

本项目成本费用测算主要包括营业成本、销售费用、管理费用和研发费用等。

## ①营业成本

报告期内，发行人力传感器未大规模量产，仅有少量生产与销售，因此成本结构不具有参考性。

本募投项目营业成本主要包括原材料、直接人工、制造费用、委外费用。A、直接原材料成本主要结合项目产品的计划BOM成本及材料价格变动趋势进行预计，进入稳定期后保持不变。B、直接人工费用根据发行人同类人员薪资水平和本项目所需的生产人员人数进行估算。C、制造费用主要为折旧摊销费用，折旧摊销费用系根据本项目固定资产投入及发行人现有折旧政策进行测算。D、委外成本主要结合项目产品的计划 BOM 成本及变动趋势进行预计，进入稳定期后保持不变。

## ②期间费用

本项目建成投产后涉及的期间费用主要是销售费用、管理费用、研发费用及财务费用。销售费用、管理费用、研发费用金额参考公司2022 至2024 年各项费用构成占当期营业收入比重的平均值进行估算。本项目假设考虑债务融资为前提，计算财务费用。2022 至 2024 年，公司销售费用、管理费用、研发费用费率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>费用占营业收入比例</td><td rowspan=2 colspan=1>均值</td><td rowspan=2 colspan=1>项目取值</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>2.99%</td><td rowspan=1 colspan=1>2.47%</td><td rowspan=1 colspan=1>2.55%</td><td rowspan=1 colspan=1>2.67%</td><td rowspan=1 colspan=1>2.67%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>8.60%</td><td rowspan=1 colspan=1>8.11%</td><td rowspan=1 colspan=1>9.54%</td><td rowspan=1 colspan=1>8.76%</td><td rowspan=1 colspan=1>8.76%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>6.59%</td><td rowspan=1 colspan=1>6.36%</td><td rowspan=1 colspan=1>6.66%</td><td rowspan=1 colspan=1>6.54%</td><td rowspan=1 colspan=1>6.54%</td></tr></table>

成本费用估算主要采用全要素法，结合产品实际成本构成和费用发生情况进行预测，具有合理性，相对谨慎。

## （3）项目毛利率情况及高于发行人现有业务毛利率的原因及合理性

本项目达产后，毛利率为 37.77%，与公司报告期相比较高。原因系本项目力传感器主要应用于机器人领域，毛利水平较其他领域用传感器高；由于同业上市公司的产品结构不同，且主要不是力传感器产品，因此，部分公司差异较大，其中，以机器人应用的力传感器为主要产品的上市公司柯力传感与发行人力传感器业务较为可比，2022-2024 年，柯力传感毛利率水平保持在 40%以上，高于发行人本募投项目预测毛利率。整体上，本项目收入和成本的预测符合公司和行业发展的实际情况，毛利率水平处于合理水平。

## （4）项目效益与现有同类业务及同行业可比公司情况

对于项目内部收益率和投资回收期的测算，均为基于现金流入和流出而进行的测算。本项目税后内部收益率为 19.26%，静态投资回收期为 7.45 年（税后，含建设期）。目前公开信息未有机器人应用力传感器的同类型项目的公开数据可比较。

4、项目四效益测算谨慎、合理，与公司现有同类业务及同行业可比公司情况未存在较大差异

## （1）项目效益测算过程，产品单价和销量数据的合理性

本项目 MEMS 压力传感器芯片模组不对外销售，全部用于内部供应，不会新增上市公司的营业收入。但因通过自建 MEMS 压力传感器芯片模组产线，对于上市公司整体而言可以节约 MEMS 压力传感器芯片模组对外采购成本，参考市场价格（即本募投项目各产品预计平均单价），测算假设本项目建成后将会减少的芯片模组采购金额（即下表中节约的营业成本）。本项目实施后净节约营业成本情况已豁免披露。

对于上市公司整体而言，原本由外部 MEMS 压力传感器芯片模组供应商享有的净利润将留存在上市公司体内，即上表中所述的“净节约的生产成本”。

因本项目产品销售单价依据公司外采 MEMS 芯片模组的外采价格，因MEMS 压力传感器模组采购价格视公司采购批次的量确定，本项目芯片模组销售单价取自近一年来公司外采的平均单价，并在保持谨慎性的情况下考虑价格有5%降幅（假设不自产情况下，外采的芯片模组的单价会随着采购量增大而下降），至达产年后保持价格稳定。本项目产品自供，系 MEMS 压力传感器原材料，不涉及汽车零部件行业价格政策影响。

在进行效益测算及销量预测时，发行人将产能释放进度与行业未来市场需求、客户开拓的进度结合。本项目建设期 2 年，分两期投产。第一期于T+2 年投产，产能利用率为 80%，期间处于产能提升阶段并逐渐放量，于 T+3 年产能利用率为 100%；第二期于 T+3 年投产，产能利用率为 80%，于 T+4 年产能利用率为100%。此外，本项目假设投产产能当年都能进行销售，项目销量、产能爬坡、效益预测具有谨慎性和合理性。

## （2）项目成本费用估算及其谨慎性、合理性

本项目成本费用测算主要包括营业成本、销售费用、管理费用和研发费用等。

## ①营业成本

报告期内，发行人未生产 MEMS 压力传感器芯片模组，故未有相关产品成

本结构可参考。

营业成本主要包括原材料、直接人工、制造费用。A、直接原材料成本系对所需的原辅材料进行物料清单规划，并根据公司经验数据确定本次项目拟采购原材料与设计产能之间的关系，同时参考公司同类原辅材料采购市场价格进行测算。B、直接人工费用根据发行人同类人员薪资水平和本项目所需的生产人员人数进行估算。C、制造费用主要为折旧摊销费用，折旧摊销费用系根据本项目固定资产投入及发行人现有折旧政策进行测算。

## ②期间费用

本项目建成投产后涉及的期间费用主要是销售费用、管理费用、研发费用（含研发人员工资及其他研发费用）及财务费用。销售费用、管理费用金额参考公司2022 至 2024 年各项费用构成占当期营业收入比重的平均值进行估算。研发费用中的研发人员工资预测详见本回复之“问题 2/一、发行人说明/（八）说明项目四研发费用的主要内容、技术可行性、研发预算及时间安排、目前研发投入及进展、已取得或预计可取得的研发成果等，是否存在较大的研发失败风险，研发投入中拟资本化部分是否符合项目实际情况、是否符合《企业会计准则》的相关规定；结合报告期内发行人同类项目、同行业公司可比项目的资本化情况，说明本次募投项目中拟资本化金额的合理性”中关于研发人员工资的预测；其他研发费用（即研发费用中剔除研发人员工资部分）参照发行人2022 至2024 年其他研发费用比例的均值进行估算。本项目假设考虑债务融资为前提，计算财务费用。2022至2024 年，公司销售费用、管理费用、其他研发费用费率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>费用占营业收入比例</td><td rowspan=2 colspan=1>均值</td><td rowspan=2 colspan=1>项目取值</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>2.99%</td><td rowspan=1 colspan=1>2.47%</td><td rowspan=1 colspan=1>2.55%</td><td rowspan=1 colspan=1>2.67%</td><td rowspan=1 colspan=1>2.67%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>8.60%</td><td rowspan=1 colspan=1>8.11%</td><td rowspan=1 colspan=1>9.54%</td><td rowspan=1 colspan=1>8.76%</td><td rowspan=1 colspan=1>8.76%</td></tr><tr><td rowspan=1 colspan=1>其他研发费用</td><td rowspan=1 colspan=1>2.82%</td><td rowspan=1 colspan=1>2.68%</td><td rowspan=1 colspan=1>3.10%</td><td rowspan=1 colspan=1>2.86%</td><td rowspan=1 colspan=1>2.86%</td></tr></table>

## （3）项目毛利率情况

本项目MEMS 压力传感器芯片模组不对外销售，全部用于内部供应，不会新增上市公司的营业收入，不适用做毛利率计算。

## （4）项目效益与现有同类业务及同行业可比公司情况

对于项目内部收益率和投资回收期的测算，因均为基于现金流流入和流出而进行的测算，对于本募投项目自用部分视同为上市公司对外采购MEMS 传感器模组产品的现金流节约，所以自用和外销并不影响项目现金流，进而本项目自用或外销情况下税后内部收益率和投资回收期是一样的。本项目税后内部收益率为13.93%，静态投资回收期为7.89 年（税后，含建设期）。本项目与同行业公司募投项目或同类型项目（芯片模组产业化项目）内部收益率、投资回收期的对比情况如下：

<table><tr><td rowspan=1 colspan=1>同业公司名称</td><td rowspan=1 colspan=1>融资类型</td><td rowspan=1 colspan=1>时间</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>内部收益率</td><td rowspan=1 colspan=1>回收期（税后）（年）</td></tr><tr><td rowspan=1 colspan=1>安培龙</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>本项目</td><td rowspan=1 colspan=1>13.93%</td><td rowspan=1 colspan=1>7.89</td></tr><tr><td rowspan=1 colspan=1>士兰微</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>2016</td><td rowspan=1 colspan=1>年产能8.9亿只MEMS传感器扩产项目（含MEMS 传感器芯片制造扩产项目、MEMS 传感器封装项目、MEMS传感器测试能力提升项目）</td><td rowspan=1 colspan=1>13.74%</td><td rowspan=1 colspan=1>7.14</td></tr><tr><td rowspan=1 colspan=1>士兰微</td><td rowspan=1 colspan=1>再融资</td><td rowspan=1 colspan=1>2022</td><td rowspan=1 colspan=1>汽车半导体封装项目（一期)</td><td rowspan=1 colspan=1>14.30%</td><td rowspan=1 colspan=1>5.30</td></tr><tr><td rowspan=1 colspan=1>华培动力</td><td rowspan=1 colspan=1>简易程序</td><td rowspan=1 colspan=1>2023</td><td rowspan=1 colspan=1>MEMS压力传感芯片及模组产业化项目</td><td rowspan=1 colspan=1>14.61%</td><td rowspan=1 colspan=1>8.37</td></tr><tr><td rowspan=1 colspan=2>平均</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>14.22%</td><td rowspan=1 colspan=1>6.94</td></tr></table>

由上表可知，本项目的内部收益率及投资回收期处于同行业区间内，与同行业公司不存在显著差异，效益测算水平略有不同系不同公司产品结构差异所致，符合行业特征，效益测算合理。

（四）结合报告期内委外加工具体情况、本次各募投项目的新增产能情况、扩产倍数、行业竞争格局、下游行业发展前景及市场需求情况、在手订单或意向性协议、公司现有产品产能利用率情况、前次募投项目的产能情况、同行业可比公司扩产情况等，说明本次募投项目新增产能的必要性及具体产能消化措施，是否存在产能消化风险

## 1、报告期内委外加工具体情况

发行人本次募投项目设计的产品如下，相关产成品均不涉及委外加工产量，发行人委外加工产品主要系 NTC 热敏电阻及温度传感器等。

<table><tr><td>产线类别</td><td>主要产品</td></tr><tr><td colspan="1" rowspan="1">压力传感器扩产项目</td><td colspan="1" rowspan="1">压力传感器，具体产品包括陶瓷电容式压力传感器、MEMS压力传感器、玻璃微熔压力传感器</td></tr><tr><td colspan="1" rowspan="1">陶瓷电容式压力传感器产线升级项目</td><td colspan="1" rowspan="1">陶瓷电容式压力传感器</td></tr><tr><td colspan="1" rowspan="1">力传感器产线建设项目</td><td colspan="1" rowspan="1">力传感器，具体产品包括拉压力传感器、力矩传感器、六维力传感器</td></tr><tr><td colspan="1" rowspan="1">MEMS传感器芯片研发及产业化项目</td><td colspan="1" rowspan="1">MEMS压力传感器芯片模组</td></tr></table>

## 2、本次各募投项目的新增产能情况、扩产倍数

## （1）压力传感器扩产项目及陶瓷电容式压力传感器产线升级项目

压力传感器扩产项目及陶瓷电容式压力传感器产线升级项目中不同类型压力传感器产品（陶瓷电容、MEMS、玻璃微熔）的产能新增情况如下：

单位：万个

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>现有产能（2024年度）</td><td rowspan=1 colspan=1>压力传感器扩产项目新增产能</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目新增产能</td><td rowspan=1 colspan=1>本次募投实施后总产能</td><td rowspan=1 colspan=1>扩产倍数</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器</td><td rowspan=1 colspan=1>1,995.84</td><td rowspan=1 colspan=1>1,496.88</td><td rowspan=1 colspan=1>686.07</td><td rowspan=1 colspan=1>4,178.79</td><td rowspan=1 colspan=1>1.09</td></tr><tr><td rowspan=1 colspan=1>MEMS 压力传感器</td><td rowspan=1 colspan=1>564.97</td><td rowspan=1 colspan=1>879.98</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1,444.95</td><td rowspan=1 colspan=1>1.56</td></tr><tr><td rowspan=1 colspan=1>玻璃微熔压力传感器</td><td rowspan=1 colspan=1>=</td><td rowspan=1 colspan=1>430.92</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>430.92</td><td rowspan=1 colspan=1>·</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>2,560.81</td><td rowspan=1 colspan=1>2,807.78</td><td rowspan=1 colspan=1>686.07</td><td rowspan=1 colspan=1>6,054.66</td><td rowspan=1 colspan=1>-</td></tr></table>

注：报告期内，玻璃微熔压力传感器处于产能爬坡阶段，产销量较低，此处未单独统计其现有产能情况。

## （2）力传感器产线建设项目及 MEMS 传感器芯片研发及产业化项目

报告期内，发行人力传感器属于小规模量产，未有规模化产能，本次募投项目新增约 50.42 万只力传感器；MEMS 压力传感器芯片模组系发行人向 MEMS压力传感器上游原材料的扩展，报告期内未有产能，本次募投项目新增 537.30万个MEMS 压力传感器芯片模组。

## 3、公司前次募投项目的产能情况及现有产品产能利用率情况

## （1）前次募投项目的产能情况

公司前次募投涉及新增产能的项目包含压力传感器建设项目、温度传感器建设项目，具体构成如下：

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>产能</td></tr><tr><td rowspan=1 colspan=1>压力传感器建设项目</td><td rowspan=1 colspan=1>年产1,500万只压力传感器产品（全部为陶瓷电容式压力传感器)</td></tr><tr><td rowspan=1 colspan=1>温度传感器建设项目</td><td rowspan=1 colspan=1>年产10,500万只温度传感器产品，其中非汽车综合用温度传感器10,000万只，汽车用温度传感器500万只</td></tr></table>

## （2）公司现有产品产能利用率情况

除补充流动资金外，本次募投项目的主要产品如下表：

<table><tr><td rowspan=1 colspan=1>产线类别</td><td rowspan=1 colspan=1>主要产品</td></tr><tr><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>压力传感器，具体产品包括陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器</td></tr><tr><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>力传感器，具体产品包括拉压力传感器、力矩传感器、六维力传感器</td></tr><tr><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>MEMS压力传感器芯片模组</td></tr></table>

注：报告期内，玻璃微熔压力传感器处于产能爬坡阶段，产销量较低，此处未单独统计其现有产能情况；力传感器及 MEMS 压力传感器芯片模组未开始规模化生产，亦未有产能利用率情况。

本次募投项目新增产品报告期内存在规模化产能的包括陶瓷电容式压力传感器及MEMS 压力传感器，陶瓷电容式压力传感器及 MEMS 压力传感器的产能利用率如下：

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>单位</td><td rowspan=1 colspan=3>2025年度</td><td rowspan=1 colspan=3>2024年度</td><td rowspan=1 colspan=3>2023年度</td></tr><tr><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td><td rowspan=1 colspan=1>自主产量</td><td rowspan=1 colspan=1>产能</td><td rowspan=1 colspan=1>利用率</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器</td><td rowspan=1 colspan=1>万个</td><td rowspan=1 colspan=1>2,108.87</td><td rowspan=1 colspan=1>2,245.329</td><td rowspan=1 colspan=1>93.92%</td><td rowspan=1 colspan=1>1,589.59</td><td rowspan=1 colspan=1>1,995.84</td><td rowspan=1 colspan=1>79.65%</td><td rowspan=1 colspan=1>1,005.53</td><td rowspan=1 colspan=1>1,605.24</td><td rowspan=1 colspan=1>62.64%</td></tr><tr><td rowspan=1 colspan=1>MEMS压力传感器</td><td rowspan=1 colspan=1>万个</td><td rowspan=1 colspan=1>342.88</td><td rowspan=1 colspan=1>575.74</td><td rowspan=1 colspan=1>59.55%</td><td rowspan=1 colspan=1>101.94</td><td rowspan=1 colspan=1>564.97</td><td rowspan=1 colspan=1>18.04%</td><td rowspan=1 colspan=1>12.65</td><td rowspan=1 colspan=1>433.45</td><td rowspan=1 colspan=1>2.92%</td></tr></table>

## ①陶瓷电容式压力传感器产能利用率总体较高

报告期内，陶瓷电容式压力传感器产能利用率逐步提升。报告期内，公司陶瓷电容式压力传感器不断斩获国内外知名汽车主机厂及一级零部件供应商的重要客户新项目定点以及订单，新客户新项目主要涉及飞行汽车热管理系统、新能源汽车及燃油汽车热泵系统、空调管路系统、发动机系统、变速箱系统，商用车刹车系统、商用车冷却机组系统，储能系统，氢燃料电池系统等领域，基本实现了国内主流自主品牌主机厂及造车新势力的全覆盖，进一步夯实了市场基础及行业地位。凭借强大的研发技术能力以及广泛的市场影响力，公司陶瓷电容式压力传感器产品获得深圳市工业和信息化局评选的第二批“制造业单项冠军企业”荣誉。报告期内，公司陶瓷电容式压力传感器除在汽车应用领域继续取得高速增长外，在商用空调以及储能领域均取得较大突破。因此，2023 年至今，公司陶瓷电容式压力传感器产能利用率不断提升。

## ②MEMS 压力传感器在报告期内处于产能爬坡及客户开拓阶段，因此产能利用率偏低，但报告期内整体呈现上升趋势，其扩产具有合理性

MEMS 压力传感器项目系发行人自报告期初开始自有资金重点投入的发展项目之一，经过多年的技术积累和客户开拓，2024 年开始产能逐渐爬坡并大规模量产，至 2025 年 MEMS 压力传感器业务开始快速增长，逐步实现向Stellantis、上汽大通、绿山咖啡等核心客户的大批量稳定交付，产能利用率开始稳步提升。因此，2023-2024 年，MEMS 压力传感器产能利用率较低系发展阶段不同所致，其扩产具有合理性，具体原因如下：

MEMS 技术系公司重要技术平台之一，MEMS 压力传感器系公司产品布局的重要组成部分。自成立以来，公司致力于持续完善传感器产品体系布局，打造成熟的产业转链条。公司依托敏感陶瓷技术及 MEMS 技术两大成熟技术平台，在产品布局方面重点关注行业应用趋势及下游客户需求，培养一系列具备竞争力的细分领域传感器产品，丰富公司产品品类，为未来公司的可持续发展奠定良好的业务基础。压力传感器扩产项目中，公司将分别对陶瓷电容式压力传感器、MEMS压力传感器、玻璃微熔压力传感器产品进行扩产。其中，陶瓷电容式压力传感器由于其封装结构的特性，适用于最大量程 0.5-15MPa 的中低压压力范围，主要用于汽车变速箱系统、汽车热管理系统、汽车发动机系统；MEMS 压力传感器主要用于小于 0.5MPa 的微低压压力范围，用于汽车发动机系统、刹车系统、尾气处理系统等气压测量场景；玻璃微熔压力传感器适用于最大量程 5-600MPa 的中高压压力范围，主要用于汽车 ABS 刹车系统、ESP 车辆稳定系统及发动机高压共轨系统、汽油机直喷系统。通过上述举措，公司紧跟压力传感器行业发展趋势，凭借自身在压力传感器领域所积淀的技术实力、运营经验、客户基础、服务口碑，积极完善全量程产品布局，升级产品结构，为市场提供高质量的压力传感器产品，夯实公司综合核心竞争力。

MEMS 压力传感器有望成为公司继陶瓷电容式压力传感器之后，在压力传感器领域的又一重要增长引擎。凭借对汽车动力总成系统及底盘制动系统以及工业消费等核心场景的深度理解，公司可充分提供满足汽车动力总成系统、底盘制动系统、咖啡机、饮料机等对 MEMS 压力传感器的多元化应用需求。2025 年，公司 MEMS 压力传感器业务增长势头迅猛，已逐步实现向 Stellantis、上汽大通、绿山咖啡等核心客户的大批量稳定交付。2025 年，公司 MEMS 压力传感器共实现营收 5,828.18 万元，同比增长 433.57%，呈现快速放量增长态势，有望成为公司继陶瓷电容式压力传感器之后，在压力传感器领域的又一重要增长引擎。公司 MEMS 压力传感器的具备自主研发 MEMS 感压元件能力以及核心零部件的自主开发能力，产品性能及介质兼容性好。同时，采用平台化、标准化设计理念，使不同 MEMS 压力传感器产品可共用自动化产线，显著降低制造成本并提升生产效率，提高产品稳定性及可靠性，且可通过规模化生产增强了市场定价能力，为国产替代提供成本优势基础。

## 4、行业竞争格局及同行业可比公司扩产情况

## （1）行业竞争格局

力传感器主要应用于机器人领域，目前人形机器人作为具身智能机器人的高阶形态，正加速迈进产业化阶段，行业内未形成稳定的竞争格局。除安培龙外，根据公开信息，国内应用于机器人领域的力传感器公司包括上市公司柯力传感，未上市公司坤维（北京）科技有限公司、蓝点触控（北京）科技有限公司、深圳市鑫精诚传感技术有限公司、常州瑞尔特测控系统有限公司等。

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">公司</td><td colspan="1" rowspan="1">机器人领域的力传感器业务说明</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">柯力传感</td><td colspan="1" rowspan="1">公司主营业务为各类传感器的研制和生产，主要产品包括机器人传感器、智能传感器、多物理量传感器等。公司六维力/力矩传感器已完成人形机器人手腕、脚腕，工业臂、协作臂末端的产品系列开发，掌握了结构解耦、算法解耦、高速采样通讯等技术要点，并已给50多家国内人形机器人、协作机器人、工业机器人客户送样，部分客户已进入批量订单阶段。</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">凌云股份</td><td colspan="1" rowspan="1">公司主营业务为汽车零部件供应，在传感器领域，公司已交付压力、扭矩力传感器的小批量订单，六维力传感器已完成设计、建成专业生产线。</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">坤维（北京）科技有限公司</td><td colspan="1" rowspan="1">公司主营业务包括智能力学类传感器的研发、制造、销售及技术推广，主要产品包括六维力传感器、力传感器、工业衡器、扭矩传感器等。2025年底公司实现年产六维力传感器3万台，并计划在2026年初达到6万台年产能。</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">蓝点触控(北京）科技有限公司</td><td colspan="1" rowspan="1">蓝点触控专注于智能机器人前沿力控技术研发，主要业务为提供机器人力传感器硬件。公司产品包括机器人六维力传感器、关节扭矩传感器等，客户包括多个机器人厂商。公司是六维力传感器的创新代表，在机器人关节力传感器方面，公司目前机器人力传感器出货量超过10万台，并在进行新产线的建设。</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">深圳市鑫精诚传感技术有限公司</td><td colspan="1" rowspan="1">公司主营业务为智能传感器的研发、生产、销售与服务，主要产品为多维力传感器、扭矩传感器等，应用领域包括工业机器人、机械设备、新能源、医疗、航天与农业。鑫精诚传感器是较早进入焊接机器人市场的企业，公司计划 2026年力矩传感器的出货量达到15万支，MEMS六维力传感器预计实现交付量5万支。</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">常州瑞尔特测控系统有限公司</td><td colspan="1" rowspan="1">公司主营业务为传感器的研发、生产、销售与服务，主要产品包括多维力传感器、压向传感器等，应用领域包括工业机器人、汽车制造装配等。公司拥有德国测力传感技术，在行业内拥有一定的创新能力。</td></tr></table>

信息来源：公司公告、官网或公众号信息等公开信息。

压力传感器方面，下游应用主要在汽车领域。国内汽车压力传感器主要被美国森萨塔、博世等国际企业所占据。中国压力传感器仍处于技术追赶阶段，只有少数公司具备产品研发和量产供货的能力，包括华工科技、苏奥传感、保隆科技、天博智能科技（山东）股份有限公司（以下简称“天博智能”）等，主要原因为：A、作为安全件，压力传感器的稳定性和性能至关重要，整车制造企业在选择供应商时相对谨慎，对产品的验证周期较长。国内产品缺乏接受大批量实际应用的验证，面对下游整车厂商对于产品的高要求，压力传感器厂商缺乏实际应用的经验和相关数据证明产品的性能，在市场竞争中处于劣势，非一朝一夕可以弥补与国际领先企业的差距。B、压力传感器与车身相应电子控制系统的配合度亟待验证。全球主流的整车厂商使用的 ECU、ESP 等汽车电子系统主要由国外汽车零部件供应商提供，这些零部件供应商在压力传感器与软件配合度方面优势明显，可提供配套化服务。相比之下，由于国内汽车电子系统的落后，导致国内压力传感器供应商所提供的零部件与汽车电子系统的适配度存在不确定性，同时也很难进入国外汽车零部件供应商体系。

## （2）同行业可比公司扩产情况

目前行业内主要传感器上市公司或非上市公司亦积极布局、扩产压力传感器、力传感器等，本次募投项目实施将有助于发行人把握行业发展趋势、抢占行业份额、提升竞争力。

## ①压力传感器

如前文所述，压力传感器方面，只有少数公司具备产品研发和量产供货的能力。同行业可比公司扩产情况如下：

<table><tr><td rowspan=1 colspan=1>公司简称</td><td rowspan=1 colspan=1>时间</td><td rowspan=1 colspan=1>融资方式</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>扩产项目情况</td></tr><tr><td rowspan=2 colspan=1>天博智能</td><td rowspan=2 colspan=1>2026年</td><td rowspan=2 colspan=1>首次公开募股</td><td rowspan=1 colspan=1>智能热管理部件及系统制造建设项目</td><td rowspan=1 colspan=1>项目建成达产后，将形成年产压力传感器1,000万只</td></tr><tr><td rowspan=1 colspan=1>汽车热管理系统及核心元器件生产基地扩产技术改造项目</td><td rowspan=1 colspan=1>项目建成达产后，将形成年产温度传感器2,800万只</td></tr><tr><td rowspan=1 colspan=1>华培动力</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>向特定对象发行股票</td><td rowspan=1 colspan=1>压力传感器产能扩充项目</td><td rowspan=1 colspan=1>项目拟通过装修厂房、购置生产设备，形成年产 350 万支陶瓷中压传感器及 500万支玻璃微熔高压传感器的生产能力</td></tr><tr><td rowspan=1 colspan=1>敏芯股份</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>向特定对象发行股票</td><td rowspan=1 colspan=1>年产车用及工业级传感器 600 万只生产研发项目</td><td rowspan=1 colspan=1>项目规划产能年产车用压力传感器600万只</td></tr><tr><td rowspan=1 colspan=1>苏奥传感</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>向特定对象发行股票</td><td rowspan=1 colspan=1>汽车传感器产品智能化生产线建设项目</td><td rowspan=1 colspan=1>项目规划年产各类压力传感器合计1,875万只</td></tr><tr><td rowspan=1 colspan=1>汉威科技</td><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>向特定对象发行股票</td><td rowspan=1 colspan=1>MEMS 传感器封测产线建设</td><td rowspan=1 colspan=1>项目达产后年产MEMS压力/流量传感器470万只</td></tr></table>

## ②力传感器

如前文所述，目前人形机器人正加速迈进产业化阶段，行业内未形成稳定的竞争格局。除安培龙外，根据公开信息，行业内坤维（北京）科技有限公司、蓝点触控（北京）科技有限公司、深圳市鑫精诚传感技术有限公司等公司亦有关于应用于机器人领域的力传感器扩产规划，产能从数万台至几十万台均有。

5、下游行业发展前景及市场需求情况、公司在手订单或意向性协议等较好，本次募投项目新增产能具有必要性

## （1）压力传感器

①下游行业发展前景及市场需求情况

随着以人工智能、5G 通信、大数据等为代表的智能化时代到来，传感器作为重要的感知触角，受到了世界各国的普遍重视，并快速发展。过去几年，全球传感器市场一直保持快速增长，随着经济环境的持续好转，市场对传感器的需求将不断增多。根据赛迪顾问的统计，2024 年全球传感器产业市场规模约为14,855.2 亿元，同比增长超 6%。中国传感器产业发展速度更加亮眼，市场规模达到 4,061.2 亿元，同比增长超 11%，远高于全球增长率。赛迪顾问预计，“十五五”期间，中国传感器市场规模将保持 15%左右增速，2030 年突破 1 万亿元规模。

![](images/3fbd365a74b177e6cb08552b7f283ea38bb28d2896d6cd17c82e921a97d6b2fc.jpg)  
数据来源：赛迪顾问

## ②公司在手订单或意向性协议

发行人客户群体主要集中为国内优质的汽车厂商，其行业生产具有计划性，客户需求具有一定的稳定性及可预见性，因此客户通常采用按月下单，同时向公司发出其未来 2-3 个月的生产计划。由于客户订单下达通常具有频率高、周期短、批次多等特点，因此在手订单通常无法真实体现相关业务的规模，该种情形符合行业惯例。公开信息显示，利来智造、福然德等汽车领域上游供应商于其招股说明书中亦披露了类似的订单模式。

参考公司以往各月获取订单情况，1-2 月系春节前后，订单量可参考性较弱；3月份的订单量相对平均。由于在手订单通常无法真实体现相关业务的规模，为了更好地体现公司获取订单情况，以 2025 年及 2026 年的 3 月份订单量平均值作为公司 2026 年平均月订单量，并进行年化处理（乘以 12），可得发行人陶瓷电容式压力传感器、MEMS 压力传感器、玻璃微熔压力传感器对应的预计年化订单数量如下：

<table><tr><td colspan="1" rowspan="1">产品</td><td colspan="1" rowspan="1">在手订单对应数量（万个）</td><td colspan="1" rowspan="1">占压力传感器扩产项目新增产能比例</td></tr><tr><td colspan="1" rowspan="1">陶瓷电容式压力传感器</td><td colspan="1" rowspan="1">1, 882. 35</td><td colspan="1" rowspan="1">126%</td></tr><tr><td colspan="1" rowspan="1">MEMS压力传感器</td><td colspan="1" rowspan="1">428. 09</td><td colspan="1" rowspan="1">49%</td></tr><tr><td colspan="1" rowspan="1">玻璃微熔压力传感器</td><td colspan="1" rowspan="1">166. 27</td><td colspan="1" rowspan="1">39%</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">2, 476. 71</td><td colspan="1" rowspan="1">88%</td></tr></table>

由上表可知，公司预计年化订单数量较客观，可较好地消化新增产能。

此外，北美某知名新能源汽车企业、德国某知名汽车零部件企业、国内某知名汽车企业等下游客户已与发行人签订了相关意向性协议。

综上，本次募投项目新增压力传感器产能具有必要性。

## （2）力传感器

①下游行业发展前景及市场需求情况

人形机器人作为具身智能机器人的高阶形态，正加速迈进产业化阶段。根据高工机器人产业研究所（GGII）于2025 年4月发布的《2025 年人形机器人产业发展蓝皮书》显示 ，2025 年全球人形机器人市场销量有望达到1.24 万台，市场规模 63.39 亿元；预计 2026 年中国人形机器人出货将达 6.25 万台；到2030 年全球人形机器人市场销量将接近 34 万台，市场规模将超过640 亿元；到2035 年，全球人形机器人市场销量将超过500 万台，市场规模将超过4,000 亿元。

通常，一个人形机器人需要配置32个传感器，相当于预计2026 年，中国人形机器人对传感器的需求将达 200 万个；2030 年需求将超1,000 万个。因此，人形机器人对传感器的需求空间巨大。

## ②公司在手订单或意向性协议

力传感器行业正处于起步发展阶段，包括发行人在内，行业内均未有大规模量产的公司，大部分公司最早于2026 年开始能有批量订单。截至本回复出具日，公司力传感器已有相应的客户，部分主要客户如下：

<table><tr><td colspan="1" rowspan="1">客户名称</td><td colspan="1" rowspan="1">应用领域</td><td colspan="1" rowspan="1">销售情况</td></tr><tr><td colspan="1" rowspan="1">客户一</td><td colspan="1" rowspan="1">人形机器人</td><td colspan="1" rowspan="1">批量生产及销售（2026年4月订单约2,000个力传感器）</td></tr><tr><td colspan="1" rowspan="1">客户二</td><td colspan="1" rowspan="1">人形机器人及机器人协作臂</td><td colspan="1" rowspan="1">小规模量产及销售</td></tr><tr><td colspan="1" rowspan="1">客户三</td><td colspan="1" rowspan="1">机器人协作臂</td><td colspan="1" rowspan="1">小规模量产及销售</td></tr><tr><td colspan="1" rowspan="1">客户四</td><td colspan="1" rowspan="1">人形机器人</td><td colspan="1" rowspan="1">试产验证</td></tr><tr><td colspan="1" rowspan="1">客户五</td><td colspan="1" rowspan="1">人形机器人</td><td colspan="1" rowspan="1">试产验证</td></tr><tr><td colspan="1" rowspan="1">客户六</td><td colspan="1" rowspan="1">人形机器人</td><td colspan="1" rowspan="1">试产验证</td></tr><tr><td colspan="1" rowspan="1">客户七</td><td colspan="1" rowspan="1">人形机器人</td><td colspan="1" rowspan="1">试产验证</td></tr></table>

力传感器下游应用主要为机器人领域，相关客户在选择上游零部件（如传感器）供应商时通常会综合考核产品技术、质量、价格、产能等各方面指标，并最终选择合格供应商，可见，产能系机器人客户重点考察供应商的重要指标之一。以发行人力传感器客户客户一为例，报告期内，发行人与客户一密切对接，持续向客户一送样，满足其各项要求，并于 2026 年一季度通过了客户一的考核，取得了客户一的定点开发通知书。该定点通开发通知书载明：“在充分分析了贵公司的质量保证体系、技术研发、生产组织能力及产品价格等诸方综合因素，决定选择贵公司作为以下零部件/服务（包含：力传感器总成、力矩传感器、力传感器等）的供应商”。因此，发行人力传感器新建产能也是为了满足下游客户需求，具有必要性。

综上，本次募投项目新增力传感器产能具有必要性。

## 6、公司已采取产能消化措施，相关产能消化风险已进行披露

## （1）公司已采取的产能消化措施

①压力传感器及力传感器庞大的市场规模将为募投项目消化奠定坚实基础

随着以人工智能、5G 通信、大数据等为代表的智能化时代到来，传感器作为重要的感知触角，受到了世界各国的普遍重视，并快速发展。过去几年，全球传感器市场一直保持快速增长，随着经济环境的持续好转，市场对传感器的需求将不断增多。根据赛迪顾问的统计，2024 年全球传感器产业市场规模约为14,855.2 亿元，同比增长超 6%。中国传感器产业发展速度更加亮眼，市场规模达到4,061.2 亿元，同比增长超 11%，远高于全球增长率。赛迪顾问预计，“十五五”期间，中国传感器市场规模将保持 15%左右增速，2030 年突破 1 万亿元规模。

![](images/d704f1ec530fbcb336b8fe06762253b089396c86d037a6c05086e1bfa4335f76.jpg)  
数据来源：赛迪顾问

②发行人具备国产替代的成功经验，募投产品预计将推动进口替代

国内汽车压力传感器市场长期由美国森萨塔、德国博世等国际厂商主导，本土企业市场份额相对较少。发行人依托压力传感器业务实现快速增长，核心驱动力源于国产替代，且已在该领域积累成熟且可复制的成功经验，形成标准化的技术突破与市场拓展体系。自业务研发及产业化落地以来，发行人成功打破国外品牌垄断格局，压力传感器营业收入由 2019 年不足 1000 万元，大幅增长至 2024年的 4.68 亿元，五年间增长逾四十倍，充分印证公司国产替代路径的可行性与有效性。本次募投项目所生产产品，将延续上述成熟的国产替代发展路径，持续推进国产替代进程，同时为新增产能消化提供坚实支撑。

③发行人加大新客户及存量客户其他项目的开拓力度，未来营收将持续增长

得益于高性能产品与优质服务，以及高效的服务响应能力，公司已与众多国内外知名企业构建起长期稳定的合作关系。其中，汽车领域的国内外知名客户（含通过汽车零部件厂商供应的主机厂）包括比亚迪、上汽集团、Stellantis、东风日产、长城汽车、东风汽车、长安汽车、奇瑞汽车、广汽埃安、理想、小鹏、赛力斯等，汽车零部件厂商包括法雷奥、麦格纳、捷温、李尔、拓普集团、三花智控、万里扬等；商用空调领域知名客户包括美的、格力等；此外，还包括储能领域、家电领域、消费电子领域等各领域的知名企业。一方面，基于上述存量客户的合作深度及合作经验的积累，发行人加大新客户的开拓力度；另一方面，随着发行人的产品质量、生产能力等不断获得验证认可，发行人切入存量客户其他项目的可实现性亦较高。随着发行人加大新客户及存量客户其他项目的开拓力度，未来发行人各应用领域的压力传感器的营收将持续增长。

此外，在机器人领域，发行人也持续开拓客户并取得一定突破和进展，目前公司力传感器已有相应的客户，部分主要客户如下：

<table><tr><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>应用领域</td></tr><tr><td rowspan=1 colspan=1>客户一</td><td rowspan=1 colspan=1>人形机器人</td></tr><tr><td rowspan=1 colspan=1>客户二</td><td rowspan=1 colspan=1>人形机器人及机器人协作臂</td></tr><tr><td rowspan=1 colspan=1>客户三</td><td rowspan=1 colspan=1>机器人协作臂</td></tr><tr><td rowspan=1 colspan=1>客户四</td><td rowspan=1 colspan=1>人形机器人</td></tr><tr><td rowspan=1 colspan=1>客户五</td><td rowspan=1 colspan=1>人形机器人</td></tr><tr><td rowspan=1 colspan=1>客户六</td><td rowspan=1 colspan=1>人形机器人</td></tr><tr><td rowspan=1 colspan=1>客户七</td><td rowspan=1 colspan=1>人形机器人</td></tr></table>

## （2）公司已披露相关产能消化风险

发行人已在募集说明书“重大事项提示”之“二、重大风险提示”之“（二）募投项目新增产能消化风险”和“第七节 与本次发行相关的风险因素”之“二、经营风险”之“1、募投项目新增产能消化风险”披露如下：

“本次发行相关的募投项目均围绕公司主营业务开展，是公司基于当前的产业政策、发展趋势、市场需求、公司经营状况等因素，经审慎论证后确定的，具有较强的可行性和必要性，符合公司的战略规划和经营需要。但是，募投项目的实施和效益产生均需一定时间，因此从项目实施、完工、达产以至最终的产品销售等均存在不确定性。若在募投项目实施过程中，宏观经济、产业政策、市场环境等发生重大不利变化，公司市场开拓成效不佳，所处行业竞争加剧，公司可能面临产能无法消化的风险。”

（五）结合本次各募投项目的具体设备购置内容、价格和作用等情况，说明拟购置设备是否为公司目前相关资产的更新或升级，相关投入规模是否合理，测算并说明募集资金投入的经济性；结合现有固定资产、在建工程情况，量化分析本次募投项目、拟建及在建项目等新增折旧摊销对发行人未来盈利能力及经营业绩的影响

1、结合本次各募投项目的具体设备购置内容、价格和作用等情况，说明拟购置设备是否为公司目前相关资产的更新或升级，相关投入规模是否合理

## （1）压力传感器扩产项目

①具体设备购置内容、价格和作用等情况，拟购置设备的更新或升级情况

本项目为全新产线，设备购置费用为 22,053.07 万元，购置产线类型包括陶瓷电容式压力传感器全自动组装线 6 条、电容产线 1 条、MEMS 压力传感器自动线4条、玻璃微熔压力传感器自动线2条、智能仓储及配套设备，具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>生产线名称</td><td rowspan=1 colspan=1>主要设备</td><td rowspan=1 colspan=1>产线/设备作用</td><td rowspan=1 colspan=1>生产线数量（条）</td><td rowspan=1 colspan=1>单线金额（万元）</td><td rowspan=1 colspan=1>合计金额（万元）</td><td rowspan=1 colspan=1>是否为更新或升级</td></tr><tr><td rowspan=1 colspan=1>1.1</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线</td><td rowspan=1 colspan=1>电容FPC 组装自动焊接设备、校准机、氮检测试设备、RTV 点胶+固化设备、震动测试设备等</td><td rowspan=1 colspan=1>用于陶瓷压力传感器扩产</td><td rowspan=1 colspan=1>6</td><td rowspan=5 colspan=1>已申请豁免披露</td><td rowspan=5 colspan=1>已申请豁免披露</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>1.2</td><td rowspan=1 colspan=1>电容产线</td><td rowspan=1 colspan=1>烧结设备、印刷设备、插针设备、检测设备等</td><td rowspan=1 colspan=1>为陶瓷电容式压力传感器全自动组装线提供陶瓷芯体，属于该自动线的前道工序</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>MEMS压力传感器自动线</td><td rowspan=1 colspan=1>壳体点胶热铆设备、激光焊接贴上盖设备、烧录电性能终测设备、单向阀组装壳体设备等</td><td rowspan=1 colspan=1>用于MEMS压力传感器扩产</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>玻璃微熔压力传感器自动线</td><td rowspan=1 colspan=1>点焊设备、激光焊接设备、三温标定设备、全自动超声波键合设备等</td><td rowspan=1 colspan=1>用于玻璃微熔压力传感器扩产</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>智能仓储</td><td rowspan=1 colspan=1>托盘四向车机器人、输送线、专用货架/周转容器、环保及配套设备等</td><td rowspan=1 colspan=1>用于运输、存储传感器产品</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=3>合计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>22,053.07</td><td rowspan=1 colspan=1></td></tr></table>

## ②相关投入规模的合理性

本项目、陶瓷电容式压力传感器产线升级项目与发行人IPO 阶段压力传感器建设项目的单位固定资产产能情况如下表所示：

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>产能（万个）</td><td rowspan=1 colspan=1>固定资产投入（万元，含税）</td><td rowspan=1 colspan=1>单位固定资产产能（个/元）</td></tr><tr><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>2,807.78</td><td rowspan=1 colspan=1>24,735.17</td><td rowspan=1 colspan=1>0.11</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>686.07</td><td rowspan=1 colspan=1>6,459.00</td><td rowspan=1 colspan=1>0.11</td></tr><tr><td rowspan=1 colspan=1>IPO-压力传感器建设项目</td><td rowspan=1 colspan=1>1,500.00</td><td rowspan=1 colspan=1>13,890.30</td><td rowspan=1 colspan=1>0.11</td></tr><tr><td rowspan=1 colspan=1>发行人2025年情况（压力传感器）</td><td rowspan=1 colspan=1>2,821. 06</td><td rowspan=1 colspan=1>25,233. 60</td><td rowspan=1 colspan=1>0.11</td></tr></table>

单位固定资产产值情况如下表所示：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>产值/收入（万元，不含税）</td><td rowspan=1 colspan=1>固定资产投入（万元，含税）</td><td rowspan=1 colspan=1>单位固定资产投入对应产值</td></tr><tr><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>73,360.73</td><td rowspan=1 colspan=1>24,735.17</td><td rowspan=1 colspan=1>2.97</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>16,334.74</td><td rowspan=1 colspan=1>6,459.00</td><td rowspan=1 colspan=1>2.53</td></tr><tr><td rowspan=1 colspan=1>IPO-压力传感器建设项目</td><td rowspan=1 colspan=1>36,665.22</td><td rowspan=1 colspan=1>13,890.30</td><td rowspan=1 colspan=1>2.64</td></tr><tr><td rowspan=1 colspan=1>发行人2025年情况（压力传感器）</td><td rowspan=1 colspan=1>67, 431. 69</td><td rowspan=1 colspan=1>25,233. 60</td><td rowspan=1 colspan=1>2. 67</td></tr></table>

注：发行人 2025 年压力传感器产值系假设 2025 年的产量全部外销的收入。

如上表所示，本次募投项目压力传感器扩产项目、陶瓷电容式压力传感器产线升级项目中单位固定资产产能或产值与公司现有水平（包括IPO 募投项目）基本匹配。

综上，本次募投项目压力传感器扩产项目、陶瓷电容式压力传感器产线升级中单位固定资产产能或产值与公司现有水平（包括IPO 募投项目）相匹配，投入具有合理性。

## （2）陶瓷电容式压力传感器产线升级项目

①具体设备购置内容、价格和作用等情况，拟购置设备的更新或升级情况

本项目设备购置费用为 6,459.00 万元，发行人将对现有 13 条产线进行技术改造（其中2 条为配套线），提升公司现有产线的标准化及自动化程度，助力公司扩充产能、降本增效、优化生产工序、提升产品工艺精度，具体如下所示：

<table><tr><td colspan="1" rowspan="1">主要设备</td><td colspan="1" rowspan="1">产线/设备作用</td><td colspan="1" rowspan="1">购置数量（台）</td><td colspan="1" rowspan="1">购置金额(万元)</td><td colspan="1" rowspan="1">是否为更新或升级</td></tr><tr><td colspan="1" rowspan="1">手工标定设备、功能测试</td><td colspan="1" rowspan="1">用于陶瓷压力</td><td colspan="1" rowspan="1">54</td><td colspan="1" rowspan="1">6,459.00</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">设备、氨检测试设备、点胶设备、终检设备等</td><td colspan="1" rowspan="1">传感器扩产</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

②相关投入规模的合理性

参见前文陶瓷电容式压力传感器产线升级项目与发行人 IPO 阶段压力传感器建设项目的单位固定资产产能比较情况、单位固定资产产值比较情况，陶瓷电容式压力传感器产线升级中单位固定资产产能或产值与公司现有水平（包括IPO募投项目）相匹配，投入具有合理性。

## （3）力传感器产线建设项目

①具体设备购置内容、价格和作用等情况，拟购置设备的更新或升级情况

本项目为全新产线，设备及软件购置5,103.60 万元，其中包括力传感器产线-MEMS 硅基工艺（前段+组装）2条、力传感器产线-金属应变片工艺（前段+组装）1 条、标定及包装设备（共用，含测试软件）、机加工设备、环保及配套设备等。

项目设备购置明细如下：
<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>生产线名称</td><td rowspan=1 colspan=1>主要设备</td><td rowspan=1 colspan=1>产线/设备作用</td><td rowspan=1 colspan=1>设备数量（台）</td><td rowspan=1 colspan=1>合计金额（万元）</td><td rowspan=1 colspan=1>是否为更新或升级</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>力传感器产线-MEMS 硅基工艺（前段+组装）</td><td rowspan=1 colspan=1>全自动丝印机、隧道炉、全自动Gage 自动贴片、自动粘板拼接设备、全自动绑线机等</td><td rowspan=2 colspan=1>用于力传感器扩产</td><td rowspan=1 colspan=1>37</td><td rowspan=1 colspan=1>1,604.70</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>力传感器产线-金属应变片工艺（前段+组装）</td><td rowspan=1 colspan=1>气相自动清洗、全自动贴片机、自动上夹具机、高温固化隧道炉等</td><td rowspan=1 colspan=1>53</td><td rowspan=1 colspan=1>971.30</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>标定及包装设备</td><td rowspan=1 colspan=1>六维力联合标定测力机、扭矩机、自动包装机等</td><td rowspan=2 colspan=1></td><td rowspan=1 colspan=1>44</td><td rowspan=1 colspan=1>1,929.60</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>机加工设备</td><td rowspan=1 colspan=1>四轴加工中心、五轴加工中心、数控机床等</td><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>498.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>环保及配套设备</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>环保配套</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=3>合计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>5,103.60</td><td rowspan=1 colspan=1>否</td></tr></table>

②相关投入规模的合理性

力传感器产线建设项目计划通过购置全新生产设备，新增年产约 50 万个力传感器产能。根据单条产线对应产能进行预估，本项目需要新建共3条产线以达成产能目标。具体单线产能情况如下：

<table><tr><td rowspan=1 colspan=1>瓶颈工序</td><td rowspan=1 colspan=1>每小时产量（个/小时）</td><td rowspan=1 colspan=1>每日班数（班/天）</td><td rowspan=1 colspan=1>每班工时（小时/班）</td><td rowspan=1 colspan=1>全年工作天数（天）</td><td rowspan=1 colspan=1>合格率（%）</td><td rowspan=1 colspan=1>单线对应产能（万个/年）</td></tr><tr><td rowspan=1 colspan=1>标定</td><td rowspan=1 colspan=1>55.0</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>10.5</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>97.00</td><td rowspan=1 colspan=1>16.81</td></tr></table>

公司基于产线各工序所需设备及设备供应商报价进行投入预算，设备（产线）数量、投入金额与新增产能相匹配，投入具有合理性。

## （4）MEMS 传感器芯片研发及产业化项目

①具体设备购置内容、价格和作用等情况，拟购置设备的更新或升级情况

本项目为全新产线，设备购置 2,610.00 万元，为 3条 MEMS 压力传感器芯片模组产线的投入，具体如下：

<table><tr><td rowspan=1 colspan=1>生产线名称</td><td rowspan=1 colspan=1>设备名称</td><td rowspan=1 colspan=1>产线/设备作用</td><td rowspan=1 colspan=1>生产线数量（条）</td><td rowspan=1 colspan=1>单线金额（万元）</td><td rowspan=1 colspan=1>合计金额（万元）</td><td rowspan=1 colspan=1>是否为更新或升级</td></tr><tr><td rowspan=1 colspan=1>MEMS压力传感器芯片模组产线</td><td rowspan=1 colspan=1>固晶机、焊线机、标定设备等</td><td rowspan=1 colspan=1>用于芯片模组扩产</td><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>870.00</td><td rowspan=1 colspan=1>2,610.00</td><td rowspan=1 colspan=1>否</td></tr></table>

②相关投入规模的合理性

本项目实施后，公司将形成年产逾 500 万个 MEMS 压力传感器芯片模组的产能规模，全部用于自供，充分满足公司MEMS 压力传感器芯片模组对于MEMS压力传感器的自产需求。根据单条产线对应产能进行预估，本项目需要新建共3条产线以达成产能目标。具体单线产能情况如下：

<table><tr><td rowspan=1 colspan=1>瓶颈工序</td><td rowspan=1 colspan=1>每小时产量（个/小时）</td><td rowspan=1 colspan=1>每日班数（班/天）</td><td rowspan=1 colspan=1>每班工时（小时/班）</td><td rowspan=1 colspan=1>全年工作天数（天）</td><td rowspan=1 colspan=1>合格率（%）</td><td rowspan=1 colspan=1>单线对应产能（万个/年）</td></tr><tr><td rowspan=1 colspan=1>焊线</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>10.0</td><td rowspan=1 colspan=1>300</td><td rowspan=1 colspan=1>99.5</td><td rowspan=1 colspan=1>179.10</td></tr></table>

公司基于产线各工序所需设备及设备供应商报价进行投入预算，设备（产线）数量、投入金额与新增产能相匹配，投入具有合理性。

## 2、测算并说明募集资金投入的经济性

本次募集资金投入具有经济性，单位投入产出比表现均优于前次募投项目及同行业可比项目，相关测算详见本问询回复之“问题 2/一、发行人说明/（九）结合本次募投项目的投资明细和募集资金拟投入情况，投入产出比测算等情况，

说明本次融资必要性，量化测算并说明补充流动资金的规模合理性，本次补充流动资金占比是否符合《证券期货法律适用意见第 18 号》相关规定”中关于投入产出比测算情况。

## 3、本次募投项目、拟建及在建项目等新增折旧摊销对发行人未来盈利能力及经营业绩的影响

## （1）本次募投项目新增折旧摊销对发行人未来盈利能力及经营业绩的影响

本次募投项目折旧与摊销金额主要系项目建设期内房屋装修支出及软硬件设备购置支出所致。根据募投项目测算，本次四个募投项目主要于 T+4 或 T+5年达产， T+1 至T+5 年每年折旧摊销金额如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>T+1</td><td rowspan=1 colspan=1>T+2</td><td rowspan=1 colspan=1>T+3</td><td rowspan=1 colspan=1>T+4</td><td rowspan=1 colspan=1>T+5</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>83.38</td><td rowspan=1 colspan=1>1,875.10</td><td rowspan=1 colspan=1>2,603.08</td><td rowspan=1 colspan=1>2,603.08</td><td rowspan=1 colspan=1>2,186.41</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>22.75</td><td rowspan=1 colspan=1>415.42</td><td rowspan=1 colspan=1>542.27</td><td rowspan=1 colspan=1>542.27</td><td rowspan=1 colspan=1>542.27</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>65.10</td><td rowspan=1 colspan=1>383.81</td><td rowspan=1 colspan=1>608.11</td><td rowspan=1 colspan=1>608.11</td><td rowspan=1 colspan=1>608.11</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>9.41</td><td rowspan=1 colspan=1>174.17</td><td rowspan=1 colspan=1>283.88</td><td rowspan=1 colspan=1>283.88</td><td rowspan=1 colspan=1>283.88</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>180.64</td><td rowspan=1 colspan=1>2,848.51</td><td rowspan=1 colspan=1>4,037.34</td><td rowspan=1 colspan=1>4,037.34</td><td rowspan=1 colspan=1>3,620.68</td></tr></table>

从上表可以看出，本次募投项目 T+1 至 T+5 年平均每年折旧摊销金额为2,944.90 万元。以本次募投项目收入完全释放后的第一年进行测算，募投项目新增收入预计 116,519.68 万元，新增净利润预计 12,276.85 万元（不考虑仅自供不对外销售的 MEMS 传感器芯片研发及产业化项目，该项目能够达到可观的降本目的，若考虑该降本效果，净利润可增加更大规模）。平均每年折旧摊销金额占预计营业收入的比例为2.53%，占预计净利润的比例为23.99%。

虽然本次募投项目的实施形成的资产将导致公司折旧摊销金额增加，但整体影响较小，且随着募投项目实施后带来的营业收入和净利润增加，公司总体经营规模将会持续上升，将有效提高公司的市场竞争地位。

## （2）主要拟建及在建项目新增折旧摊销对发行人未来盈利能力及经营业绩的影响

发行人主要拟建项目折旧与摊销为发行人前次募集资金投资项目之超募资金投资项目建设期内房屋装修支出及软硬件设备购置支出所致。根据前次募集资金超募资金投资项目测算，两个募投项目分别于T+4 或T+5年达产，T+1至T+5年每年折旧摊销金额如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>T+1年</td><td rowspan=1 colspan=1>T+2年</td><td rowspan=1 colspan=1>T+3年</td><td rowspan=1 colspan=1>T+4年</td><td rowspan=1 colspan=1>T+5年</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>新一代智能驾驶刹车系统用力传感器建设项目</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>227.00</td><td rowspan=1 colspan=1>227.00</td><td rowspan=1 colspan=1>227.00</td><td rowspan=1 colspan=1>227.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>贴片式NTC 热敏电阻研发及产业化建设项目</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>28.31</td><td rowspan=1 colspan=1>267.39</td><td rowspan=1 colspan=1>267.39</td><td rowspan=1 colspan=1>267.39</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>255.31</td><td rowspan=1 colspan=1>494.39</td><td rowspan=1 colspan=1>494.39</td><td rowspan=1 colspan=1>494.39</td></tr></table>

从上表可以看出，前次募集资金超募资金投资项目 T+1 至 T+5 年平均每年折旧摊销金额为 347.69 万元。以前次募集资金超募资金投资项目收入完全释放后的第一年进行测算，超募项目新增收入预计19,562.81 万元，新增净利润预计2,533.79 万元。平均每年折旧摊销金额占预计营业收入的比例为 1.78%，占预计净利润的比例为4.22%。虽然前次募集资金超募资金投资项目的实施形成的资产将导致公司折旧摊销金额增加，但整体影响较小，且随着前次募集资金超募资金投资项目实施后带来的营业收入和净利润增加，公司总体经营规模将会持续上升，将有效提高公司的市场竞争地位。

截至报告期末，发行人其他主要在建及拟建项目如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>项目投资总额</td><td rowspan=1 colspan=1>资本性支出投入</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>在制设备-全自动产线项目</td><td rowspan=1 colspan=1>3,150.00</td><td rowspan=1 colspan=1>3,150.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>泰国传感器基地项目装修工程项目</td><td rowspan=1 colspan=1>357. 69</td><td rowspan=1 colspan=1>357. 69</td></tr></table>

截至报告期末，发行人其他主要在建项目为在制设备-全自动产线项目，该项目涉及的资本性支出主要为设备购置支出；发行人其他主要拟建项目为泰国传感器基地项目装修工程项目，该项目涉及的资本性支出主要为装修工程支出。假设发行人营业收入及净利润按 2025 年度营业收入及净利润金额进行测算（该假设仅为测算新增折旧摊销对公司未来经营业绩的影响，不代表公司对未来年度盈利情况的承诺，也不代表公司对未来年度经营情况及趋势的判断），预计年新增折旧摊销约为 370.79 万元，新增折旧摊销占年营业收入的比例为 0.31%，占年净利润的比例为4.09%，总体占比较小。虽然该项目的实施形成的资产将导致公司折旧摊销金额增加，但整体影响较小，且该项目实施有助于公司节省人工成本、提高生产效率、满足下游客户需要，公司总体经营规模将会持续上升，将有效提高公司的市场竞争地位。

综上，公司本次募集资金投资项目、其他在建和拟建项目实施形成的资产将导致公司折旧摊销金额有所增加，但整体影响较小，且各项目实施后带来的营业收入和净利润增加、成本的节约，将有效提升公司未来盈利能力，助力公司业绩增长。

（六）说明本次募投项目是否已取得开展所需的相关资质、认证、许可及备案，是否存在重大不确定性或实质性障碍；项目四使用租赁土地的原因及合理性，土地的用途、使用年限、租用年限、租金及到期后对土地的处置计划

## 1、本次募投项目的环评批复及备案情况

截至本回复出具日，发行人本次发行募投项目的项目备案及环评批复情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>备案编号</td><td rowspan=1 colspan=1>环评批复/备案</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>深坪山发改备案（2025）522号</td><td rowspan=1 colspan=1>深环坪备[2025]077 号</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>深坪山发改备案[2025]1523 号</td><td rowspan=1 colspan=1>本项目已于2024年2月取得深圳市生态环境局坪山管理局出具的《告知性备案回执》（深环坪备[2024]027号)，该次环评审批手续已覆盖本次升级项目，本项目无需另行办理环评审批手续</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>深坪山发改备案[2026]2 号</td><td rowspan=1 colspan=1>无需办理环评手续</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>深坪山发改备案[2025]1481号、《上海市企业投资项目备案证明》（项目代码：上海代码：310114MADMBWQ0320251D3101001，国家代码：2512-310114-04-01-899915)</td><td rowspan=1 colspan=1>无需办理环评手续</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>补充流动资金</td><td rowspan=1 colspan=1>不涉及</td><td rowspan=1 colspan=1>不涉及</td></tr></table>

根据深圳市生态环境局坪山管理局 2025 年5 月16 日发布的《<坪山区高新南先进制造业园区区域空间生态环境管理清单>：哪些项目还需审批，哪些项目豁免环评？》，“在已公布管理清单的区域，纳入《深圳市区域空间生态环境评价重点项目环境影响审批名录（试行）》的建设项目实施审批管理，建设单位应依法组织开展建设项目环境影响评价，编制环境影响评价文件报送有审批权的生态环境主管部门审批。未纳入《深圳市区域空间生态环境评价重点项目环境影响审批名录（试行）》的建设项目实施清单管理，建设单位无需进行环境影响评价，执行所在评价单元的管理清单有关规定，按管理清单要求在环境信息公开平台（专栏）进行信息公开。”根据《深圳市区域空间生态环境评价重点项目环境影响审批名录（试行）》，涉及“电子元件及电子专用材料制造 398”中的“半导体材料制造；印刷电路板制造；电子专用材料制造”需办理环境影响报告表，而发行人“力传感器产线建设项目”及“MEMS 传感器芯片研发及产业化项目”属于“敏感元件及传感器制造”，不涉及以上内容，不需要办理环境影响报告表，属于名录未作规定的建设项目，不纳入建设项目环境影响评价管理，无需履行环境影响评价相关的审批或备案程序。因此，发行人“力传感器产线建设项目”及“MEMS 传感器芯片研发及产业化项目”位于深圳部分均无需办理环评审批手续。

根据《〈建设项目环境影响评价分类管理名录〉上海市实施细化规定（2021年版）》（沪环规〔2021〕11号），涉及“印刷电路板制造；电子专用材料制造（电子化工材料制造除外）；使用有机溶剂的；有酸洗的（以上均不含仅简单机加工的）”需办理环境影响报告表，而发行人“MEMS 传感器芯片研发及产业化项目”属于“敏感元件及传感器制造”，不涉及以上内容，不需要办理环境影响报告表，属于名录未作规定的建设项目，不纳入建设项目环境影响评价管理，无需履行环境影响评价相关的审批或备案程序。因此，本项目位于上海部分无需办理环评审批手续。

截至本回复出具日，除“力传感器产线建设项目”及“MEMS 传感器芯片研发及产业化项目”无需办理环评手续及“补充流动资金项目”不涉及项目备案及环评手续外，发行人本次发行的募投项目均已取得项目立项备案以及环境影响评价的批复文件。

除前述项目立项备案、环评手续外，发行人本次发行的募投项目不涉及需办理其他资质、认证、许可及备案的情形。

综上，发行人本次募投项目已取得开展所需的相关资质、认证、许可及备案，不存在重大不确定性或实质性障碍。

## 2、项目四使用租赁土地的原因及合理性

项目四实施主体为安培龙及上海安培龙，建设地点分别位于深圳市坪山区坑梓街道金沙社区聚园路 1 号安培龙智能传感器产业园及上海市嘉定区江桥镇金园四路188 号，其中上海安培龙使用租赁厂房。

目前发行人及其子公司拥有的房屋建筑物主要位于广东省深圳市和东莞市。项目四实施主体之一上海安培龙使用租赁厂房形式实施募投项目，有利于减少大额资本性支出，提高资金使用效率，降低新购置土地及厂房建设的不确定性，提升项目灵活性，具备合理性。具体如下：

（1）使用租赁厂房可有效避免土地购置、厂房建设及长期维护的资本性支出，将资金集中于购置生产设备、产线建设等核心业务环节，提高资金使用效率。

（2）相较于购置土地及厂房建设流程中存在的政策审批等周期不确定性，租赁成熟场地可快速启动项目建设，确保及时进入市场、响应市场需求，形成有效市场竞争力；

（3）如募投项目在未来需根据市场需求进行扩张或调整，租赁厂房模式可提供更高的灵活性，更高效地支持调整产能或更换场地。

综上，项目四使用租赁厂房具备合理性。

## 3、土地的用途、使用年限、租用年限、租金及到期后对土地的处置计划

本次募投项目“MEMS 传感器芯片研发及产业化项目”实施主体之一上海安培龙通过租赁已建成厂房作为项目的实施地，具体厂房租赁情况如下：

<table><tr><td rowspan=1 colspan=1>承租方</td><td rowspan=1 colspan=1>出租方</td><td rowspan=1 colspan=1>地址</td><td rowspan=1 colspan=1>租赁面积（m）</td><td rowspan=1 colspan=1>租金</td><td rowspan=1 colspan=1>租赁期限</td><td rowspan=1 colspan=1>厂房所在土地用途</td><td rowspan=1 colspan=1>产权证号</td></tr><tr><td rowspan=1 colspan=1>上海安培龙</td><td rowspan=1 colspan=1>上海愉虹企业发展有限公司</td><td rowspan=1 colspan=1>上海市嘉定区江桥镇金园四路188号2幢106厂房</td><td rowspan=1 colspan=1>630</td><td rowspan=1 colspan=1>2.59万元/月（每满2年递增6%）</td><td rowspan=1 colspan=1>2025.05.10-2028.05.09</td><td rowspan=1 colspan=1>工业</td><td rowspan=1 colspan=1>沪房地嘉字（2003）第009896号</td></tr></table>

本项目不涉及租赁土地的情形，不涉及到期后对土地的处置计划。

根据上海安培龙与出租方签署的《租赁合同》的约定，租赁期满后，上海安培龙继续承租的，则应于租赁期届满前三个月，向出租方提出续租书面要求，经

出租方同意后，双方应重新签订租赁合同，同等条件下，上海安培龙有优先续租权。因此，即使该房屋租赁到期，同等条件下，上海安培龙有优先承租的权利。

（七）结合报告期内关联交易的具体情况，说明本次募投项目的实施是否新增关联交易，如是，新增关联交易价格的公允性及保证公平的相关措施，是否符合《注册办法》第十二条的相关规定

## 1、报告期内关联交易情况

报告期内，公司与关联方发生的经常性关联交易及偶发性关联交易对本公司的财务状况和经营成果无重大影响，关联采购占原材料采购总额比例分别为0.40%、0%和 0%，关联销售占营业收入比例分别为 0.64%、0.07%和 0.06%，占比极低。具体如下：

## （1）经常性关联交易

①采购商品、接受劳务情况

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>海纳微及其子公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>110.77</td></tr></table>

注：根据《上市规则》，海纳微 2024 年、2025 年不再认定为发行人关联方。下同。

②销售商品、提供劳务情况

单位：万元

<table><tr><td rowspan=1 colspan=1>关联方</td><td rowspan=1 colspan=1>关联交易内容</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>海纳微及其子公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>411.86</td></tr><tr><td rowspan=1 colspan=1>深圳市安士利科技有限公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>42.57</td><td rowspan=1 colspan=1>53.95</td><td rowspan=1 colspan=1>54.81</td></tr><tr><td rowspan=1 colspan=1>成都兴利佳科技有限公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>18.85</td><td rowspan=1 colspan=1>7.38</td><td rowspan=1 colspan=1>8.77</td></tr><tr><td rowspan=1 colspan=1>广东天机智能系统有限公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>2.90</td><td rowspan=1 colspan=1>0.75</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>深圳菲菱科思通信技术股份有限公司</td><td rowspan=1 colspan=1>电子元器件</td><td rowspan=1 colspan=1>1.74</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td></tr></table>

③关键管理人员薪酬

报告期内，公司关键管理人员在公司领取薪酬的情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>关键管理人员报酬</td><td rowspan=1 colspan=1>563. 02</td><td rowspan=1 colspan=1>447.13</td><td rowspan=1 colspan=1>381.20</td></tr></table>

单位：万元

## （2）偶发性关联交易

①2023 年度

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">担保方</td><td colspan="1" rowspan="1">被担保方</td><td colspan="1" rowspan="1">担保协议签署日</td><td colspan="1" rowspan="1">担保金额（万元）</td><td colspan="1" rowspan="1">担保合同约定的保证责任期间</td><td colspan="1" rowspan="1">担保类型</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.08.29</td><td colspan="1" rowspan="1">7,000</td><td colspan="1" rowspan="1">自保证书生效之日起至主合同项下债务履行期（包括展期、延期）届满之日后满三年之日止。若主合同项下债务分期履行，则每期债务保证期间均为自本保证书生效之日起至主合同项下最后一期债务履行期限届满之日后满三年之日止。若主合同项下债务被宣布提前到期的，保证期间至债务被宣布提前到期之日后满三年之日止。</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.09.13</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">主合同约定的债务人债务履行期限届满之日起两年。主合同约定债务分笔到期的，则保证期间为每笔债务履行期限届满之日起两年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.05.12</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">保证期间为三年，起算日按如下方式确定：任何一笔债务的履行期限届满日早于或同于被担保债权的确定日时，保证期间起算日为被担保债权的确定日；任何一笔债务的履行期限届满日晚于被担保债权的确定日时，保证期间起算日为该笔债务的履行期限届满日。</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.05.16</td><td colspan="1" rowspan="1">15,000</td><td colspan="1" rowspan="1">若主合同为借款合同或贵金属租赁合同，则保证期间为自主合同项下的借款期限或贵金属租赁期限届满之次日起三年或借款或贵金属提前到期日之次日起三年；若主合同为银行承兑协议，则保证期间为自债权人对外承付之次日起三年；若主合同为开立担保协议，则保证期间为自债权人履行担保义务之次日起三年；若主合同为信用证开证协议/合同，则保证期间为自债权人支付信用证项下款项之次日起三年；若主合同为其他融资文件，则保证期间自主合同确定的债权到期或提前到期之次日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.04.17</td><td colspan="1" rowspan="1">3,000</td><td colspan="1" rowspan="1">主合同约定的债务人债务履行期限届满之日起两年。主合同约定债务</td><td colspan="1" rowspan="1">连带责任</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">分笔到期的，则保证期间为每笔债务履行期限届满之日起两年</td><td colspan="1" rowspan="1">保证</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.03.09</td><td colspan="1" rowspan="1">6,000</td><td colspan="1" rowspan="1">主合同项下债务履行期限届满之日起三年，即自债务人依具体业务合同约定的债务履行期限届满之日起满三年。每一具体业务合同项下的保证期间单独计算。</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.02.21</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">主合同下的债务履行期届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.02.20</td><td colspan="1" rowspan="1">30,000</td><td colspan="1" rowspan="1">主合同项下每笔债务履行期届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.12.06</td><td colspan="1" rowspan="1">15,000</td><td colspan="1" rowspan="1">若主合同为借款合同或贵金属租赁合同，则保证期间为自主合同项下的借款期限或贵金属租赁期限届满之次日起三年或借款或贵金属提前到期日之次日起三年；若主合同为银行承兑协议，则保证期间为自债权人对外承付之次日起三年；若主合同为开立担保协议，则保证期间为自债权人履行担保义务之次日起三年；若主合同为信用证开证协议/合同，则保证期间为自债权人支付信用证项下款项之次日起三年；若主合同为其他融资文件，则保证期间自主合同确定的债权到期或提前到期之次日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.12.01</td><td colspan="1" rowspan="1">3,000</td><td colspan="1" rowspan="1">自每笔债权合同债务履行期届满之日起至该债权合同约定的债务履行期届满之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">郭若军</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.11.24</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">自具体授信业务合同或协议约定的授信人履行债务期间届满之日或债务提前到期日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">12</td><td colspan="1" rowspan="1">郭若军</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.09.20</td><td colspan="1" rowspan="1">3,500</td><td colspan="1" rowspan="1">担保合同项下所担保的债务逐笔单独计算保证期间，各债务保证期间为该笔债务履行期限届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">13</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.09.14</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">主合同项下每一笔具体融资业务的保证期限单独计算，为自具体融资合同约定的债务人履行期限届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">14</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.04.14</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">具体业务项下的债务履行期限届满日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">15</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2021.03.05</td><td colspan="1" rowspan="1">3,000</td><td colspan="1" rowspan="1">担保书生效之日起至授信协议项下每笔贷款或其他融资或银行受让的应收账款债权到日期或每笔垫款的</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">垫款日另加三年</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">16</td><td colspan="1" rowspan="1">邬若军</td><td colspan="1" rowspan="1">发行人20</td><td colspan="1" rowspan="1">22.03.03</td><td colspan="1" rowspan="1">7,500</td><td colspan="1" rowspan="1">保证期间按债权人对债务人单笔融资分别计算，自单笔融资业务起始日至该笔债务履行期限届满之日后3年止，如债权人宣布债务提前到期的，保证期间至债务提前到期之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">17</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2021.11.19</td><td colspan="1" rowspan="1">6,000</td><td colspan="1" rowspan="1">具体业务项下的债务履行期限届满日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">18</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2021.08.16</td><td colspan="1" rowspan="1">27,426</td><td colspan="1" rowspan="1">主债权的清偿期届满之日起三年。如主债权为分期清偿，则保证期间为自担保合同生效之日起至最后一期债务履行期届满之日后三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">19</td><td colspan="1" rowspan="1">邬若军</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2021.03.24</td><td colspan="1" rowspan="1">2,000</td><td colspan="1" rowspan="1">自担保合同生效之日起至主合同项下债务履行期间届满之日后三年止。担保方同意债务展期的，保证期间至展期协议重新约定的债务履行期限届满之日后三年止。若债务人根据主合同约定，宣布债务提前到期的，保证期间至债务人宣布的债务提前到期日后三年止。如果主合同项下的债务分期履行，则对每期债务而言，保证期间均至最后一期债务履行期间届满之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr></table>

度

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">担保方</td><td colspan="1" rowspan="1">被担保方</td><td colspan="1" rowspan="1">担保协议签署日</td><td colspan="1" rowspan="1">担保金额（万元）</td><td colspan="1" rowspan="1">担保合同约定的保证责任期间</td><td colspan="1" rowspan="1">担保类型</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2024.01.02</td><td colspan="1" rowspan="1">6,600</td><td colspan="1" rowspan="1">主合同项下债务履行期限届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.08.29</td><td colspan="1" rowspan="1">7,000</td><td colspan="1" rowspan="1">自保证书生效之日起至主合同项下债务履行期（包括展期、延期）届满之日后满三年之日止。若主合同项下债务分期履行，则每期债务保证期间均为自本保证书生效之日起至主合同项下最后一期债务履行期限届满之日后满三年之日止。若主合同项下债务被宣布提前到期的，保证期间至债务被宣布提前到期之日后满三年之日止。</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.09.13</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">主合同约定的债务人债务履行期限届满之日起两年。主合同约定债务分笔到期的，则保证期间为每笔债务履行期限届满之日起两年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">郭若军、</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.05.12</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">保证期间为三年，起算日按如下方</td><td colspan="1" rowspan="1">连带</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">黎莉</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">式确定：任何一笔债务的履行期限届满日早于或同于被担保债权的确定日时，保证期间起算日为被担保债权的确定日；任何一笔债务的履行期限届满日晚于被担保债权的确定日时，保证期间起算日为该笔债务的履行期限届满日。</td><td colspan="1" rowspan="1">责任保证</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.05.16</td><td colspan="1" rowspan="1">15,000</td><td colspan="1" rowspan="1">若主合同为借款合同或贵金属租赁合同，则保证期间为自主合同项下的借款期限或贵金属租赁期限届满之次日起三年或借款或贵金属提前到期日之次日起三年；若主合同为银行承兑协议，则保证期间为自债权人对外承付之次日起三年；若主合同为开立担保协议，则保证期间为自债权人履行担保义务之次日起三年；若主合同为信用证开证协议/合同，则保证期间为自债权人支付信用证项下款项之次日起三年；若主合同为其他融资文件，则保证期间自主合同确定的债权到期或提前到期之次日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.04.17</td><td colspan="1" rowspan="1">3,000</td><td colspan="1" rowspan="1">主合同约定的债务人债务履行期限届满之日起两年。主合同约定债务分笔到期的，则保证期间为每笔债务履行期限届满之日起两年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.04.14</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">具体业务项下的债务履行期限届满日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.02.20</td><td colspan="1" rowspan="1">30,000</td><td colspan="1" rowspan="1">主合同项下每笔债务履行期届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.12.06</td><td colspan="1" rowspan="1">15,000</td><td colspan="1" rowspan="1">若主合同为借款合同或贵金属租赁合同，则保证期间为自主合同项下的借款期限或贵金属租赁期限届满之次日起三年或借款或贵金属提前到期日之次日起三年；若主合同为银行承兑协议，则保证期间为自债权人对外承付之次日起三年；若主合同为开立担保协议，则保证期间为自债权人履行担保义务之次日起三年；若主合同为信用证开证协议/合同，则保证期间为自债权人支付信用证项下款项之次日起三年；若主合同为其他融资文件，则保证期间自主合同确定的债权到期或提前到期之次日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">郭若军、</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.12.01</td><td colspan="1" rowspan="1">3,000</td><td colspan="1" rowspan="1">自每笔债权合同债务履行期届满之</td><td colspan="1" rowspan="1">连带</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">黎莉</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日起至该债权合同约定的债务履行期届满之日后三年止</td><td colspan="1" rowspan="1">责任保证</td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">郭若军</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.11.24</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">自具体授信业务合同或协议约定的授信人履行债务期间届满之日或债务提前到期日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">12</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.02.21</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">主合同下的债务履行期届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">13</td><td colspan="1" rowspan="1">郭若军</td><td colspan="1" rowspan="1">发行人2</td><td colspan="1" rowspan="1">022.03.03</td><td colspan="1" rowspan="1">7,500</td><td colspan="1" rowspan="1">保证期间按债权人对债务人单笔融资分别计算，自单笔融资业务起始日至该笔债务履行期限届满之日后3年止，如债权人宣布债务提前到期的，保证期间至债务提前到期之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">14</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人2</td><td colspan="1" rowspan="1">021.08.16</td><td colspan="1" rowspan="1">27,426</td><td colspan="1" rowspan="1">主债权的清偿期届满之日起三年。如主债权为分期清偿，则保证期间为自担保合同生效之日起至最后一期债务履行期届满之日后三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr></table>

③2025 年度

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">担保方</td><td colspan="1" rowspan="1">被担保方</td><td colspan="1" rowspan="1">担保协议签署日</td><td colspan="1" rowspan="1">担保金额（万元）</td><td colspan="1" rowspan="1">担保合同约定的保证责任期间</td><td colspan="1" rowspan="1">担保类型</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">郭若军</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.03.03</td><td colspan="1" rowspan="1">7,500</td><td colspan="1" rowspan="1">保证期间按债权人对债务人单笔融资分别计算，自单笔融资业务起始日至该笔债务履行期限届满之日后3年止，如债权人宣布债务提前到期的，保证期间至债务提前到期之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">邬若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2022.12.06</td><td colspan="1" rowspan="1">15,000</td><td colspan="1" rowspan="1">若主合同为借款合同或贵金属租赁合同，则保证期间为自主合同项下的借款期限或贵金属租赁期限届满之次日起三年或借款或贵金属提前到期日之次日起三年；若主合同为银行承兑协议，则保证期间为自债权人对外承付之次日起三年；若主合同为开立担保协议，则保证期间为自债权人履行担保义务之次日起三年；若主合同为信用证开证协议/合同，则保证期间为自债权人支付信用证项下款项之次日起三年；若主合同为其他融资文件，则保证期间自主合同确定的债权到期或提前到期之次日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.02.21</td><td colspan="1" rowspan="1">5,000</td><td colspan="1" rowspan="1">主合同下的债务履行期届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.09.13</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">主合同约定的债务人债务履行期限届满之日起两年。主合同约定债务分笔到期的，则保证期间为每笔债务履行期限届满之日起两年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2023.05.12</td><td colspan="1" rowspan="1">10,000</td><td colspan="1" rowspan="1">保证期间为三年，起算日按如下方式确定：任何一笔债务的履行期限届满日早于或同于被担保债权的确定日时，保证期间起算日为被担保债权的确定日；任何一笔债务的履行期限届满日晚于被担保债权的确定日时，保证期间起算日为该笔债务的履行期限届满日</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">郭若军、黎莉</td><td colspan="1" rowspan="1">发行人</td><td colspan="1" rowspan="1">2024.01.02</td><td colspan="1" rowspan="1">6,600</td><td colspan="1" rowspan="1">主合同项下债务履行期限届满之日起三年</td><td colspan="1" rowspan="1">连带责任保证</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">邬若军|发</td><td colspan="1" rowspan="1">行人|2</td><td colspan="1" rowspan="1">025.11.27</td><td colspan="1" rowspan="1">5,550</td><td colspan="1" rowspan="1">为发行人在相关融资租赁合同项下的履约义务提供担保，担保期间为保证函生效之日起至相关融资租赁合同项下的债务履行期限届满之日后三年止</td><td colspan="1" rowspan="1">连带责任保证</td></tr></table>

## 2、本次募投项目的实施可能增加关联销售，但为公司正常经营需要，具有合理性和必要性

本次发行募集资金总额不超过54,440.00 万元（含本数），在扣除相关发行费用后的募集资金净额将全部用于以下项目：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资总额</td><td rowspan=1 colspan=1>拟投入募集资金</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>28,000.00</td><td rowspan=1 colspan=1>26,860.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>7,220.00</td><td rowspan=1 colspan=1>6,900.00</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>6,250.00</td><td rowspan=1 colspan=1>6,040.00</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS 传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>5,790.00</td><td rowspan=1 colspan=1>5,640.00</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>补充流动资金</td><td rowspan=1 colspan=1>9,000.00</td><td rowspan=1 colspan=1>9,000.00</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>56,260.00</td><td rowspan=1 colspan=1>54,440.00</td></tr></table>

根据募投项目《可行性研究报告》、募投项目的投资明细等，本次募投项目生产产品主要为压力传感器、陶瓷电容式压力传感器、力传感器、MEMS 传感器芯片模组等。其中，针对“力传感器产线建设项目”的力传感器产品，可能新增向公司报告期内曾经的关联方广东天机智能系统有限公司（以下简称“天机智能”）的关联销售。其他募投项目产品预计不涉及新增向关联方采购原材料或向关联方销售产品。具体如下：

## （1）天机智能与发行人的关联关系

公司报告期内曾经的关联方天机智能主要从事单机自动化设备、自动化线体的设计生产及智能工厂整体改造等业务，是国家级高新技术企业、“专精特新”企业，“专精特新”小巨人、广东省机器人骨干企业。

天机智能是报告期内曾间接持有公司 5%以上股份的自然人陈奇星之女陈曦担任董事长、经理的公司。2025 年 8 月，陈奇星间接持有发行人比例从 5.67%降至4.67%，因此天机智能是发行人报告期内曾经的关联方。根据《深圳证券交易所创业板股票上市规则》等法规规定，自天机智能不再成为关联方的 12 个月内（即截至 2026 年8 月止），双方之间的交易将构成关联交易

## （2）发行人向天机智能可能新增的关联销售具备合理性和必要性，发行人将根据市场化原则定价，保证关联交易公允性

发行人“力传感器产线建设项目”产品包括拉压力传感器、力矩传感器、六维力传感器等，主要下游应用于为机器人领域；而天机智能因其从事单机自动化设备、自动化线体的设计生产及智能工厂整体改造等业务，存在购置力传感器的需求。报告期内，公司已向天机智能小批量送样力传感器产品，销售金额分别为0 万元、0.75 万元和 2.90 万元，处于小批量试产阶段。因此公司“力传感器产线建设项目”的实施可能导致向天机智能的关联销售增加，具备业务合理性和必要性。

若因本次发行募投项目的实施而新增关联交易，发行人将严格按照相关法律、法规和规范性文件的规定履行决策程序与信息披露义务，遵循公允、合理的市场定价原则，保证价格的公允性。

综上所述，本次募投项目可能涉及新增向天机智能的关联销售，为公司正常经营需要，具有合理性和必要性。涉及新增关联交易的定价将遵循市场化原则，保证定价公允。

（八）说明项目四研发费用的主要内容、技术可行性、研发预算及时间安排、目前研发投入及进展、已取得或预计可取得的研发成果等，是否存在较大的研发失败风险，研发投入中拟资本化部分是否符合项目实际情况、是否符合《企业会计准则》的相关规定；结合报告期内发行人同类项目、同行业公司可比项目的资本化情况，说明本次募投项目中拟资本化金额的合理性

报告期内及本次募投项目，公司均不存在研发费用资本化的情形。

## 1、MEMS 传感器芯片研发及产业化项目研发费用的主要内容

本项目研发费用包括研发人员费用、流片费用及测试认证费用，合计2,360.00万元。其中，研发人员费用投入为820 万元（T+1 年及T+2 年的人员投入）。

本项目拟投入研发人员 7 人，包括研发工程师、测试工程师、模拟电路工程师、数字电路工程师、数模验证工程师、系统应用工程师、版图工程师等职能人员。预计第一年实现全部人员到位。项目研发人员薪酬按照 10 年测算（项目建设期 2 年），并同时考虑测算期内的薪酬涨幅（年增长 5%，至达产年 T+5 年后不变），具体如下：

单位：万元/年

<table><tr><td rowspan=1 colspan=1>岗位名称</td><td rowspan=1 colspan=1>T+1年</td><td rowspan=1 colspan=1>T+2年</td><td rowspan=1 colspan=1>T+3年</td><td rowspan=1 colspan=1>T+4年</td><td rowspan=1 colspan=1>T+5年</td><td rowspan=1 colspan=1>T+6年</td><td rowspan=1 colspan=1>T+7年</td><td rowspan=1 colspan=1>T+8年</td><td rowspan=1 colspan=1>T+9年</td><td rowspan=1 colspan=1>T+10年</td></tr><tr><td rowspan=1 colspan=1>研发工程师</td><td rowspan=1 colspan=1>40.00</td><td rowspan=1 colspan=1>42.00</td><td rowspan=1 colspan=1>44.10</td><td rowspan=1 colspan=1>46.31</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td></tr><tr><td rowspan=1 colspan=1>测试工程师</td><td rowspan=1 colspan=1>40.00</td><td rowspan=1 colspan=1>42.00</td><td rowspan=1 colspan=1>44.10</td><td rowspan=1 colspan=1>46.31</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td></tr><tr><td rowspan=1 colspan=1>模拟电路工程师</td><td rowspan=1 colspan=1>80.00</td><td rowspan=1 colspan=1>84.00</td><td rowspan=1 colspan=1>88.20</td><td rowspan=1 colspan=1>92.61</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td></tr><tr><td rowspan=1 colspan=1>数字电路工程师</td><td rowspan=1 colspan=1>80.00</td><td rowspan=1 colspan=1>84.00</td><td rowspan=1 colspan=1>88.20</td><td rowspan=1 colspan=1>92.61</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td></tr><tr><td rowspan=1 colspan=1>数模验证工程师</td><td rowspan=1 colspan=1>80.00</td><td rowspan=1 colspan=1>84.00</td><td rowspan=1 colspan=1>88.20</td><td rowspan=1 colspan=1>92.61</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td><td rowspan=1 colspan=1>97.24</td></tr><tr><td rowspan=1 colspan=1>系统应用工程师</td><td rowspan=1 colspan=1>40.00</td><td rowspan=1 colspan=1>42.00</td><td rowspan=1 colspan=1>44.10</td><td rowspan=1 colspan=1>46.31</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td></tr><tr><td rowspan=1 colspan=1>版图工程师</td><td rowspan=1 colspan=1>40.00</td><td rowspan=1 colspan=1>42.00</td><td rowspan=1 colspan=1>44.10</td><td rowspan=1 colspan=1>46.31</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td><td rowspan=1 colspan=1>48.62</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>400.00</td><td rowspan=1 colspan=1>420.00</td><td rowspan=1 colspan=1>441.00</td><td rowspan=1 colspan=1>463.05</td><td rowspan=1 colspan=1>486.20</td><td rowspan=1 colspan=1>486.20</td><td rowspan=1 colspan=1>486.20</td><td rowspan=1 colspan=1>486.20</td><td rowspan=1 colspan=1>486.20</td><td rowspan=1 colspan=1>486.20</td></tr></table>

流片费用1,200.00 万元，具体情况如下：  
单位：万元

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">产品类型</td><td colspan="1" rowspan="1">流片类型</td><td colspan="1" rowspan="1">金额</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">MEMS 压力传感器感压芯片研发（绝压）</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">MEMS 压力传感器感压芯片研发（表压）</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">单桥压力接口芯片</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">双桥压力接口芯片</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">MEMS 三轴加速感应芯片</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">MEMS 三轴陀螺仪感应芯片</td><td colspan="1" rowspan="1">Full</td><td colspan="1" rowspan="1">200.00</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">1,200.00</td></tr></table>

测试认证费用340.00 万元，具体情况如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>研发课题名</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>投入 (万元）</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>MEMS 压力传感器感压芯片研发（绝压）</td><td rowspan=1 colspan=1>AECQ</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>MEMS 压力传感器感压芯片研发（表压）</td><td rowspan=1 colspan=1>ATE</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=3 colspan=1>3</td><td rowspan=3 colspan=1>单桥压力接口芯片</td><td rowspan=1 colspan=1>EDA</td><td rowspan=1 colspan=1>100.00</td></tr><tr><td rowspan=1 colspan=1>ATE</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>AECQ</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>双桥压力接口芯片</td><td rowspan=1 colspan=1>ATE</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>压力/力传感器半导体应变片</td><td rowspan=1 colspan=1>AECQ</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>MEMS 三轴加速感应芯片</td><td rowspan=1 colspan=1>ATE</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>MEMS 三轴陀螺仪感应芯片</td><td rowspan=1 colspan=1>AECQ</td><td rowspan=1 colspan=1>30.00</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>340.00</td></tr></table>

2、MEMS 传感器芯片研发及产业化项目研发预算及时间安排、技术可行性、目前研发投入及进展、已取得或预计可取得的研发成果等，是否存在较大的研发失败风险

（1）MEMS 传感器芯片研发及产业化项目研发预算及时间安排、技术可行性、目前研发投入及进展、已取得或预计可取得的研发成果

MEMS 传感器芯片研发及产业化项目涉及的主要研发项目的研发预算及时间安排、目前（截至 2026 年2 月末）研发投入及进展、已取得或预计可取得的研发成果等情况如下：

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">储备研发项目名称</td><td colspan="1" rowspan="1">研发的具体内容及技术指标、性能指标</td><td colspan="1" rowspan="1">技术可行性及目前进展</td><td colspan="1" rowspan="1">预计取得研发成果及时间安排</td><td colspan="1" rowspan="1">研发预算（万元）</td><td colspan="1" rowspan="1">目前研发投入（万元）</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">MEMS压力传感器</td><td colspan="1" rowspan="1">研发用于汽车以及消费类电子用MEMS绝</td><td colspan="1" rowspan="1">公司在消费类MEMS压</td><td colspan="1" rowspan="1">完成高性价比贵金属绝</td><td colspan="1" rowspan="1">240</td><td colspan="1" rowspan="1">60</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">感压芯片研发（绝压）</td><td colspan="1" rowspan="1">压感压芯体，实现0-5bar气压的测量，其中汽车用产品使用铂金工艺实现耐腐蚀要求</td><td colspan="1" rowspan="1">力传感器芯片领域已经批量生产供货并获得市场认可，基于目前汽车MEMS 压力传感器的产量飞速增长，结合成熟</td><td colspan="1" rowspan="1">压MEMS；预计1年完成</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">MEMS压力传感器感压芯片研发（表压）</td><td colspan="1" rowspan="1">沿用汽车以及消费类电子用MEMS表压感压芯体，实现0-5bar气压的测量，其中汽车用产品使用铂金工艺实现耐腐蚀要求</td><td colspan="1" rowspan="1">的芯片封装应用经验，该项目整体可靠性较高；公司正在申请相关专利；公司已完成基于SOI的压力传感器芯片的设计与工艺仿真工作，即将开展第一轮流片</td><td colspan="1" rowspan="1">完成高性价比贵金属表压MEMS；预计1年完成</td><td colspan="1" rowspan="1">200</td><td colspan="1" rowspan="1">10</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">MEMS 三轴加速感应芯片</td><td colspan="1" rowspan="1">研发用于汽车以及工业领域用MEMS 三轴加速度感应芯片，量程覆盖±2g，±4g，±6g，±8g，±12g，±16g.用于公司加速度传感器的研发与生产</td><td colspan="1" rowspan="1">公司具备计算，设计以及工艺仿真能力，第一版芯片设计完成；公司正在申请相关专利；工艺仿真进行中，并拟进行流片</td><td colspan="1" rowspan="1">完成高性价比三轴加速度传感器；预计1.5年完成</td><td colspan="1" rowspan="1">320</td><td colspan="1" rowspan="1">10</td></tr><tr><td colspan="1" rowspan="1">MEMS4</td><td colspan="1" rowspan="1">三轴陀螺仪感应芯片</td><td colspan="1" rowspan="1">研发用于汽车以及工业领域用MEMS三轴陀螺仪感应芯片。量程覆盖±100%至±400%s。用于公司加陀螺仪的研发与生产</td><td colspan="1" rowspan="1">公司具备计算及工艺仿真能力；项目可行性分析完成，设计预研中</td><td colspan="1" rowspan="1">完成高性价比三轴陀螺仪传感器；预计1.5年完成</td><td colspan="1" rowspan="1">400</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">压力/力传感器半导体应变片</td><td colspan="1" rowspan="1">优化以及新开发用于玻璃微溶压力传感器的半导体应变片。该应变片也可以用于工业以及机器人用力以及力矩传感器</td><td colspan="1" rowspan="1">公司已经开发成功了硅基应变片，拟重新加入SOI工艺以及开发针对于机器人用特殊形状与参数应变片</td><td colspan="1" rowspan="1">完成高性价比半导体应变片；预计1年完成</td><td colspan="1" rowspan="1">220</td><td colspan="1" rowspan="1">10</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">单桥压力接口芯片</td><td colspan="1" rowspan="1">单桥压力接口芯片是为安培龙MEMS及玻璃微熔等阻式压力传感器提供专用接口电路芯片。该接口芯片采用新一代数模混合工艺，集成国际先进的∑-△（SD）高精度ADC 转换电路，在保证高精度压力信号采集的同时，有效降低系统芯片成本，并显著提升压力检测精度</td><td colspan="1" rowspan="1">该电路设计基于低线宽数模混合 BCD工艺平台，具备良好的工艺适配性。相关电路架构已在国外公开文献中报道；项目已经完成可行性分析。目前正在设计EV样品，计划2026下半年给客户提供样品</td><td colspan="1" rowspan="1">完成高性价国产替代方案；预计1年完成</td><td colspan="1" rowspan="1">580</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">双桥压力</td><td colspan="1" rowspan="1">不同于单桥压力接口</td><td colspan="1" rowspan="1">本电路方案基于单桥压</td><td colspan="1" rowspan="1">实现国内独</td><td colspan="1" rowspan="1">580</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td>接口芯片</td><td>芯片，双桥压力接口芯 片面向ISO 26262 ASIL-D 最高功能安全 等级应用，主要用于汽 车动力链、制动系统等 关键安全场景。除采用 双通道架构外，芯片整 体在电路架构、设计方 法及验证流程等方面 均引入高安全机制，并 通过第三方专业功能 安全机构的评估与认 可</td><td>力接口芯片的成熟设 计，在此基础上对功能 安全架构进行强化，目 标是使系统达到 ISO 26262 ASIL-D 功能安 全等级要求，满足车辆 安全关键应用需求； 项目已经完成可行性分 析。此项目基于单桥压 力接口芯片IP设计。单 桥压力EV 测试结束以 后，团队会立即开始双 桥压力EV样品测试。计 划 2027年初给客户提供 样品</td><td>有的高功能 安全 （ASIL-D) 方案；预计 1.5年完成</td><td></td><td></td></tr></table>

## （2）公司已补充披露相关风险

发行人已在募集说明书“重大事项提示”之“二、重大风险提示”之“（三）募投项目研发失败的风险”和“第七节 与本次发行相关的风险因素”之“二、经营风险”之“5、募投项目研发失败的风险”披露如下：

“公司本次募投项目之一“MEMS 传感器芯片研发及产业化项目”的部分募集资金拟用于研发支出。若未来行业技术革新节奏加快、下游应用场景及市场需求发生重大变化，公司未能及时跟进前沿技术趋势、精准研判市场导向并实现核心技术攻关，或因研发环节存在不确定性、工艺适配难度较大、规模化量产落地存在瓶颈等因素，导致研发成果未能达到预期标准、相关技术无法顺利转化为自主供应产能及产业化效益，将面临募投项目实施失败的风险，进而对公司持续经营能力、盈利水平及核心竞争力产生不利影响。”

（九）结合本次募投项目的投资明细和募集资金拟投入情况，投入产出比测算等情况，说明本次融资必要性，量化测算并说明补充流动资金的规模合理性，本次补充流动资金占比是否符合《证券期货法律适用意见第 18 号》相关规定

1、结合本次募投项目的投资明细和募集资金拟投入情况，投入产出比测算等情况，说明本次融资必要性

## （1）本次募投项目的投资明细和募集资金拟投入情况

本次发行募集资金总额不超过54,440.00 万元（含本数），在扣除相关发行费用后的募集资金净额将全部用于以下项目：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资总额</td><td rowspan=1 colspan=1>拟投入募集资金</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>28,000.00</td><td rowspan=1 colspan=1>26,860.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>7,220.00</td><td rowspan=1 colspan=1>6,900.00</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>6,250.00</td><td rowspan=1 colspan=1>6,040.00</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS 传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>5,790.00</td><td rowspan=1 colspan=1>5,640.00</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>补充流动资金</td><td rowspan=1 colspan=1>9,000.00</td><td rowspan=1 colspan=1>9,000.00</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>56,260.00</td><td rowspan=1 colspan=1>54,440.00</td></tr></table>

“压力传感器扩产项目”总投资 28,000.00 万元，拟使用募集资金投资26,860.00 万元，具体投资安排如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>投资构成</td><td rowspan=1 colspan=1>投资金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>拟投入募集资金</td><td rowspan=1 colspan=1>是否属于资本性支出</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>建设投资</td><td rowspan=1 colspan=1>25,971.92</td><td rowspan=1 colspan=1>92.76%</td><td rowspan=1 colspan=1>25,360.00</td><td rowspan=1 colspan=1>:</td></tr><tr><td rowspan=1 colspan=1>1.1</td><td rowspan=1 colspan=1>装修工程费用</td><td rowspan=1 colspan=1>1,357.10</td><td rowspan=1 colspan=1>4.85%</td><td rowspan=1 colspan=1>1,350.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.2</td><td rowspan=1 colspan=1>设备及软件购置费用</td><td rowspan=1 colspan=1>23,378.07</td><td rowspan=1 colspan=1>83.49%</td><td rowspan=1 colspan=1>22,780.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.3</td><td rowspan=1 colspan=1>预备费</td><td rowspan=1 colspan=1>1,236.76</td><td rowspan=1 colspan=1>4.42%</td><td rowspan=1 colspan=1>1,230.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>铺底流动资金</td><td rowspan=1 colspan=1>2,028.08</td><td rowspan=1 colspan=1>7.24%</td><td rowspan=1 colspan=1>1,500.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>28,000.00</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>26,860.00</td><td rowspan=1 colspan=1>一</td></tr></table>

“陶瓷电容式压力传感器产线升级项目”总投资7,220.00 万元，拟使用募集资金投资6,900.00 万元，具体投资安排如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">投资构成</td><td colspan="1" rowspan="1">投资金额</td><td colspan="1" rowspan="1">占比</td><td colspan="1" rowspan="1">拟投入募集资金</td><td colspan="1" rowspan="1">是否属于资本性支出</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">建设投资</td><td colspan="1" rowspan="1">6,781.95</td><td colspan="1" rowspan="1">93.93%</td><td colspan="1" rowspan="1">6,500.00</td><td colspan="1" rowspan="1">：</td></tr><tr><td colspan="1" rowspan="1">1.1</td><td colspan="1" rowspan="1">设备购置费用</td><td colspan="1" rowspan="1">6,459.00</td><td colspan="1" rowspan="1">89.46%</td><td colspan="1" rowspan="1">6,190.00</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">1.2</td><td colspan="1" rowspan="1">预备费</td><td colspan="1" rowspan="1">322.95</td><td colspan="1" rowspan="1">4.47%</td><td colspan="1" rowspan="1">310.00</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">铺底流动资金</td><td colspan="1" rowspan="1">438.05</td><td colspan="1" rowspan="1">6.07%</td><td colspan="1" rowspan="1">400.00</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">7,220.00</td><td colspan="1" rowspan="1">100.00%</td><td colspan="1" rowspan="1">6,900.00</td><td colspan="1" rowspan="1"></td></tr></table>

“力传感器产线建设项目”总投资 6,250.00 万元，拟使用募集资金投资6,040.00 万元，具体投资安排如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>投资构成</td><td rowspan=1 colspan=1>投资金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>拟投入募集资金</td><td rowspan=1 colspan=1>是否属于资本性支出</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>建设投资</td><td rowspan=1 colspan=1>5,876.43</td><td rowspan=1 colspan=1>94.02%</td><td rowspan=1 colspan=1>5,672.43</td><td rowspan=1 colspan=1>:</td></tr><tr><td rowspan=1 colspan=1>1.1</td><td rowspan=1 colspan=1>装修工程费用</td><td rowspan=1 colspan=1>493.00</td><td rowspan=1 colspan=1>7.89%</td><td rowspan=1 colspan=1>289.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.2</td><td rowspan=1 colspan=1>设备及软件购置费用</td><td rowspan=1 colspan=1>5,103.60</td><td rowspan=1 colspan=1>81.66%</td><td rowspan=1 colspan=1>5,103.60</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.3</td><td rowspan=1 colspan=1>预备费</td><td rowspan=1 colspan=1>279.83</td><td rowspan=1 colspan=1>4.48%</td><td rowspan=1 colspan=1>279.83</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>铺底流动资金</td><td rowspan=1 colspan=1>373.57</td><td rowspan=1 colspan=1>5.98%</td><td rowspan=1 colspan=1>367.57</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>6,250.00</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>6,040.00</td><td rowspan=1 colspan=1></td></tr></table>

“MEMS 传感器芯片研发及产业化项目”总投资 5,790.00 万元，拟使用募集资金投资5,640.00 万元，具体投资安排如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>投资构成</td><td rowspan=1 colspan=1>投资金额</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>拟投入募集资金</td><td rowspan=1 colspan=1>是否属于资本性支出</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>建设投资</td><td rowspan=1 colspan=1>5,597.80</td><td rowspan=1 colspan=1>96.68%</td><td rowspan=1 colspan=1>5,450.00</td><td rowspan=1 colspan=1>:</td></tr><tr><td rowspan=1 colspan=1>1.1</td><td rowspan=1 colspan=1>装修工程费用</td><td rowspan=1 colspan=1>300.00</td><td rowspan=1 colspan=1>5.18%</td><td rowspan=1 colspan=1>200.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.2</td><td rowspan=1 colspan=1>场地租赁费用</td><td rowspan=1 colspan=1>61.24</td><td rowspan=1 colspan=1>1.06%</td><td rowspan=1 colspan=1>30.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>1.3</td><td rowspan=1 colspan=1>设备购置费用</td><td rowspan=1 colspan=1>2,610.00</td><td rowspan=1 colspan=1>45.08%</td><td rowspan=1 colspan=1>2,600.00</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>1.4</td><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>2,360.00</td><td rowspan=1 colspan=1>40.76%</td><td rowspan=1 colspan=1>2,360.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>1.5</td><td rowspan=1 colspan=1>预备费</td><td rowspan=1 colspan=1>266.56</td><td rowspan=1 colspan=1>4.60%</td><td rowspan=1 colspan=1>260.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>铺底流动资金</td><td rowspan=1 colspan=1>192.20</td><td rowspan=1 colspan=1>3.32%</td><td rowspan=1 colspan=1>190.00</td><td rowspan=1 colspan=1>否</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>5,790.00</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>5,640.00</td><td rowspan=1 colspan=1></td></tr></table>

因此，发行人本次募投项目支出主要包括装修工程费用、场地租赁费用、设备及软件购置费用、研发费用、预备费和铺底流动资金，均为投资项目必要的支出项，本次融资具有必要性。

## （2）本次募投项目的投入产出比测算情况

结合公开信息查询情况，本次募投项目的单位投入产出比与前次募投项目、同行业可比项目对比情况如下：

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>融资轮次</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资金额（万元）</td><td rowspan=1 colspan=1>达产后年收入（万元）</td><td rowspan=1 colspan=1>单位投入产出比</td></tr><tr><td rowspan=6 colspan=1>发行人</td><td rowspan=4 colspan=1>2026年向特定对象发行股票</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>28,000.00</td><td rowspan=1 colspan=1>80,951.72</td><td rowspan=1 colspan=1>2.89</td></tr><tr><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>7,220.00</td><td rowspan=1 colspan=1>19,211.24</td><td rowspan=1 colspan=1>2.66</td></tr><tr><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>6,250.00</td><td rowspan=1 colspan=1>16,356.72</td><td rowspan=1 colspan=1>2.62</td></tr><tr><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>5,790.00</td><td rowspan=1 colspan=1>7,389.95</td><td rowspan=1 colspan=1>1.28</td></tr><tr><td rowspan=2 colspan=1>2023年首次公开募股</td><td rowspan=1 colspan=1>安培龙智能传感器产业园项目-压力传感器建设项目</td><td rowspan=1 colspan=1>18,764.16</td><td rowspan=1 colspan=1>36,665.22</td><td rowspan=1 colspan=1>1.95</td></tr><tr><td rowspan=1 colspan=1>安培龙智能传感器产业园项目-温度传感器建设项目</td><td rowspan=1 colspan=1>14,289.87</td><td rowspan=1 colspan=1>30,419.67</td><td rowspan=1 colspan=1>2.13</td></tr><tr><td rowspan=2 colspan=1>天博智能</td><td rowspan=2 colspan=1>2026年首次公开募股</td><td rowspan=1 colspan=1>智能热管理部件及系统制造建设项目</td><td rowspan=1 colspan=1>105,013.57</td><td rowspan=1 colspan=1>109,000.00</td><td rowspan=1 colspan=1>1.04</td></tr><tr><td rowspan=1 colspan=1>汽车热管理系统及核心元器件生产基地扩产技术改造项目</td><td rowspan=1 colspan=1>70,933.14</td><td rowspan=1 colspan=1>76,400.00</td><td rowspan=1 colspan=1>1.08</td></tr><tr><td rowspan=2 colspan=1>华培动力</td><td rowspan=2 colspan=1>2024年向特定对象发行股票</td><td rowspan=1 colspan=1>压力传感器产能扩充项目</td><td rowspan=1 colspan=1>14,114.57</td><td rowspan=1 colspan=1>23,181.12</td><td rowspan=1 colspan=1>1.64</td></tr><tr><td rowspan=1 colspan=1>磁类传感器产能扩充项目</td><td rowspan=1 colspan=1>3,083.96</td><td rowspan=1 colspan=1>5,531.57</td><td rowspan=1 colspan=1>1.79</td></tr></table>

注 1：单位投入产出比=达产后年收入/投入金额；  
注 2：发行人 MEMS 传感器芯片研发及产业化项目产品不对外销售，全部用于内部供应，不会新增上市公司的营业收入，使用预计年节约营业成本代替达产后年收入测算单位投入产出比；  
注 3：华培动力未披露达产后年收入，使用测算期内年均收入代替达产后年收入测算单位投入产出比。

根据上表数据，公司本次募投项目“压力传感器扩产项目”“陶瓷电容式压力传感器产线升级项目”“力传感器产线建设项目”单位投入产出比表现均优于前次募投项目及同行业可比项目。“MEMS 传感器芯片研发及产业化项目”单位投入产出比较前次募投项目及同行业可比项目不存在重大差异，但相比于其他本次募投项目较低，主要系①该项目非单纯的扩产项目，项目投资包括对 MEMS压力传感器感压芯片、单桥压力接口芯片、双桥压力接口芯片、玻璃微熔压力传感器用MEMS半导体应变片以及力传感器用MEMS半导体应变片等芯片的技术研发工作，研发费用占比较高；②该项目产品不对外销售，全部用于内部供应，不会新增上市公司的营业收入，使用预计年节约营业成本代替达产后年收入测算单位投入产出比，测算口径有所差异，因此该差异具有合理性。

因此，发行人本次募投项目投入产出比表现合理，本次融资具有必要性。

综上，发行人本次募投项目支出主要包括装修工程费用、场地租赁费用、设备及软件购置费用、研发费用、预备费和铺底流动资金，均为投资项目必要的支出项，发行人本次募投项目投入产出比表现合理，本次融资具有必要性。

## 2、量化测算并说明补充流动资金的规模合理性，本次补充流动资金占比是否符合《证券期货法律适用意见第 18 号》相关规定

## （1）经测算，补充流动资金规模具有合理性

综合考虑公司的可自由支配资金、未来期间经营性现金流入净额、最低现金保有量、未来三年预计现金分红、未来投资需求等，公司未来仍存在总体资金缺口85,401.60 万元，本次募集资金补充流动资金规模具有合理性，具体测算如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>计算公式</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>2025年末货币资金余额</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>16,904. 59</td></tr><tr><td rowspan=1 colspan=1>2025年末使用受限的货币资金金额</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>0.00</td></tr><tr><td rowspan=1 colspan=1>前次募投项目未使用资金</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>4, 427. 25</td></tr><tr><td rowspan=1 colspan=1>可自由支配资金</td><td rowspan=1 colspan=1>④=①-②-③</td><td rowspan=1 colspan=1>12, 477. 34</td></tr><tr><td rowspan=1 colspan=1>未来三年预计经营性现金流入净额</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>36,838.88</td></tr><tr><td rowspan=1 colspan=1>最低现金保有量需求（2025年末）</td><td rowspan=1 colspan=1>®</td><td rowspan=1 colspan=1>14,131. 55</td></tr><tr><td rowspan=1 colspan=1>未来三年营运资金需求</td><td rowspan=1 colspan=1>?</td><td rowspan=1 colspan=1>52,177. 70</td></tr><tr><td rowspan=1 colspan=1>未来三年预计现金分红</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>14,723. 56</td></tr><tr><td rowspan=1 colspan=1>未来三年偿还有息债务的利息</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>3,332. 20</td></tr><tr><td rowspan=1 colspan=1>投资项目资金需求</td><td rowspan=1 colspan=1>?</td><td rowspan=1 colspan=1>50,352.80</td></tr><tr><td rowspan=1 colspan=1>未来资金需求合计</td><td rowspan=1 colspan=1>①=⑥+⑦+8+⑨+0</td><td rowspan=1 colspan=1>134, 717. 82</td></tr><tr><td rowspan=1 colspan=1>总体资金缺口</td><td rowspan=1 colspan=1>②-0-4-⑤</td><td rowspan=1 colspan=1>85,401. 60</td></tr></table>

## 1）可自由支配资金

截至2025 年末，公司货币资金余额为 16,904.59 万元，其中使用受限的货币资金金额为 0 万元，尚未使用的募集资金金额为 4,427.25 万元，剩余可以自由支配的货币资金金额为12,477.34 万元。

## 2）未来期间经营性现金流入净额

未来3年预计经营活动产生的现金流量净额按照未来3年预计营业收入合计×公司最近五年经营活动产生的现金流量净额合计与营业收入合计比值测算。

## ①营业收入

2023 年至 2025 年，公司营业收入复合增长率为 25.91%，2025 年度，公司营业收入增长率 25.88%。随着传感器下游应用市场规模的扩大以及公司不断加大研发投入、产品线不断丰富，预计未来公司营业收入仍有较大的增长空间。基于合理谨慎的原则，假设未来三年营业收入增长率为 20%，则 2026 年至 2028年公司营业收入如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2026年度</td><td rowspan=1 colspan=1>2027年度</td><td rowspan=1 colspan=1>2028年度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>142, 017. 31</td><td rowspan=1 colspan=1>170,420. 77</td><td rowspan=1 colspan=1>204, 504. 92</td></tr></table>

上述相关假设及预估的财务数据仅用于本次资金缺口测算，不构成盈利预测或承诺。

②经营活动产生的现金流量净额

公司属于传感器行业，公司的经营情况会受到行业周期波动影响发生相应波动。公司综合考虑过去 5 年（2021 年至2025 年）的经营性现金净流量占营业收入的比例以更合理地预测公司未来经营现金流量净额。2021-2025年，公司经营性现金净流量合计 28,487.90 万元，营业收入合计 399,757.56 万元，经营性现金净流量/营业收入为7.13%。基于前述长期的历史数据，假设未来公司经营性现金净流量/营业收入为7.13%。

经测算，未来三年预计日常经营积累为36,838.88 万元，具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">计算公式</td><td colspan="1" rowspan="1">2026年</td><td colspan="1" rowspan="1">2027年</td><td colspan="1" rowspan="1">2028年</td><td colspan="1" rowspan="1">合计</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">A</td><td colspan="1" rowspan="1">142, 017. 31</td><td colspan="1" rowspan="1">170, 420. 77</td><td colspan="1" rowspan="1">204, 504. 92</td><td colspan="1" rowspan="1">516,943.00</td></tr><tr><td colspan="1" rowspan="1">公司2021年至2025年经营活动产生的现金流量净额合计占营业收入合计的比值</td><td colspan="1" rowspan="1">B</td><td colspan="1" rowspan="1">7.13%</td><td colspan="1" rowspan="1">7.13%</td><td colspan="1" rowspan="1">7.13%</td><td colspan="1" rowspan="1">7. 13%</td></tr><tr><td colspan="1" rowspan="1">经营活动产生的现金流量净额</td><td colspan="1" rowspan="1">C=A*B</td><td colspan="1" rowspan="1">10,120.57</td><td colspan="1" rowspan="1">12,144. 69</td><td colspan="1" rowspan="1">14, 573. 62</td><td colspan="1" rowspan="1">36,838.88</td></tr></table>

## 3）最低现金保有量

最低现金保有量系公司为维持其日常营运所需要的最低货币资金金额。对于最低现金保有量的测算，基于谨慎性原则，公司选取安全月数法测算结果（14,131.55 万元）、公式法测算结果（45,117.58 万元）的孰低值作为公司最低现金保有量，具体计算过程及结果如下：

## ①安全月数法

结合公司生产管理历史经验、现金收支情况等，测算假设最低保留3个月经营活动现金流出资金。由于公司近年来业绩持续增长，因此以 2025 年度经营活动现金流出总额 56,526.21 万元为基础，计算平均3 个月的经营活动现金流出金额为14,131.55 万元，并以此作为安全月数法下最低现金保有量金额。

## ②公式法

根据2025 年度财务数据，公司在现行运营规模下日常经营需要保有的最低货币资金为45,117.58 万元，具体测算过程如下：

<table><tr><td rowspan=1 colspan=1>财务指标</td><td rowspan=1 colspan=1>计算公式</td><td rowspan=1 colspan=1>计算结果</td></tr><tr><td rowspan=1 colspan=1>最低现金保有量（万元）</td><td rowspan=1 colspan=1>①=②÷③</td><td rowspan=1 colspan=1>45,117. 58</td></tr><tr><td rowspan=1 colspan=1>付现成本总额（万元）</td><td rowspan=1 colspan=1>②-4+5-6</td><td rowspan=1 colspan=1>101, 431. 59</td></tr><tr><td rowspan=1 colspan=1>营业成本（万元）</td><td rowspan=1 colspan=1>④</td><td rowspan=1 colspan=1>83,956.98</td></tr><tr><td rowspan=1 colspan=1>期间费用（万元）</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>24, 980. 77</td></tr><tr><td rowspan=1 colspan=1>非付现成本总额（万元）</td><td rowspan=1 colspan=1>®</td><td rowspan=1 colspan=1>7,506. 16</td></tr><tr><td rowspan=1 colspan=1>货币资金周转次数(现金周转率）</td><td rowspan=1 colspan=1>③=360-⑦</td><td rowspan=1 colspan=1>2. 25</td></tr><tr><td rowspan=1 colspan=1>现金周转期(天)</td><td rowspan=1 colspan=1>⑦-8+9-0</td><td rowspan=1 colspan=1>160. 13</td></tr><tr><td rowspan=1 colspan=1>存货周转期(天)</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>137.73</td></tr><tr><td rowspan=1 colspan=1>应收款项周转期（天)</td><td rowspan=1 colspan=1>④</td><td rowspan=1 colspan=1>130.58</td></tr><tr><td rowspan=1 colspan=1>应付款项周转期（天)</td><td rowspan=1 colspan=1>?</td><td rowspan=1 colspan=1>108.18</td></tr></table>

注 1：非付现成本包括固定资产折旧、使用权资产折旧、无形资产摊销、长摊费用摊销和股份支付费用；  
注 2：存货周转期=360\*平均存货账面价值/营业成本；

注 3：应收款项周转期=360\*（平均应收账款账面价值+平均应收款项融资账面价值+平均预付账款账面价值）/营业收入；

注 4：应付款项周转期=360\*（平均应付账款账面价值+平均应付票据账面价值+平均合同负债账面价值）/营业成本。

## 4）未来三年营运资金需求

由于营运资金需求主要来自于公司经营过程中产生的经营性流动资产及经营性流动负债，假设公司经营模式及各项资产、负债的周转情况长期保持稳定，利用销售百分比法测算公司未来由营业收入增长导致的相关经营性流动资产及经营性流动负债的变化，进而测算其营运资金需求缺口。

2023年度至 2025 年度，发行人营业收入复合增长率为 25.91%。基于谨慎性考虑，假设未来三年发行人营业收入增长率为20%，同时，为降低仅采用单一会计年度财务数据造成的结果偏差，公司采用最近三年各科目占营业收入比重的平均值作为本次测算的估算值，发行人营运资金需求缺口测算如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>平均占营业收入比例</td><td rowspan=1 colspan=1>2026年度</td><td rowspan=1 colspan=1>2027年度</td><td rowspan=1 colspan=1>2028年度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>118, 347.76</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>142,017. 31</td><td rowspan=1 colspan=1>170,420.77</td><td rowspan=1 colspan=1>204,504.92</td></tr><tr><td rowspan=1 colspan=1>应收票据</td><td rowspan=1 colspan=1>7,919.36</td><td rowspan=1 colspan=1>7. 24%</td><td rowspan=1 colspan=1>10,278.35</td><td rowspan=1 colspan=1>12,334.02</td><td rowspan=1 colspan=1>14,800. 83</td></tr><tr><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>39,050.28</td><td rowspan=1 colspan=1>37.51%</td><td rowspan=1 colspan=1>53,273.09</td><td rowspan=1 colspan=1>63,927.70</td><td rowspan=1 colspan=1>76,713. 24</td></tr><tr><td rowspan=1 colspan=1>应收款项融资</td><td rowspan=1 colspan=1>4,335. 04</td><td rowspan=1 colspan=1>3.28%</td><td rowspan=1 colspan=1>4, 651. 12</td><td rowspan=1 colspan=1>5,581. 35</td><td rowspan=1 colspan=1>6,697. 62</td></tr><tr><td rowspan=1 colspan=1>预付款项</td><td rowspan=1 colspan=1>1,416.30</td><td rowspan=1 colspan=1>0.90%</td><td rowspan=1 colspan=1>1,283.82</td><td rowspan=1 colspan=1>1,540. 58</td><td rowspan=1 colspan=1>1,848. 69</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>34,760. 27</td><td rowspan=1 colspan=1>29.34%</td><td rowspan=1 colspan=1>41,666. 07</td><td rowspan=1 colspan=1>49,999. 29</td><td rowspan=1 colspan=1>59,999.14</td></tr><tr><td rowspan=1 colspan=1>经营性流动资产合计</td><td rowspan=1 colspan=1>87, 481. 25</td><td rowspan=1 colspan=1>78. 27%</td><td rowspan=1 colspan=1>111, 152.45</td><td rowspan=1 colspan=1>133, 382. 94</td><td rowspan=1 colspan=1>160,059.53</td></tr><tr><td rowspan=1 colspan=1>应付账款</td><td rowspan=1 colspan=1>27,459. 79</td><td rowspan=1 colspan=1>23.36%</td><td rowspan=1 colspan=1>33,168.23</td><td rowspan=1 colspan=1>39,801.88</td><td rowspan=1 colspan=1>47,762. 25</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>91. 69</td><td rowspan=1 colspan=1>0.09%</td><td rowspan=1 colspan=1>131. 80</td><td rowspan=1 colspan=1>158.16</td><td rowspan=1 colspan=1>189.79</td></tr><tr><td rowspan=1 colspan=1>经营性流动负债合计</td><td rowspan=1 colspan=1>27, 551. 48</td><td rowspan=1 colspan=1>23.45%</td><td rowspan=1 colspan=1>33,300.03</td><td rowspan=1 colspan=1>39,960.04</td><td rowspan=1 colspan=1>47,952. 05</td></tr><tr><td rowspan=1 colspan=1>经营性流动资产-经营性流动负债</td><td rowspan=1 colspan=1>59,929. 77</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>77, 852. 42</td><td rowspan=1 colspan=1>93,422. 90</td><td rowspan=1 colspan=1>112, 107. 48</td></tr><tr><td rowspan=1 colspan=1>新增营运资金金额</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>17,922. 64</td><td rowspan=1 colspan=1>15,570.48</td><td rowspan=1 colspan=1>18, 684. 58</td></tr><tr><td rowspan=1 colspan=1>营运资金需求合计</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>:</td><td rowspan=1 colspan=3>52,177. 70</td></tr></table>

## 5）未来三年预计现金分红

2023年至 2025年公司营业收入及归属于上市公司股东的净利润情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>三年合计</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>118, 347. 76</td><td rowspan=1 colspan=1>94, 016.42</td><td rowspan=1 colspan=1>74, 657. 09</td><td rowspan=1 colspan=1>287, 021. 28</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>9, 074. 52</td><td rowspan=1 colspan=1>8,263.76</td><td rowspan=1 colspan=1>7,989. 15</td><td rowspan=1 colspan=1>25, 327. 42</td></tr><tr><td rowspan=1 colspan=4>归属于上市公司股东的净利润率</td><td rowspan=1 colspan=1>8.82%</td></tr></table>

单位：万元

2023年至 2025年期间归属于上市公司股东的净利润率（三年累计归属于上市公司股东的净利润/三年累计营业收入）为8.82%。据此，假设未来三年归属上市公司股东的净利润率为8.82%。

发行人2023 年至2025年公司分红情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>三年合计</td></tr><tr><td rowspan=1 colspan=1>现金分红总额</td><td rowspan=1 colspan=1>2,952. 06</td><td rowspan=1 colspan=1>2,952. 06</td><td rowspan=1 colspan=1>2,270. 82</td><td rowspan=1 colspan=1>8,174.93</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>9,074. 52</td><td rowspan=1 colspan=1>8,263.76</td><td rowspan=1 colspan=1>7, 989. 15</td><td rowspan=1 colspan=1>25, 327. 42</td></tr><tr><td rowspan=1 colspan=4>现金分红比例</td><td rowspan=1 colspan=1>32. 28%</td></tr></table>

2023 年至2025年期间现金分红比例（三年累计现金分红/三年累计归属于上市公司股东的净利润）为 32.28%。据此，假设公司未来三年现金分红比例为32.28%。

假设未来三年公司营业收入按照20%的速度增长，并结合上述假设，未来三年预计现金分红的资金需求情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2026年</td><td rowspan=1 colspan=1>2027年</td><td rowspan=1 colspan=1>2028年</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>142, 017. 31</td><td rowspan=1 colspan=1>170, 420. 77</td><td rowspan=1 colspan=1>204,504. 92</td></tr><tr><td rowspan=1 colspan=1>未来三年累计营业收入</td><td rowspan=1 colspan=3>516,943.00</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润率</td><td rowspan=1 colspan=3>8.82%</td></tr><tr><td rowspan=1 colspan=1>未来三年归属于上市公司股东的净利润</td><td rowspan=1 colspan=3>45, 616. 25</td></tr><tr><td rowspan=1 colspan=1>现金分红比例</td><td rowspan=1 colspan=3>32. 28%</td></tr><tr><td rowspan=1 colspan=1>未来三年现金分红金额</td><td rowspan=1 colspan=3>14,723. 56</td></tr></table>

## 6）未来三年偿还有息债务利息

截至 2025 年末，公司短期借款余额为 32,824.44 万元，长期借款余额为3,600.00 万元。考虑到 2025 年末，1 年期 LPR 为 3%，5 年期以上 LPR 为 3.5%，

假设未来三年公司的有息债务（短期借款和长期借款）的规模不变、短期借款利率为 3%、长期借款利率为 3.5%，未来三年偿还有息债务利息情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>财务指标</td><td rowspan=1 colspan=1>计算公式</td><td rowspan=1 colspan=1>计算结果</td></tr><tr><td rowspan=1 colspan=1>短期借款金额</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>32, 824. 44</td></tr><tr><td rowspan=1 colspan=1>短期借款利率</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>3%</td></tr><tr><td rowspan=1 colspan=1>短期借款利息</td><td rowspan=1 colspan=1>③=①*②*3</td><td rowspan=1 colspan=1>2,954. 20</td></tr><tr><td rowspan=1 colspan=1>长期借款金额</td><td rowspan=1 colspan=1>④</td><td rowspan=1 colspan=1>3,600. 00</td></tr><tr><td rowspan=1 colspan=1>长期借款利率</td><td rowspan=1 colspan=1>⑤</td><td rowspan=1 colspan=1>3.5%</td></tr><tr><td rowspan=1 colspan=1>长期借款利息</td><td rowspan=1 colspan=1>⑥=4*⑤*3</td><td rowspan=1 colspan=1>378. 00</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>7-③+⑥</td><td rowspan=1 colspan=1>3, 332. 20</td></tr></table>

## 7）投资项目资金需求

截至2025 年末，公司主要投资项目资金需求如下：

①本次募投项目

剔除补充流动资金项目后，本次募投项目投资金额为 47,260.00 万元，明细如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资总额</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>28,000.00</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>7,220.00</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>6,250.00</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS 传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>5,790.00</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>47,260.00</td></tr></table>

②前次募集资金超募资金投资项目

截至2025 年末，公司超募资金5,064.02 万元。其中，“新一代智能驾驶刹车系统用力传感器建设项目”使用超募资金4,130.70 万元建设，“贴片式NTC 热敏电阻研发及产业化建设项目”拟使用剩余超募资金933.32万元、自有资金3,144.30万元投入建设。

③其他项目

截至2025 年末，公司其他主要投资项目资金需求约 317.69 万元，公司将以

自有资金或通过银行借款等融资方式解决。具体如下：

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>截至2025年末拟投资金额</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>在制设备-全自动产线项目</td><td rowspan=1 colspan=1>174. 62</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>泰国传感器基地项目装修工程项目</td><td rowspan=1 colspan=1>143.08</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>317. 69</td></tr></table>

单位：万元

综上所述，随着公司主营业务的持续发展，公司资金缺口为85,401.60 万元，高于本次募集资金规模 54,440.00 万元，其中补充流动资金 9,000.00 万元，未超过前述测算资金缺口，需要通过融资补充资金，以满足公司业务扩展的资金需求。因此，本次募集资金规模、补充流动资金规模具有合理性和必要性。

## （2）本次补充流动资金占比是否符合《证券期货法律适用意见第 18 号》相关规定

本次募集资金投资项目中，各项目中预备费、铺底流动资金、场地租赁费用、研发费用等使用募集资金的资本性支出和补充流动资金项目总额及占募集资金总额的比例情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>投资金额</td><td rowspan=1 colspan=1>使用募集资金金额</td><td rowspan=1 colspan=1>使用募集资金的非资本性支出金额</td><td rowspan=1 colspan=1>占募集资金总额的比</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>压力传感器扩产项目</td><td rowspan=1 colspan=1>28,000.00</td><td rowspan=1 colspan=1>26,860.00</td><td rowspan=1 colspan=1>2,730.00</td><td rowspan=1 colspan=1>5.01%</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>力传感器产线建设项目</td><td rowspan=1 colspan=1>6,250.00</td><td rowspan=1 colspan=1>6,040.00</td><td rowspan=1 colspan=1>647.40</td><td rowspan=1 colspan=1>1.19%</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>陶瓷电容式压力传感器产线升级项目</td><td rowspan=1 colspan=1>7,220.00</td><td rowspan=1 colspan=1>6,900.00</td><td rowspan=1 colspan=1>710.00</td><td rowspan=1 colspan=1>1.30%</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>MEMS传感器芯片研发及产业化项目</td><td rowspan=1 colspan=1>5,790.00</td><td rowspan=1 colspan=1>5,640.00</td><td rowspan=1 colspan=1>2,840.00</td><td rowspan=1 colspan=1>5.22%</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>补充流动资金</td><td rowspan=1 colspan=1>9,000.00</td><td rowspan=1 colspan=1>9,000.00</td><td rowspan=1 colspan=1>9,000.00</td><td rowspan=1 colspan=1>16.53%</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>56,260.00</td><td rowspan=1 colspan=1>54,440.00</td><td rowspan=1 colspan=1>15,927.40</td><td rowspan=1 colspan=1>29.26%</td></tr></table>

如上表所示，公司本次拟投入募集资金合计54,440.00 万元。其中，压力传感器扩产项目拟投入募集资金 26,860.00 万元，其中预备费及铺底流动资金系非资本性支出，合计拟使用募集资金2,730.00 万元；力传感器产线建设项目拟投入募集资金6,040.00 万元，其中预备费及铺底流动资金系非资本性支出，合计拟使用募集资金 647.40 万元；陶瓷电容式压力传感器产线升级项目拟投入募集资金6,900.00 万元，其中预备费及铺底流动资金系非资本性支出，合计拟使用募集资金 710.00 万元；MEMS 传感器芯片研发及产业化项目拟投入募集资金 5,640.00万元，其中场地租赁费用、研发费用、预备费及铺底流动资金系非资本性支出，合计拟使用募集资金 2,840.00 万元。同时，拟使用募集资金补充流动资金9,000.00万元，非资本性支出合计金额为15,927.40万元，占募集资金总额的比例为29.26%，未超过本次募集资金总额的 30%。

综上，公司本次募集资金中，补充流动资金等非资本性支出的占比未超过本次募集资金总额的 30%，符合《证券期货法律适用意见第 18 号》的规定。

（十）前次募投项目延期的原因及合理性，相关变更情况是否已按规定履行相关审议程序与披露义务，相关影响因素是否持续，是否对本次募投项目实施造成重大不利影响

## 1、前次募投项目延期的原因及合理性

公司首次公开发行募集资金实际使用情况对照情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>募集资金承诺投资金额</td><td rowspan=1 colspan=1>投资资金来源</td><td rowspan=1 colspan=1>是否延期</td><td rowspan=1 colspan=1>是否实施完毕</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>安培龙智能传感器产业园项目-压力传感器建设项目</td><td rowspan=1 colspan=1>18,764.16</td><td rowspan=1 colspan=1>招股说明书承诺投资项目</td><td rowspan=1 colspan=1>否</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>安培龙智能传感器产业园项目-温度传感器建设项目</td><td rowspan=1 colspan=1>14,289.87</td><td rowspan=1 colspan=1>招股说明书承诺投资项目</td><td rowspan=1 colspan=1>是</td><td rowspan=1 colspan=1>否，截至2025年12月31日使用比例已达92.75%，预计达到预定可使用状态日期2027年6月</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>安培龙智能传感器产业园项目-智能传感器研发中心建设项目</td><td rowspan=1 colspan=1>6,309.88</td><td rowspan=1 colspan=1>招股说明书承诺投资项目</td><td rowspan=1 colspan=1>是</td><td rowspan=1 colspan=1>是</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>补充流动资金</td><td rowspan=1 colspan=1>10,000.00</td><td rowspan=1 colspan=1>招股说明书承诺投资项目</td><td rowspan=1 colspan=1>否</td><td rowspan=1 colspan=1>不适用</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>新一代智能驾驶刹车系统用力传感器建设项目</td><td rowspan=1 colspan=1>4,130.70</td><td rowspan=1 colspan=1>超募资金投向</td><td rowspan=1 colspan=1>是</td><td rowspan=1 colspan=1>预计达到预定可使用状态日期2027年5月</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>贴片式NTC 热敏电阻研发及产业化建设项目</td><td rowspan=1 colspan=1>933.32</td><td rowspan=1 colspan=1>超募资金投向</td><td rowspan=1 colspan=1>否</td><td rowspan=1 colspan=1>预计达到预定可使用状态日期2028年2月</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>54,427.93</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr></table>

## （1）“温度传感器建设项目”根据行业及公司实际发展情况审慎延期

“温度传感器建设项目”通过扩建安培龙智能传感器产业园项目子项目温度传感器建设项目生产线，旨在进一步提高公司温度传感器的生产能力，满足客户对公司产品持续增长的需求，进一步提升产品的产业化速度，为公司战略目标的实现提供产能和运营管理支持。但由于国内外家电市场需求放缓，发行人为降低募集资金的投资风险以保障资金的安全、合理、高效使用，结合市场需求和自身产能情况，经审慎研究，决定对该募投项目进行延期，具备合理性。

## （2）“智能传感器研发中心建设项目”因小部分资金未使用完毕而延期，现已达到调整后的预定可使用状态

“智能传感器研发中心建设项目”为研发性质，公司旨在通过该项目培育新的业务增长点、抢占市场先机奠定前提条件，有利于进一步提升公司自身研发及创新能力，并满足客户多样化需求，增强公司核心竞争力，为公司未来业务持续发展奠定坚实基础。但由于截至 2023 年末还有小部分资金尚未使用完毕（使用进度约为 96.20%），故将该项目达到预定可使用状态时间延期至 2024 年6月30日，且如期实现。

## （3）超募投资项目“新一代智能驾驶刹车系统用力传感器建设项目”根据行业及公司实际发展情况审慎延期

“新一代智能驾驶刹车系统用力传感器建设项目”计划建设新一代智能驾驶刹车系统 EMB 力传感器产线，以打造 EMB 力传感器生产能力，提高产能储备以应对未来的市场需求。自超募投资项目规划以来，公司综合考虑行业发展趋势并保持设备先进性，动态调整了原材料处理相关设备，稳步推进建设工作，降低募集资金的投资风险，保证资金安全并合理运用。截至 2025 年 12 月31 日，该项目累计投入占比为 43.58%。考虑到客户对EMB 力传感器质量要求严格，公司结合客户需求及目前获取订单情况，公司需同步优化施工计划、设备配置及资金投入节奏，确保项目建设与市场周期精准匹配。为保障项目投产后的盈利水平，避免盲目赶工带来的运营风险，经审慎评估后，拟将项目达到预定可使用状态的时间延期至 2027 年5 月。该超募投资项目延期具备合理性。

## 2、相关变更情况已按规定履行审议程序与披露义务

针对前次募投项目延期情况，发行人已按规定履行相关审议程序与披露义务，符合募集资金管理和使用有关规定。具体如下：

2024 年 4 月 8 日，公司召开第三届董事会第二十二次会议、第三届监事会第十五次会议，审议通过了《关于部分募集资金项目延期的议案》，对部分募投项目进行延期，将募投项目“安培龙智能传感器产业园项目”子项目“温度传感器建设项目”达到预定可使用状态日期延长至 2025 年6月30 日，将募投项目“安培龙智能传感器产业园项目”子项目“智能传感器研发中心建设项目”达到预定可使用状态日期延长至2024 年6月30 日。发行人于2024 年4月9日披露了《关于部分募集资金项目延期的公告》（公告编号：2024-024）。

2025 年4月23 日，公司召开的第四届董事会第四次会议、第四届监事会第三次会议审议通过了《关于部分募集资金项目延期的议案》及《关于部分募投项目增加实施主体及实施地点的议案》，将募投项目“安培龙智能传感器产业园项目”子项目“温度传感器建设项目”达到预定可使用状态日期由2025 年6月30日延长至2026 年6月30 日。发行人于2025 年4月25日披露了《关于部分募集资金项目延期的公告》（公告编号：2025-032）。

2026 年1月28 日，公司召开了第四届董事会第十三次会议，审议通过了《关于原超募投资项目延期的议案》，将“新一代智能驾驶刹车系统用力传感器建设项目”达到预定可使用状态的时间延期至 2027 年 5 月。发行人于 2026 年 1 月29 日披露了《关于原超募投资项目延期的公告》（公告编号：2026-011）。

2026 年4 月22 日，公司召开了第四届董事会第十四次会议，审议通过了《关于部分募集资金项目延期的议案》，将募投项目“安培龙智能传感器产业园项目”子项目“温度传感器建设项目”达到预定可使用状态日期延长至 2027 年6 月30日。发行人于 2026 年4 月24日披露了《关于部分募集资金项目延期的公告》（公告编号：2026-028）。

综上，发行人前次募投项目延期已按规定履行审议程序与披露义务。

## 3、相关影响因素是否持续，是否对本次募投项目实施造成重大不利影响

## （1）前次募投项目延期相关因素短期内预计可能持续

发行人前次募投项目延期事项为公司基于当时市场环境、行业发展情况、公司战略规划做出的决策，确保募集资金使用效率，有利于保障投资者利益和确保募投项目顺利实施，具有合理性。具体如下：

①温度传感器建设项目：由于国内外家电市场需求放缓，发行人为降低募集资金的投资风险以保障资金的安全、合理、高效使用，结合市场需求和自身产能情况，经审慎研究，对“温度传感器建设项目”进行延期；此外，本次募投项目涉及外销的产品包括压力传感器及力传感器，一方面，温度传感器与本次募投项目产品不同，本次募投项目不涉及温度传感器，另一方面，压力传感器主要应用于汽车领域，力传感器主要应用于机器人领域，与温度传感器应用不同，因此，温度传感器建设项目延期的影响因素不会对本次募投项目实施造成重大不利影响；

②新一代智能驾驶刹车系统用力传感器建设项目：结合客户需求及目前获取订单情况，公司需同步优化施工计划、设备配置及资金投入节奏，确保项目建设与市场周期精准匹配，公司对“新一代智能驾驶刹车系统用力传感器建设项目”进行了延期；此外，本次募投项目涉及外销的产品包括压力传感器及力传感器，其中，压力传感器主要应用于汽车领域，力传感器主要应用于机器人领域，一方面，本次募投项目的力传感器的应用（机器人领域）与新一代智能驾驶刹车系统用力传感器建设项目不同，另一方面，本次募投项目的压力传感器主要应用于汽车领域中的空调、发动机、变速箱等，与新一代智能驾驶刹车系统用力传感器建设项目的应用亦不同，因此，新一代智能驾驶刹车系统用力传感器建设项目延期的影响因素不会对本次募投项目实施造成重大不利影响。

综上，基于对行业趋势、下游客户需求等情况的审慎评估，发行人对项目投资节奏采取更为稳健的安排。在行业增长节奏、下游客户需求等市场环境情况保持当前特征的情况下，相关影响因素短期内预计将可能持续。

（2）相关因素对本次募投项目实施不造成重大影响

相关因素对本次募投新项目实施不造成重大影响，一方面公司规划本次募投项目已充分考虑宏观环境、市场环境、行业发展、公司情况等因素并在此基础上进行可行性分析；另一方面，前次延期募投项目“温度传感器建设项目”产品主要下游应用领域为国内外家电市场、“新一代智能驾驶刹车系统用力传感器建设项目”产品主要应用于汽车制动系统，与本次募投项目在产品、具体下游应用领域方面等均存在较大差异，前次募投延期相关影响因素对本次募投项目实施不会造成重大不利影响。

## 二、核查程序及核查意见

## （一）核查程序

保荐人履行了如下核查程序：

1、查阅发行人本次募投项目及前次募投项目可行性研究报告；查阅发行人关于本次募投项目与公司主营业务及前次募投项目在具体生产产品、所需原材料、应用领域、下游客户、主要技术参数等的区别和联系的相关说明；查阅发行人关于本次募投项目技术储备及募投项目投向主业的相关说明；

2、查阅本次募投项目可行性研究报告，测算MEMS 芯片模组转为自产的成本节约情况，了解发行人资产 MEMS 芯片模组参数指标情况；查阅同行业公司公开披露文件，了解传感器企业自产芯片模组是否符合行业趋势；查阅发行人本次募投项目及前次募投项目的可行性研究报告，了解本次募投项目是否涉及前次募投项目所投入设备；分析发行人“陶瓷电容式压力传感器产线升级项目”的合理性及必要性；

3、查阅发行人本次募投项目可行性研究报告，并分析募投项目建设投资测算过程、测算依据、参数假设、计算逻辑等；获取发行人相关产品报告期内的收入、单价、毛利率等数据，通过公开信息查询同行业可比公司类似项目的毛利率及内部收益率等有关数据，与本次募投项目测算进行对比，分析本次募投项目效益测算的合理性；

4、查阅发行人本次募投项目及前次募投项目的可行性研究报告，了解本次各募投项目及前次募投项目的新增产能情况、扩产倍数情况、新增产能的必要性及具体产能消化措施；访谈发行人管理层，了解公司不同产成品的委外加工情况；查阅发行人出具的行业竞争格局、下游行业发展前景及市场需求情况、公司现有产品产能利用率情况的说明，获取公司本次募投项目所涉及产品的在手订单或意向性协议情况，并通过公开资料查询同行业可比公司扩产情况等，分析本次募投项目各产品产能规模合理性及产能消化措施有效性；

5、查阅发行人本次募投项目的可行性研究报告，了解本次各募投项目的具体设备购置内容和作用等情况；获取设备报价情况，了解设备价格情况；获取发行人关于拟购置设备是否为公司目前相关资产的更新或升级的相关说明；分析相关投入规模是否合理；取得发行人本次募投项目可行性研究报告，并分析募投项目建设投资测算过程、测算依据、参数假设、计算逻辑等，分析募集资金投入的经济性；查阅发行人本次募投项目的可行性研究报告，了解本次募投项目的固定资产、无形资产等投资进度安排以及折旧摊销情况，查阅发行人出具的现有在建工程的建设进度、预计转固时间、公司现有固定资产和无形资产折旧摊销计提情况、折旧摊销政策等事项的说明，分析本次募投项目、拟建及在建项目等新增折旧摊销对发行人未来盈利能力及经营业绩的影响；

6、查阅了发行人本次发行募投项目的项目备案及环评相关文件；取得了上海安培龙与出租方签署的租赁协议文件；访谈发行人管理层，了解关于租赁厂房实施募投项目的原因；

7、查阅报告期内发行人关联方及关联交易相关资料，了解关联交易具体内容；查阅募投项目《可行性研究报告》，查阅本次募投项目建筑工程、设备购置明细及募投项目涉及产品情况，了解本次募投项目是否可能新增关联交易。

8、查阅发行人本次募投项目的可行性研究报告，了解本次募投项目研发费用的主要内容；查阅发行人关于本次募投项目技术可行性、研发预算及时间安排、目前研发投入及进展、已取得或预计可取得的研发成果等的说明，分析是否存在较大的研发失败风险；查阅发行人关于研发投入是否涉及资本化的说明；

9、查阅本次募投项目的可行性研究报告，了解投资明细和募集资金使用情况，测算投入产出比；整理并测算前次募投项目、同行业可比募投项目投入产出比，与公司情况进行对比以分析融资必要性；测算发行人资金缺口，分析补充流动资金规模的必要性；分析本次补充流动资金占比是否符合《证券期货法律适用意见第18 号》相关规定；

10、获取发行人前次募投项目调整、延期事项的三会文件并查询相关公告。

## （二）核查意见

经核查，保荐人认为：

1、本次募投项目与前次募投项目系属于互相独立的投资项目，在生产产品、应用领域、下游客户、主要技术参数等方面具有协同性，既有一定联系，亦存在明显差异，不存在重复建设的情形；本次募投项目之一的 MEMS 传感器芯片研发及产业化项目向产业链上游扩展具有必要性，有助于公司 MEMS 压力传感器芯片模组由原来的外采转变为自主供应为主，可较大程度降低 MEMS 压力传感器的生产成本，提升公司盈利能力，增强市场竞争力；发行人自研的 MEMS 传感器芯片模组的设计指标参数优于外购模组参数，满足汽车领域 MEMS 压力传感器的应用，具有小尺寸、成本低的优势，其中，MEMS 晶圆设计同时采用多晶硅屏蔽层、 $\mathrm { S i O } _ { 2 }$ 与 SiN 双钝化层，以及铂金或者铝的双金属互联可选，采用自主可控的工艺测试与工艺改进，以满足自身产品的质量要求，有利于确保MEMS压力传感器的质量稳定性与协同性，对公司加快新技术、新产品的产业化落地具有积极意义；除 MEMS 传感器芯片研发及产业化项目外，本次募投项目其他项目不存在向产业链上下游扩展的情形；本次募投项目的实施不存在重大不确定性，符合募集资金投向主业的要求；

2、发行人MEMS芯片模组由对外采购转为自行研发生产有利于降低MEMS压力传感器的生产成本，提升公司盈利能力，增强市场竞争力，同时有利于确保MEMS 压力传感器的质量稳定性与协同性，符合行业发展趋势，具备合理性；2024 年以来，发行人陶瓷电容式压力传感器产能利用率保持在较高水平；项目二“陶瓷电容式压力传感器产线升级项目”将对现有 13 条陶瓷电容式压力传感器产线进行技术升级改造（其中 2 条为配套线），提升公司现有产线的标准化及自动化程度，助力公司扩充产能、降本增效、优化生产工序、提升产品工艺精度；该项目涉及对前次募投所投入少量设备拆除，主要涉及振动测试机设备（账面原值约 210 万元，账面净值约为 153 万元），该部分设备拆除后将作为产线补充测试设备使用；本次升级涉及的陶瓷电容式压力传感器产线自 2021 年开始投建，自动化程度有限，本次升级有利于提升产线自动化水平，进一步扩充产能，实现降本增效，提升公司盈利能力，具有合理性和必要性。

3、受客户端降价要求及上游原材料端短期波动影响，发行人主要产品最近一年毛利率有所下滑，上述因素已逐步消除，叠加新产线带来的降本增效及产品结构优化，本次募投项目预计毛利率略高于发行人现有业务毛利率，预测具有合理性；本次募投内部收益率与同行业可比公司情况不存在重大差异，效益测算谨慎、合理，与公司现有同类业务及同行业可比公司情况不存在较大差异；

4、下游行业发展前景及市场需求情况、公司在手订单或意向性协议等较好，本次募投项目新增产能具有必要性；公司已采取产能消化措施，相关产能消化风险已进行披露；

5、拟购置设备基本为全新设备，仅陶瓷电容式压力传感器产线升级项目涉及部分相关资产的更新或升级，相关投入规模合理，募集资金投入具有经济性；虽然本次募投项目及其他在建和拟建项目的实施形成的资产将导致公司折旧摊销金额增加，但整体影响较小，且随着募投项目及其他在建和拟建项目实施后带来的营业收入和净利润增加、成本的节约，公司总体经营规模将会持续上升，将有效提高公司的市场竞争地位；

6、本次募投项目已取得开展所需的相关资质、认证、许可及备案，不存在重大不确定性或实质性障碍；项目四不涉及租赁土地，发行人租赁厂房形式实施募投项目主要基于提高资金使用效率、降低新购置土地及厂房建设的不确定性、提升项目灵活性等原因，具备合理性；

7、综上所述，本次募投项目可能涉及新增向天机智能的关联销售，为公司正常经营需要，具有合理性和必要性。涉及新增关联交易的定价将遵循市场化原则，保证定价公允；

8、项目四不存在较大的研发失败风险，针对可能的研发失败风险，公司已补充披露募投项目研发失败的风险；公司研发投入不存在资本化情形；

9、发行人本次募投项目支出主要包括装修工程费用、场地租赁费用、设备及软件购置费用、研发费用、预备费和铺底流动资金，均为投资项目必要的支出项，发行人本次募投项目投入产出比合理，本次融资具有必要性；本次向特定对象发行拟使用募集资金 9,000.00 万元用于补充流动资金，在公司未来经营资金需求缺口范围内，具备合理性；本次募集资金中，补充流动资金等非资本性支出的占比未超过本次募集资金总额的 30%，符合《证券期货法律适用意见第 18 号》的规定；

10、发行人部分前次募投项目存在调整、延期的情况，相关事项已履行必要的决策程序并及时披露，市场环境、行业发展情况、公司战略规划做出的决策，具有合理性；在行业增长节奏、下游客户需求等市场环境情况保持当前特征的情况下，导致前次募投延期相关影响因素短期内预计将可能持续；本次募投已充分考虑宏观环境、市场环境、行业发展、公司情况等因素并在此基础上进行可行性分析，亦不涉及温度传感器、新一代智能驾驶刹车系统用力传感器等相关业务，前次募投延期相关影响因素对本次募投项目实施不会造成重大不利影响。

## 其他问题

请发行人在募集说明书扉页重大事项提示中，按重要性原则披露对发行人及本次发行产生重大不利影响的直接和间接风险。披露风险应避免包含风险对策、发行人竞争优势及类似表述，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序。

同时，请发行人关注社会关注度较高、传播范围较广、可能影响本次发行的媒体报道情况，请保荐人对上述情况中涉及本次项目信息披露的真实性、准确性、完整性等事项进行核查，并于答复本审核问询函时一并提交。若无重大舆情情况，也请予以书面说明。

## 回复：

一、请发行人在募集说明书扉页重大事项提示中，按重要性原则披露对发行人及本次发行产生重大不利影响的直接和间接风险。披露风险应避免包含风险对策、发行人竞争优势及类似表述，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序

公司已在募集说明书扉页重大事项提示中，按重要性原则完善并披露了与公司及本次发行密切相关的重要直接和间接风险因素，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序。

二、请发行人关注社会关注度较高、传播范围较广、可能影响本次发行的媒体报道情况，请保荐人对上述情况中涉及本次项目信息披露的真实性、准确性、完整性等事项进行核查，并于答复本审核问询函时一并提交。若无重大舆情情况，也请予以书面说明

## （一）主要媒体报道及关注事项情况

公司于2025 年1月8日公告《深圳安培龙科技股份有限公司2026 年度向特定对象发行股票预案》，自上述预案公告日至本回复出具日，公司及保荐人持续关注媒体报道，通过 Wind、企查查、百度等主要数据库查询公司的敏感舆情，并通过常用搜索引擎查询财经网站、微信公众号等公开网络信息平台分析公众对于此类舆情的反馈。

经核查，自公司本次发行预案公告日至本回复出具日，不存在社会关注度较高、传播范围较广、可能影响本次发行的媒体报道，未出现对本次发行信息披露的真实性、准确性、完整性进行质疑的情形，本次发行申请文件中涉及的相关信息披露真实、准确、完整。

公司及保荐人将持续关注有关公司本次发行相关的媒体报道情况，如果出现媒体对公司本次发行信息披露的真实性、准确性、完整性提出质疑的情形，公司及保荐人将及时进行核查并持续关注相关事项进展。

## （二）核查程序及核查意见

## 1、核查程序

保荐人执行了以下核查程序：

通过网络检索等方式检索发行人自本次发行预案公告日至本回复出具日的相关媒体报道情况，查看是否存在与发行人本次发行相关的重大舆情或媒体质疑情况，并与本次发行申请文件进行对比。

## 2、核查意见

自发行人本次发行预案公告日至本回复出具日，不存在社会关注度较高、传播范围较广、可能影响本次发行的报道，未出现对本次发行信息披露的真实性、准确性、完整性进行质疑的情形。本次发行申请文件中涉及的相关信息披露真实、准确、完整。

保荐人将持续关注与发行人本次发行相关的媒体报道情况，如果出现媒体对本次发行信息披露真实性、准确性、完整性提出质疑的情形，保荐人将及时进行核查。

（本页无正文，为《关于深圳安培龙科技股份有限公司申请向特定对象发行股的审核问询函的回复》之签章页）

深圳安培龙科技股份有限公

![](images/b753f085d4fb8ed6723c76a61066a0620907b8f99b4b1fb61eb38cd06d26f7f0.jpg)  
深圳安培龙科技股份有限公司 130702948

年 月

## 发行人董事长声

本人已认真阅读《关于深圳安培龙科技股份有限公司申请向特定对象发行票的审核问询函的回复》的全部内容，确认回复的内容真实、准确、完整，不在虚假记载、误导性陈述或重大遗漏，并对其真实性、准确性、完整性承担相法律责任。

发行人董事长

郭若军

![](images/b2b8af663792eec3d9d6468b9204151bba94dd57aed8e6e6695982c368de51cc.jpg)  
深圳安培龙科技股份有限公司 X030703948

深圳安培龙科技股份有限公

2026年5月11日

（本页无正文，为华泰联合证券有限责任公司《关于深圳安培龙科技股份有限公司申请向特定对象发行股票的审核问询函的回复》之签章页）

保荐代表人：

罗剑群

黄

靳盼盼

![](images/b67260e75ddcc22ca46a73b918cd4ead068217d9e42b3721b17c98f1e57a930b.jpg)  
华泰联台科限责任公司

## 保荐机构法定代表人声明

本人已认真阅读深圳安培龙科技股份有限公司本次问询意见回复报告的全部内容，了解报告涉及问题的核查过程、本公司的内核和风险控制流程，确认本公司按照勤勉尽责原则履行核查程序，问询意见回复报告不存在虚假记载、误导性陈述或者重大遗漏，并对上述文件的真实性、准确性、完整性、及时性承担相应法律责任。

保荐机构法定代表人：

三

江禹

华泰联合证券有限责任公司

![](images/4607cac50099e3ac159ffa5cbfda73109ee7356b69573bee84453a8d07334513.jpg)  
中泰联容证券有限责任公司