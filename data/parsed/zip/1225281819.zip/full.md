盛屯矿业集团股份有限公司

关于上海证券交易所对公司2025年年度报告

# 信息披露监管问询函回复的公告

本公司董事会及全体董事保证本公告内容不存在任何虚假记载、误导性陈述或者重大遗漏，并对其内容的真实性、准确性和完整性承担法律责任。

盛屯矿业集团股份有限公司（以下简称“盛屯矿业”或“公司”）于近日收到上海证券交易所出具的《关于盛屯矿业集团股份有限公司 2025年年度报告的信息披露监管问询函》（上证公函[2026]0580 号）（以下简称“《问询函》”），收到《问询函》后，公司高度重视，针对《问询函》中提到的问题积极与会计师事务所进行了细致的研究与分析，结合公司实际情况，现将《问询函》的回复公告如下：

问题 1.关于业绩波动。年报显示，公司 2025 年营业收入同比增长 $1 6 . 6 \%$ ，净利润同比下滑 $2 . 1 9 \%$ 。铜、钴、镍等主要产品毛利率呈现下滑趋势，与 2025 年有色金属价格走势不一致。公司各季度业绩呈现显著波动，公司第一季度收入仅占全年收入的$1 8 . 8 9 \%$ ，第四季度净利润环比下滑 $5 9 . 9 7 \%$ 。公司部分销售合同采用可变对价安排。同时，2025 年公司矿石原材料总成本149.74 亿元，其中境外、境内采购比重分别为 $6 8 . 8 \% .$ 、$2 8 . 7 9 \%$ ，仅有 2.41%来自于自有矿山。请公司：（1）区分主要金属产品与业务板块，结合公司产品的定价政策及单价波动情况，说明毛利率下滑的主要原因，变动趋势与有色金属市场不一致的主要因素；（2）结合公司产量波动情况以及矿石来源等因素，区分固定成本与可变成本，说明公司增收不增利的主要原因，相关收入的确认方法及依据；（3）说明公司第一季度营业收入以及第四季度净利润出现大幅下降的主要原因；（4）结合具体合同条款等，说明不同合同的收入确认时点存在差异的合理性；公司是否合理区分点价权导致的公允价值变动和可变对价导致的收入调整，是否存在调节收入的情形；（5）公司主要供应商和客户是否存在重合情况，如是，请说明重合原因及合理性，以及采购商品和销售商品之间的对应关系，说明相关交易的商业合理性。

公司回复：

一、区分主要金属产品与业务板块，结合公司产品的定价政策及单价波动情况，说明毛利率下滑的主要原因，变动趋势与有色金属市场不一致的主要因素。

# 1.主要金属产品及业务板块的毛利率变动情况

2025 年，公司主营业务涵盖铜、钴、镍、锌等有色金属的开采、冶炼及贸易，主要产品及业务板块毛利率变动如下：

铜产品分类别列示毛利：  

<table><tr><td rowspan=1 colspan=1>业务板块/产品</td><td rowspan=1 colspan=1>2025年营业收入（万元）</td><td rowspan=1 colspan=1>2025年毛利率</td><td rowspan=1 colspan=1>2024年营业收入（万元）</td><td rowspan=1 colspan=1>2024年毛利率</td><td rowspan=1 colspan=1>变动(百分点)</td></tr><tr><td rowspan=1 colspan=1>能源金属业务</td><td rowspan=1 colspan=1>2,038,435.41</td><td rowspan=1 colspan=1>25.69%</td><td rowspan=1 colspan=1>1, 569,081.15</td><td rowspan=1 colspan=1>28.40%</td><td rowspan=1 colspan=1>减少2.71个百分点</td></tr><tr><td rowspan=1 colspan=1>其中：铜产品</td><td rowspan=1 colspan=1>1,407,062.16</td><td rowspan=1 colspan=1>28.88%</td><td rowspan=1 colspan=1>1,048,478. 15</td><td rowspan=1 colspan=1>35.23%</td><td rowspan=1 colspan=1>减少6.35个百分点</td></tr><tr><td rowspan=1 colspan=1>钴产品</td><td rowspan=1 colspan=1>101,111.37</td><td rowspan=1 colspan=1>53.76%</td><td rowspan=1 colspan=1>145,774.87</td><td rowspan=1 colspan=1>43.55%</td><td rowspan=1 colspan=1>增加10.21个百分点</td></tr><tr><td rowspan=1 colspan=1>镍产品</td><td rowspan=1 colspan=1>428,612.97</td><td rowspan=1 colspan=1>0.32%</td><td rowspan=1 colspan=1>378,753.23</td><td rowspan=1 colspan=1>3.57%</td><td rowspan=1 colspan=1>减少3.25个百分点</td></tr><tr><td rowspan=1 colspan=1>基础金属业务</td><td rowspan=1 colspan=1>824, 531. 64</td><td rowspan=1 colspan=1>4.81%</td><td rowspan=1 colspan=1>805,187. 11</td><td rowspan=1 colspan=1>4.13%</td><td rowspan=1 colspan=1>增加0.68个百分点</td></tr><tr><td rowspan=1 colspan=1>其中：锌产品</td><td rowspan=1 colspan=1>646,883.76</td><td rowspan=1 colspan=1>-5.27%</td><td rowspan=1 colspan=1>656,889.13</td><td rowspan=1 colspan=1>-1.61%</td><td rowspan=1 colspan=1>-1.61%减少3.66个百分点</td></tr></table>

<table><tr><td rowspan=1 colspan=1>业务板块/产品</td><td rowspan=1 colspan=1>2025年营业收入（万元）</td><td rowspan=1 colspan=1>2025年毛利率</td><td rowspan=1 colspan=1>2024年营业收入（万元）</td><td rowspan=1 colspan=1>2024年毛利率</td><td rowspan=1 colspan=1>变动（百分点）</td></tr><tr><td rowspan=1 colspan=1>铜产品-自采矿料</td><td rowspan=1 colspan=1>278,178.88</td><td rowspan=1 colspan=1>56.87%</td><td rowspan=1 colspan=1>334,694.38</td><td rowspan=1 colspan=1>61.89%</td><td rowspan=1 colspan=1>减少5.02个百分点</td></tr><tr><td rowspan=1 colspan=1>铜产品-外采矿料</td><td rowspan=1 colspan=1>1,128,883.28</td><td rowspan=1 colspan=1>21.98%</td><td rowspan=1 colspan=1>713,783.76</td><td rowspan=1 colspan=1>22.72%</td><td rowspan=1 colspan=1>22.72%减少0.74个百分点</td></tr></table>

公司铜、镍产品及锌产品毛利率均呈现不同程度的下滑，钴产品毛利率增加。

# 2.定价政策及单价波动情况

（1）公司主要产品定价政策（2）公司主要产品市场价格波动情况

<table><tr><td rowspan=1 colspan=1>产品名称</td><td rowspan=1 colspan=1>定价方式</td><td rowspan=1 colspan=1>点价期</td></tr><tr><td rowspan=1 colspan=1>刚果（金）-电积铜</td><td rowspan=1 colspan=1>LME铜价减去合同适用折扣</td><td rowspan=1 colspan=1>M+N（“M”代表交货月，“N”代表交货月后“N”月属于点价期。）</td></tr><tr><td rowspan=1 colspan=1>刚果（金）-氢氧化钴</td><td rowspan=1 colspan=1>主要参考MB钴报价</td><td rowspan=1 colspan=1>不涉及</td></tr><tr><td rowspan=1 colspan=1>科立鑫-四氧化三钴、氧化钴</td><td rowspan=1 colspan=1>SMM四氧化三钴高低幅均价*对应系数或上海有色网硫酸钴的市场价为基准*对应系数</td><td rowspan=1 colspan=1>不涉及</td></tr><tr><td rowspan=1 colspan=1>印尼-镍铁</td><td rowspan=1 colspan=1>合同日期市场价</td><td rowspan=1 colspan=1>不涉及</td></tr><tr><td rowspan=1 colspan=1>盛屯锌锗-锌锭</td><td rowspan=1 colspan=1>上海有色网0#、1#锌锭扣减升贴水</td><td rowspan=1 colspan=1>不涉及</td></tr><tr><td rowspan=1 colspan=1>贵州-电池级硫酸镍</td><td rowspan=1 colspan=1>上海有色网SMM电池级硫酸镍低幅均价月均价乘约定比例</td><td rowspan=1 colspan=1>不涉及</td></tr></table>

铜产品：铜价格“区间波动、重心上移”，全年均价高于2024年。2024 年LME 铜现货价均价约9,144美元/吨，2025年LME 铜现货价 $8 , 5 0 0 - 1 2 , 5 0 4$ 美元/吨，半年震荡调整，10 月后加速上涨，年末LME 铜现货价12,504美元/吨，全年均价约9,945美元/吨，全年均价增长约 $8 . 7 6 \%$ 。

![](images/c41d6694dd95e4a306764b2d0a6d7e3ec7b9b7e9d03c36fcba0e5f083482f13f.jpg)  
现货结算价：LME铜   
数据来源：同花顺iFinD

钴产品：MB 钴价在2024年持续走低，到2025 年2月跌至谷底。随后，在全球最大钴生产国刚果（金）的出口管制政策刺激下，价格迅速反弹并在年末冲高。2024年四氧化三钴均价约 125,383.47 元/吨，2025 年四氧化三钴均价约 218,613.93 元/吨，全年均价增长约 $7 4 . 3 6 \%$ 。

![](images/833be2c8b6e9df382b91bdca048dabf5daff70d5f828e977b4b9891745ba4e63.jpg)  
平均价：四氧化三钻  
数据来源：同花顺iFinD

镍产品：镍价格“整体震荡下行”。2024 年，镍价呈现先抑后扬的走势，LME镍价年初约 1.63 万美元/金属吨，5 月冲高至 2.13 万美元/金属吨后回落，年末跌至 1.51万美元/金属吨，全年均价较2023年下降约 $2 1 . 7 5 \%$ 。2025 年，镍价区间 LME 镍 1.38 万–1.88万美元/吨；沪镍14 万-19万元/吨,2025年全年低位震荡；12 月印尼宣布2026年镍矿配额削减，价格短期暴涨超 $3 0 \%$ 。2024 年,LME 镍均价约 16,811.63 美元/吨，2025年镍均价约15,159.94 美元/吨，全年均价降低约 $9 , 8 2 \%$ 。

![](images/c2e3ae62903a1c4a710e0bfad31aa5970fdd91735840fa750f3435facbb53324.jpg)  
现货结算价：LME镍   
数据来源：同花顺iFinD

锌产品：锌价格“承压下行”，表现弱于其他基本金属。2024年趋势性上行，锌价开启了一轮显著的震荡上行行情,在 2024年末触及高点后，锌价自2025 年初起进入回调阶段。2024 年 SMM0#锌锭均价 23,397.69/吨，2025 年 SMM0#锌锭均价 22,865.97/吨，全年均价降低约 $2 . 2 7 \%$ 。

![](images/e586067361361f9b63651557d725021c1aea88eb5d00b3afc6743b63bc33a56a.jpg)  
生产资料价格：锌锭（0#）  
数据来源：同花顺iFinD

# 3. 毛利率下滑的主要原因

（1）公司主要产品及毛利率情况：

<table><tr><td rowspan=1 colspan=1>产品</td><td rowspan=1 colspan=1>2025年营收（万元）</td><td rowspan=1 colspan=1>营收占比(%)</td><td rowspan=1 colspan=1>2025年度毛利率(%）</td><td rowspan=1 colspan=1>2025年度毛利额（万元）</td><td rowspan=1 colspan=1>2024年营收（万元）</td><td rowspan=1 colspan=1>收占比（%）</td><td rowspan=1 colspan=1>毛利率（%）</td><td rowspan=1 colspan=1>2024年度毛利额(万元)</td></tr><tr><td rowspan=1 colspan=1>铜产品</td><td rowspan=1 colspan=1>1,407,062. 16</td><td rowspan=1 colspan=1>54.46</td><td rowspan=1 colspan=1>28.884</td><td rowspan=1 colspan=1>8406,374.881</td><td rowspan=1 colspan=1>81,048,478.15</td><td rowspan=1 colspan=1>47.02</td><td rowspan=1 colspan=1>35.233</td><td rowspan=1 colspan=1>369,363.36</td></tr><tr><td rowspan=1 colspan=1>钴产品</td><td rowspan=1 colspan=1>101,111.37</td><td rowspan=1 colspan=1>3.91</td><td rowspan=1 colspan=1>53.76</td><td rowspan=1 colspan=1>54,354.72</td><td rowspan=1 colspan=1>145,774.87</td><td rowspan=1 colspan=1>6.54</td><td rowspan=1 colspan=1>43.55</td><td rowspan=1 colspan=1>63,486.98</td></tr><tr><td rowspan=1 colspan=1>镍产品</td><td rowspan=1 colspan=1>428,612.97</td><td rowspan=1 colspan=1>16.59</td><td rowspan=1 colspan=1>0.32</td><td rowspan=1 colspan=1>1,377.00</td><td rowspan=1 colspan=1>378,753.23</td><td rowspan=1 colspan=1>16.99</td><td rowspan=1 colspan=1>3.57</td><td rowspan=1 colspan=1>13,503.40</td></tr><tr><td rowspan=1 colspan=1>锌产品</td><td rowspan=1 colspan=1>646,883.76</td><td rowspan=1 colspan=1>25.04</td><td rowspan=1 colspan=1>-5.27</td><td rowspan=1 colspan=1>-34,068.22</td><td rowspan=1 colspan=1>656,889.13</td><td rowspan=1 colspan=1>29.46</td><td rowspan=1 colspan=1>-1.61</td><td rowspan=1 colspan=1>-10,553.32</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>2,583,670.27</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>16.57</td><td rowspan=1 colspan=1>428,038.38</td><td rowspan=1 colspan=1>16.57428,038.382,229,895.39</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1>19.54</td><td rowspan=1 colspan=1>19.54435,800.42</td></tr></table>

对公司毛利贡献超过 $9 0 \%$ 的铜产品的毛利率下降，拉低公司整体毛利率水平。其他产品情况：钴产品受价格上涨影响毛利率提升，但因受销量减少的影响营业收入及毛利额较上年减少；镍产品受市场价格下跌的影响，毛利额及毛利率较上年均有所下降；锌产品受市场行情影响，亏损增加。

（2）主要产品销售单价及单位成本情况：

单位：元/吨

<table><tr><td colspan="1" rowspan="2">年度</td><td colspan="1" rowspan="2">项目</td><td colspan="1" rowspan="2">类别</td><td colspan="4" rowspan="1">产品</td></tr><tr><td colspan="1" rowspan="1">铜产品</td><td colspan="1" rowspan="1">钻产品</td><td colspan="1" rowspan="1">镍产品</td><td colspan="1" rowspan="1">锌产品</td></tr><tr><td colspan="1" rowspan="7">2025年</td><td colspan="1" rowspan="1">销售单价</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">68,092.03</td><td colspan="1" rowspan="1">174,027.51</td><td colspan="1" rowspan="1">89,809.01</td><td colspan="1" rowspan="1">19,859.49</td></tr><tr><td colspan="1" rowspan="4">单位可变成本</td><td colspan="1" rowspan="1">原料</td><td colspan="1" rowspan="1">34,227. 14</td><td colspan="1" rowspan="1">11,895.10</td><td colspan="1" rowspan="1">54,575.15</td><td colspan="1" rowspan="1">17,643. 04</td></tr><tr><td colspan="1" rowspan="1">辅料</td><td colspan="1" rowspan="1">2,609.75</td><td colspan="1" rowspan="1">24,945.17</td><td colspan="1" rowspan="1">7,756.73</td><td colspan="1" rowspan="1">382.43</td></tr><tr><td colspan="1" rowspan="1">能源</td><td colspan="1" rowspan="1">6,725.42</td><td colspan="1" rowspan="1">15,152.32</td><td colspan="1" rowspan="1">12,411. 44</td><td colspan="1" rowspan="1">1, 667. 92</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">43, 562.31</td><td colspan="1" rowspan="1">51,992.59</td><td colspan="1" rowspan="1">74,743. 32</td><td colspan="1" rowspan="1">19,693.39</td></tr><tr><td colspan="1" rowspan="2">单位固定成本及其他</td><td colspan="1" rowspan="1">人工</td><td colspan="1" rowspan="1">1,120.43</td><td colspan="1" rowspan="1">4,192.26</td><td colspan="1" rowspan="1">2,990.86</td><td colspan="1" rowspan="1">503.77</td></tr><tr><td colspan="1" rowspan="1">折旧及其他</td><td colspan="1" rowspan="1">3,743.57</td><td colspan="1" rowspan="1">24,290.20</td><td colspan="1" rowspan="1">11,786.31</td><td colspan="1" rowspan="1">708.25</td></tr><tr><td colspan="1" rowspan="3"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">4,864.00</td><td colspan="1" rowspan="1">28,482.46</td><td colspan="1" rowspan="1">14,777.17</td><td colspan="1" rowspan="1">1,212.02</td></tr><tr><td colspan="1" rowspan="1">单位成本合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">48, 426.31</td><td colspan="1" rowspan="1">80,475.05</td><td colspan="1" rowspan="1">89,520.49</td><td colspan="1" rowspan="1">20,905.41</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">28.88%</td><td colspan="1" rowspan="1">53.76%</td><td colspan="1" rowspan="1">0.32%</td><td colspan="1" rowspan="1">-5. 27%</td></tr><tr><td colspan="1" rowspan="10">2024年</td><td colspan="1" rowspan="1">销售单价</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">62,810.96</td><td colspan="1" rowspan="1">124,380.76</td><td colspan="1" rowspan="1">110,693.38</td><td colspan="1" rowspan="1">20,411. 65</td></tr><tr><td colspan="1" rowspan="4">单位可变成本</td><td colspan="1" rowspan="1">原料</td><td colspan="1" rowspan="1">28, 430.04</td><td colspan="1" rowspan="1">14, 691. 46</td><td colspan="1" rowspan="1">58,893.82</td><td colspan="1" rowspan="1">17, 212. 48</td></tr><tr><td colspan="1" rowspan="1">辅料</td><td colspan="1" rowspan="1">3,111.23</td><td colspan="1" rowspan="1">19,069.56</td><td colspan="1" rowspan="1">12,277. 57</td><td colspan="1" rowspan="1">414.32</td></tr><tr><td colspan="1" rowspan="1">能源</td><td colspan="1" rowspan="1">4,787.24</td><td colspan="1" rowspan="1">9,479.86</td><td colspan="1" rowspan="1">18,417. 34</td><td colspan="1" rowspan="1">1,820.52</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">36,328.51</td><td colspan="1" rowspan="1">43,240.88</td><td colspan="1" rowspan="1">89, 588.73</td><td colspan="1" rowspan="1">19,447.32</td></tr><tr><td colspan="1" rowspan="3">单位固定成本及其他</td><td colspan="1" rowspan="1">人工</td><td colspan="1" rowspan="1">1,073.16</td><td colspan="1" rowspan="1">3,575.68</td><td colspan="1" rowspan="1">5,123.45</td><td colspan="1" rowspan="1">551.92</td></tr><tr><td colspan="1" rowspan="1">折旧及其他</td><td colspan="1" rowspan="1">3,281.93</td><td colspan="1" rowspan="1">23,394. 66</td><td colspan="1" rowspan="1">12,034.73</td><td colspan="1" rowspan="1">740.35</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">4,355.09</td><td colspan="1" rowspan="1">26, 970. 34</td><td colspan="1" rowspan="1">17, 158. 18</td><td colspan="1" rowspan="1">1,292. 27</td></tr><tr><td colspan="1" rowspan="1">单位成本合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">40,683. 60</td><td colspan="1" rowspan="1">70,211.22</td><td colspan="1" rowspan="1">106,746. 91</td><td colspan="1" rowspan="1">20,739.59</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">35.23%</td><td colspan="1" rowspan="1">43.55%</td><td colspan="1" rowspan="1">3.57%</td><td colspan="1" rowspan="1">-1. 61%</td></tr><tr><td colspan="1" rowspan="10">两期变动</td><td colspan="1" rowspan="1">销售单价</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">8.41%</td><td colspan="1" rowspan="1">39.92%</td><td colspan="1" rowspan="1">-18.87%</td><td colspan="1" rowspan="1">-2.71%</td></tr><tr><td colspan="1" rowspan="4">单位可变成本</td><td colspan="1" rowspan="1">原料</td><td colspan="1" rowspan="1">20.39%</td><td colspan="1" rowspan="1">-19.03%</td><td colspan="1" rowspan="1">-7.33%</td><td colspan="1" rowspan="1">2.50%</td></tr><tr><td colspan="1" rowspan="1">辅料</td><td colspan="1" rowspan="1">-16.12%</td><td colspan="1" rowspan="1">30.81%</td><td colspan="1" rowspan="1">-36.82%</td><td colspan="1" rowspan="1">-7. 70%</td></tr><tr><td colspan="1" rowspan="1">能源</td><td colspan="1" rowspan="1">40.49%</td><td colspan="1" rowspan="1">59.84%</td><td colspan="1" rowspan="1">-32.61%</td><td colspan="1" rowspan="1">-8.38%</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">19.91%</td><td colspan="1" rowspan="1">20.24%</td><td colspan="1" rowspan="1">-16.57%</td><td colspan="1" rowspan="1">1. 27%</td></tr><tr><td colspan="1" rowspan="3">单位固定成本及其他</td><td colspan="1" rowspan="1">人工</td><td colspan="1" rowspan="1">4.40%</td><td colspan="1" rowspan="1">17.24%</td><td colspan="1" rowspan="1">-41. 62%</td><td colspan="1" rowspan="1">-8.72%</td></tr><tr><td colspan="1" rowspan="1">折旧及其他</td><td colspan="1" rowspan="1">14.07%</td><td colspan="1" rowspan="1">3.83%</td><td colspan="1" rowspan="1">-2.06%</td><td colspan="1" rowspan="1">-4.34%</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">11. 69%</td><td colspan="1" rowspan="1">5.61%</td><td colspan="1" rowspan="1">-13.88%</td><td colspan="1" rowspan="1">-6.21%</td></tr><tr><td colspan="1" rowspan="1">单位成本合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">19.03%</td><td colspan="1" rowspan="1">14.62%</td><td colspan="1" rowspan="1">-16.14%</td><td colspan="1" rowspan="1">0.80%</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">-6.35%</td><td colspan="1" rowspan="1">10.21%</td><td colspan="1" rowspan="1">-3.25%</td><td colspan="1" rowspan="1">-3.66%</td></tr></table>

2025 年公司各产品的毛利率受销售价格及单位成本变动的综合影响。

铜产品：2025 年销售单价为 68,092.03 元/吨，较 2024 年上涨 $8 . 4 1 \%$ ；单位成本合计为 48,426.31 元/吨，上涨 $1 9 . 0 3 \%$ 。其中原料成本上涨 $2 0 . 3 9 \%$ ，能源成本上涨 $4 0 . 4 9 \%$ 。毛利率由2024年的 $3 5 . 2 3 \%$ 下降至 $2 8 . 8 8 \%$ ，下降6.35个百分点。

钴产品：2025 年销售单价为 174,027.51 元/吨，较 2024 年上涨 $3 9 . 9 2 \%$ ；单位成本合计为 80,475.05 元/吨，上涨 $1 4 . 6 2 \%$ 。其中原料成本下降 $1 9 . 0 3 \%$ ，辅料成本上涨 $3 0 . 8 1 \%$ ，能源成本上涨 $5 9 . 8 4 \%$ 。毛利率由2024 年的 $4 3 . 5 5 \%$ 上升至 $5 3 . 7 6 \%$ ，上升10.21个百分点。

镍产品：2025 年销售单价为 89,809.01 元/吨，较 2024 年下降 $1 8 . 8 7 \%$ ；单位成本合计为 89,520.49 元/吨，下降 $1 6 . 1 4 \%$ 。其中辅料成本下降 $3 6 , 8 2 \%$ ，能源成本下降 $3 2 . 6 1 \%$ ，人工成本下降 $4 1 . 6 2 \%$ 。毛利率由2024年的 $3 . 5 7 \%$ 下降至 $0 . 3 2 \%$ ，下降3.25个百分点。

锌产品：2025 年销售单价为 19,859.49 元/吨，较 2024 年下降 $2 . 7 1 \%$ ；单位成本合计为 20,905.41 元/吨，上升 $0 , 8 0 \%$ 。毛利率由2024年的 $- 1 . 6 1 \%$ 下降至 $- 5 . 2 7 \%$ ，下降 3.66个百分点。

（3）铜产品毛利率变动：

2025年度公司铜产品毛利率较上年下降约6.35个百分点，主要系原料成本上涨及延迟定价安排影响扩大所致。

$\textcircled{1}$ 铜产品原料成本上涨导致本年毛利率较上年下降

2025 年，LME 铜均价同比上涨 $8 . 7 6 \%$ ，公司铜产品销售单价亦同比上涨 $8 . 4 1 \%$ ，与市场走势基本一致。公司单位原料成本同比大幅上涨 $2 0 . 3 9 \%$ ，致使原料成本占营业收入的比例由 $4 5 . 2 6 \%$ 升至 $5 0 . 2 7 \%$ 。尽管销售单价有所提高，但更大幅度的原料成本上涨，导致铜产品毛利率较上年减少 $5 , 0 1 \%$ 。

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>两期变动</td></tr><tr><td rowspan=1 colspan=1>销售数量（吨)</td><td rowspan=1 colspan=1>206, 641. 23</td><td rowspan=1 colspan=1>166,925.99</td><td rowspan=1 colspan=1>23.79%</td></tr><tr><td rowspan=1 colspan=1>营业收入（铜产品)（万元）</td><td rowspan=1 colspan=1>1,407,062.16</td><td rowspan=1 colspan=1>1, 048, 478. 15</td><td rowspan=1 colspan=1>34.20%</td></tr><tr><td rowspan=1 colspan=1>销售单价（元/吨）</td><td rowspan=1 colspan=1>68,092.03</td><td rowspan=1 colspan=1>62,810.96</td><td rowspan=1 colspan=1>8.41%</td></tr><tr><td rowspan=1 colspan=1>原料成本（铜产品）（万元）</td><td rowspan=1 colspan=1>707,273. 87</td><td rowspan=1 colspan=1>474, 571. 21</td><td rowspan=1 colspan=1>49.03%</td></tr><tr><td rowspan=1 colspan=1>单位原料成本(元/吨)</td><td rowspan=1 colspan=1>34,227. 14</td><td rowspan=1 colspan=1>28,430. 04</td><td rowspan=1 colspan=1>20.39%</td></tr><tr><td rowspan=1 colspan=1>原料成本/营业收入</td><td rowspan=1 colspan=1>50. 27%</td><td rowspan=1 colspan=1>45.26%</td><td rowspan=1 colspan=1>5.01%</td></tr></table>

单位原料成本上涨原因为刚果（金）冶炼项目铜产品矿料结构变动。自有矿料投料占比下降，而单价较高的外采矿料占比增加，导致单位矿料成本较上期增长 $2 2 . 1 5 \%$ 。数据对比如下：

<table><tr><td rowspan=1 colspan=1>期间</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>自有矿料</td><td rowspan=1 colspan=1>外采矿料</td><td rowspan=1 colspan=1>合计</td></tr><tr><td rowspan=3 colspan=1>2025年度</td><td rowspan=1 colspan=1>数量（万吨）</td><td rowspan=1 colspan=1>4.40</td><td rowspan=1 colspan=1>17.43</td><td rowspan=1 colspan=1>21.83</td></tr><tr><td rowspan=1 colspan=1>金额（万元）</td><td rowspan=1 colspan=1>27,754. 57</td><td rowspan=1 colspan=1>632,198.77</td><td rowspan=1 colspan=1>659, 953. 34</td></tr><tr><td rowspan=1 colspan=1>矿料单价(元/吨)</td><td rowspan=1 colspan=1>6,307.86</td><td rowspan=1 colspan=1>36,270.73</td><td rowspan=1 colspan=1>30,231. 49</td></tr><tr><td rowspan=3 colspan=1>2024年度</td><td rowspan=1 colspan=1>数量（万吨）</td><td rowspan=1 colspan=1>6.76</td><td rowspan=1 colspan=1>12.86</td><td rowspan=1 colspan=1>19.62</td></tr><tr><td rowspan=1 colspan=1>金额（万元）</td><td rowspan=1 colspan=1>34,686. 52</td><td rowspan=1 colspan=1>450,892.80</td><td rowspan=1 colspan=1>485, 579.32</td></tr><tr><td rowspan=1 colspan=1>矿料单价（元/吨）</td><td rowspan=1 colspan=1>5,131. 14</td><td rowspan=1 colspan=1>35,061. 65</td><td rowspan=1 colspan=1>24,749. 20</td></tr><tr><td rowspan=3 colspan=1>两期变动</td><td rowspan=1 colspan=1>数量（%）</td><td rowspan=1 colspan=1>-34.91</td><td rowspan=1 colspan=1>35.54</td><td rowspan=1 colspan=1>11. 26</td></tr><tr><td rowspan=1 colspan=1>金额（%）</td><td rowspan=1 colspan=1>-19.98</td><td rowspan=1 colspan=1>40.21</td><td rowspan=1 colspan=1>35.91</td></tr><tr><td rowspan=1 colspan=1>矿料单价（%）</td><td rowspan=1 colspan=1>22.93</td><td rowspan=1 colspan=1>3.45</td><td rowspan=1 colspan=1>22.15</td></tr></table>

（注：上表基于原材料投料口径分析，矿料成本增幅 $2 2 . 1 5 \%$ 。此数据与前述基于营业成本口径分析的单位原料成本增幅 $2 0 . 3 9 \%$ 存在差异，系两者统计口径不同所致。）

矿料结构变动的背景系随着自有矿山开采深度加深、采矿作业面缩小，出矿量减少。生产主体KMSA卡隆威公司为满足生产安排，开始对外采购矿料，导致外采矿料使用比例增加，并与自有矿料混合使用。

$\textcircled{2}$ 铜产品的销售延期定价安排导致本年毛利率较上年下降

2025 年，计入公允价值变动损益的延期定价安排占铜产品销售收入合计的比例升至$2 , 5 0 \%$ （2024 年： $0 . 8 1 \%$ ），导致本期毛利相应减少 $2 , 5 0 \%$ （2024年：减少 $0 . 8 1 \%$ ），其对毛利的负面影响较上年扩大了 $1 , 6 9 \%$ 。

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>两期变动</td></tr><tr><td rowspan=1 colspan=1>营业收入(铜产品)</td><td rowspan=1 colspan=1>1, 407,062. 16</td><td rowspan=1 colspan=1>1, 048,478. 15</td><td rowspan=1 colspan=1>358, 584. 01</td></tr><tr><td rowspan=1 colspan=1>计入公允价值变动损益的延期定价安排（铜产品）</td><td rowspan=1 colspan=1>36,010.24</td><td rowspan=1 colspan=1>8,599.88</td><td rowspan=1 colspan=1>27,410.36</td></tr><tr><td rowspan=1 colspan=1>销售收入合计(铜产品)</td><td rowspan=1 colspan=1>1,443, 072. 40</td><td rowspan=1 colspan=1>1, 057,078. 03</td><td rowspan=1 colspan=1>385,994.37</td></tr><tr><td rowspan=1 colspan=1>计入公允价值变动损益的延期定价安排（铜产品）/销售收入合计(铜产品)</td><td rowspan=1 colspan=1>2.50%</td><td rowspan=1 colspan=1>0.81%</td><td rowspan=1 colspan=1>1. 69%</td></tr></table>

综上，2025 年公司铜产品毛利率较 2024 年下降约6.35 个百分点，主要原因在于，虽然销售单价同比上涨 $8 . 4 1 \%$ ，但原料单位成本上升及销售延期定价安排占比扩大等因素的影响导致毛利率下降。

# 4. 毛利率变动与有色金属市场不一致的主要因素

（1）产品结构影响：2025年有色金属市场整体上行主要由铜等品种驱动，而公司产品结构中，镍、锌等价格表现较弱（镍价下行，锌价承压）的品种占有一定比例，且其毛利率下滑或为负，抵消了铜、钴价格上涨带来的正面影响。

（2）成本结构差异：公司2025 年度铜矿矿石自给率较2024 年度有所降低（2024年为 $3 4 . 4 5 \%$ ，2025 年为 $2 0 . 1 6 \%$ ），铜产品单位矿料成本上涨约 $2 2 . 1 5 \%$ ，抵消了铜价上涨带来的正向影响，导致“增收不增利”，毛利率表现弱于市场整体趋势。

# （3）钴业务内部结构影响

从全年均价看，四氧化三钴价格由 2024 年的约125,383.47 元/吨上涨至2025年的约 218,613.93 元/吨，涨幅达 $7 4 . 3 6 \%$ 。受此影响，公司钴产品整体毛利率提升约10.21个百分点，毛利率涨幅远低于市场价格涨幅，主要系产品销售月份、成本变动与市场行情波动的综合作用结果。公司钴产品业务主要分为境外（刚果金）与境内（珠海科立鑫）两部分，具体表现如下：

$\textcircled{1}$ 境外刚果金业务：2025 年2月刚果金实施钴出口禁令，导致以往年度高毛利率的钴产品本年度销量大幅下降，营业收入及毛利总额同步减少，刚果金钴产品毛利总额较上年减少1.94亿元，毛利率增长约 $1 4 . 5 9 \%$ 。

$\textcircled{2}$ 境内珠海科立鑫业务：受益于钴价上涨，珠海科立鑫钴产品毛利总额增加 1.32亿元，毛利率增长约 $2 0 . 4 8 \%$ 。

$\textcircled{3}$ 其他主体及未实现内部损益导致钴产品毛利总额较上年增加0.54亿元。

以上因素共同导致本年钴产品毛利率仅增长10.21个百分点。

# 二、结合公司产量波动情况以及矿石来源等因素，区分固定成本与可变成本，说明公司增收不增利的主要原因，相关收入的确认方法及依据。

# 1. 产量波动情况

2025 年主要产品产量情况如下：  

<table><tr><td rowspan=1 colspan=1>产品</td><td rowspan=1 colspan=1>2025年产量</td><td rowspan=1 colspan=1>2024年产量</td><td rowspan=1 colspan=1>同比增减</td></tr><tr><td rowspan=1 colspan=1>铜产品 (金属吨)</td><td rowspan=1 colspan=1>207, 383. 16</td><td rowspan=1 colspan=1>176, 530. 02</td><td rowspan=1 colspan=1>17.48%</td></tr><tr><td rowspan=1 colspan=1>钴产品(金属吨）</td><td rowspan=1 colspan=1>9,203.13</td><td rowspan=1 colspan=1>13,257. 65</td><td rowspan=1 colspan=1>-30.58%</td></tr><tr><td rowspan=1 colspan=1>镍产品 (金属吨)</td><td rowspan=1 colspan=1>49, 418. 04</td><td rowspan=1 colspan=1>32,852. 54</td><td rowspan=1 colspan=1>50.42%</td></tr><tr><td rowspan=1 colspan=1>锌产品 (金属吨)</td><td rowspan=1 colspan=1>326,296.84</td><td rowspan=1 colspan=1>322,722.94</td><td rowspan=1 colspan=1>1. 11%</td></tr></table>

铜、镍产品产量实现较大幅度增长，但钴产品因出口限制及原料原因产量下降明显。

# 2. 矿石来源及成本结构如下

2025 年公司矿石原材料开采、采购成本149.74 亿元，来源构成如下：自有矿山成本 3.61 亿元，国内采购成本43.11 亿元，境外采购成本103.02 亿元。

3. 两年单位产品成本：

单位：元/吨

<table><tr><td colspan="1" rowspan="2">年度</td><td colspan="1" rowspan="2">项目</td><td colspan="1" rowspan="2">类别</td><td colspan="4" rowspan="1">产品</td></tr><tr><td colspan="1" rowspan="1">铜产品</td><td colspan="1" rowspan="1">钻产品</td><td colspan="1" rowspan="1">镍产品</td><td colspan="1" rowspan="1">锌产品</td></tr><tr><td colspan="1" rowspan="8">2025年</td><td colspan="1" rowspan="4">可变成本</td><td colspan="1" rowspan="1">原料</td><td colspan="1" rowspan="1">34,227. 14</td><td colspan="1" rowspan="1">11,895.10</td><td colspan="1" rowspan="1">54, 575.15</td><td colspan="1" rowspan="1">17,643. 04</td></tr><tr><td colspan="1" rowspan="1">辅料</td><td colspan="1" rowspan="1">2,609.75</td><td colspan="1" rowspan="1">24,945.17</td><td colspan="1" rowspan="1">7,756.73</td><td colspan="1" rowspan="1">382.43</td></tr><tr><td colspan="1" rowspan="1">能源</td><td colspan="1" rowspan="1">6,725.42</td><td colspan="1" rowspan="1">15,152.32</td><td colspan="1" rowspan="1">12, 411. 44</td><td colspan="1" rowspan="1">1, 667. 92</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">43,562. 31</td><td colspan="1" rowspan="1">51,992.59</td><td colspan="1" rowspan="1">74,743. 32</td><td colspan="1" rowspan="1">19,693.39</td></tr><tr><td colspan="1" rowspan="3">固定成本及其他</td><td colspan="1" rowspan="1">人工</td><td colspan="1" rowspan="1">1,120.43</td><td colspan="1" rowspan="1">4,192.26</td><td colspan="1" rowspan="1">2,990.86</td><td colspan="1" rowspan="1">503.77</td></tr><tr><td colspan="1" rowspan="1">折旧及其他</td><td colspan="1" rowspan="1">3,743. 57</td><td colspan="1" rowspan="1">24,290.20</td><td colspan="1" rowspan="1">11, 786. 31</td><td colspan="1" rowspan="1">708.25</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">4,864.00</td><td colspan="1" rowspan="1">28,482.46</td><td colspan="1" rowspan="1">14,777. 17</td><td colspan="1" rowspan="1">1,212. 02</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">48,426.31</td><td colspan="1" rowspan="1">80,475.05</td><td colspan="1" rowspan="1">89,520.49</td><td colspan="1" rowspan="1">20,905.41</td></tr><tr><td colspan="1" rowspan="8">2024年</td><td colspan="1" rowspan="4">可变成本</td><td colspan="1" rowspan="1">原料</td><td colspan="1" rowspan="1">28,430. 04</td><td colspan="1" rowspan="1">14,691. 46</td><td colspan="1" rowspan="1">58,893.82</td><td colspan="1" rowspan="1">17,212. 48</td></tr><tr><td colspan="1" rowspan="1">辅料</td><td colspan="1" rowspan="1">3, 111.23</td><td colspan="1" rowspan="1">19,069. 56</td><td colspan="1" rowspan="1">12, 277. 57</td><td colspan="1" rowspan="1">414.32</td></tr><tr><td colspan="1" rowspan="1">能源</td><td colspan="1" rowspan="1">4,787. 24</td><td colspan="1" rowspan="1">9,479.86</td><td colspan="1" rowspan="1">18,417. 34</td><td colspan="1" rowspan="1">1,820. 52</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">36,328.51</td><td colspan="1" rowspan="1">43,240.88</td><td colspan="1" rowspan="1">89,588.73</td><td colspan="1" rowspan="1">19,447. 32</td></tr><tr><td colspan="1" rowspan="3">固定成本及其他</td><td colspan="1" rowspan="1">人工</td><td colspan="1" rowspan="1">1,073.16</td><td colspan="1" rowspan="1">3,575.68</td><td colspan="1" rowspan="1">5,123.45</td><td colspan="1" rowspan="1">551.92</td></tr><tr><td colspan="1" rowspan="1">折旧及其他</td><td colspan="1" rowspan="1">3,281.93</td><td colspan="1" rowspan="1">23,394. 66</td><td colspan="1" rowspan="1">12, 034.73</td><td colspan="1" rowspan="1">740.35</td></tr><tr><td colspan="1" rowspan="1">小计</td><td colspan="1" rowspan="1">4,355.09</td><td colspan="1" rowspan="1">26,970.34</td><td colspan="1" rowspan="1">17,158. 18</td><td colspan="1" rowspan="1">1,292. 27</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">40, 683. 60</td><td colspan="1" rowspan="1">70,211. 22</td><td colspan="1" rowspan="1">106,746.91</td><td colspan="1" rowspan="1">20,739.59</td></tr><tr><td colspan="1" rowspan="2">两年变动</td><td colspan="1" rowspan="1">可变成本</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">19.91%</td><td colspan="1" rowspan="1">20.24%</td><td colspan="1" rowspan="1">-16.57%</td><td colspan="1" rowspan="1">1.27%</td></tr><tr><td colspan="1" rowspan="1">固定成本及其他</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">11. 69%</td><td colspan="1" rowspan="1">5.61%</td><td colspan="1" rowspan="1">-13.88%</td><td colspan="1" rowspan="1">-6.21%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">19.03%</td><td colspan="1" rowspan="1">14. 62%</td><td colspan="1" rowspan="1">-16. 14%</td><td colspan="1" rowspan="1">0.80%</td></tr></table>

注：上表数据口径为当期实现销售的产品营业成本。

# 4. 增收不增利的主要原因

（1）根据“一.3.毛利率下滑的主要原因”分析，公司各产品毛利下降原因为： $\textcircled{1}$ 刚果（金）铜产品销售单价上涨未覆盖原料成本更大幅度的上涨，导致毛利率下降 $5 , 0 1 \%$ 。同时，计入公允价值变动损益的延期定价安排，占铜产品销售收入合计的比例由2024年的 $0 . 8 1 \%$ 升至2025年的 $2 , 5 0 \%$ ，导致本期毛利减少2.50个百分点（上期减少0.81个百分点），负面影响较上年增加1.69个百分点。 $\textcircled{2}$ 受市场行情影响，镍产品、锌产品毛利率略微下滑。

（2）产品结构变化： $\textcircled{1}$ 铜产品毛利率下滑，产品收入占比提升。 $\textcircled{2}$ 毛利率下滑且为负的镍产品、锌产品进一步拉低了整体毛利率水平。 $\textcircled{3}$ 钴产品毛利率虽大幅提升，但其收入占比远低于其他产品。

<table><tr><td rowspan=2 colspan=1>产品</td><td rowspan=1 colspan=3>2025年度</td><td rowspan=1 colspan=3>2024年度</td></tr><tr><td rowspan=1 colspan=1>营业收入（万元）</td><td rowspan=1 colspan=1>占比(%)</td><td rowspan=1 colspan=1>毛利率(%)</td><td rowspan=1 colspan=1>营业收入（万元）</td><td rowspan=1 colspan=1>占比(%)</td><td rowspan=1 colspan=1>毛利率(%)</td></tr><tr><td rowspan=1 colspan=1>铜产品</td><td rowspan=1 colspan=1>1,407,062. 16</td><td rowspan=1 colspan=1>54.46</td><td rowspan=1 colspan=1>28.88</td><td rowspan=1 colspan=1>1,048,478. 15</td><td rowspan=1 colspan=1>47.02</td><td rowspan=1 colspan=1>35.23</td></tr><tr><td rowspan=1 colspan=1>钻产品</td><td rowspan=1 colspan=1>101,111. 37</td><td rowspan=1 colspan=1>3.91</td><td rowspan=1 colspan=1>53.76</td><td rowspan=1 colspan=1>145,774. 87</td><td rowspan=1 colspan=1>6.54</td><td rowspan=1 colspan=1>43.55</td></tr><tr><td rowspan=1 colspan=1>镍产品</td><td rowspan=1 colspan=1>428, 612.97</td><td rowspan=1 colspan=1>16.59</td><td rowspan=1 colspan=1>0.32</td><td rowspan=1 colspan=1>378, 753. 23</td><td rowspan=1 colspan=1>16.99</td><td rowspan=1 colspan=1>3.57</td></tr><tr><td rowspan=1 colspan=1>锌产品</td><td rowspan=1 colspan=1>646,883.76</td><td rowspan=1 colspan=1>25.04</td><td rowspan=1 colspan=1>-5.27</td><td rowspan=1 colspan=1>656,889.13</td><td rowspan=1 colspan=1>29.46</td><td rowspan=1 colspan=1>-1. 61</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>2, 583, 670. 27</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>2,229,895.39</td><td rowspan=1 colspan=1>100.00</td><td rowspan=1 colspan=1></td></tr></table>

（3）非经常性损益影响：2025年公司非经常性损益为-5.67亿元，主要系公司进行套期保值为目的的期货衍生品投资发生亏损所致，而去年同期为正。这导致归属于上市公司股东的净利润（19.61亿元）大幅低于扣非后的净利润（25.29亿元）。

# 5. 主要收入确认方法及依据

<table><tr><td colspan="1" rowspan="1">产品名称</td><td colspan="1" rowspan="1">销售模式</td><td colspan="1" rowspan="1">主要合同条款</td><td colspan="1" rowspan="1">收入确认方法及依据</td></tr><tr><td colspan="1" rowspan="1">刚果（金）-电解铜</td><td colspan="1" rowspan="1">FCA模式</td><td colspan="1" rowspan="1">定价：按LME现金结算价减去质量相关折扣定价。交货方式：采用FCA方式交货。</td><td colspan="1" rowspan="1">货交第一承运人以后控制权转移，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">刚果（金）-电解铜</td><td colspan="1" rowspan="1">DAP模式</td><td colspan="1" rowspan="1">定价：按LME现金结算价减去交货地及质量相关折扣定价。交货方式：采用DAP方式交货。</td><td colspan="1" rowspan="1">货物运至指定地，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">刚果（金）-氢氧化钴</td><td colspan="1" rowspan="1">FCA模式</td><td colspan="1" rowspan="1">定价：价格为销售时固定市场单价。交货方式：采用FCA方式交货。</td><td colspan="1" rowspan="1">货交第一承运人以后控制权转移，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">刚果（金）-氢氧化钴</td><td colspan="1" rowspan="1">CIF模式</td><td colspan="1" rowspan="1">定价：价格按Fastmarkets标准级钴低幅月均价乘以系数月均价再乘以2204.62计算。交货方式：采用CIF交货方式</td><td colspan="1" rowspan="1">卖方在指定装运港将货物装上船即完成交货，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">刚果（金）-氢氧化钴</td><td colspan="1" rowspan="1">EXW模式</td><td colspan="1" rowspan="1">定价：价格为销售时固定市场单价。交货方式：采用EXW方式交货。</td><td colspan="1" rowspan="1">卖方指定地点将货物备妥，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">科立鑫-四氧化三钴、氧化钴</td><td colspan="1" rowspan="1">国内现货销售</td><td colspan="1" rowspan="1">定价：价格以实际交货月或合同签订月（零星）SMM四氧化三钴高低幅均价*对应系数或上海有色网硫酸钴的市场价为基准*对应系数。交货方式：按确定的日期送货至买方指定地点/买方自提。</td><td colspan="1" rowspan="1">收到对方验收单或规定的验收周期届满，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">印尼-镍铁</td><td colspan="1" rowspan="1">FOB模式</td><td colspan="1" rowspan="1">定价：合同日期市场价。交货方式：采用FOB方式交货。</td><td colspan="1" rowspan="1">装运港船上交货，装货港船上发生控制权转移，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">盛屯锌锗-锌锭</td><td colspan="1" rowspan="1">国内现货销售</td><td colspan="1" rowspan="1">定价：价格按计价期内上海有色网0#、1#锌锭扣减升贴水。交货方式：客户工厂自提。</td><td colspan="1" rowspan="1">客户工厂提货，并据此确认收入。</td></tr><tr><td colspan="1" rowspan="1">贵州-电池级硫酸镍</td><td colspan="1" rowspan="1">国内现货销售</td><td colspan="1" rowspan="1">定价：上海有色网SMM电池级硫酸镍低幅均价月均价乘约定比例。交货方式：按确定的日期送货至买方指定地点</td><td colspan="1" rowspan="1">货物运至指定地、验收合格，并据此确认收入。</td></tr></table>

公司按控制权转移确认收入，FCA、FOB、DAP、CIF、EXW 及国内现货销售等模式，均以合同约定的交货、验收节点作为收入确认时点，符合企业会计准则规定。

# 三、说明公司第一季度营业收入以及第四季度净利润出现大幅下降的主要原因。

1.第一季度营业收入大幅下降的主要原因

公司各季度收入及主要产品情况如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>566,669. 61</td><td rowspan=1 colspan=1>813,721.92</td><td rowspan=1 colspan=1>791,295.66</td><td rowspan=1 colspan=1>828,580.47</td></tr><tr><td rowspan=1 colspan=1>各季度收入占比</td><td rowspan=1 colspan=1>18.89%</td><td rowspan=1 colspan=1>27.12%</td><td rowspan=1 colspan=1>26.37%</td><td rowspan=1 colspan=1>27.62%</td></tr><tr><td rowspan=1 colspan=1>其中：刚果（金）铜产品</td><td rowspan=1 colspan=1>252,405.05</td><td rowspan=1 colspan=1>390,574.89</td><td rowspan=1 colspan=1>363,251.71</td><td rowspan=1 colspan=1>381,638.94</td></tr><tr><td rowspan=1 colspan=1>贵州镍产品</td><td rowspan=1 colspan=1>17,874.99</td><td rowspan=1 colspan=1>34,265.27</td><td rowspan=1 colspan=1>46,281.71</td><td rowspan=1 colspan=1>65,913.26</td></tr><tr><td rowspan=1 colspan=1>盛屯锌锗锌产品及副产品</td><td rowspan=1 colspan=1>171,102.40</td><td rowspan=1 colspan=1>200,641.42</td><td rowspan=1 colspan=1>206,165.81</td><td rowspan=1 colspan=1>210,598.97</td></tr></table>

公司第一季度营业收入为56.67 亿元，占全年收入的 $1 8 . 8 9 \%$ ，为四个季度中最低。第二季度起收入逐步回升，主要受各板块产销量季节性及项目投产节奏影响，具体原因

如下：

刚果（金）铜产品：第二季度起收入显著增长，主要由于子公司BMS 铜二期于2025年 3 月顺利达产并逐步稳定，铜产销量大幅提升，叠加铜价上涨因素。

贵州镍产品：随着镍产线于 2025 年完成产能爬坡，产销量逐季上升，收入呈现逐季增长态势。

盛屯锌锗（锌产品及副产品）：第一季度为枯水期，电价较高，产线集中检修导致产量较低；同时受春节假期影响，出货量减少，因此第一季度收入处于低位。

综上，第一季度收入占比偏低，主要受锌产品季节性检修与假期因素以及铜与镍产品产能尚未充分释放的共同影响；第二季度起，随着子公司BMS 铜二期达产、贵州镍产线爬坡完成及盛屯锌锗锌产品生产恢复正常，收入呈现增长态势。

# 2.第四季度净利润大幅下降的主要原因

2025年各季度公司主要利润表项目情况如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年第一季度</td><td rowspan=1 colspan=1>2025年第二季度</td><td rowspan=1 colspan=1>2025年第三季度</td><td rowspan=1 colspan=1>2025年第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>566,669.61</td><td rowspan=1 colspan=1>813,721.92</td><td rowspan=1 colspan=1>791,295.66</td><td rowspan=1 colspan=1>828,580.47</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>461, 430. 65</td><td rowspan=1 colspan=1>650,664.55</td><td rowspan=1 colspan=1>626, 467. 19</td><td rowspan=1 colspan=1>687,934. 21</td></tr><tr><td rowspan=1 colspan=1>税金及附加</td><td rowspan=1 colspan=1>19,729.05</td><td rowspan=1 colspan=1>21,689.74</td><td rowspan=1 colspan=1>20,570.65</td><td rowspan=1 colspan=1>23,964.40</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>647.88</td><td rowspan=1 colspan=1>963.68</td><td rowspan=1 colspan=1>947.49</td><td rowspan=1 colspan=1>989.52</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>26,280.97</td><td rowspan=1 colspan=1>17,091. 50</td><td rowspan=1 colspan=1>23,125. 67</td><td rowspan=1 colspan=1>32,019.14</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>1,113. 62</td><td rowspan=1 colspan=1>1,826.96</td><td rowspan=1 colspan=1>901.58</td><td rowspan=1 colspan=1>1,433. 76</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>16,220. 81</td><td rowspan=1 colspan=1>17,360. 75</td><td rowspan=1 colspan=1>17, 553. 53</td><td rowspan=1 colspan=1>20,606.01</td></tr><tr><td rowspan=1 colspan=1>其他收益</td><td rowspan=1 colspan=1>632.30</td><td rowspan=1 colspan=1>864.33</td><td rowspan=1 colspan=1>750.59</td><td rowspan=1 colspan=1>1,223.98</td></tr><tr><td rowspan=1 colspan=1>投资收益</td><td rowspan=1 colspan=1>5,826.30</td><td rowspan=1 colspan=1>-4,862.40</td><td rowspan=1 colspan=1>-4,452. 39</td><td rowspan=1 colspan=1>-23,143.96</td></tr><tr><td rowspan=1 colspan=1>公允价值变动收益</td><td rowspan=1 colspan=1>-15,113.05</td><td rowspan=1 colspan=1>12, 596. 93</td><td rowspan=1 colspan=1>699.90</td><td rowspan=1 colspan=1>-23,141. 99</td></tr><tr><td rowspan=1 colspan=1>信用减值损失</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>152.41</td><td rowspan=1 colspan=1>0.43</td><td rowspan=1 colspan=1>-9,160. 47</td></tr><tr><td rowspan=1 colspan=1>资产减值损失</td><td rowspan=1 colspan=1>101.50</td><td rowspan=1 colspan=1>-10, 714. 45</td><td rowspan=1 colspan=1>-9,196.73</td><td rowspan=1 colspan=1>4,025.47</td></tr><tr><td rowspan=1 colspan=1>资产处置收益</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>316.96</td><td rowspan=1 colspan=1>499.22</td><td rowspan=1 colspan=1>2.15</td></tr><tr><td rowspan=1 colspan=1>营业外收入</td><td rowspan=1 colspan=1>188.96</td><td rowspan=1 colspan=1>30.20</td><td rowspan=1 colspan=1>45.02</td><td rowspan=1 colspan=1>226.77</td></tr><tr><td rowspan=1 colspan=1>营业外支出</td><td rowspan=1 colspan=1>50.28</td><td rowspan=1 colspan=1>180.74</td><td rowspan=1 colspan=1>425.93</td><td rowspan=1 colspan=1>2,219.00</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>29,117. 38</td><td rowspan=1 colspan=1>76,155.06</td><td rowspan=1 colspan=1>64,893.68</td><td rowspan=1 colspan=1>25,975.96</td></tr></table>

2025年各季度公司主要利润表项目与收入匹配情况如下：

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">第一季度</td><td colspan="1" rowspan="1">第二季度</td><td colspan="1" rowspan="1">第三季度</td><td colspan="1" rowspan="1">第四季度</td><td colspan="1" rowspan="1">2025年度</td></tr><tr><td colspan="1" rowspan="1">毛利率</td><td colspan="1" rowspan="1">18.57%</td><td colspan="1" rowspan="1">20.04%</td><td colspan="1" rowspan="1">20.83%</td><td colspan="1" rowspan="1">16. 97%</td><td colspan="1" rowspan="1">19.12%</td></tr><tr><td colspan="1" rowspan="1">税金及附加占收入比例</td><td colspan="1" rowspan="1">3.48%</td><td colspan="1" rowspan="1">2.67%</td><td colspan="1" rowspan="1">2.60%</td><td colspan="1" rowspan="1">2.89%</td><td colspan="1" rowspan="1">2.86%</td></tr><tr><td colspan="1" rowspan="1">三项费用率</td><td colspan="1" rowspan="1">7. 61%</td><td colspan="1" rowspan="1">4.35%</td><td colspan="1" rowspan="1">5.26%</td><td colspan="1" rowspan="1">6.47%</td><td colspan="1" rowspan="1">5.79%</td></tr><tr><td colspan="1" rowspan="1">投资收益占收入比例</td><td colspan="1" rowspan="1">1.03%</td><td colspan="1" rowspan="1">-0.60%</td><td colspan="1" rowspan="1">-0.56%</td><td colspan="1" rowspan="1">-2.79%</td><td colspan="1" rowspan="1">-0.89%</td></tr><tr><td colspan="1" rowspan="1">公允价值变动收益占收入比例</td><td colspan="1" rowspan="1">-2. 67%</td><td colspan="1" rowspan="1">1.55%</td><td colspan="1" rowspan="1">0.09%</td><td colspan="1" rowspan="1">-2.79%</td><td colspan="1" rowspan="1">-0.83%</td></tr><tr><td colspan="1" rowspan="1">信用减值损失占收入比例</td><td colspan="1" rowspan="1">0.00%</td><td colspan="1" rowspan="1">0.02%</td><td colspan="1" rowspan="1">0.00%</td><td colspan="1" rowspan="1">-1. 11%</td><td colspan="1" rowspan="1">-0.30%</td></tr><tr><td colspan="1" rowspan="1">资产减值损失占收入比例</td><td colspan="1" rowspan="1">0.02%</td><td colspan="1" rowspan="1">-1.32%</td><td colspan="1" rowspan="1">-1.16%</td><td colspan="1" rowspan="1">0.49%</td><td colspan="1" rowspan="1">-0.53%</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净利润</td><td colspan="1" rowspan="1">5.14%</td><td colspan="1" rowspan="1">9.36%</td><td colspan="1" rowspan="1">8.20%</td><td colspan="1" rowspan="1">3.13%</td><td colspan="1" rowspan="1">6.54%</td></tr></table>

由上表可知，公司2025 年度第四季度净利润出现大幅下降，主要系受期货套期保值亏损影响（影响科目：投资收益、公允价值变动收益）。2025年第四季度期货亏损约5.71亿，占全年期货亏损总额的 $6 6 , 4 0 \%$ ，构成当季利润下滑的主要驱动因素。

2025年各季度扣非净利如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益后的净利润</td><td rowspan=1 colspan=1>44,273.90</td><td rowspan=1 colspan=1>71,948.98</td><td rowspan=1 colspan=1>69,866.09</td><td rowspan=1 colspan=1>66,766. 72</td></tr></table>

综上，2025 年第四季度归母净利润下降主要受期货套期保值亏损影响。因套期保值业务不完全符合运用套期会计的适用条件，作为为交易而持有的衍生金融工具处理，其平仓损益及浮动盈亏计入当期损益，列入公司非经常性损益，与公司披露的归母扣非净利相符。

四、结合具体合同条款等，说明不同合同的收入确认时点存在差异的合理性；公司是否合理区分点价权导致的公允价值变动和可变对价导致的收入调整，是否存在调节收入的情形。

# 1. 不同合同收入确认时点差异的合理性

各产品主要合同条款见上文<二.4.主要收入确认方法及依据>，公司销售合同类型多样，收入确认时点差异主要源于商品控制权转移时点的不同，符合企业会计准则的规定。

# 2. 点价权与可变对价的区分及会计处理

公司关于点价权与可变对价的会计处理原则为：

点价权导致的公允价值变动：对于部分销售合同，商品交付后，销售价格尚未最终确定，公司在未来某一时期拥有点价权。公司将该类合同中的点价权确认为一项嵌入衍生工具。初始确认收入时，以收入确认时点的基础价格确认收入。后续价格变动，计入“公允价值变动损益”。

可变对价导致的收入调整：对于因产品验收后品位、质量等差异而导致的最终结算价格调整，属于与商品本身相关的价格调整。公司在收入确认时，基于可获取信息（如自检结果）对交易价格进行最佳估计。后续实际结算时，根据最终检验结果对收入进行调整，计入当期损益（主营业务收入）。

公司在会计处理上严格区分了这两类事项，公司将点价权合约明确列示在“交易性金融资产/负债”项下，而因品质调整产生的收入变动则直接反映在营业收入中，不存在混淆的情况。

# 3. 是否存在调节收入的情形

经自查，公司收入确认政策一贯执行，所有收入均在控制权转移时点确认。对于可变对价和点价权的会计处理，均严格按照相关会计准则执行，并在财务报告中进行了恰当列报和披露。

五、公司主要供应商和客户是否存在重合情况，如是，请说明重合原因及合理性，以及采购商品和销售商品之间的对应关系，说明相关交易的商业合理性。

本集团前五名客户及2025年交易额：  

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>交易金额 (万元）</td><td rowspan=1 colspan=1>销售产品</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>客户1</td><td rowspan=1 colspan=1>642, 276. 91</td><td rowspan=1 colspan=1>电解铜</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>客户2</td><td rowspan=1 colspan=1>294,536. 89</td><td rowspan=1 colspan=1>电解铜</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>客户3</td><td rowspan=1 colspan=1>210, 479. 91</td><td rowspan=1 colspan=1>电解铜</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>客户4</td><td rowspan=1 colspan=1>175, 549. 94</td><td rowspan=1 colspan=1>镍铁</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>客户5</td><td rowspan=1 colspan=1>111, 891. 50</td><td rowspan=1 colspan=1>电解铜</td></tr></table>

本集团前五名供应商及2025年交易额：  

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>供应商名称</td><td rowspan=1 colspan=1>交易金额(万元）</td><td rowspan=1 colspan=1>采购产品</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>供应商1</td><td rowspan=1 colspan=1>228,870. 59</td><td rowspan=1 colspan=1>铜精矿</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>供应商2</td><td rowspan=1 colspan=1>110,228. 24</td><td rowspan=1 colspan=1>锌精矿</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>供应商3</td><td rowspan=1 colspan=1>94,918. 55</td><td rowspan=1 colspan=1>镍矿</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>供应商4</td><td rowspan=1 colspan=1>79,569. 49</td><td rowspan=1 colspan=1>铜精矿</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>供应商5</td><td rowspan=1 colspan=1>67,293. 61</td><td rowspan=1 colspan=1>锌精矿</td></tr></table>

本集团前五名客户与供应商在法人主体层面无重叠，但在集团范围内，基于产业链协同与资源互补的商业逻辑，存在供应商与客户重合的情形。本集团从外部采购生产所需原材料，并向第三方客户销售产品。采购商品主要为锌精矿、镍矿等生产所需原材料，销售商品主要为电解铜、锌锭、镍铁等产成品。两类商品在形态、用途及流转环节上相互独立，不存在直接对应关系。相关交易均遵循市场化原则定价，具备真实的商业实质与合理的业务背景。

此外，集团范围内存在少量既是客户又是供应商交易同一类金属产品的情形，主要涉及锌精矿等金属产品，该情形形成的原因包括：一方面基于运输成本等商业因素考量，公司将自有矿山的锌精矿通过贸易商对外销售，报告期内确认内蒙古自有矿山锌精矿销售收入为917 万元,四川冶炼子公司因原料需求采购锌精矿1,460 万元；另一方面，仅有少数几家从事贸易业务的客商存在采购与销售交易产品重合的情况，且相关销售金额较小，报告期内确认销售收入为1,464万元，采购金额为4,855 万元。公司按照合同约定将商品实物交付至约定地点并由客户接收，视为商品控制权发生转移确认收入；公司自第三方取得商品控制权后再转让给客户，在交易过程中承担向客户转让商品的主要责任、承担存货风险，并能有权自主决定所交易的商品的价格，公司在该交易中的身份是主要责任人，按总额法确认收入。同时，公司也会考虑实物交易业务的其他相关事实和情况，如：公司不负责安排实物的运输环节，公司赚取的为固定利润的业务未承担商品价格波动风险，此部分业务以净额法确认收入。

客户和供应商重叠系行业参与者结合市场行情、自身需求、供需变化及各自对市场的判断，发生在不同时间段的正常商业行为，符合有色金属行业的特征。经查询，同行业上市公司云南铜业等亦存在供应商、客户重叠的情形，该情形符合行业惯例。

# 会计师意见：

执行的主要程序：

1.了解并测试了与销售收款循环相关的内部控制，评价关键控制设计及运行的有效性。

2.选取样本检查销售合同，识别控制权转移条款，评价公司收入确认时点是否符合企业会计准则要求；检查结算单、发票、出库单等支持性文件。

3.执行分析性复核程序：获取产品销售明细表，对主要产品销售价格及原材料采购价格进行同期对比分析，并与金属市场价格走势进行比对。

4. 分析营业收入、营业成本及毛利变动，与同行业可比上市公司进行比较。

5.选取重要客户实施交易额及往来余额函证，对未回函样本执行替代测试。

6.获取利润表明细，对期间费用（销售费用、管理费用、财务费用）进行详细分析，检查是否存在异常增长的费用项目。

7. 评估管理层对可变对价的估计是否合理，以及是否恰当区分了点价权（可能作为嵌入衍生工具处理）和可变对价（作为交易价格的一部分）的会计处理。检查与点价或价格调整相关的后续结算单据，核实最终交易价格与初始估计的差异，评估是否存在利用会计估计调节收入的情形。

8.获取公司客户清单与供应商清单，交叉比对客户与供应商清单，核查重叠客商的交易产品及其交易合理性。

# 基于执行的审计程序，我们认为：

1. 公司关于业绩波动、毛利率变动、收入确认、客商重叠的相关说明，在所有重大方面与我们审计过程中所获取的资料及了解的情况一致。

2.公司收入确认政策符合会计准则规定，不同合同的收入确认时点存在差异具有合理性。

3.公司对点价权与可变对价的区分及会计处理符合准则要求，未发现调节收入的情形。

问题2.关于资产情况。2025 年末，公司境外资产合计 194.52 亿元，占总资产的比重为 $4 5 . 1 2 \%$ ，同比增长 $3 5 . 1 6 \%$ ；公司存放在境外的款项总额达 20.42 亿元，较 2024年期末增加11.32 亿元。存货期末账面价值为102.15 亿元，占总资产的比重为 $2 3 . 6 9 \%$ ，其中发出商品、在途物资同比大幅增长。在建工程期末账面价值为21.44 亿元，同比增长 $9 2 . 6 6 \%$ 。同时，公司未办妥产权证书的固定资产账面价值为 13.53 亿元，主要系贵州化学、汉源盛屯锌锗等房屋建筑物。自有矿山大理三鑫等仍处于建设阶段，目前未开展正常生产经营。请公司：（1）结合公司境外资产的具体构成、变动情况及原因、受限情况，说明境外资产变动是否与境外业务相匹配；（2）补充说明公司期末境外资金增长的合理性，公司为保障境外资金安全采取的有效措施；（3）结合货物转移政策，说明发出商品、在途物资规模大幅增长的原因，期后收入确认情况；（4）结合公司刚果（金）实际产能需求，说明报告期内在建工程大幅增长的原因，相关矿山难以正常生产经营面临的主要障碍，是否存在减值迹象；公司与主要工程及设备供应商是否存在关联关系，相关定价是否公允。

公司回复：

# 一、结合公司境外资产的具体构成、变动情况及原因、受限情况，说明境外资产变动是否与境外业务相匹配。

1. 境外资产的具体构成与变动情况

境外资产主要构成及其变动情况如下：

<table><tr><td colspan="1" rowspan="1">主要构成</td><td colspan="1" rowspan="1">价值(万元）</td><td colspan="1" rowspan="1">价值(万元)</td><td colspan="1" rowspan="1">两年变动(万元）</td><td colspan="1" rowspan="1">变动比例</td><td colspan="1" rowspan="1">变动原因说明</td><td colspan="1" rowspan="1">是否受限</td></tr><tr><td colspan="1" rowspan="1">固定资产</td><td colspan="1" rowspan="1">685,868.12</td><td colspan="1" rowspan="1">688,985.07</td><td colspan="1" rowspan="1">-3,116.95</td><td colspan="1" rowspan="1">-0.45%</td><td colspan="1" rowspan="1">本年固定资产原值增加约7.5亿元，折旧计提约7.81亿元，固定定资产净额资产净值减少约0.31亿元。固定6.63亿元，资产原值增加主要系BMS项目二 用于非金融期扩建和技改工程转固约5.15亿 机构贷款抵元所致。</td><td colspan="1" rowspan="1">期末受限固押。</td></tr><tr><td colspan="1" rowspan="1">境外资产主要构成</td><td colspan="1" rowspan="1">2025年末账面价值(万元)</td><td colspan="1" rowspan="1">2024年末账面价值（万元)</td><td colspan="1" rowspan="1">两年变动（万元）</td><td colspan="1" rowspan="1">变动比例</td><td colspan="1" rowspan="1">变动原因说明</td><td colspan="1" rowspan="1">是否受限</td></tr><tr><td colspan="1" rowspan="1">存货</td><td colspan="1" rowspan="1">627,561. 17</td><td colspan="1" rowspan="1">372,374.03</td><td colspan="1" rowspan="1">255,187.14</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">随着境外产能及产量的提高，公司原材料备货及各类库存相应增加。具体而言，BMS项目二期投产后，铜年产能自6万吨提升至12万吨，公司在刚果（金）地区的总产能达23万金属吨。产能扩张68.53%|相应原材料储备的增加，其中矿料备货规模增加约17亿元。同时，期末在产品、库存商品及发出商品相应增长约6.84亿元。在途物资亦增加约1.46亿元，主要为生产与工程建设所需备品备件的提前采购所致。</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">货币资金</td><td colspan="1" rowspan="1">204,176.86</td><td colspan="1" rowspan="1">91,000.99</td><td colspan="1" rowspan="1">113,175.87</td><td colspan="1" rowspan="1">124.37%</td><td colspan="1" rowspan="1">本年境外营业收入增加、融资增加所致。</td><td colspan="1" rowspan="1">期末受限货币资金5.56亿元。其中：期货保证金4.48亿元。</td></tr><tr><td colspan="1" rowspan="1">在建工程</td><td colspan="1" rowspan="1">105,450.70</td><td colspan="1" rowspan="1">50,732.34</td><td colspan="1" rowspan="1">54,718.36</td><td colspan="1" rowspan="1">107.86%</td><td colspan="1" rowspan="1">主要为新增尾矿库扩建、电力保障项目、硫化矿浮选等投入。</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">应收账款</td><td colspan="1" rowspan="1">73,777. 20</td><td colspan="1" rowspan="1">48,251.81</td><td colspan="1" rowspan="1">25,525.39</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">主要系应收托克集团款项增加约1.43亿元。应收PT.HUAKE NICKEL52.90%|INDONESIA款项增加约1.86亿元。应收嘉能可集团款项增加约0.88亿元。期后均在正常账期内回款。</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">其他流动资产</td><td colspan="1" rowspan="1">53,610.84</td><td colspan="1" rowspan="1">55,993.33</td><td colspan="1" rowspan="1">-2,382. 49</td><td colspan="1" rowspan="1">-4.25%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">其他非流动资产</td><td colspan="1" rowspan="1">41,018.74</td><td colspan="1" rowspan="1">16,021.98</td><td colspan="1" rowspan="1">24,996.77</td><td colspan="1" rowspan="1">156.02%</td><td colspan="1" rowspan="1">主要系印尼永誉项目预付土地款增长所致。</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">其他权益工具投资</td><td colspan="1" rowspan="1">37,145. 49</td><td colspan="1" rowspan="1">19,553.04</td><td colspan="1" rowspan="1">17, 592. 46</td><td colspan="1" rowspan="1">89.97%</td><td colspan="1" rowspan="1">公司持有的对中创新航科技股份有限公司的股权投资按公允价值计量，该公司股价上涨导致期末价值增加。</td><td colspan="1" rowspan="1">是，期末因借款质押受限2.49亿元。</td></tr><tr><td colspan="1" rowspan="1">预付款项</td><td colspan="1" rowspan="1">36,423.55</td><td colspan="1" rowspan="1">5,631. 09</td><td colspan="1" rowspan="1">30,792.46</td><td colspan="1" rowspan="1">546.83%</td><td colspan="1" rowspan="1">年末预付锌精矿货款1.38 亿元；预付硫磺货款约0.76 亿元。</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">无形资产</td><td colspan="1" rowspan="1">30,967. 40</td><td colspan="1" rowspan="1">45,090.66</td><td colspan="1" rowspan="1">-14,123. 26</td><td colspan="1" rowspan="1">-31.32%</td><td colspan="1" rowspan="1">主要系本年计提摊销所致。</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">49,167. 55</td><td colspan="1" rowspan="1">45, 549.03</td><td colspan="1" rowspan="1">3,618.52</td><td colspan="1" rowspan="1">7.94%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">1,945,167. 62</td><td colspan="1" rowspan="1">1,439,183.36</td><td colspan="1" rowspan="1">505,984.26</td><td colspan="1" rowspan="1">35.16%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

2. 境外资产变动与境外业务的匹配性分析  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>增长率</td></tr><tr><td rowspan=1 colspan=1>境外营业收入（万元)</td><td rowspan=1 colspan=1>1, 805,533. 68</td><td rowspan=1 colspan=1>1,446, 591. 58</td><td rowspan=1 colspan=1>24.81%</td></tr><tr><td rowspan=1 colspan=1>其中：铜产品收入</td><td rowspan=1 colspan=1>1,387,870. 59</td><td rowspan=1 colspan=1>1,041,004. 02</td><td rowspan=1 colspan=1>33.32%</td></tr><tr><td rowspan=1 colspan=1>钴产品收入</td><td rowspan=1 colspan=1>28,949.57</td><td rowspan=1 colspan=1>69, 874.52</td><td rowspan=1 colspan=1>-58.57%</td></tr><tr><td rowspan=1 colspan=1>镍产品收入</td><td rowspan=1 colspan=1>246,726.99</td><td rowspan=1 colspan=1>287,521.99</td><td rowspan=1 colspan=1>-14. 19%</td></tr><tr><td rowspan=1 colspan=1>其他收入</td><td rowspan=1 colspan=1>141, 986. 53</td><td rowspan=1 colspan=1>48,191. 05</td><td rowspan=1 colspan=1>194. 63%</td></tr><tr><td rowspan=1 colspan=1>境外资产总计(万元)</td><td rowspan=1 colspan=1>1, 945,167. 62</td><td rowspan=1 colspan=1>1,452, 389. 81</td><td rowspan=1 colspan=1>33.93%</td></tr><tr><td rowspan=1 colspan=1>境外铜产量（万吨）</td><td rowspan=1 colspan=1>20.52</td><td rowspan=1 colspan=1>17.55</td><td rowspan=1 colspan=1>16.94%</td></tr><tr><td rowspan=1 colspan=1>境外钴产量（万吨）</td><td rowspan=1 colspan=1>0.57</td><td rowspan=1 colspan=1>1.24</td><td rowspan=1 colspan=1>-53.69%</td></tr><tr><td rowspan=1 colspan=1>境外镍产量（万吨）</td><td rowspan=1 colspan=1>3.25</td><td rowspan=1 colspan=1>3.54</td><td rowspan=1 colspan=1>-8.17%</td></tr></table>

公司境外资产变动与境外业务发展情况高度匹配，具体体现在：

（1）境外资产的增长，特别是 BMS 项目二期扩建和技改工程的投入，直接推动了铜冶炼产能的提升（BMS 年产能达到 12 万金属吨）。2025 年，公司境外铜产品产量同比增长 $1 6 . 9 4 \%$ ，境外铜钴板块营业收入显著增加。这表明资产投入有效转化为业务产出。

（2）随着境外业务规模的扩大，销售回款及经营性现金流相应增加，反映为“货币资金”和“应收账款”等流动资产增长。同时，为保障原材料供应（矿石外购比例高），公司维持了较高的存货规模和预付款项。上述营运资产的变化与业务规模相匹配。

# 二、补充说明公司期末境外资金增长的合理性，公司为保障境外资金安全采取的有效措施。

公司存放在境外的款项总额达20.42 亿元，较 2024 年期末增加11.32 亿元。主要原因系本期境外收入增长盈利增加及融资增加所致：2025 年境外营业收入为180.55 亿元，同比增长 $2 4 . 8 1 \%$ ；境外主体主要有息负债（长期借款 $^ +$ 短期借款 $^ +$ 一年内到期的非流动负债）2025年末余额为30.45亿元，2024年末余额19.42亿元，增加11.03亿元。

公司为保障境外资金安全采取的有效措施：（1）公司优先选择具有全球服务能力的大型银行作为结算及跨境业务合作伙伴，主要主体均开立离岸 $^ +$ 在岸账户，有效规避账户管制风险；（2）公司持续关注涉外被投资主体国家的经济政治、外汇管理政策变化，适时采取相关风险应对措施；（3）公司按照《货币资金管理制度》要求，对境外平台的账户资金实施动态管控。

三、结合货物转移政策，说明发出商品、在途物资规模大幅增长的原因，期后收入确认情况。

# 1.发出商品

公司两期报告期末的发出商品明细如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>产品</td><td rowspan=1 colspan=1>2025年12月31日金额</td><td rowspan=1 colspan=1>2024年12月31日金额</td><td rowspan=1 colspan=1>变动金额</td><td rowspan=1 colspan=1>截至2026年3月31日收入确认金额</td></tr><tr><td rowspan=1 colspan=1>电解铜</td><td rowspan=1 colspan=1>27,557.88</td><td rowspan=1 colspan=1>19, 656.14</td><td rowspan=1 colspan=1>7,901. 74</td><td rowspan=1 colspan=1>27, 557.88</td></tr><tr><td rowspan=1 colspan=1>锌、铅精矿(贸易)</td><td rowspan=1 colspan=1>6,342.00</td><td rowspan=1 colspan=1>7,232.66</td><td rowspan=1 colspan=1>-890.66</td><td rowspan=1 colspan=1>6,342.00</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>10,335. 43</td><td rowspan=1 colspan=1>12, 426. 14</td><td rowspan=1 colspan=1>-2,090.71</td><td rowspan=1 colspan=1>9,953.96</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>44, 235.31</td><td rowspan=1 colspan=1>39,314. 94</td><td rowspan=1 colspan=1>4, 920.37</td><td rowspan=1 colspan=1>43, 853. 84</td></tr></table>

报告期末，公司发出商品账面余额为44,235.31万元，较上期增加4,920.37万元，增幅为 $1 2 . 5 2 \%$ 。该变动主要系核心产品电解铜的期末余额上升所致。

电解铜在报告期末的数量与金额具体如下表所示：  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>数量 (金吨)</td><td rowspan=1 colspan=1>单位成本（万元）</td><td rowspan=1 colspan=1>金额(万元）</td></tr><tr><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>5,560. 22</td><td rowspan=1 colspan=1>4.96</td><td rowspan=1 colspan=1>27, 557. 88</td></tr><tr><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>4,973. 21</td><td rowspan=1 colspan=1>3.95</td><td rowspan=1 colspan=1>19, 656.14</td></tr><tr><td rowspan=1 colspan=1>变动额</td><td rowspan=1 colspan=1>587.01</td><td rowspan=1 colspan=1>1. 01</td><td rowspan=1 colspan=1>7,901. 74</td></tr><tr><td rowspan=1 colspan=1>变动率</td><td rowspan=1 colspan=1>11.80%</td><td rowspan=1 colspan=1>25.40%</td><td rowspan=1 colspan=1>40.20%</td></tr></table>

由表可知，截至 2025 年12 月31 日，电解铜的发出数量较上期增长 $1 1 . 8 0 \%$ ，主要系公司产销量增加，同时采用 DAP 销售模式的数量有所增加所致；其次，受生产成本增长影响，发出商品单位成本也有所上升。

公司发出商品的确认严格遵循《企业会计准则》关于“控制权转移”的规定。不同产品因销售模式及合同条款差异，其收入确认时点有所不同：

<table><tr><td rowspan=1 colspan=1>产品</td><td rowspan=1 colspan=1>控制权转移</td></tr><tr><td rowspan=1 colspan=1>电解铜</td><td rowspan=1 colspan=1>FCA 模式：货交承运人即第一承运人后控制权转移;DAP 模式：货物运至指定地后控制权转移</td></tr><tr><td rowspan=1 colspan=1>锌、铅精矿（贸易）：</td><td rowspan=1 colspan=1>自供方交货至需方指定地点签收后转移至需方</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>自供方交货至需方指定地点签收后转移至需方</td></tr></table>

公司期末发出商品余额为 44,235.31 万元，截至 2026 年 3 月 31 日，其中 $9 9 . ~ 1 4 \%$ 已实现销售并确认收入。综上，期末发出商品均源于正常销售订单，不存在长期未验收、退货或滞销风险，相关会计处理符合企业会计准则规定。

# 2.在途物资

公司两期报告期末的在途物资明细如下：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末金额</td><td rowspan=1 colspan=1>上年金额</td><td rowspan=1 colspan=1>变动金额</td><td rowspan=1 colspan=1>截至2026年3月31日到货金额</td></tr><tr><td rowspan=1 colspan=1>锌精矿</td><td rowspan=1 colspan=1>48,498.88</td><td rowspan=1 colspan=1>5,979.01</td><td rowspan=1 colspan=1>42,519.87</td><td rowspan=1 colspan=1>48,498.88</td></tr><tr><td rowspan=1 colspan=1>高冰镍</td><td rowspan=1 colspan=1>17,599.29</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>17,599. 29</td><td rowspan=1 colspan=1>17,599.29</td></tr><tr><td rowspan=1 colspan=1>生产、建设所需的设备、备品备件</td><td rowspan=1 colspan=1>30,580.35</td><td rowspan=1 colspan=1>16, 759.27</td><td rowspan=1 colspan=1>13,821.08</td><td rowspan=1 colspan=1>30,580.35</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>747.86</td><td rowspan=1 colspan=1>362.81</td><td rowspan=1 colspan=1>385.05</td><td rowspan=1 colspan=1>747.86</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>97, 426.38</td><td rowspan=1 colspan=1>23,101.09</td><td rowspan=1 colspan=1>74,325.29</td><td rowspan=1 colspan=1>97, 426.38</td></tr></table>

公司 2025 年报告期末在途物资主要为境内子公司所需的原材料锌精矿及高冰镍、为境外公司采购的设备及备品备件。

（1）报告期末，在途物资中的锌精矿及高冰镍均为境内子公司盛屯锌锗和贵州化学保障生产连续性而采购的核心原材料。

2025 年国内镍精矿原料供应紧张，故通过外采半成品高冰镍来补充原料端生产所需。报告期末高冰镍系自印尼采购，采用FOB（离岸价）结算方式，货物在装运港越过船舷后风险与所有权即转移至公司。截至报告期末，相关货物仍处于国际海运途中，尚未抵达国内港口。

锌精矿为应对国内供应结构性短缺，公司采购的海外锌精矿比例显著上升。期末在途的锌精矿系为保障2026 年一季度生产需求而提前备货的矿源。由于进口锌精矿涉及国际海运，导致期末时点处于运输途中（尚未抵港或入库）的物资余额较往期增加。锌精矿采购入账时点为公司收到提单、完成付款或收到货权转移通知，且货物所有权实质性转移至本公司时。

（2）报告期末设备及备品备件主要系公司境外子公司基于工程建设、技术改造及生产运营，从中国境内集中采购并处于国际物流运输途中的物资。具体分布：刚果（金）区域子公司（CCR、CCM、kmsa和bms）采购29,306.49万元，占比 $9 5 , 8 3 \%$ ；印尼区域子公司（友山镍业）采购1,273.86万元,占比4. $1 7 \%$ 。

由于刚果（金）及印尼当地工业基础相对薄弱，缺乏生产所需的关键机器设备及精密备品备件的制造能力。为确保境外生产基地的平稳运行及工艺升级，公司采取“境内集采、跨境调拨”的供应链模式，利用中国制造业的完备产业链优势，向境外子公司输送核心生产资料。刚果（金）子公司正处于工程建设、提升作业效率与优化工艺设计的关键期，对专用设备与备品备件的需求显著增加。期末在途物资的大幅增长，系公司为支持海外产能扩张及技术迭代所进行的战略性备货，旨在通过设备升级提升资源回收率与生产效率。

受国际海运周期较长、通关手续复杂及物流运输不确定性等因素影响，跨境物资流转需预留充足的时间窗口。期末大额在途物资系公司为规避断供风险、保障生产连续性而进行的正常经营备货。该批物资均系近6个月内采购，物流状态正常，符合公司供应链管理的预期节奏。

截至2026年3月31日，在途物资均已到达公司仓库。

四、结合公司刚果（金）实际产能需求，说明报告期内在建工程大幅增长的原因，相关矿山难以正常生产经营面临的主要障碍，是否存在减值迹象；公司与主要工程及设备供应商是否存在关联关系，相关定价是否公允。

# 1. 报告期内在建工程大幅增长的原因

报告期末，公司在建工程账面价值（含工程物资）为21.44亿元，同比增长 $9 2 . 6 6 \%$ ，具体原因如下：

（1）刚果（金）地区铜钴板块为满足生产及电力保障需求，相关项目建设投入大幅增加，公司刚果（金）各项目年末在建工程余额合计约7.79亿元。

刚果（金）矿区面临电力供应不稳定问题，为保障生产的稳定运转，公司同步推进多项发电及储能项目建设，包括： $\textcircled{1}$ BMS 发电及储能项目，年末在建工程账面余额约2.52亿元； $\textcircled{2}$ 刚果资源发电及储能项目，年末在建工程账面余额约2.82亿元。 $\textcircled{3}$ KMSA 发电及储能项目，年末在建工程账面余额1.06亿元；

同时，为提高精矿品位和金属回收率， $\mathrm { K M S A 5 0 0 0 t / d }$ 浮选厂项目，年末在建工程余额 0.76 亿元。

刚果（金）其他改扩建项目在建工程账面余额合计约1.82亿元。

（2）印尼永誉项目，在建工程余额1.25亿元，主要系项目建设用地的前期开发工程投入，具体包含土建材料、场地清表、土方平整、空间规划费及人工薪酬等支出。

（3）国内新增磷酸铁产能、矿山建设等，包括： $\textcircled{1}$ 国内新建15 万吨磷酸铁项目（贵州新材料），在建工程账面余额约 6.00 亿元。 $\textcircled{2}$ 大理三鑫采矿 $5 0 0 \mathrm { t } / \mathrm { d }$ 、选矿 16.5 万$\mathrm { { t } / a }$ 项目，年末在建工程余额1.48亿元。 $\textcircled{3}$ 国内其他改扩建项目在建工程账面余额合计约 1.96 亿元。

（4）工程建设购买的工程物资约4.33亿元，其中：刚果（金）冶炼项目合计0.65亿元，印尼永誉 0.49 亿元，贵州新材料3.18 亿元，其他项目合计约0.01亿元。

综上，报告期内在建工程的大幅增长，是公司为满足国内外各板块产能扩张、能源保障、生产改良的结果，与公司实际产能需求及未来发展规划相匹配。

2. 相关矿山难以正常生产经营面临的主要障碍及减值情况公司尚未投产的矿山情况如下：

<table><tr><td rowspan=1 colspan=1>公司</td><td rowspan=1 colspan=1>矿山进展</td></tr><tr><td rowspan=1 colspan=1>REGAL</td><td rowspan=1 colspan=1>勘探阶段</td></tr><tr><td rowspan=1 colspan=1>银鑫矿业</td><td rowspan=1 colspan=1>2025年取得技改工程复工批复，开展井巷技改工作。</td></tr><tr><td rowspan=1 colspan=1>大理三鑫</td><td rowspan=1 colspan=1>2025年取得云南省发改委出具的关于大理三鑫采选工程项目核准的批复，并开展洪水评价报告、尾矿库建设项目库区坑道探测调查报告、尾矿库建设项目库区坑道专项治理设计报告、尾矿库《安全设施设计》、节能报告、排土场选址意见书、合规用地手续等各项评审报批工作。</td></tr><tr><td rowspan=1 colspan=1>恒源鑫茂</td><td rowspan=1 colspan=1>2025年办理并取得采矿项目的核准批复，开展土地预审、环评、水保、社稳、节能、用地指标等各项评审报批工作。供电工程有序进行。</td></tr><tr><td rowspan=1 colspan=1>风驰矿业</td><td rowspan=1 colspan=1>2025年取得新的采矿许可证、办理风驰矿业尾矿库回采事宜。探矿权恢复工作尚在审批中。</td></tr><tr><td rowspan=1 colspan=1>鑫盛矿业</td><td rowspan=1 colspan=1>2025年取得新的采矿证，尚未复工复产。</td></tr></table>

公司尚未投产的矿山处于建设阶段、证照办理阶段，尚未产生经济效益，但其核心障碍为证照办理进度，而非项目本身的资源价值或技术可行性出现问题。公司已取得采矿证及多项核准批复，证照办理正稳步推进，公司对矿权价值进行测算，矿权价值不存在减值。

# 3. 公司与主要工程及设备供应商采购情况

（1）主要工程及设备合同

公司主要工程合同及设备采购合同定价公允。主要工程及设备供应商采购情况如下：

<table><tr><td colspan="1" rowspan="1">主体</td><td colspan="1" rowspan="1">供应商</td><td colspan="1" rowspan="1">采购类别</td><td colspan="1" rowspan="1">采购内容</td><td colspan="1" rowspan="1">币种</td><td colspan="1" rowspan="1">合同金额（万是否关元/万美元）</td><td colspan="1" rowspan="1">联方</td></tr><tr><td colspan="1" rowspan="12">刚果（金）铜钴冶炼项目</td><td colspan="1" rowspan="1">太原锅炉集团有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">发电项目汽轮机及发电机设备</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">6,248.00否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">南京汽轮电机（集团）有限责任公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">发电项目锅炉</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">6,133.00</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">杭州三耐环保科技股份有限公司设备</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">电解装置、导电排等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,861.96</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">天津鸿翊盛运科技发展有限公司设备</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">钢材等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,273.91</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">上海引益实业有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">钢材等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,237. 60</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">淮北矿山机器制造有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">浓密机等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">2,632.23</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">伟明环保装备集团有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">变电站、开关柜等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">2,304.19</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">四川赛孚迅储能技术有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">储能设备等</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,259.26</td><td colspan="1" rowspan="1">是</td></tr><tr><td colspan="1" rowspan="1">十五冶对外工程有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">发电项目建筑安装工程</td><td colspan="1" rowspan="1">美元</td><td colspan="1" rowspan="1">526.36香</td><td colspan="1" rowspan="1">526.36香</td></tr><tr><td colspan="1" rowspan="1">STE de Developpement duCommerce et de ConstructionSarl</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">发电项目土建工程</td><td colspan="1" rowspan="1">美元</td><td colspan="1" rowspan="1">657.07否</td><td colspan="1" rowspan="1">657.07否</td></tr><tr><td colspan="1" rowspan="1">SLY INDUSTRY GROUP PTE.LTD</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">发电项目建筑安装工程</td><td colspan="1" rowspan="1">美元</td><td colspan="1" rowspan="1">587.83否</td><td colspan="1" rowspan="1">587.83否</td></tr><tr><td colspan="1" rowspan="1">LUALABA PROSPERE SARL</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">发电项目、磨浸技改美元</td><td colspan="1" rowspan="1">美元</td><td colspan="1" rowspan="1">320.82否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="2"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">项目土建工程</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">十五冶对外工程有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">选矿项目建筑安装工程</td><td colspan="1" rowspan="1">美元</td><td colspan="1" rowspan="1">476.34</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="11">贵州磷酸铁项目</td><td colspan="1" rowspan="1">中国化学工程第六建设有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">建筑工程</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">32,142. 19</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">贵州福越建筑工程有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">施工工程</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">7,189.53</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">温州豪大花岗岩集团有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">防腐工程</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,092.00</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">贵州中邦混凝土有限公司</td><td colspan="1" rowspan="1">工程</td><td colspan="1" rowspan="1">混泥土加工</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,040.00</td><td colspan="1" rowspan="1">香</td></tr><tr><td colspan="1" rowspan="1">南京亨格水处理科技有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">磷酸铁浆料膜处理系统设备</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">5,980.00</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">咸阳华光窑炉设备有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">电池级磷酸铁干燥窑、冷却窑</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,828.00否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">湖南华通粉体设备科技有限公司设备</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">锂电材料项目磷酸铁碟巢磨干燥粉碎人民币及粉体输送系统</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">6,050.00否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">江苏久吾高科技股份有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">磷酸铁水处理（预处理单元、膜处理单人民币元）项目</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">5,160.00否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">深圳市瑞升华科技股份有限公司设备</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">磷酸铁水处理蒸发结晶项目</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">4,238.00否</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">贵州微化科技有限公司</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">磷酸铁智能连续反应设备</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">6,398.00</td><td colspan="1" rowspan="1">否</td></tr><tr><td colspan="1" rowspan="1">西安泰金新能科技股份有限公司设备阳极板</td><td colspan="1" rowspan="1">设备</td><td colspan="1" rowspan="1">阳极板</td><td colspan="1" rowspan="1">人民币</td><td colspan="1" rowspan="1">3,844.99</td><td colspan="1" rowspan="1">否</td></tr></table>

上述主要供应商除四川赛孚迅储能技术有限公司外，均为独立第三方，与公司不存在关联关系,公司采购价格符合市场公允水平。公司向四川赛孚迅储能技术有限公司采购已履行了必要的关联交易审批程序。

公司对工程施工、设备采购类供应商实行准入评审管理，综合考察其资质等级、行业业绩、技术实力、履约能力、财务状况及商业信誉等，经评审合格后纳入合格供应商名录，并实施动态跟踪管理；达到相应金额标准的工程及设备采购，通过公开招标、邀请招标、竞争性谈判或询比价等方式组织实施。

# （2）关联方供应商情况

报告期内，公司项目涉及的主要工程及设备供应商中，存在以下关联交易情形：

$\textcircled{1}$ 光储电站项目建设。2025 年，公司向关联方 GREE GREEN ENERGY POWER SAS、广东格睿绿能技术有限公司采购光伏工程服务764.80万元。

$\textcircled{2}$ 储能设备采购。2025年，公司向关联方四川赛孚迅储能技术有限公司采购光伏储能设备等 3,259.26 万元。

（3）关联交易定价公允性分析

向关联方采购储能设备及工程服务，均参照市场同类产品或服务的价格水平确定，交易价格与第三方市场价格无重大差异。公司已建立完善的关联交易管理制度，确保交易定价的公允性。

综上，报告期内公司在建工程大幅增长主要系为满足刚果（金）铜钴板块产能提升与电力保障、印尼项目前期开发、国内新能源材料及矿山建设等实际生产经营与发展需求所进行的必要投入，与公司整体产能规划高度匹配。相关在产矿山运营正常，尚未投产矿山主要因证照办理、技改、建设周期等原因暂未全面投产，不存在资源或技术层面的实质性障碍，主要在建工程及矿山资产未发现减值迹象。公司与主要工程、设备供应商中存在少量关联方交易，相关交易均履行了内部审批程序，定价参考市场水平，公允合理。

# 会计师意见：

执行的主要程序包括：

1.为获取与境外资产相关的充分、适当的审计证据，我们对境外重要经营实体执行现场审计：派遣项目组成员赴刚果（金）及印度尼西亚，对主要境外经营主体执行现场审计工作。针对其实物资产、货币资金及往来款项，我们执行了包括监盘、函证及检查在内的实质性程序。（1）监盘程序：对存货、固定资产、在建工程等实施现场监盘程序；（2）函证程序：对境外全部银行账户实施函证程序，并对重要往来款项选取样本实施函证程序；（3）检查程序：对资产增减变动的支持性文件实施了检查程序。

2.与本次回复相关的核查程序包括：（1）获取境外资产明细表，了解并分析固定资产、存货、货币资金、在建工程等主要项目的变动原因，与境外业务收入、产量等经营数据进行匹配性分析。（2）获取境外货币资金的银行对账单，核实余额并了解货币资金受限情况。访谈管理层了解境外资金增长原因及资金安全保障措施。（3）对存货中的发出商品、在途物资实施函证程序，获取期后账簿资料核对公司对期后发出商品收入确认及在途物资到货情况的统计数据是否正确。（4）对重要在建工程实施现场监盘程序，并检查了重大工程合同、工程进度确认资料，分析工程支出的合理性。同时，获取主要工程及设备供应商清单，通过公开信息核查关联关系，了解并评价关联交易定价的公允性。（5）对主要矿山资产，获取资源储量报告、采矿权证、项目核准批复等关键文件，复核管理层减值测算过程的合理性。

# 基于执行的审计程序，我们认为：

1.公司关于境外资产、境外资金、发出商品及在途物资、在建工程、矿山建设、供应商及关联交易的说明在所有重大方面与我们在审计过程中所获取的资料及了解的情况一致。

2.公司境外资产变动与境外业务相匹配，期末境外资金增长具备合理性。

3.经核查公司发出商品，期后已全部确认收入；在途物资为生产采购的锌精矿、高冰镍及为境外项目采购的设备备件，期后已到货。

4.经核查尚未正常生产经营的矿山主要障碍为证照办理进度及矿山在建进度。主要工程及设备供应商中的关联交易已履行审批程序，定价公允，关联方交易已在年度报告披露。

问题 3.关于流动性。年报显示，公司货币资金期末账面金额为 80.62 亿元，同比增长 $4 4 . 7 \%$ ；同时公司短期借款、一年内到期的非流动负债及长期借款合计 148.25 亿元，同比增长 $2 6 . 8 3 \%$ 。公司受限资金 42.90 亿元，受限资产账面价值105.02 亿元，均用于抵押借款。2025 年末，公司对外提供80.25 亿元担保，较2024 年末增长 $1 9 . 5 2 \%$ ，其中直接或间接为资产负债率超过 $7 0 \%$ 的被担保对象提供担保的金额合计55.94 亿元。此外，公司第四季度现金流由正转负。请公司：（1）逐项说明受限资金明细的具体内容及合理性，海关关税税款保函保证金期末大幅增加的原因，是否存在政策变化；（2）结合公司贷款成本、财务管理模式和资金使用计划等，说明公司在货币资金余额较高同时负债大幅增长的原因及合理性，是否存在流动性风险，相关资金是否存在流向关联方的情况；（3）说明第四季度现金流大幅下滑的具体原因，结算方式是否发生变化，公司经营现金流是否稳定。

公司回复：

一、逐项说明受限资金明细的具体内容及合理性，海关关税税款保函保证金期末大幅增加的原因，是否存在政策变化。

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">年末余额</td><td colspan="1" rowspan="1">具体内容及合理性</td></tr><tr><td colspan="1" rowspan="1">票据、借款保证金</td><td colspan="1" rowspan="1">318,355.50</td><td colspan="1" rowspan="1">包含银行承兑汇票保证金226,259.76万元、商业承兑汇票保证金10,002.42万元、信用证保证金74，363.76万元及流贷保证金7,729.56万元，票据保证金大幅增长。由于公司业务规模扩大、银行授信政策、票据结算模式等原因，公司票据开据量增多，票据融资金额 540,860.41万元，保证金比例从0到100%不等，相应票据保证金金额增长，符合行业惯例与公司实际经营需要。</td></tr><tr><td colspan="1" rowspan="1">期货交易保证金</td><td colspan="1" rowspan="1">88,256.96</td><td colspan="1" rowspan="1">为管理有色金属价格波动风险，公司对铜、锌、镍等产品进行期货卖期合约进行套期保值，通常按合约价值8%-25%的比例缴纳保证金。主要品种持仓情况如下：铜：铜期货空头月平均净持仓量3.6万吨（2024年：2.27万吨），全年累计空头数量占现货比例61%（上年同期为59%）；锌：锌期货空头月平均净持仓量4万吨（2024年：0.78万吨），全年累计空头数量占现货比例76%（上年同期为46%）；镍：镍期货空头月平均净持仓量0.16万吨（2024年：0.4万吨），全年累计空头数量占现货比例33%（上年同期为22%）。2025 年末，期末期货保证金账户余额占期末持仓合约市值（以期末结算价计算）比例约14%（2024年末：约18%），该比例下降主要系两年</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">末持仓品种结构不同，以及2024年末期货端浮盈较多、保证金账户剩余备付追保资金较多。</td></tr><tr><td colspan="1" rowspan="1">海关关税税款保函保证金</td><td colspan="1" rowspan="1">11,300.00</td><td colspan="1" rowspan="1">企业向担保银行缴纳的保函保证金，用于担保银行应进口商的申请而向海关出具的、保证进口商履行缴纳关税义务的保函（见说明)</td></tr><tr><td colspan="1" rowspan="1">环境治理保证金</td><td colspan="1" rowspan="1">2,071.39</td><td colspan="1" rowspan="1">采矿权人在开采矿产资源过程中，依法保护矿山地质环境，履行矿山地质环境治理责任，在财政部门指定银行专户缴存的保证金。只能用于因矿产开发引发的矿山地质灾害和破坏的矿山地质环境的监测、恢复治理及矿山土地复垦。</td></tr><tr><td colspan="1" rowspan="1">证券账户保证金</td><td colspan="1" rowspan="1">1,393. 35</td><td colspan="1" rowspan="1">为担保证券交易履约而向证券公司缴存的资金，存放于银行等金融机构并专用于交易保证。</td></tr><tr><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">7,629.83</td><td colspan="1" rowspan="1">其中未达账项（资金到账延迟）金额7,176.40万元,其余为结算备付金</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">429,007.03</td><td></td></tr></table>

海关关税税款保函保证金大幅增加的原因及政策说明：公司 2025 年镍产品处于产能爬坡期，公司直接进口镍原料大幅增加。镍原料进口时以暂估价申报，因最终计价需经品质检测、买卖双方价格确认等多环节流程，计税价格及对应税款金额暂无法确定，完整结算周期通常为货物到港后 6-12 个月。若按暂估价直接预缴税款，将造成大额资金长期占用，影响资金使用效益。鉴于公司镍原料进口业务符合“计税价格尚未确定”的税款担保适用情形，为优化资金占用、提高资金使用效率、实现资金收益最大化，公司通过开立海关税款保函的方式办理税款担保，在保障依法足额纳税的前提下，有效提升通关效率与资金运营效益。截至目前，本公司未获悉相关税收担保政策发生重大变化。

二、结合公司贷款成本、财务管理模式和资金使用计划等，说明公司在货币资金余额较高同时负债大幅增长的原因及合理性，是否存在流动性风险，相关资金是否存在流向关联方的情况。

2025 年12 月31 日货币资金期末余额80.62亿元，其中受限资金42.90亿元，实际可自由支配的资金金额37.72 亿元。

2025 年公司项目建设、股权收购等资本性支出增加，配套项目建设、股权收购进行的长期借款融资也同步增加；为了满足项目投产、扩产后的流动现金需求，2025年短期借款也随之增加。同时公司经营活动产生的现金流入净额较大，可以充分保障生产运营的现金需求，同时为未来潜在的投资需求提供资金支持。

结合公司所处行业特征及资金管理需求，公司形成“高现金储备与高负债并存”的财务结构主要基于以下行业特性和战略考量：（1）行业资本密集属性驱动：作为典型的重资产行业，有色金属企业需要持续投入大量资本用于固定资产建设，包括矿山开采设施、冶炼设备及生产线等。这类投资主要依赖长期项目贷款等债务融资工具，从而形成较大的负债规模。同时，企业保持较高现金余额往往是为未来重大资本支出（如新矿山开发）或技术设备升级预留的专项资金；（2）价格波动风险应对机制：行业产品价格受全球宏观经济及供需关系影响显著（如LME金属价格周期性波动）。为抵御价格暴跌等市场风险，公司需要维持充足的现金储备以确保经营现金流稳定（包括持续运营资金保障和债务利息支付），同时通过债务融资实现跨周期的资本支出平滑；（3）风险管理资金占用：公司参与期货市场进行价格风险对冲时，需要缴纳高额交易保证金。这部分资金虽在财务报表中体现为货币资金，但实际使用受限，导致公司仍需通过债务融资来满足日常运营资金需求。（4）同时公司多备现金储备也是为了规避出现流动性风险。

公司目前不存在流动性风险，也不存在资金流向关联方的情况。

主要有息负债的明细情况：

单位：万元  

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日余额</td><td rowspan=1 colspan=1>2024年12月31日余额</td><td rowspan=1 colspan=1>利率</td><td rowspan=1 colspan=1>期限</td><td rowspan=1 colspan=1>融资用途</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>846,576.80</td><td rowspan=1 colspan=1>660,138.250.8%至8%</td><td rowspan=1 colspan=1>660,138.250.8%至8%</td><td rowspan=1 colspan=1>2026年到期</td><td rowspan=1 colspan=1>补充流动资金</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动负债</td><td rowspan=1 colspan=1>165,628.90</td><td rowspan=1 colspan=1>223,273.94</td><td rowspan=1 colspan=1>1.95%至8%</td><td rowspan=1 colspan=1>2026年到期</td><td rowspan=1 colspan=1>项目建设、项目并购等</td></tr><tr><td rowspan=1 colspan=1>长期借款</td><td rowspan=1 colspan=1>470,268.50</td><td rowspan=1 colspan=1>285,506.341.95%至8%</td><td rowspan=1 colspan=1>285,506.341.95%至8%</td><td rowspan=1 colspan=1>2027年-2035年</td><td rowspan=1 colspan=1>项目建设、项目并购等</td></tr><tr><td rowspan=1 colspan=1>长期应付款</td><td rowspan=1 colspan=1>130,902.21</td><td rowspan=1 colspan=1>124,430.29|2%-6.2%</td><td rowspan=1 colspan=1>124,430.29|2%-6.2%</td><td rowspan=1 colspan=1>2027年-2032年</td><td rowspan=1 colspan=1>融资租赁款项及投资款等</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>1,613,376.41|1,293,348.82</td><td rowspan=1 colspan=1>1,613,376.41|1,293,348.82</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# 三、说明第四季度现金流大幅下滑的具体原因，结算方式是否发生变化，公司经营现金流是否稳定。

公司第四季度经营活动现金流由正转负，主要系购买商品、接受劳务支付现金流有所上升，主要在以下方面体现：

$\textcircled{1}$ 为了平衡自有矿山自采矿比例和外购矿比例，均衡资源分配，第四季度公司国外自有矿山开始提高外购矿比例，从外购到投产加工至销售收现，平均需要三个月完成现金流收现；

$\textcircled{2}$ 由于全球新能源需求持续走强，矿端供应偏紧，第四季度铜均价突破1.1 万美元每金属吨，较三季度均价上浮 $1 3 . 2 3 \%$ 左右，且第四季度刚果（金）铜加工厂增加矿料备货，受价格数量双重影响进一步降低第四季度经营现金流；

$\textcircled{3}$ 由于第四季度锌锭原料单价处于较低水平且2026 年春节假期较往年晚，锌锭加工厂第四季度进行的冬储量较往年多，以确保生产线在冬季及后续时段稳定运行，避免因缺料导致的生产停滞；

$\textcircled{4}$ 贵州一期项目于2024年9月份转固，并在2025 年第四季度完成产能爬坡，实现满负荷生产，对应生产所需的原料支出较前季度均有大幅上升。

综上所述，公司第四季度经营活动现金流净额由正转负，主要系当期为优化矿源结构、保障生产连续运行及产能释放等原因，原料采购在数量与价格上均阶段性增加，并非经营质量恶化，公司对主要客户、供应商的信用政策、结算周期、预收预付及应收应付结算方式未发生重大变化，公司具备稳健的持续经营能力，经营现金流较稳定。

# 会计师意见：

执行的主要程序：

1.获取货币资金明细表及受限资金清单，检查银行对账单、保函协议等，核实受限资金的性质及金额合理性；访谈了解海关关税税款保函保证金增加的原因。

2.获取借款合同、担保合同，复核利率、期限、融资用途；了解公司货币资金余额与有息负债同时较高的原因，获取公司对流动性风险的分析说明并评价其合理性。

3.获取报告期现金流量表，分析各季度经营活动现金流波动原因，结合对主要客户及供应商的信用政策、结算周期的检查，关注是否发生重大变化。

4.对大额资金流水进行抽样检查，关注是否存在未经审批或未披露的流向关联方的资金。

# 基于执行的审计程序，我们认为：

1.公司就流动性相关的说明在所有重大方面与我们在审计过程中所获取的资料及了解的情况一致。

2.公司受限资金及海关关税保函保证金期末增加的原因描述具有合理性，未发现重大政策变化。

3.公司资金余额较高同时负债大幅增长的原因说明具有合理性，未发现流动性风险。公司关联方资金往来已恰当披露，未发现其他资金流向关联方。

4.公司第四季度现金流大幅下滑的原因说明具有合理性，结算方式未发生重大变化，经营现金流整体稳定。

问题4.关于套期保值。年报显示，报告期非经常性损益为-5.67 亿元，其中除同公司正常经营业务相关的有效套期保值业务外，非金融企业持有金融资产和金融负债产生的公允价值变动损益以及处置金融资产和金融负债产生的损益达-8.09亿元，2025 年公司进行套期保值为目的的期货衍生品投资发生大额亏损。请公司：（1）补充说明公司衍生品投资决策机制、套期保值采取的主要策略，是否存在除套期保值外的大宗商品投机行为，是否已按照要求履行内部决策程序；（2）结合开展期货交易的实际投入、杠杆情况、具体投资品种、对应的现货规模等，并与公司主营业务实际生产销售的原材料数量进行比较，说明购买衍生品的数量与公司现货或外汇数量是否存在稳定比例；（3）补充说明公司报告期内商品衍生品和外汇衍生品交易大额亏损的合理性。

公司回复：

一、补充说明公司衍生品投资决策机制、套期保值采取的主要策略，是否存在除套期保值外的大宗商品投机行为，是否已按照要求履行内部决策程序。

# 1.衍生品投资决策机制

公司已建立完善的《商品衍生品交易业务管理制度》及《外汇套期保值业务管理制度》，明确了套保业务的组织架构、审批权限及风控流程。所有衍生品交易均在股东会授权范围内执行。

# 2.套期保值采取的主要策略

本年度公司主要从事的商品衍生品品种为铜、锌、镍、黄金。基于全产业链风险管理需求，公司实施采购端与销售端相结合的套期保值策略，数量控制在现货风险敞口范围内的期货合约进行风险对冲。坚持品种相关、方向相反、保值规模不超过现货风险敞口的套期保值原则，主要金属品种保值情况说明如下：

铜：公司铜金属现货主要为刚果区域子公司生产的铜（含原材料、生产线上在制品、库存成品铜板及运输在途铜）及小部分国内冶炼加工副产品铜。结合铜金属市场行情及公司风险管理策略，在现货敞口额度范围内开展部分空头套期保值。

锌：公司锌金属现货主要为国内锌冶炼工厂各类存货及贸易端临时性库存。针对锌冶炼环节中配料消化周期较长的渣料类原料库存及生产线上液态在制品库存，结合锌金属行情变化及风险管理策略，在现货敞口范围内开展部分套期保值。

镍：公司镍金属现货主要为国内贵州盛屯、中合镍业及印尼友山等镍冶炼子公司各类库存。为防范库存价格下跌风险，结合生产经营与库存周转节奏开展空头套期保值。

黄金：公司黄金现货主要为未签订保价协议的历史出租黄金及华金矿山库存。2025年针对黄金市场价格持续单边大幅上涨的态势，为控制期货端浮动亏损与保证金追加压力，主动优化调整空头套保规模，降低套保比例。

# 3. 是否存在除套期保值外的大宗商品投机行为，是否已按照要求履行内部决策程序

公司不存在除套期保值外的大宗商品投机行为。衍生品业务均以正常生产经营为基础，以规避和防范价格及汇率风险为目的，并按照要求履行内部决策程序。

二、结合开展期货交易的实际投入、杠杆情况、具体投资品种、对应的现货规模等，并与公司主营业务实际生产销售的原材料数量进行比较，说明购买衍生品的数量与公司现货或外汇数量是否存在稳定比例。

公司开展商品衍生品交易以套期保值为唯一目的，实际投入主要为期货交易保证金。保证金比例由合作期货经纪商参照LME、上期所公布的各品种基础保证金标准，并结合其风控要求上浮确定，通常为合约价值的 $8 \% - 2 5 \%$ ，随交易所规则调整及期货公司风控政策动态变化。年度衍生品保证金账户平均余额 5.81亿元，截至报告期末，公司期货保证金账户余额占持仓合约期末结算价金额的比例为 $1 3 . 9 8 \%$ ，整体杠杆水平与套保业务规模相匹配，风险可控。

公司衍生品持仓数量与现货、外汇数量不存在固定、稳定的比例关系，而是结合市场环境与经营实际实施动态套保策略，相关决策主要综合考虑以下因素：对应金属品种市场价格波动情况、对价格未来走势的判断、现货生产经营成本、期货保值综合成本（包括期货公司限仓要求、合约移仓成本、开仓手续费及追加保证金资金成本等）。所有套保头寸均严格控制在公司现货生产、采购、销售及库存对应的风险敞口范围内，不开展投机性交易。

结合 2025 年度主要金属品种期现匹配数据，公司套保比例随市场行情动态调整：

针对产成品库存，在金属价格呈波动上行态势时，通常在现货风险敞口范围内适度提高空头套保比例，锁定生产经营利润；

在金属价格持续单边大幅上涨、且短期上行趋势明确时，为控制期货端浮动亏损、降低保证金追加压力与持仓成本、优化资金使用效率，将适当下调空头套保比例；

针对部分品种因现货定价机制与期货标的相关性较弱等情况，相应采取更为保守的套保比例，确保套保效果与风险承受能力匹配。

综上，公司衍生品持仓规模始终围绕主营业务现货风险敞口开展，套保比例动态调整具有合理性、必要性，与实际生产经营高度匹配，不存在脱离现货背景的投机行为。

结合 2025 年主要金属品种期现匹配及交易情况，各品种套保比例差异主要基于现货结构、定价相关性及市场行情判断形成，2024-2025年主要金属品种期末及交易量期现对比情况如下：

<table><tr><td rowspan=1 colspan=1>金属品种</td><td rowspan=1 colspan=1>2024年累计期现比例</td><td rowspan=1 colspan=1>2025年累计期现比例</td><td rowspan=1 colspan=1>2024年期末期现比例</td><td rowspan=1 colspan=1>2025年期末期现比例</td></tr><tr><td rowspan=1 colspan=1>铜</td><td rowspan=1 colspan=1>59%</td><td rowspan=1 colspan=1>61%</td><td rowspan=1 colspan=1>23%</td><td rowspan=1 colspan=1>29%</td></tr><tr><td rowspan=1 colspan=1>锌</td><td rowspan=1 colspan=1>46%</td><td rowspan=1 colspan=1>76%</td><td rowspan=1 colspan=1>10%</td><td rowspan=1 colspan=1>27%</td></tr><tr><td rowspan=1 colspan=1>镍</td><td rowspan=1 colspan=1>22%</td><td rowspan=1 colspan=1>33%</td><td rowspan=1 colspan=1>63%</td><td rowspan=1 colspan=1>17%</td></tr><tr><td rowspan=1 colspan=1>金</td><td rowspan=1 colspan=1>68%</td><td rowspan=1 colspan=1>81%</td><td rowspan=1 colspan=1>41%</td><td rowspan=1 colspan=1>0%</td></tr></table>

注：期货交易数量不含移仓、期现货包含贸易业务。对各产品期现统计说明如下：

铜：现货包含境外刚果（金）生产铜、国内冶炼副产品铜及贸易铜业务，部分物料（如尾砂、部分低品位铜）因品质、变现节奏等因素未纳入保值范围，综合形成期现匹配比例区间波动。

锌：现货包含国内冶炼厂库存及贸易锌精矿，同时对部分周转较慢的渣料类原料及在制品库存，公司结合锌价走势在现货敞口内实施部分套保。

镍：现货以硫酸镍为主，其价格与期货标的电解镍价格波动相关性较弱、非完全正相关，套保对冲效果存在一定局限性，因此整体采取较为保守的套保比例。

黄金：2025 年黄金价格持续单边大幅上涨，公司结合市场价格波动、现货成本等情况实施部分空头套保锁定收益，套保比例随行情动态调整。

# 三、补充说明公司报告期内商品衍生品和外汇衍生品交易大额亏损的合理性。

报告期公司衍生品亏损主要为铜产品衍生品亏损，占亏损总额 $8 2 . 4 \%$ ，锌、镍等其他产品合计占 $1 7 . 6 \%$ 。

# 1.亏损性质说明

报告期衍生品亏损主要系全球大宗商品市场铜价格呈现持续单边大幅上涨，公司对上述品种主要采用卖出套期保值策略，期货端形成相应浮动亏损，属于套期保值业务正常波动。上述亏损主要为持仓浮动亏损，对应现货库存同期价值同步提升，期现货整体实现风险对冲效果。公司严格按照套期保值内部控制制度及风险限额执行操作，整体风险可控。

# 2.市场客观原因

报告期内全球大宗商品和主要贵金属价格出现剧烈波动，公司主要经营的金属品种市场行情变化情况如下表：

<table><tr><td rowspan=1 colspan=1>金属品种</td><td rowspan=1 colspan=1>行情取数</td><td rowspan=1 colspan=1>单位</td><td rowspan=1 colspan=1>2025年均价</td><td rowspan=1 colspan=1>2025年末</td><td rowspan=1 colspan=1>2024年均价</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>年度均价涨幅</td><td rowspan=1 colspan=1>2025年头尾涨幅</td></tr><tr><td rowspan=1 colspan=1>铜</td><td rowspan=1 colspan=1>LME现货结算价</td><td rowspan=1 colspan=1>美元/吨</td><td rowspan=1 colspan=1>9,945</td><td rowspan=1 colspan=1>12,504</td><td rowspan=1 colspan=1>9,144</td><td rowspan=1 colspan=1>8,706</td><td rowspan=1 colspan=1>8.76%</td><td rowspan=1 colspan=1>43.63%</td></tr><tr><td rowspan=1 colspan=1>镍</td><td rowspan=1 colspan=1>SHFE结算价</td><td rowspan=1 colspan=1>元／吨</td><td rowspan=1 colspan=1>122,575</td><td rowspan=1 colspan=1>133,340</td><td rowspan=1 colspan=1>132,433</td><td rowspan=1 colspan=1>124,570</td><td rowspan=1 colspan=1>-7. 44%</td><td rowspan=1 colspan=1>7. 04%</td></tr><tr><td rowspan=1 colspan=1>锌</td><td rowspan=1 colspan=1>SHFE结算价</td><td rowspan=1 colspan=1>元／吨</td><td rowspan=1 colspan=1>22,534</td><td rowspan=1 colspan=1>23,295</td><td rowspan=1 colspan=1>23,329</td><td rowspan=1 colspan=1>25,310</td><td rowspan=1 colspan=1>-3.41%</td><td rowspan=1 colspan=1>-7.96%</td></tr><tr><td rowspan=1 colspan=1>金</td><td rowspan=1 colspan=1>SHFE结算价</td><td rowspan=1 colspan=1>元／吨</td><td rowspan=1 colspan=1>800</td><td rowspan=1 colspan=1>981</td><td rowspan=1 colspan=1>559</td><td rowspan=1 colspan=1>616</td><td rowspan=1 colspan=1>43.11%</td><td rowspan=1 colspan=1>59.25%</td></tr></table>

铜：受全球铜矿供应约束增强、美国关税政策引发全球铜流“虹吸效应”以及美联储降息周期开启等因素共振，2025年铜价呈现“区间波动、重心上移”走势，LME现货结算价全年均价同比上涨约 $8 . 8 \%$ ，12 月份加速上涨，年末较年初大幅上涨约 $4 3 . 6 \%$ 。铜为公司产业链核心布局金属，刚果（金）铜产能扩建完成后，报告期末合计年产规模达23 万金属吨，报告期全公司铜产量207,383.16吨。为锁定加工利润、防范产品价格下跌风险，公司对自产铜原料及相关铜产品库存开展部分空头套期保值，期末铜套保持仓与现货匹配比例约 $2 9 \%$ 。该部分持仓在年末铜价快速上行背景下，产生较大金额公允价值浮动亏损。铜期货亏损约占衍生品亏损总额的 $8 2 . 4 \%$ 。

其他：在美元信用弱化、地缘政治风险、全球央行持续购金因素推动下，报告期内黄金市场呈现强势上涨行情，而镍、锌等价格波动相对平缓，在市场价格上涨情况下，期货端空头套保也形成相应亏损。

从行业整体情况来看，在大宗商品价格单边上行周期中，行业内实施稳健套期保值策略的企业，普遍呈现期货端浮动亏损与现货端收益对冲的情形，具有明显的行业共性特征。

# 3.对冲效果

报告期内，公司衍生品交易产生公允价值变动及平仓亏损合计87,058.62 万元；同期合并报表主营业务毛利（扣除无衍生品保值的钴业务后）实现509,266.34 万元，衍生品亏损占上述现货毛利比例为 $1 7 . 0 9 \%$ 。

报告期内大宗商品价格整体呈现单边大幅上涨态势，公司以卖出套期保值为主的策略导致期货端出现亏损，但相应现货库存及经营收益同步提升，期货端亏损已被现货端增值收益有效覆盖。公司通过套期保值锁定了生产经营环节的核心利润，规避了未来价格大幅回落可能带来的经营业绩波动风险，整体对冲效果有效。

# 4.合规性与非投机说明

报告期内，公司所有期货及衍生品交易均具备对应的现货生产、库存、采购或销售背景，严格按照套期保值管理制度及审批程序开展，不存在主观投机交易、违规操作及内部控制失效情形。公司持续跟踪市场波动与保证金状况，及时完成保证金追加、仓位调整与风险控制，报告期内未发生强制平仓、资金流动性风险等异常情况，整体风险可控。

综上所述，报告期衍生品交易产生的亏损，系大宗商品价格大幅波动背景下，套期保值业务形成的正常浮动，具有合理性和行业普遍性。公司通过衍生品工具有效对冲了现货价格波动风险，实现了锁定经营利润、稳定经营业绩的套期保值目标。

# 会计师意见：

执行的主要程序：

1.获取公司衍生品投资管理制度、董事会及股东会决议文件，了解决策机制和审批程序；访谈管理层，了解套期保值策略及具体操作模式。

2.获取期货交易账户流水、交易确认书、持仓明细，对实际投入资金、杠杆比例、交易品种、持仓规模等情况执行分析性程序。

3.将衍生品交易品种（如铜、锌、镍等期货合约）与公司现货采购、销售、库存数量进行匹配分析，评估套期保值关系及比例稳定性。

4.对公允价值变动损益及处置损益进行重新计算，与公司记录进行核对；分析大额亏损的形成原因，结合市场价格走势评价其合理性。

# 基于执行的审计程序，我们认为：

1.公司就套期保值的相关说明在所有重大方面与我们在审计过程中所获取的资料及了解的情况一致。

2.公司套期保值业务已按照要求履行内部决策程序。公司开展的商品衍生品交易品种与公司主营产品及主要原材料直接相关，持仓规模与现货敞口大致匹配。

3.报告期内商品衍生品及外汇衍生品交易发生大额亏损，主要系2025 年铜产品价格大幅上涨，公司套期保值空头头寸产生较大浮动亏损。亏损金额与市场价格变动方向及公司套保方向一致，具有合理性。

特此公告。

盛屯矿业集团股份有限公司董事会2026 年 5 月 8 日