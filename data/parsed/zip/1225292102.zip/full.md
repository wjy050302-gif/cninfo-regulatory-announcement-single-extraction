![](images/2e70d18db9261e4a2bb1b508f3d91b3b3c3ac8d5a3fb35263ffcb1f7fa2c37eb.jpg)

# 探路者控股集团股份有限公司

与

向特定对象发行股票的

审核问询函的回复

保荐人（主承销商）

![](images/0706010ceccf6dbb812f601f5dbf1176995a201e40a7aba67dae9e15abb40701.jpg)

国泰海通证券股份有限公司GUOTAI HAITONG SECURITIES CO., LTD.

（中国（上海）自由贸易试验区商城路618 号）

二〇二六年五月

## 深圳证券交易所：

根据贵所于2026 年4月20 日印发的《关于探路者控股集团股份有限公司申请向特定对象发行股票的审核问询函》（审核函〔2026〕020030 号）（以下简称“问询函”）的要求，探路者控股集团股份有限公司（以下简称“探路者”、“发行人”或“公司”）会同国泰海通证券股份有限公司（以下简称“保荐人”或“国泰海通”）、北京市天元律师事务所（以下简称“发行人律师”）、立信会计师事务所（特殊普通合伙）（以下简称“申报会计师”），对问询函提出的问题逐项进行了认真核查落实。现回复如下，请予审核。

如无特别说明，本回复中的简称或名词释义与募集说明书具有相同含义。本问询函回复中的字体代表以下含义：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>字体</td></tr><tr><td rowspan=1 colspan=1>审核问询函所列问题</td><td rowspan=1 colspan=1>黑体</td></tr><tr><td rowspan=1 colspan=1>对审核问询函所列问题的回复</td><td rowspan=1 colspan=1>宋体</td></tr><tr><td rowspan=1 colspan=1>对募集说明书的修改、补充</td><td rowspan=1 colspan=1>楷体 (加粗)</td></tr></table>

本问询函回复中所引用数据，如合计数与各分项数直接相加之和存在差异，或小数点后尾数与原始数据存在差异，可能系由精确位数不同或四舍五入形成。

## 目录

目录 ...  
问题 1.. 3  
问题 2.. 37  
其他问题. . 96

## 问题1

申报材料显示，本次拟向特定对象发行股票募集资金不超过 18.58 亿元，全部用于补充流动资金。发行对象为发行人实际控制人李明控制的北京通域合盈投资管理有限公司（以下简称通域合盈）、北京明弘毅科技服务有限公司（以下简称明弘毅）。明弘毅成立于2025 年10 月29 日。通域合盈和明弘毅的认购资金来源为自筹资金，通域合盈预计将以本次发行后其持有的全部发行人股票进行质押担保，用于申请贷款。发行人控股股东为北京通域众合科技发展中心（有限合伙）（以下简称通域众合），通域众合及其一致行动人持有公司13.68%的股份。报告期末，发行人持有货币资金余额为 7.64 亿元，交易性金融资产余额为1.86 亿元，资产负债率为 26.79%。2025 年 10 月17 日，发行人董事会审议并披露拟使用不超过 8 亿元额度的闲置自有资金用于购买安全性高、流动性好、低风险的理财产品，期限为董事会审议通过之日起 12 个月内。2025 年 8 月 25 日，发行人首次披露本次再融资预案，2025 年 10 月 31 日，发行人对本次方案进行了修订，涉及发行对象、价格、金额等。公司前次非公开发行募集资金补充流动资金金额为127,138.48 万元（含利息），占实际募集资金总额比例为90.58%。

请发行人补充说明：（1）结合发行人资产负债率、在手资金、未来资金流入及资金支出安排等说明在持有较多闲置资金的情况下本次募集资金用于补充流动资金的必要性及规模合理性，未来大额资金支出安排是否已履行相关审议程序，是否具有必要性。（2）明确本次发行金额的下限及认购股票数量的下限，承诺的最低认购数量应与拟募集的资金金额相匹配。（3）本次认购资金具体筹资安排，各借款主体的背景，与发行人及控股股东、实控人的关系，是否存在资金短缺的风险；各借款主体是否存在除借款协议之外的其他安排，是否存在对外募集、代持、结构化安排；本次认购资金借款是否有明确可行的偿债计划；是否存在将发行人股票质押用于本次认购及减持发行人股票用于偿还借款的情形或计划，如有，请说明是否对发行人控制权稳定性产生影响及发行人应对措施。（4）结合发行人目前股权结构、董事会席位等说明控股股东及实际控制人的认定是否合理，发行人控制权是否稳定。（5）李明及其控制的主体在本次定价基准日前六个月是否存在减持其所持发行人股份的情形，是否已根据《上市公司收购管理办法》出具相关期限内不减持的承诺。（6）发行人于2025 年10 月对本次发行方案进行调整的原因，通过不同主体参与本次发行认购的背景和原因，明弘毅是否专为本次发行而设立，后续对通域合盈和明弘毅持股结构安排及具体计划，是否存在规避锁定期限等相关要求的情形。（7）发行人变更前次募集资金用途用于永久补充流动资金的具体情况，是否符合《证券期货法律适用意见第18 号》第五条的相关规定。

请保荐人核查并发表明确意见，请发行人律师对（2）（3）（4）（5）（6）（7）核查并发表明确意见，请会计师对（1）（3）（7）核查并发表明确意见。

## 回复：

一、结合发行人资产负债率、在手资金、未来资金流入及资金支出安排等说明在持有较多闲置资金的情况下本次募集资金用于补充流动资金的必要性及规模合理性，未来大额资金支出安排是否已履行相关审议程序，是否具有必要性。

## （一）发行人资产负债率情况

报告期各期末，公司的资产负债率分别为20.14%、26.05%和26.80%，资产负债率呈现持续上升趋势。未来随着公司在芯片领域的持续拓展，预计其对资金的需求将进一步增长。

公司本次发行拟募集资金总额为185,842.57 万元。若采用银行借款等债务融资方式，则存在以下两方面主要影响：一方面，银行借款的授信期限相对较短，且到期需一次性偿还全部本金，这将导致公司资产负债率大幅攀升。以截至2025年 12 月 31 日的资产负债结构为基准进行测算，若全部募集资金均通过银行借款方式获取，公司资产负债率将急剧上升至 96.79%，显著加大偿债风险，不利于公司的长期稳健发展。

另一方面，银行借款融资将导致公司承担高额利息费用。中国人民银行于2026 年 4 月 20 日公布的 5 年期以上贷款市场报价利率（LPR）3.50%为基准，若募集资金全部采用银行借款，利息费用支出将大幅增加，从而进一步加剧公司的资金紧张状况。

综上，从资产负债率的角度，公司通过本次定向增发进行融资具有必要性、融资规模具有合理性。

## （二）结合发行人在手资金、未来资金流入及资金支出安排等说明在持有较多闲置资金的情况下本次募集资金用于补充流动资金的规模合理性

结合公司在手资金、未来资金流入及资金支出安排等，根据截至2025 年12月末的财务数据，公司模拟测算了未来三年资金缺口情况，测算的具体过程情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>备注</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=4 colspan=1>可自由支配资金</td><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>57,721.90</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>20,702.70</td></tr><tr><td rowspan=1 colspan=1>受限资金</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>2,584.61</td></tr><tr><td rowspan=1 colspan=1>可自由支配货币资金</td><td rowspan=1 colspan=1>A=①+②-③</td><td rowspan=1 colspan=1>75,839.99</td></tr><tr><td rowspan=7 colspan=1>未来资金需求</td><td rowspan=1 colspan=1>未来三年营运资金需求</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>14,288.76</td></tr><tr><td rowspan=1 colspan=1>最低现金保有量</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>67,138.44</td></tr><tr><td rowspan=1 colspan=1>未来期间新增最低现金保有量</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>25,070.74</td></tr><tr><td rowspan=1 colspan=1>拟偿还有息负债</td><td rowspan=1 colspan=1>④</td><td rowspan=1 colspan=1>13,590.76</td></tr><tr><td rowspan=1 colspan=1>预计现金分红</td><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>6,127.97</td></tr><tr><td rowspan=1 colspan=1>已审议的重大资本性支出</td><td rowspan=1 colspan=1>®</td><td rowspan=1 colspan=1>159,552.65</td></tr><tr><td rowspan=1 colspan=1>总体资金需求合计</td><td rowspan=1 colspan=1>B-①+②+③+④+⑤+⑥</td><td rowspan=1 colspan=1>285,769.31</td></tr><tr><td rowspan=1 colspan=1>未来新增资金</td><td rowspan=1 colspan=1>未来三年现金流入净额</td><td rowspan=1 colspan=1>C</td><td rowspan=1 colspan=1>20,271.23</td></tr><tr><td rowspan=1 colspan=2>未来三年总体资金缺口</td><td rowspan=1 colspan=1>D=A-B+C</td><td rowspan=1 colspan=1>-189,658.09</td></tr></table>

## 1、货币资金及交易性金融资产

截至2025年12 月31 日，公司货币资金账面价值为57,721.90 万元，交易性金融资产账面价值为 20,702.70 万元，受限资金为 2,584.61 万元，可自由支配货币资金合计75,839.99 万元。公司货币资金具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>库存现金</td><td rowspan=1 colspan=1>3.13</td></tr><tr><td rowspan=1 colspan=1>银行存款</td><td rowspan=1 colspan=1>53,799.77</td></tr><tr><td rowspan=1 colspan=1>其他货币资金</td><td rowspan=1 colspan=1>3,919.00</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>57,721.90</td></tr></table>

其中受到限制的货币资金明细如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>结构性存款</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>存放在电商支付账户的保证金</td><td rowspan=1 colspan=1>63.02</td></tr><tr><td rowspan=1 colspan=1>银行承兑汇票保证金</td><td rowspan=1 colspan=1>2,521.59</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>2,584.61</td></tr></table>

交易性金融资产系公司使用闲置自有资金进行现金管理，投资于安全性高、流动性好、低风险的理财产品或存款类产品。具体构成如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末余额</td></tr><tr><td rowspan=1 colspan=1>以公允价值计量且其变动计入当期损益的金融资产</td><td rowspan=1 colspan=1>20,702.70</td></tr><tr><td rowspan=1 colspan=1>其中：银行理财产品及其他</td><td rowspan=1 colspan=1>20,702.70</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>20,702.70</td></tr></table>

综上，公司可自由支配的货币资金情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>备注</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>57,721.90</td></tr><tr><td rowspan=1 colspan=1>交易性金融资产</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>20,702.70</td></tr><tr><td rowspan=1 colspan=1>募集资金专户资金</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>受限资金</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>2,584.61</td></tr><tr><td rowspan=1 colspan=1>可自由支配货币资金</td><td rowspan=1 colspan=1>A=①+②-③-④</td><td rowspan=1 colspan=1>75,839.99</td></tr></table>

## 2、未来三年营运资金需求

公司未来三年的营运资金需求按户外业务和芯片业务来分别进行测算：

## （1）户外业务

采用 2025 年为基数期，2026 年-2028 年为预测期。公司2024 年户外业务收入较2023 年增长较多，2025 年户外业务收入较 2024 年有所下滑，2025 年户外业务下滑主要系宏观市场环境、产品迭代等因素影响，公司预计相关不利影响不具有持续性，预计不会形成不可逆转的下滑，详见问题2 的回复之“问题2、一、（三）下滑趋势是否具有持续性及发行人的应对措施”。此外，公司2025 年四季度以及 2026 年一季度的户外业务收入及增长情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年一季度</td><td rowspan=1 colspan=1>2026年一季度</td><td rowspan=1 colspan=1>增长率</td><td rowspan=1 colspan=1>2025年三季度</td><td rowspan=1 colspan=1>2025年四季度</td><td rowspan=1 colspan=1>增长率</td></tr><tr><td rowspan=1 colspan=1>户外业务收入</td><td rowspan=1 colspan=1>29,706.83</td><td rowspan=1 colspan=1>31,624.46</td><td rowspan=1 colspan=1>6.46%</td><td rowspan=1 colspan=1>23,547.46</td><td rowspan=1 colspan=1>37,689.20</td><td rowspan=1 colspan=1>60.06%</td></tr></table>

综上，公司 2026 年一季度户外业务营业收入较去年同期增长 6.46%，2025年四季度户外业务营业收入较三季度增幅明显。因此，合理预计公司 2026 年户外业务收入不会持续下滑。

报告期内，公司户外业务收入呈现波动变化，基于谨慎性考虑，假设 2026年至 2028 年发行人户外业务的营业收入与2025 年度持平，即115,077.48 万元。2026 年至2028 年预计户外业务营运资金需求为0。

## （2）芯片业务

报告期内，公司于 2025 年 11 月30 日召开董事会并公告收购深圳贝特莱电子科技股份有限公司（以下简称“贝特莱”）及上海通途半导体科技有限公司（以下简称“上海通途”）51%的股权。因新收购的公司规模较大，且在2026 年1月份才纳入合并报表范畴，为更准确评估未来资金需求，将公司芯片业务区分为原有芯片业务和新增芯片业务（贝特莱及上海通途）两部分，并分别进行独立的测算，具体情况如下：

## ①芯片原有业务

采用 2025 年为基数期，2026 年-2028 年为预测期。报告期内公司芯片业务营业收入情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>芯片-营业收入</td><td rowspan=1 colspan=1>22,993.83</td><td rowspan=1 colspan=1>22,230.84</td><td rowspan=1 colspan=1>13,347.05</td></tr></table>

综上，2023 年至2025 年的芯片业务营业收入复合增长率为31.25%。公司坚定推行“户外+芯片”双主业战略，未来将进一步加大对芯片业务领域的投入，

继续完善产品布局。但基于谨慎性考虑，假设2026 年度至2028 年度发行人芯片业务的营业收入增长率按照 10%来计算。2026 年至2028 年预计芯片原有业务营运资金需求的具体测算过程如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>2025年度/末</td><td rowspan=2 colspan=1>占营业收入比例</td><td rowspan=1 colspan=3>2026年至2028年预计经营资产及经营负债金额</td></tr><tr><td rowspan=1 colspan=1>2026年度/末</td><td rowspan=1 colspan=1>2027年度/末</td><td rowspan=1 colspan=1>2028年度/末</td></tr><tr><td rowspan=1 colspan=1>芯片-营业收入</td><td rowspan=1 colspan=1>22,993.83</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>25,293.21</td><td rowspan=1 colspan=1>27,822.53</td><td rowspan=1 colspan=1>30,604.79</td></tr><tr><td rowspan=1 colspan=1>芯片-应收账款</td><td rowspan=1 colspan=1>4,095.20</td><td rowspan=1 colspan=1>17.81%</td><td rowspan=1 colspan=1>4,504.72</td><td rowspan=1 colspan=1>4,955.19</td><td rowspan=1 colspan=1>5,450.71</td></tr><tr><td rowspan=1 colspan=1>芯片-预付款项</td><td rowspan=1 colspan=1>2,559.66</td><td rowspan=1 colspan=1>11.13%</td><td rowspan=1 colspan=1>2,815.63</td><td rowspan=1 colspan=1>3,097.19</td><td rowspan=1 colspan=1>3,406.91</td></tr><tr><td rowspan=1 colspan=1>芯片-存货</td><td rowspan=1 colspan=1>2,781.69</td><td rowspan=1 colspan=1>12.10%</td><td rowspan=1 colspan=1>3,059.85</td><td rowspan=1 colspan=1>3,365.84</td><td rowspan=1 colspan=1>3,702.42</td></tr><tr><td rowspan=1 colspan=1>经营性流动资产合计</td><td rowspan=1 colspan=1>9,436.55</td><td rowspan=1 colspan=1>41.03%</td><td rowspan=1 colspan=1>10,380.21</td><td rowspan=1 colspan=1>11,418.23</td><td rowspan=1 colspan=1>12,560.05</td></tr><tr><td rowspan=1 colspan=1>芯片-应付票据</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>0.00%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>=</td><td rowspan=1 colspan=1>=</td></tr><tr><td rowspan=1 colspan=1>芯片-应付账款</td><td rowspan=1 colspan=1>2,619.55</td><td rowspan=1 colspan=1>11.39%</td><td rowspan=1 colspan=1>2,881.51</td><td rowspan=1 colspan=1>3,169.66</td><td rowspan=1 colspan=1>3,486.62</td></tr><tr><td rowspan=1 colspan=1>芯片-合同负债</td><td rowspan=1 colspan=1>894.80</td><td rowspan=1 colspan=1>3.89%</td><td rowspan=1 colspan=1>984.28</td><td rowspan=1 colspan=1>1,082.70</td><td rowspan=1 colspan=1>1,190.97</td></tr><tr><td rowspan=1 colspan=1>经营性流动负债合计</td><td rowspan=1 colspan=1>3,514.35</td><td rowspan=1 colspan=1>15.28%</td><td rowspan=1 colspan=1>3,865.78</td><td rowspan=1 colspan=1>4,252.36</td><td rowspan=1 colspan=1>4,677.60</td></tr><tr><td rowspan=1 colspan=1>营运资金占用额（经营资产-经营负债）</td><td rowspan=1 colspan=1>5,922.20</td><td rowspan=1 colspan=1>25.75%</td><td rowspan=1 colspan=1>6,514.42</td><td rowspan=1 colspan=1>7,165.87</td><td rowspan=1 colspan=1>7,882.45</td></tr><tr><td rowspan=1 colspan=3>各年度营运资金缺口（下期营运资金占用额-上期营运资金占用额)</td><td rowspan=1 colspan=1>592.22</td><td rowspan=1 colspan=1>651.44</td><td rowspan=1 colspan=1>716.59</td></tr><tr><td rowspan=1 colspan=3>2026年至2028年预计营运资金需求</td><td rowspan=1 colspan=3>1,960.25</td></tr></table>

## ②芯片新增业务

芯片新增业务系公司报告期内公告收购的两家公司贝特莱和上海通途。贝特莱和上海通途过去三年收入情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2025年</td></tr><tr><td rowspan=1 colspan=1>贝特莱营业收入</td><td rowspan=1 colspan=1>15,096.47</td><td rowspan=1 colspan=1>17,938.53</td><td rowspan=1 colspan=1>25,371.03</td></tr><tr><td rowspan=1 colspan=1>上海通途营业收入</td><td rowspan=1 colspan=1>1,908.42</td><td rowspan=1 colspan=1>5,941.18</td><td rowspan=1 colspan=1>16,106.73</td></tr></table>

注：2023-2025 年贝特莱和上海通途的财务数据均经过审计。

贝特莱过去三年营业收入复合增长率为 29.64%，上海通途过去三年营业收入复合增长率为 190.51%。基于谨慎性考虑，且公司与该两家标的公司均签订了业绩承诺协议，2026 至2028 年为业绩承诺期，贝特莱和上海通途未来三年营业收入按照收购时上海东洲资产评估有限公司出具的评估报告中根据收益法对标的公司未来营业收入的预估数作为预测数。

根据评估报告中的预测数据，贝特莱和上海通途收入预测情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2026年</td><td rowspan=1 colspan=1>2027年</td><td rowspan=1 colspan=1>2028年</td></tr><tr><td rowspan=1 colspan=1>贝特莱营业收入</td><td rowspan=1 colspan=1>26,200.00</td><td rowspan=1 colspan=1>35,020.00</td><td rowspan=1 colspan=1>45,786.80</td><td rowspan=1 colspan=1>57,010.62</td></tr><tr><td rowspan=1 colspan=1>上海通途营业收入</td><td rowspan=1 colspan=1>18.906.00</td><td rowspan=1 colspan=1>29,724.90</td><td rowspan=1 colspan=1>39,467.42</td><td rowspan=1 colspan=1>50,742.51</td></tr></table>

注 1：2025 年至 2028 年贝特莱的营业收入预测数据系根据《探路者控股集团股份有限公司拟现金收购股权所涉及的深圳贝特莱电子科技股份有限公司股东全部权益估值技术说明》（东洲咨报字【2025】第 2490 号）中按照收益法估值时，对贝特莱未来营业收入的预估数为预测数；

注 2：2025 年及 2028 年上海通途的营业收入预测数据系根据《探路者控股集团股份有限公司拟现金收购股权所涉及的上海通途半导体科技有限公司股东全部权益估值技术说明》（东洲咨报字【2025】第 2612 号）中按照收益法估值时，对上海通途未来营业收入的预估数为预测数。

2025 年，贝特莱和上海通途的实际收入数据和评估报告中的预测数对比情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年实际数</td><td rowspan=1 colspan=1>2025年预测数</td><td rowspan=1 colspan=1>差异率</td></tr><tr><td rowspan=1 colspan=1>贝特莱营业收入</td><td rowspan=1 colspan=1>25,371.03</td><td rowspan=1 colspan=1>26,200.00</td><td rowspan=1 colspan=1>3.16%</td></tr><tr><td rowspan=1 colspan=1>上海通途营业收入</td><td rowspan=1 colspan=1>16,106.73</td><td rowspan=1 colspan=1>18,906.00</td><td rowspan=1 colspan=1>14.81%</td></tr></table>

注：2025 年贝特莱和上海通途财务数据均经过审计。

如上所示，贝特莱的实际营业收入和预测数据差异较小，上海通途的实际营业收入和预测数据的差异率为 14.81%。上海通途2025 年度收入未达预测数的主要原因系上海通途为提升市场占有率、保障出货规模及客户黏性，在四季度采取了短暂的降价措施，因此影响了四季度的营业收入和净利润。

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年一季度</td><td rowspan=1 colspan=1>2026年一季度</td><td rowspan=1 colspan=1>增长率</td><td rowspan=1 colspan=1>2026年目标增长率</td></tr><tr><td rowspan=1 colspan=1>贝特莱营业收入</td><td rowspan=1 colspan=1>4,111.80</td><td rowspan=1 colspan=1>6,675.63</td><td rowspan=1 colspan=1>62.35%</td><td rowspan=1 colspan=1>38.03%</td></tr><tr><td rowspan=1 colspan=1>上海通途营业收入</td><td rowspan=1 colspan=1>1,043.68</td><td rowspan=1 colspan=1>4,414.41</td><td rowspan=1 colspan=1>322.97%</td><td rowspan=1 colspan=1>84.55%</td></tr></table>

注 1：2026 年目标增长率是指要达到 2026 年评估报告中的预测收入需要达到的收入增长率；

注 2：2026 年目标增长率=（2026 年评估报告中的预测收入-2025 年实际收入）/2025 年实际收入。

贝特莱2026 年一季度营业收入较2025 年同期增长62.35%，上海通途2026年一季度营业收入较2025 年同期增长322.97%，两家公司2026 年一季度的收入增长率均远高于2026 年全年收入的目标增长率。

因此采用 2025 年为基数期，2026 年-2028 年为预测期。根据评估报告中的预测营业收入数据来测算未来的资金需求。2026 年至2028 年预计芯片新增业务营运资金需求的具体测算过程如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>贝特莱2025年度/末</td><td rowspan=2 colspan=1>上海通途2025年度/末</td><td rowspan=2 colspan=1>合并数据</td><td rowspan=2 colspan=1>占合并营业收入比例</td><td rowspan=1 colspan=3>2026年至2028年预计经营资产及经营负债数额</td></tr><tr><td rowspan=1 colspan=1>2026年度/末</td><td rowspan=1 colspan=1>2027年度末</td><td rowspan=1 colspan=1>2028年度/末</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>25,371.03</td><td rowspan=1 colspan=1>16,106.73</td><td rowspan=1 colspan=1>41,477.76</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>64,744.90</td><td rowspan=1 colspan=1>85,254.22</td><td rowspan=1 colspan=1>107,753.13</td></tr><tr><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>2,621.23</td><td rowspan=1 colspan=1>5,376.97</td><td rowspan=1 colspan=1>7,998.21</td><td rowspan=1 colspan=1>19.28%</td><td rowspan=1 colspan=1>12,484.84</td><td rowspan=1 colspan=1>16,439.68</td><td rowspan=1 colspan=1>20,778.17</td></tr><tr><td rowspan=1 colspan=1>预付款项</td><td rowspan=1 colspan=1>900.62</td><td rowspan=1 colspan=1>150.62</td><td rowspan=1 colspan=1>1,051.24</td><td rowspan=1 colspan=1>2.53%</td><td rowspan=1 colspan=1>1,640.93</td><td rowspan=1 colspan=1>2,160.73</td><td rowspan=1 colspan=1>2,730.96</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>5,239.81</td><td rowspan=1 colspan=1>795.95</td><td rowspan=1 colspan=1>6,035.76</td><td rowspan=1 colspan=1>14.55%</td><td rowspan=1 colspan=1>9,421.55</td><td rowspan=1 colspan=1>12,406.03</td><td rowspan=1 colspan=1>15,680.02</td></tr><tr><td rowspan=1 colspan=1>经营性流动资产合计</td><td rowspan=1 colspan=1>8,761.66</td><td rowspan=1 colspan=1>6,323.54</td><td rowspan=1 colspan=1>15,085.21</td><td rowspan=1 colspan=1>36.37%</td><td rowspan=1 colspan=1>23,547.32</td><td rowspan=1 colspan=1>31,006.44</td><td rowspan=1 colspan=1>39,189.16</td></tr><tr><td rowspan=1 colspan=1>应付票据</td><td rowspan=1 colspan=1>192.93</td><td rowspan=1 colspan=1>0.00</td><td rowspan=1 colspan=1>192.93</td><td rowspan=1 colspan=1>0.47%</td><td rowspan=1 colspan=1>301.15</td><td rowspan=1 colspan=1>396.55</td><td rowspan=1 colspan=1>501.20</td></tr><tr><td rowspan=1 colspan=1>应付账款</td><td rowspan=1 colspan=1>1,067.94</td><td rowspan=1 colspan=1>3,845.81</td><td rowspan=1 colspan=1>4,913.75</td><td rowspan=1 colspan=1>11.85%</td><td rowspan=1 colspan=1>7,670.14</td><td rowspan=1 colspan=1>10,099.81</td><td rowspan=1 colspan=1>12,765.19</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>2,248.62</td><td rowspan=1 colspan=1>14.25</td><td rowspan=1 colspan=1>2,262.86</td><td rowspan=1 colspan=1>5.46%</td><td rowspan=1 colspan=1>3,532.23</td><td rowspan=1 colspan=1>4,651.14</td><td rowspan=1 colspan=1>5,878.59</td></tr><tr><td rowspan=1 colspan=1>经营性流动负债合计</td><td rowspan=1 colspan=1>3,509.48</td><td rowspan=1 colspan=1>3,860.05</td><td rowspan=1 colspan=1>7,369.54</td><td rowspan=1 colspan=1>17.77%</td><td rowspan=1 colspan=1>11,503.51</td><td rowspan=1 colspan=1>15,147.50</td><td rowspan=1 colspan=1>19,144.98</td></tr><tr><td rowspan=1 colspan=1>营运资金占用额（经营资产-经营负债）</td><td rowspan=1 colspan=1>5,252.18</td><td rowspan=1 colspan=1>2,463.49</td><td rowspan=1 colspan=1>7,715.67</td><td rowspan=1 colspan=1>18.60%</td><td rowspan=1 colspan=1>12,043.81</td><td rowspan=1 colspan=1>15,858.94</td><td rowspan=1 colspan=1>20,044.18</td></tr><tr><td rowspan=1 colspan=5>各年度营运资金缺口(下期营运资金占用额-上期营运资金占用额)</td><td rowspan=1 colspan=1>4,328.14</td><td rowspan=1 colspan=1>3,815.13</td><td rowspan=1 colspan=1>4,185.23</td></tr><tr><td rowspan=1 colspan=5>2026年至2028年预计营运资金需求</td><td rowspan=1 colspan=3>12,328.51</td></tr></table>

综上，公司未来三年营运资金需求合计金额为14,288.76 万元。

## 3、最低现金保有量

最低现金保有量系公司为维持其日常营运所需要的最低货币资金金额，以应对客户回款不及时，支付供应商货款、职工薪酬、税费等短期付现成本。上市公司持有一定金额的最低现金保有量主要目的是为了在极端情形下，依然能保障和满足上市公司正常经营的需要，避免发生经营风险。根据公司合并报表，报告期内公司经营性现金流出情况及据此测算的公司货币资金保有量情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2025年</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流出小计</td><td rowspan=1 colspan=1>148,933.66</td><td rowspan=1 colspan=1>167,934.09</td><td rowspan=1 colspan=1>166,529.01</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流出/营业收入</td><td rowspan=1 colspan=1>107%</td><td rowspan=1 colspan=1>106%</td><td rowspan=1 colspan=1>121%</td></tr><tr><td rowspan=1 colspan=1>月均经营活动现金支出A</td><td rowspan=1 colspan=1>12,411.14</td><td rowspan=1 colspan=1>13,994.51</td><td rowspan=1 colspan=1>13,877.42</td></tr><tr><td rowspan=1 colspan=1>期末货币资金余额B</td><td rowspan=1 colspan=1>76,374.96</td><td rowspan=1 colspan=1>74,783.96</td><td rowspan=1 colspan=1>57,721.90</td></tr><tr><td rowspan=1 colspan=1>覆盖月数（月）=B/A</td><td rowspan=1 colspan=1>6.15</td><td rowspan=1 colspan=1>5.34</td><td rowspan=1 colspan=1>4.16</td></tr><tr><td rowspan=1 colspan=1>报告期内月均经营活动现金支出</td><td rowspan=1 colspan=3>13,427.69</td></tr></table>

注：报告期内月均经营活动现金支出=Σ报告期各期经营活动现金流出小计/报告期内月份合计。

由上表可知，报告期各期末，公司期末货币资金对月均经营活动现金流出的覆盖月份数分别为6.15 个月、5.34 个月和4.16 个月。其中，2025 年因在年底12月份支付贝特莱和上海通途 34,815.87 万元的收购款导致期末货币资金余额大幅减少，如果将该偶发性因素剔除，2025 年覆盖月份数约6.67 个月。

因此，为保证公司经营运转稳定，公司通常预留5个月左右日常经营所需现金，因此测算保留 5个月经营活动现金流出资金作为最低现金保有量。按照前述测算，谨慎选择报告期内月均经营活动现金支出 13,427.69 万元为基础，确定最低现金保有量为67,138.44 万元。

## 4、未来期间新增最低现金保有量

随着公司业务持续发展，预计未来将新增一定的最低资金保有量需求。假设公司维持现行现金周转效率不变，公司所需最低现金保有量也将按照 2026 年至2028 年公司营业收入的增长情况同比例上升，预计截至2028 年公司需要新增最低现金保有量为 25,071.17 万元，营业收入的预测增长情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>备注</td><td rowspan=1 colspan=1>2026年度</td><td rowspan=1 colspan=1>2027年度</td><td rowspan=1 colspan=1>2028年度</td></tr><tr><td rowspan=1 colspan=1>预测的营业收入</td><td rowspan=1 colspan=1>A=①+②+③</td><td rowspan=1 colspan=1>205,115.59</td><td rowspan=1 colspan=1>228,154.23</td><td rowspan=1 colspan=1>253,435.40</td></tr><tr><td rowspan=1 colspan=1>其中：户外业务收入</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>115,077.48</td><td rowspan=1 colspan=1>115,077.48</td><td rowspan=1 colspan=1>115,077.48</td></tr><tr><td rowspan=1 colspan=1>原有的芯片业务收入</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>25,293.21</td><td rowspan=1 colspan=1>27,822.53</td><td rowspan=1 colspan=1>30,604.79</td></tr><tr><td rowspan=1 colspan=1>新增的芯片业务收入</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>64,744.90</td><td rowspan=1 colspan=1>85,254.22</td><td rowspan=1 colspan=1>107,753.13</td></tr></table>

注：基于谨慎性考虑，假设 2026 年至 2028 年发行人户外业务的营业收入与 2025 年度持平；假设 2026 年度至 2028 年度发行人原有的芯片业务的营业收入增长率按照 10%来计算；新增的芯片业务收入指贝特莱和上海通途的业务收入，假设 2026 年度至 2028 年度营业收入按照评估报告中的预估营业收入数作为预测数。

基于公司未来营业收入的增长情况，公司需要新增的最低现金保有量按照2026 年-2028年营业收入的复合增长率进行测算的过程如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2026年度</td><td rowspan=1 colspan=1>2027年度</td><td rowspan=1 colspan=1>2028年度</td></tr><tr><td rowspan=1 colspan=1>最低现金保有量</td><td rowspan=1 colspan=1>67,138.44</td><td rowspan=1 colspan=1>74,628.64</td><td rowspan=1 colspan=1>82,954.48</td><td rowspan=1 colspan=1>92,209.17</td></tr><tr><td rowspan=1 colspan=2>2026 年-2028年营业收入的复合增长率</td><td rowspan=1 colspan=3>11.16%</td></tr><tr><td rowspan=1 colspan=2>未来期间新增最低现金保有量</td><td rowspan=1 colspan=3>25,070.74</td></tr></table>

## 5、偿还有息负债

截至2025年12 月31日，公司有息负债主要情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>余额</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>3,590.76</td></tr><tr><td rowspan=1 colspan=1>一年内到期的长期借款</td><td rowspan=1 colspan=1>3,000.00</td></tr><tr><td rowspan=1 colspan=1>长期借款</td><td rowspan=1 colspan=1>7,000.00</td></tr><tr><td rowspan=1 colspan=1>总计</td><td rowspan=1 colspan=1>13,590.76</td></tr></table>

截至2025 年12 月31 日，公司借款余额为13,590.76 万元。为保障财务稳健性，降低流动性风险，提高行业风险应对能力，公司需要为上述借款预留部分现金。

## 6、未来三年预计现金分红

未来三年预计现金分红所需资金采用未来三年归属于上市公司股东的净利润乘现金分红比例来进行测算。最近三年，公司现金分红情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2025年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">2023年</td></tr><tr><td colspan="1" rowspan="1">现金分红</td><td colspan="1" rowspan="1">851.66</td><td colspan="1" rowspan="1">1,013.92</td><td colspan="1" rowspan="1">2,027.85</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净利润</td><td colspan="1" rowspan="1">7,898.80</td><td colspan="1" rowspan="1">10,662.31</td><td colspan="1" rowspan="1">7,179.79</td></tr><tr><td colspan="1" rowspan="1">当年现金分红占归属于上市公司股东的</td><td colspan="1" rowspan="1">10.78%</td><td colspan="1" rowspan="1">9.51%</td><td colspan="1" rowspan="1">28.24%</td></tr><tr><td colspan="1" rowspan="1">净利润的比例</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">最近三年累计现金分配合计/最近三年归属于上市公司股东的净利润</td><td colspan="3" rowspan="1">15.13%</td></tr></table>

注：2025年4月27日公司第六届董事会第十三次会议审议通过了《2025年度利润分配预案》，尚需提交公司 2025 年年度股东会审议通过后方可实施。

预计2026 年至2028 年现金分红所需资金情况如下：  
单位：万元
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2026E</td><td rowspan=1 colspan=1>2027E</td><td rowspan=1 colspan=1>2028E</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>205,115.59</td><td rowspan=1 colspan=1>228,154.23</td><td rowspan=1 colspan=1>253,435.40</td></tr><tr><td rowspan=1 colspan=1>归属于母公司所有者的净利润</td><td rowspan=1 colspan=1>12,101.41</td><td rowspan=1 colspan=1>13,460.64</td><td rowspan=1 colspan=1>14,952.18</td></tr><tr><td rowspan=1 colspan=1>现金分红</td><td rowspan=1 colspan=1>1,830.40</td><td rowspan=1 colspan=1>2,035.99</td><td rowspan=1 colspan=1>2,261.59</td></tr><tr><td rowspan=1 colspan=1>现金分红总计</td><td rowspan=1 colspan=3>6,127.97</td></tr></table>

未来期间预计现金分红所需资金为 6,127.97 万元。（注：此处未来三年分红预计数据仅为测算资金缺口所需，不构成分红承诺）。

## 7、未来的重大资本性支出

截至2025 年12 月31 日，发行人已通过总裁办公会或董事会程序审议的重要投资项目或投资计划，预计合计支出金额为194,368.52 万元，其中已在2025年 12 月份支付 34,815.87 万元，剩余 159,552.65 万元。具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">预计总投资规模</td><td colspan="1" rowspan="1">已支付金额</td><td colspan="1" rowspan="1">剩余投资金额</td></tr><tr><td colspan="1" rowspan="1">收购深圳贝特莱电子科技股份有限公司51%的股份</td><td colspan="1" rowspan="1">32,130.00</td><td colspan="1" rowspan="1">16,965.87</td><td colspan="1" rowspan="1">15,164.13</td></tr><tr><td colspan="1" rowspan="1">收购上海通途半导体科技有限公司51%的股份</td><td colspan="1" rowspan="1">35,700.00</td><td colspan="1" rowspan="1">17,850.00</td><td colspan="1" rowspan="1">17,850.00</td></tr><tr><td colspan="1" rowspan="1">收购深圳贝特莱电子科技股份有限公司49%的股份</td><td colspan="1" rowspan="1">30,870.00</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">30,870.00</td></tr><tr><td colspan="1" rowspan="1">收购上海通途半导体科技有限公司49%的股份</td><td colspan="1" rowspan="1">34,300.00</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">34,300.00</td></tr><tr><td colspan="1" rowspan="1">购买通州紫光科技园的办公楼</td><td colspan="1" rowspan="1">34,965.52</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">34,965.52</td></tr><tr><td colspan="1" rowspan="1">热成像封装工程一期设备及洁净车间建设</td><td colspan="1" rowspan="1">3,343.00</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3,343.00</td></tr><tr><td colspan="1" rowspan="1">热成像封装工程二期投资</td><td colspan="1" rowspan="1">5,685.00</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">5,685.00</td></tr><tr><td colspan="1" rowspan="1">研发中心建设选址及建设投资</td><td colspan="1" rowspan="1">6,700.00</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">6,700.00</td></tr><tr><td colspan="1" rowspan="1">二号生产厂房及办公楼建设选址及建设投资</td><td colspan="1" rowspan="1">10,675.00</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">10,675.00</td></tr><tr><td colspan="1" rowspan="1">合计数</td><td colspan="1" rowspan="1">194,368.52</td><td colspan="1" rowspan="1">34,815.87</td><td colspan="1" rowspan="1">159,552.65</td></tr></table>

## 8、未来三年经营活动产生的现金净流入

采用 2025 年为基数期，2026 年-2028 年为预测期，参照上文对于 2026-2028年公司营业收入的预计，则发行人 2026 年至2028 年预计经营活动产生的现金流量净额为20,271.23 万元，具体测算如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>2025年度/末</td><td rowspan=2 colspan=1>占营业收入比例</td><td rowspan=1 colspan=3>2026年至2028年预计现金流量净额</td></tr><tr><td rowspan=1 colspan=1>2026年度/末</td><td rowspan=1 colspan=1>2027年度/末</td><td rowspan=1 colspan=1>2028年度/末</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>138,071.31</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>205,115.59</td><td rowspan=1 colspan=1>228,154.23</td><td rowspan=1 colspan=1>253,435.40</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>4,075.80</td><td rowspan=1 colspan=1>2.95%</td><td rowspan=1 colspan=1>6,054.92</td><td rowspan=1 colspan=1>6,735.01</td><td rowspan=1 colspan=1>7,481.30</td></tr><tr><td rowspan=1 colspan=3>2026年至2028年预计现金流量净额合计数</td><td rowspan=1 colspan=3>20,271.23</td></tr></table>

综上，公司未来面临的总体资金缺口金额约为-189,658.09 万元，而本次募集资金总额为不超过 185,842.57 万元（含本数），本次募集资金用于补充流动资金具有规模的合理性。

## （三）本次募集资金用于补充流动资金的必要性

## 1、持续推动“户外+芯片”双主业战略，提升公司核心竞争力

公司积极响应国家培育新质生产力的战略部署，以“科技引领、创新突破”为核心驱动力，深度融入国家发展战略，锚定全球行业前沿，持续巩固行业领军地位。面对全球经济变革和技术创新浪潮，公司坚定推行“户外+芯片”双主业战略，持续深化跨国布局，构建核心竞争壁垒，推动高质量发展。

公司的双主业战略需要以核心技术攻关和产业链协同布局为抓手，推动关键领域自主可控，完成基础技术的不断迭代优化、科技平台的战略升级。本次发行拟使用募集资金补充流动资金，增强了公司资金储备，为公司技术创新、产品开发和项目投资等方面提供了资金支持，有助于公司实现长期战略发展目标，巩固行业优势

地位。

## 2、满足资金需求，保障业务发展，提升公司盈利能力

近年来公司经营规模持续扩大，资产规模迅速提升，营运资金投入量较大。公司芯片业务发展较快，保持较高的流动资产比例及较高的资金储备有利于公司长期健康稳定发展，保障经营活动的顺利开展，从而为股东创造更高的价值。未来，随着投资项目建设的推进，公司业务规模将进一步扩大，对流动资金的需求不断增加。本次发行拟使用募集资金补充流动资金，有利于公司未来户外业务和芯片业务的发展，增强核心竞争力，进而提升公司盈利能力和经营稳健性。

## 3、增加实际控制人的控制权比例

本次定向增发预计将直接提升公司实际控制人李明先生的持股比例，从而巩固其对公司治理、战略方向及日常经营的控制力。此举不仅优化了股权集中度，增强了控制权的稳定性与决策效率，更向市场传递了控股股东对公司长期价值与发展前景的坚定信心。

## （四）未来大额资金支出安排是否已履行相关审议程序，是否具有必要性。

发行人未来大额资金支出安排具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">预计总投资规模</td><td colspan="1" rowspan="1">已履行的审议程序</td><td colspan="1" rowspan="1">必要性</td></tr><tr><td colspan="1" rowspan="1">收购深圳贝特莱电子科技股份有限公司51%的股份</td><td colspan="1" rowspan="1">32,130.00</td><td colspan="1" rowspan="1">第六届董事会第十次会议</td><td colspan="1" rowspan="4">本次收购的核心目的，是与公司现有的芯片业务板块形成深度互补与全面强化。贝特莱在信号链芯片上的技术积累，将与公司现有产品线形成有力互补，显著拓展公司在模拟及数模混合芯片市场的产品维度与客户广度。上海通途的技术资源将增强公司在显示驱动、视频处理等方向的技术竞争力与创新能力。通过整合两家公司的技术、产品与客户资源，公司将加速实现芯片业务板块的技术升级与市场拓展，形成更加完整和强大的芯片产业布局，从而显著提升公司在芯片行业的综合竞争力，推动芯片主业的快速发展。</td></tr><tr><td colspan="1" rowspan="1">收购上海通途半导体科技有限公司51%的股份</td><td colspan="1" rowspan="1">35,700.00</td><td colspan="1" rowspan="1">第六届董事会第十次会议</td></tr><tr><td colspan="1" rowspan="1">收购深圳贝特莱电子科技股份有限公司49%的股份</td><td colspan="1" rowspan="1">30,870.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td></tr><tr><td colspan="1" rowspan="1">收购上海通途半导体科技有限公司49%的股份</td><td colspan="1" rowspan="1">34,300.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td></tr><tr><td colspan="1" rowspan="1">购买通州紫光科技园的办公楼</td><td colspan="1" rowspan="1">34,965.52</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td><td colspan="1" rowspan="1">公司现有办公场所均系租赁取得的，本次办公楼的购买是为满足其办公场所需求，具有必要性与合理性。</td></tr><tr><td colspan="1" rowspan="1">热成像封装工程一期设备及洁净车间建设</td><td colspan="1" rowspan="1">3,343.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td><td colspan="1" rowspan="2">公司子公司江苏鼎茂掌握红外封装技术且积累多年经验。报告期内，江苏鼎茂收入和订单量迅速增长，公司计划提前布局、扩大产能以应对未来市场需求，具有必要性与合理性。</td></tr><tr><td colspan="1" rowspan="1">热成像封装工程二期投资</td><td colspan="1" rowspan="1">5,685.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td></tr><tr><td colspan="1" rowspan="1">研发中心建设选址及建设投资</td><td colspan="1" rowspan="1">6,700.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td><td colspan="1" rowspan="1">公司芯片业务主要聚焦在“图、显、触控、指纹”四大领域，研发中心的建设有利于四大领域间的深度合作研发与协同优化，从而降低开发成本、缩短新产品上市周期，具有必要性与合理性。</td></tr><tr><td colspan="1" rowspan="1">二号生产厂房及办公楼建设选址及建设投资</td><td colspan="1" rowspan="1">10,675.00</td><td colspan="1" rowspan="1">总裁办公会审议通过、董事长审批通过</td><td colspan="1" rowspan="1">报告期内，江苏鼎茂收入和订单量迅速增长，公司计划新建生产厂房来扩大产能以应对未来市场需求，新建办公楼来满足办公场所需求，具有必要性与合理性。</td></tr><tr><td colspan="1" rowspan="1">合计数</td><td colspan="1" rowspan="1">194,368.52</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

综上，公司未来大额资金支出均已履行相关审议程序，具有必要性。

## 二、明确本次发行金额的下限及认购股票数量的下限，承诺的最低认购数量应与拟募集的资金金额相匹配。

公司本次发行股票的数量为 265,110,655 股（含本数），对应本次募集资金总额不超过 185,842.57 万元（含本数），扣除发行费用后的募集资金净额拟全部用于补充流动资金。2025 年 10 月 31 日，明弘毅、通域合盈共同与发行人签署了《附条件生效的股份认购协议》，其中约定明弘毅、通域合盈认购公司本次发行的全部股票，认购金额不超过 185,842.57 万元。明弘毅的认购数量不超过79,533,197 股，认购金额不超过 55,752.77 万元；通域合盈的认购数量不超过185,577,458 股，认购金额不超过 130,089.80 万元。若公司股票在定价基准日至发行日期间派发现金股利、送红股、资本公积金转增股本等除权除息事项，则本次发行价格将进行相应调整。

为进一步明确认购数量及认购金额的下限，发行对象明弘毅、通域合盈分别出具了《关于认购股票数量及金额的承诺函》，具体承诺内容分别如下：

“明弘毅认购探路者控股集团股份有限公司向特定对象发行股票（以下简称“本次发行”）总金额不低于人民币 30,243.42 万元（含本数）且不超过人民币55,752.77 万元（含本数），认购价格为 7.01 元/股。本次认购数量区间由认购总金额除以认购价格计算得出，数量不足1股的余数作取整处理，即认购数量不低于 43,143,256 股（含本数）且不超过 79,533,197 股（含本数）。

在本次发行的定价基准日至发行日期间，若发行人发生派发现金股利、送红股、资本公积金转增股本等除权除息事项，或因深圳证券交易所、中国证监会要求等其他原因导致本次发行价格发生调整，则明弘毅认购本次发行的认购价格和认购数量将作出相应调整。”

“通域合盈认购探路者控股集团股份有限公司向特定对象发行股票（以下简称“本次发行”）总金额不低于人民币70,567.99 万元（含本数）且不超过人民币130,089.80 万元（含本数），认购价格为7.01 元/股。本次认购数量区间由认购总金额除以认购价格计算得出，数量不足1股的余数作取整处理，即认购数量不低于 100,667,598 股（含本数）且不超过 185,577,458 股（含本数）。

在本次发行的定价基准日至发行日期间，若发行人发生派发现金股利、送红股、资本公积金转增股本等除权除息事项，或因深圳证券交易所、中国证监会要求等其他原因导致本次发行价格发生调整，则通域合盈认购本次发行的认购价格和认购数量将作出相应调整。”

综上所述，本次发行金额的下限为100,811.41 万元，认购股票数量的下限为143,810,854 股，承诺的最低认购数量与拟募集的资金金额相匹配。其中明弘毅、通域合盈承诺本次认购金额下限分别为30,243.42 万元和70,567.99 万元，对应认购股票数量下限分别为 43,143,256 股和100,667,598 股，明弘毅、通域合盈已承诺的最低认购数量与发行人拟募集资金金额相匹配。

三、本次认购资金具体筹资安排，各借款主体的背景，与发行人及控股股东、实控人的关系，是否存在资金短缺的风险；各借款主体是否存在除借款协议之外的其他安排，是否存在对外募集、代持、结构化安排；本次认购资金借款是否有明确可行的偿债计划；是否存在将发行人股票质押用于本次认购及减持发行人股票用于偿还借款的情形或计划，如有，请说明是否对发行人控制权稳定性产生影响及发行人应对措施。

（一）本次认购资金具体筹资安排，各借款主体的背景，与发行人及控股股东、实控人的关系，是否存在资金短缺的风险；各借款主体是否存在除借款协议之外的其他安排，是否存在对外募集、代持、结构化安排

本次认购资金来源于自筹资金，具体筹资安排情况如下：

<table><tr><td rowspan=1 colspan=1>借款对象</td><td rowspan=1 colspan=1>借款金额</td><td rowspan=1 colspan=1>借款利率</td><td rowspan=1 colspan=1>借款期限</td><td rowspan=1 colspan=1>还款方式</td></tr><tr><td rowspan=1 colspan=1>世纪金源投资集团有限公司</td><td rowspan=1 colspan=1>不超过11亿元</td><td rowspan=1 colspan=1>年化利率6%</td><td rowspan=1 colspan=1>3.5年</td><td rowspan=1 colspan=1>到期一次性还本付息</td></tr><tr><td rowspan=1 colspan=1>天津信托有限责任公司</td><td rowspan=1 colspan=1>不超过5亿元</td><td rowspan=1 colspan=1>年化综合成本不超过6.5%</td><td rowspan=1 colspan=1>不超过48个月</td><td rowspan=1 colspan=1>每年年末付息；借款到期，一次性归还本金</td></tr><tr><td rowspan=1 colspan=1>王波</td><td rowspan=1 colspan=1>不超过7,000万元</td><td rowspan=2 colspan=1>年化利率6%</td><td rowspan=2 colspan=1>3.5年</td><td rowspan=2 colspan=1>到期一次性还本付息</td></tr><tr><td rowspan=1 colspan=1>任丽必</td><td rowspan=1 colspan=1>不超过2亿元</td></tr></table>

各借款主体的背景情况如下：

<table><tr><td rowspan=1 colspan=1>借款主体</td><td rowspan=1 colspan=1>借款主体背景</td><td rowspan=1 colspan=1>与发行人及控股股东、实控人的关系</td></tr><tr><td rowspan=1 colspan=1>世纪金源投资集团有限公司</td><td rowspan=1 colspan=1>该公司成立于2001年，法定代表人和实际控制人为黄涛。公司主营业务涵盖地产开发、酒店文旅、商业运营、生活服务、大健康五大领域，连续多年入选中国房地产开发企业500 强和中国商业地产100 强榜单</td><td rowspan=1 colspan=1>世纪金源投资集团有限公司实际控制人黄涛系发行对象通域合盈的间接股东，与实控人李明系朋友关系</td></tr><tr><td rowspan=1 colspan=1>天津信托有限责任公司</td><td rowspan=1 colspan=1>该公司系国有控股信托公司</td><td rowspan=1 colspan=1>与发行人及控股股东、实控人无关联关系，仅为金融机构协商借款</td></tr><tr><td rowspan=1 colspan=1>王波</td><td rowspan=1 colspan=1>有资金实力的个人</td><td rowspan=1 colspan=1>王波与发行人及控股股东无关联关系，与实控人李明系朋友关系</td></tr><tr><td rowspan=1 colspan=1>任丽必</td><td rowspan=1 colspan=1>有资金实力的个人</td><td rowspan=1 colspan=1>任丽必与发行人及控股股东无关联关系，与实控人李明系朋友关系</td></tr></table>

通过获取世纪金源投资集团有限公司、王波、任丽必的借款协议，以及天津信托有限责任公司出具的融资要素确认函；获取自然人任丽必股票账户余额截图和基金投资人资产证明、获取自然人王波股票账户资产截图以及获取世纪金源投资集团有限公司和天津信托有限责任公司的财务报表，证明各借款主体均具备相应的借款实力，不存在资金短缺风险，并就相关借款事项、是否存在除借款协议外的其他安排，是否存在对外募集、代持、结构化安排等情况访谈通域合盈及明弘毅实际控制人李明、借款对象任丽必、王波、天津信托有限责任公司以及世纪金源投资集团有限公司。

任丽必与王波均出具承诺函，承诺“1、本次借款资金为合法自有资金，资金来源合法合规，不存在任何纠纷或潜在纠纷；2、本人与明弘毅及其实际控制人李明、上市公司、北京通域众合科技发展中心（有限合伙）、北京通域高精尖股权投资中心（有限合伙）之间均不存在除借款协议之外的其他安排，不存在对外募集、代持、结构化安排等情形。”

世纪金源投资集团有限公司已出具承诺函，承诺“1、本次借款资金为合法自有资金，资金来源合法合规，不存在任何纠纷或潜在纠纷；2、本公司与明弘毅、通域合盈及其实际控制人李明、上市公司、北京通域众合科技发展中心（有限合伙）、北京通域高精尖股权投资中心（有限合伙）之间均不存在除借款协议之外的其他安排，不存在对外募集、代持、结构化安排等情形。”

综上，本次认购资金不存在短缺的风险，各借款主体不存在除借款协议之外的其他安排，不存在对外募集、代持、结构化安排。

（二）本次认购资金借款是否有明确可行的偿债计划；是否存在将发行人股票质押用于本次认购及减持发行人股票用于偿还借款的情形或计划，如有，请说明是否对发行人控制权稳定性产生影响及发行人应对措施

## 1、本次认购资金借款是否有明确可行的偿债计划

发行人 2015 年度非公开发行涉及的前次募集资金存在用于补充流动资金的比例超过30%的情形，在本次向特定对象发行股票中将根据前次募集资金超额补流金额调减本次募集资金的金额。公司前次募集资金不属于董事会提前确认发行对象的非公开发行，根据《证券期货法律适用意见第 18 号》第五条规定用于补充流动资金和偿还债务的比例不得超过募集资金总额的 30%。上述超额补流金额超过30%的部分应当于本次募集资金的总金额中调减，公司前次募集资金补充流动资金金额为127,138.48 万元（含利息），占实际募集资金总额比例为90.58%，超过实际募集资金总额的 30%，超出部分的金额 85,031.16 万元应于本次募集资金总额中扣减。

本次向特定对象发行募集资金总额不超过人民币185,842.57 万元（含本数）,其中明弘毅的认购金额不超过 55,752.77 万元，通域合盈的认购金额不超过130,089.80 万元。本次预计在前次募集资金超额补流扣减后实际募集资金总额不超过人民币 100,811.41 万元，其中明弘毅的认购金额不超过 30,243.42 万元，通域合盈的认购金额不超过70,567.99 万元。

假定公司于 2026 年6月完成本次发行，综合考虑明弘毅和通域合盈认购本次发行而新增的借款，明弘毅和通域合盈合计需要偿还本金和利息共计约124,481.80 万元。

实际控制人控制的企业明弘毅和通域合盈未来的偿还资金来源包括：实际控制人李明从发行人获取的薪酬及自有资金、明弘毅和通域合盈获取的现金分红、通域合盈进行私募基金管理收取的管理费及收益提成、其他合法自筹资金及减持发行人股份等。

经测算，发行对象具备认购本次发行股份的资金偿还能力，具体如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2027年6月</td><td colspan="1" rowspan="1">2028年6月</td><td colspan="1" rowspan="1">2029年6月</td><td colspan="1" rowspan="1">2029年12月</td><td colspan="1" rowspan="1">2030年6月</td></tr><tr><td colspan="2" rowspan="1"></td><td colspan="2" rowspan="1">还款资金安排</td><td colspan="2" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">归还金融机构质押融资本金</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">50,000.00</td></tr><tr><td colspan="1" rowspan="1">归还金融机构质押融资利息</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">3,250.00</td></tr><tr><td colspan="1" rowspan="1">归还其他第三方借款本息</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">61,481.80</td><td colspan="1" rowspan="1">■</td></tr><tr><td colspan="1" rowspan="1">当期需还款金额合计</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">61,481.80</td><td colspan="1" rowspan="1">53,250.00</td></tr><tr><td colspan="6" rowspan="1">还款来源测算</td></tr><tr><td colspan="1" rowspan="1">李明薪资及自有资金</td><td colspan="1" rowspan="1">659.13</td><td colspan="1" rowspan="1">439.42</td><td colspan="1" rowspan="1">439.42</td><td colspan="1" rowspan="1">219.71</td><td colspan="1" rowspan="1">219.71</td></tr><tr><td colspan="1" rowspan="1">通域合盈及明弘毅预计分红金额</td><td colspan="1" rowspan="1">270.57</td><td colspan="1" rowspan="1">300.74</td><td colspan="1" rowspan="1">325.72</td><td colspan="1" rowspan="1">167.46</td><td colspan="1" rowspan="1">180.37</td></tr><tr><td colspan="1" rowspan="1">通域合盈收取的管理费</td><td colspan="1" rowspan="1">2,567.97</td><td colspan="1" rowspan="1">2,145.31</td><td colspan="1" rowspan="1">2,145.31</td><td colspan="1" rowspan="1">1,072.66</td><td colspan="1" rowspan="1">1,072.66</td></tr><tr><td colspan="1" rowspan="1">合规减持部分通域基金股份，通域合盈收取的收益提成</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">116.86</td><td colspan="1" rowspan="1">339.55</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">合规减持本次通域合盈及明弘毅认购股份所得资金</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">60,021.98</td><td colspan="1" rowspan="1">51,777.26</td></tr><tr><td colspan="1" rowspan="1">前期盈余资金</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">247.66</td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">=</td></tr><tr><td colspan="1" rowspan="1">还款来源合计金额</td><td colspan="1" rowspan="1">3,497.66</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">3,250.00</td><td colspan="1" rowspan="1">61,481.80</td><td colspan="1" rowspan="1">53,250.00</td></tr><tr><td colspan="1" rowspan="1">还款来源是否足以覆盖当期还款金额</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">是</td><td colspan="1" rowspan="1">是</td></tr></table>

注 1：向金融机构质押贷款按照固定年息定期付息，到期一次性还本方式测算还款；向其他第三方借款按照到期一次性还本付息方式测算还款；  
注 2：2027 年 6 月李明薪资及自有资金、通域合盈收取的管理费金额系 2026 年全年及 2027年 1-6 月数据的汇总；2027 年 6 月通域合盈及明弘毅分红金额系 2026 年 6 月发行完成后至2027 年 6 月的预计分红金额；  
注 3：2028 年 6 月前期盈余资金系 2027 年 6 月还款来源合计金额减去 2027 年 6 月当期需还款金额合计。

（1）李明从发行人处取得的薪酬及自有资金：实际控制人李明 2023 年度-2025 年度领取的薪酬平均为 439.42 万元。假设 2026 年至 2030 年 6 月，李明从公司领取的薪酬保持同等水平，则实际控制人李明合计将从公司领取薪酬1,977.39 万元；

（2）从发行人处取得的分红：按照 2023 年度-2025 年度的现金分红情况，结合合理预估未来营业收入和归属于母公司所有者的净利润的情况，预计 2026年-2030 年公司现金分红金额合计为 11,098.42 万元。根据本次发行完成后通域合盈和明弘毅的持股比例，预计 2026 年6 月完成本次发行后至2030 年6月，通域合盈和明弘毅预计将从公司取得分红1,244.87 万元；

（3）通域合盈进行私募基金管理收取的管理费及收益提成：1）通域合盈

2025 年收取的通域基金管理费为 845.31 万元；海南博芯股权投资基金合伙企业（有限合伙）预计将于 2026 年 7月进入投资运作阶段，通域合盈作为管理人，预计管理费收入 1,300.00 万元/年，则 2026 年至 2030 年 6 月，通域合盈合计收取的基金管理费为 9,003.90 万元；2）通域基金目前持有探路者 7.80%的股权，通域众合持有探路者5.85%的股份，如未来通过减持探路者股份实现退出，通域合盈作为管理人，将按20%的比例提取相应的收益提成。为满足2028 年6月和2029 年 6 月的还款需求，预计 2028 年和 2029 年将需通过减持通域基金持有的公司股份分别获取 116.86 万元和 339.55 万元。假设以2026 年 4月探路者收盘价均价15.01 元/股作为减持价格进行测算，通域基金预计将于2028 年6月和2029年 6 月分别减持发行人 315.65 万股和 1,290.21 万股；

（4）其他合法自筹资金：在上述质押借款到期前，发行对象还可以通过办理展期或滚动质押延长还款期限，或者通过其他方式合法自筹资金偿还股票融资本息；

（5）减持发行人股份：除上述还款资金外，必要时发行对象可以通过减持部分本次认购股份进行还款。假设以 2026 年 4月探路者收盘价均价 15.01 元/股作为减持价格进行测算，通域合盈和明弘毅预计将在股份锁定期满后减持发行人7,447.37 万股，可得到资金 111,799.24 万元。

在通域基金对发行人股份、以及通域合盈或明弘毅对本次发行后股份进行减持后，作为发行人实际控制人的李明仍控制约16.95%的股份，上述减持行为不会对其控制权的稳定性构成影响。

综上，本次认购资金借款有明确可行的偿债计划，本次发行方案不存在无法实施的风险。

2、是否存在将发行人股票质押用于本次认购及减持发行人股票用于偿还借款的情形或计划，如有，请说明是否对发行人控制权稳定性产生影响及发行人应对措施

本次认购资金存在将发行人股票质押用于本次认购的情形或计划，通域合盈预计将以本次发行后其持有的全部探路者股票进行质押担保，从天津信托有限责任公司贷款不超过 5 亿元用于通域合盈认购本次发行股份。按照扣减后的实际募集资金金额和股份数计算，本次发行完成后，通域合盈质押的股份数占实际控制人李明间接控制的股份数的比例为 38.03%，未超过 50%，不属于高比例质押，不存在因质押平仓导致股权变动或控制权不稳定的风险。

发行对象未来的偿还借款资金来源在必要时包括减持发行人股票用于偿还借款的情形。具体减持情况详见本题“三、（二）1、本次认购资金借款是否有明确可行的偿债计划”之回复。减持后李明仍然控制约 16.95%的股份，高于目前李明控制的股权比例13.68%，不影响其控制权的稳定性。

按照扣减后的实际募集资金金额和股份数计算，本次发行完成后，公司实际控制人股权控制比例将从 13.68%增至25.76%，且发行对象偿还借款的方式还包括实际控制人李明从发行人获取的薪酬及自有资金、明弘毅和通域合盈获取的现金分红、通域合盈进行私募基金管理收取的管理费及收益提成、其他合法自筹资金等情形。因此通过本次向特定对象发行股票，实际控制人将进一步增强控制权的稳定性。

综上，发行对象存在将发行人股票质押用于本次认购的情形，质押股份占实际控制人控制的股份数的比例未超过50%，不属于高比例质押，不存在因质押平仓导致股权变动或控制权不稳定的风险，不会对发行人控制权稳定性产生影响；发行对象未来的偿还借款资金来源包括减持发行人股票用于偿还借款的情形，减持后李明仍然控制约 16.95%的股份，高于目前李明控制的股权比例 13.68%，不影响其控制权的稳定性。本次发行完成后实际控制人持股比例将进一步增加，实际控制人将进一步增强控制权的稳定性。

四、结合发行人目前股权结构、董事会席位等说明控股股东及实际控制人的认定是否合理，发行人控制权是否稳定。

## （一）发行人股权结构情况

截至2026 年3月31 日，发行人前十大股东情况如下：

<table><tr><td colspan="1" rowspan="1">股东名称</td><td colspan="1" rowspan="1">股东性质</td><td colspan="1" rowspan="1">持股数量(股)</td><td colspan="1" rowspan="1">持股比例</td><td colspan="1" rowspan="1">其中有限售条件的股份数量</td></tr><tr><td colspan="1" rowspan="1">北京通域合盈投资管理有限公司一北京通域高精尖股权投资中心（有限合伙）</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">68,921,672</td><td colspan="1" rowspan="1">7.80%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">北京通域众合科技发展中心（有限合伙）</td><td colspan="1" rowspan="1">境内非国有法人</td><td colspan="1" rowspan="1">51,691,257</td><td colspan="1" rowspan="1">5.85%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">盛发强</td><td colspan="1" rowspan="1">境内自然人</td><td colspan="1" rowspan="1">47,963,237</td><td colspan="1" rowspan="1">5.43%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">王静</td><td colspan="1" rowspan="1">境内自然人</td><td colspan="1" rowspan="1">39,465,369</td><td colspan="1" rowspan="1">4.47%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">上海芯奉企业管理合伙企业（有限合伙）</td><td colspan="1" rowspan="1">境内非国有法人</td><td colspan="1" rowspan="1">22,284,566</td><td colspan="1" rowspan="1">2.52%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">华泰金融控股（香港）有限公司一客户资金</td><td colspan="1" rowspan="1">境外法人</td><td colspan="1" rowspan="1">13,785,900</td><td colspan="1" rowspan="1">1.56%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">香港中央结算有限公司</td><td colspan="1" rowspan="1">境外法人</td><td colspan="1" rowspan="1">11,097,188</td><td colspan="1" rowspan="1">1.26%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">中信证券资产管理（香港）有限公司一客户资金</td><td colspan="1" rowspan="1">境外法人</td><td colspan="1" rowspan="1">10,729,127</td><td colspan="1" rowspan="1">1.21%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">国都创业投资有限责任公司－国都鼎源1号私募股权投资基金</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">10,000,700</td><td colspan="1" rowspan="1">1.13%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="1" rowspan="1">蔡垂明</td><td colspan="1" rowspan="1">境内自然人</td><td colspan="1" rowspan="1">8,500,000</td><td colspan="1" rowspan="1">0.96%</td><td colspan="1" rowspan="1">0</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">284,439,016</td><td colspan="1" rowspan="1"> 32.19%</td><td colspan="1" rowspan="1">1</td></tr></table>

截至 2026 年 3 月 31 日，发行人总股本为 883,702,186 股。通域众合直接持有公司 51,691,257 股股份，占公司本次发行前总股本的5.85%；通域基金直接持有公司 68,921,672 股股份，占公司本次发行前总股本的7.80%，根据通域基金与通域众合签署的《表决权委托协议》，通域基金将其所持股份对应的表决权委托给通域众合；百益钎顺直接持有公司275,424 股股份，占公司本次发行前总股本的 0.03%，根据通域众合与百益钎顺签署的《一致行动协议》，百益钎顺将其所持股份对应的表决权委托给通域众合，通域众合合计控制公司股份数为120,888,353 股，占公司股份总数的13.68%，为公司控股股东。

李明直接持有通域合盈60%的股权，通域合盈系公司控股股东通域众合的执行事务合伙人，李明通过控制通域众合从而间接控制公司 120,888,353 股股份，占公司股份总数的 13.68%，为公司实际控制人。其具体控制关系如下图：

![](images/23453be376fa43cdfcdc8009406893776178bb1adedd62e4f31dddbf489fc166.jpg)

公司控股股东及实际控制人控制的公司股份比例为 13.68%，公司第三大股东盛发强持股比例为 5.43%，公司第四大股东王静持股比例为 4.47%，公司股东盛发强、王静不存在一致行动关系，且根据公司股东盛发强、王静于 2021 年 1月 26 日出具的承诺函，公司股东盛发强、王静均已承诺不会单独或与未经通域众合同意的其他第三方共同谋求发行人的实际控制权。除上述股东外，公司前十大股东中其他股东持股比例均未超过 5%，且持股分散。公司控股股东及实际控制人可主导发行人股东会决策，表决权支配地位清晰且稳固。

本次发行完成后，实际控制人所控制的公司股份比例将进一步增加，有利于维护实际控制人的控制地位及控制权稳定。

## （二）发行人董事会席位情况

公司董事会由7名董事组成，其中非独立董事4名、独立董事3名。非独立董事包括：李明（董事长）、毛志苗、董嘉鹏、宋扬（职工董事）。李明同时担任公司董事长，并担任战略委员会主任委员，对公司的经营方针和重大决策具有实质性影响力。

报告期内，从7名董事候选人来源构成看：在 2021 年 2月提交发行人股东大会审议的第五届董事会董事候选人中，控股股东通域众合提名了李明、高伟、何华杰三位非独立董事候选人以及高子程、李东红、王玥三位独立董事候选人并经发行人股东大会顺利审议通过；在2025 年 3 月提交发行人股东大会审议的第六届董事会董事候选人中，第五届董事会提名了由控股股东通域众合推荐的李明、毛志苗两位非独立董事候选人以及柳迪、朱克实、李东红三位独立董事候选人并经发行人股东大会顺利审议通过。上述两届董事会多数董事候选人均由控股股东推荐或直接提名产生，控股股东能够主导董事会决策，控股股东对董事会具有实际控制力。

公司总裁及董事会秘书人选均由李明董事长提名产生，公司副总裁及财务总监人选均由总裁何华杰提名产生，进一步巩固了实际控制人李明在公司经营层面的控制权。

综上，公司控股股东及实际控制人可主导发行人股东会决策，表决权支配地位清晰且稳固；控股股东能够主导董事会决策，控股股东对董事会具有实际控制力；实际控制人李明通过提名总裁、董事会秘书人选，并间接通过其所提名后聘任的总裁提名副总裁、财务总监等人选巩固了其在公司经营层面的控制权。发行人的控股股东及实际控制人认定合理，发行人的控制权稳定。

五、李明及其控制的主体在本次定价基准日前六个月是否存在减持其所持发行人股份的情形，是否已根据《上市公司收购管理办法》出具相关期限内不减持的承诺。

李明未直接持有公司股份，李明所控制的主体中仅通域众合、通域基金分别持有公司 5.85%、7.80%的股份，通域众合、通域基金在本次定价基准日前六个月均不存在减持发行人股份的情况。

根据《上市公司收购管理办法》第六十三条规定：“有下列情形之一的，投资者可以免于发出要约：……（三）经上市公司股东会非关联股东批准，投资者取得上市公司向其发行的新股，导致其在该公司拥有权益的股份超过该公司已发行股份的30%，投资者承诺3年内不转让本次向其发行的新股，且公司股东会同意投资者免于发出要约。”

本次发行对象明弘毅及通域合盈已承诺其认购的本次向特定对象发行的股份自发行结束之日起 36 个月内不转让。明弘毅及通域合盈已根据《上市公司收购管理办法》出具《关于特定期间不存在减持情况或减持计划的承诺函》。

六、发行人于 2025 年 10 月对本次发行方案进行调整的原因，通过不同主体参与本次发行认购的背景和原因，明弘毅是否专为本次发行而设立，后续对通域合盈和明弘毅持股结构安排及具体计划，是否存在规避锁定期限等相关要求的情形。

（一）发行人于 2025 年 10 月对本次发行方案进行调整的原因，通过不同主体参与本次发行认购的背景和原因

公司于 2025 年 10 月 31 日召开第六届董事会第九次会议，审议通过《关于调整公司2025 年度向特定对象发行股票方案的议案》《关于公司<2025 年度向特定对象发行股票预案（修订稿）>的议案》等议案，本次发行方案调整主要涉及到发行对象由李明及其控制的企业通域合盈变更为李明控制的企业明弘毅和通域合盈，以及因发行对象变更使得定价基准日变化导致的发行价格和募集资金总额的变更。

发行人于2025年10月对本次发行方案进行调整系本次认购主体由李明个人变更为其全资控股的公司明弘毅，认购主体调整的主要原因系：公司作为独立法人实体向金融机构申请贷款时，通常可获得较个人贷款更高的贷款额度、更优惠的利率水平、更长的借款期限以及其他较为有利的融资条件，有利于降低融资成本。

通过通域合盈（李明持股60%，西藏万青投资管理有限公司持股40%）和明弘毅（李明持股100%）两个不同主体参与本次发行认购的原因主要系：（1）实际控制人李明间接控制公司的股权比例为 13.68%，本次发行将直接提升公司实际控制人李明的持股比例，从而巩固其对公司治理、战略方向及日常经营的控制力，不仅优化了股权集中度，增强了控制权的稳定性与决策效率，更向市场传递了控股股东及实际控制人对公司长期价值与发展前景的坚定信心；（2）本次募集资金总额为不超过185,842.57万元（含本数），其中明弘毅认购金额不超过55,752.77万元，通域合盈认购金额不超过 130,089.80 万元。考虑到实际控制人的财务状况和偿债能力，引入通域合盈共同作为认购主体既有利于增强李明的控制力，也能够降低本次发行因认购资金不足导致无法实施的风险。

## （二）明弘毅是否专为本次发行而设立

截至本回复出具日，明弘毅的基本情况如下：

<table><tr><td rowspan=1 colspan=1>企业名称</td><td rowspan=1 colspan=1>北京明弘毅科技服务有限公司</td></tr><tr><td rowspan=1 colspan=1>法定代表人</td><td rowspan=1 colspan=1>李明</td></tr><tr><td rowspan=1 colspan=1>成立日期</td><td rowspan=1 colspan=1>2025年10月29日</td></tr><tr><td rowspan=1 colspan=1>股权结构</td><td rowspan=1 colspan=1>李明持股100%</td></tr><tr><td rowspan=1 colspan=1>注册资本</td><td rowspan=1 colspan=1>1,000.00万元</td></tr><tr><td rowspan=1 colspan=1>统一社会信用代码</td><td rowspan=1 colspan=1>91110115MAG0F5QG8B</td></tr><tr><td rowspan=1 colspan=1>注册地</td><td rowspan=1 colspan=1>北京市大兴区经济开发区科苑路18号3幢一层A1920室</td></tr><tr><td rowspan=1 colspan=1>经营范围</td><td rowspan=1 colspan=1>技术服务、技术开发、技术咨询、技术交流、技术转让、技术推广；软件开发；人工智能理论与算法软件开发；人工智能基础软件开发；企业管理咨询；企业形象策划；市场调查（不含涉外调查）；会议及展览服务；组织文化艺术交流活动；信息咨询服务（不含许可类信息咨询服务）：咨询策划服务：市场营销策划：企业管理：社会经济咨询服务：旅游开发项目策划咨询：游览景区管理：休闲观光活动；园区管理服务。</td></tr></table>

明弘毅为公司实际控制人李明专门为本次发行而设立的持股平台，截至本回复出具日，明弘毅除参与本次发行外，未实际开展业务。

## （三）后续对通域合盈和明弘毅持股结构安排及具体计划，是否存在规避锁定期限等相关要求的情形

李明就后续对通域合盈和明弘毅持股结构安排及具体计划出具承诺：“自本次发行完成之日起的 36 个月内，本人不会通过转让、增资等方式直接或间接向第三方转让通域合盈和明弘毅的权益；本人将保持通域合盈和明弘毅控制权的稳定性，不会通过直接或间接改变通域合盈和明弘毅的股权结构以规避本次向特定对象发行股票相关锁定期限承诺；暂无改变通域合盈和明弘毅股权结构的计划或安排；不存在委托他人管理本人持有通域合盈和明弘毅股权的情形；不存在通过通域合盈和明弘毅给关联方或利益相关方进行股份代持、结构化安排等情形。上述锁定期届满后拟改变通域合盈和明弘毅股权结构的，本人将严格遵守法律、法规及规范性文件的规定。”

根据《上市公司证券发行注册管理办法》第五十七条规定，“向特定对象发行股票的定价基准日为发行期首日。上市公司应当以不低于发行底价的价格发行股票。上市公司董事会决议提前确定全部发行对象，且发行对象属于下列情形之一的，定价基准日可以为关于本次发行股票的董事会决议公告日、股东大会决议公告日或者发行期首日：（一）上市公司的控股股东、实际控制人或者其控制的关联人；（二）通过认购本次发行的股票取得上市公司实际控制权的投资者；（三）董事会拟引入的境内外战略投资者。”《上市公司证券发行注册管理办法》第五十九条规定,“向特定对象发行的股票，自发行结束之日起六个月内不得转让。发行对象属于本办法第五十七条第二款规定情形的，其认购的股票自发行结束之日起十八个月内不得转让。”

根据《上市公司收购管理办法》第六十三条规定：“有下列情形之一的，投资者可以免于发出要约：……（三）经上市公司股东会非关联股东批准，投资者取得上市公司向其发行的新股，导致其在该公司拥有权益的股份超过该公司已发行股份的30%，投资者承诺3年内不转让本次向其发行的新股，且公司股东会同意投资者免于发出要约。”

本次发行对象明弘毅及通域合盈已出具《关于特定期间不存在减持情况或减持计划的承诺函》，承诺其认购的本次向特定对象发行的股份自发行结束之日起36 个月内不转让。

综上，发行对象不存在规避锁定期限等相关要求的情形。

七、发行人变更前次募集资金用途用于永久补充流动资金的具体情况，是否符合《证券期货法律适用意见第 18 号》第五条的相关规定。

## （一）发行人变更前次募集资金用途用于永久补充流动资金的具体情况

## 1、前次非公开发行募集资金到位及验资情况

经中国证券监督管理委员会证监许可[2016]530 号文《关于核准探路者控股集团股份有限公司非公开发行股票的批复》核准，公司于 2016 年5月实施非公开发行股票方案，向5名特定对象发行了人民币普通股8,000 万股，每股面值人民币1.00 元，发行价格为人民币15.88 元/股，计划募资128,323.00 万元、实际募资 127,040.00 万元，扣除保荐承销费用及其他发行费用共计1,374.34 万元后，募集资金净额为 125,665.66 万元，上述款项已于2016 年5 月16 日全部到位，并存入相应募集资金专用账户，2022 年度完成全部募集资金的使用。瑞华会计师事务所（特殊普通合伙）已于2016 年5月16 日对公司本次非公开发行股票的资金到位情况进行了审验，并出具瑞华验字[2016]01970005 号《探路者控股集团股份有限公司验资报告》。

## 2、募集资金使用情况及当前余额

公司非公开发行股票募集资金累计已使用140,357.75 万元，其中探路者云项目累计投入 12,019.97 万元，DISCOVERYEXPEDITION 品牌营销网络建设项目投入 1,197.79 万元，补充流动资金项目投入127,138.48 万元，募集资金理财时缴纳的电子回单柜年费或转账手续费1.51 万元；累计利息收入和理财收益14,692.07 万元，尚未使用募集资金为0 万元（含利息收入及理财收益），期末募集资金账户余额为0万元，募集资金账户均已注销，募集资金全部使用完毕。

公司前次募集资金的实际投入情况与计划投入情况存在较大差异，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>募投项目名称</td><td rowspan=1 colspan=1>募集资金承诺投资金额</td><td rowspan=1 colspan=1>募集资金实际投资金额</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>探路者云项目</td><td rowspan=1 colspan=1>51,726.28</td><td rowspan=1 colspan=1>12,019.97</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>绿野户外旅行O20项目</td><td rowspan=1 colspan=1>19,978.60</td><td rowspan=1 colspan=1>0.19</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>户外用品垂直电商项目</td><td rowspan=1 colspan=1>18,772.00</td><td rowspan=1 colspan=1>0.16</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>户外安全保障服务平台项目</td><td rowspan=1 colspan=1>17,846.41</td><td rowspan=1 colspan=1>0.69</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>补充流动资金项目</td><td rowspan=1 colspan=1>20,000.00</td><td rowspan=1 colspan=1>127,138.48</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>DISCOVERYEXPEDITION 品牌营销网络建设项目</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1,197.79</td></tr><tr><td rowspan=1 colspan=2>总计</td><td rowspan=1 colspan=1>128,323.29</td><td rowspan=1 colspan=1>140,357.75</td></tr></table>

注 1：DISCOVERYEXPEDITION 品牌营销网络建设项目系公司变更募集资金所投资的新项目；  
注 2：募集资金实际投入金额包含募集资金历年的利息收入及理财收益等。

## 3、公司前次募集资金投资项目的资金用途变更已履行如下批准程序：

（1）经2018 年4月23 日召开的公司第四届董事会第三次会议和第四届监事会第二次会议以及 2018 年 6 月 7 日召开的2017 年度股东大会审议通过，公司终止了“绿野户外旅行O2O 项目”、“户外用品垂直电商项目”、“户外安全保障服务平台项目”三个项目。

（2）经2018 年9月12 日召开的第四届董事会第七次会议和第四届监事会第四次会议以及2018年9月28日召开的2018年第四次临时股东大会审议通过，变更部分募集资金25,000万元至新项目“DISCOVERY EXPEDITION品牌营销网络建设项目”中。

（3）经2019 年4月24 日召开的第四届董事会第十三次会议和第四届监事会第八次会议及2019 年5 月29 日召开的2018 年度股东大会审议通过，缩减“探路者云项目”投资规模至 11,882.19 万元，其节余募集资金39,844.09 万元以及募集资金的利息及现金管理收益 1,443.63 万元（合计41,287.72 万元）用于永久性补充流动资金，同时结合目前该项目的实际进展情况，将“探路者云项目”的预计可使用状态日期延至2021 年6月30 日。

（4）经2020 年3月18 日召开的第四届董事会第二十一次会议和第四届监事会第十三次会议及2020 年4月13 日召开的2019 年度股东大会审议通过，同意延长“DISCOVERY EXPEDITION 品牌营销网络建设项目”的建设期至 2023 年12 月 31 日。

（5）经2021 年4月14 日召开的第五届董事会第二次会议和第五届监事会第二次会议审议通过，同意延长“探路者云项目”的建设期至2022 年12 月31 日。

（6）经2021 年12 月31 日召开的第五届董事会第九次会议和第五届监事会第七次会议及2022 年1月17 日召开的2022 年第一次临时股东大会审议通过，同意公司终止“DISCOVERY EXPEDITION 品牌营销网络建设项目”，并将“DISCOVERY EXPEDITION 品牌营销网络建设项目”的剩余募集资金及尚未明确用途的募集资金全部用于永久性补充流动资金。

综上所述，发行人存在变更前次募集资金用途用于永久补充流动资金的情况，并已履行相关审批程序。

## （二）是否符合《证券期货法律适用意见第 18 号》第五条的相关规定

根据《证券期货法律适用意见第18 号》第五条“（一）通过配股、发行优先股或者董事会确定发行对象的向特定对象发行股票方式募集资金的，可以将募集资金全部用于补充流动资金和偿还债务。通过其他方式募集资金的，用于补充流动资金和偿还债务的比例不得超过募集资金总额的百分之三十。对于具有轻资产、高研发投入特点的企业，补充流动资金和偿还债务超过上述比例的，应当充分论证其合理性，且超过部分原则上应当用于主营业务相关的研发投入。”

公司前次募集资金不属于董事会提前确认发行对象的非公开发行，根据《证券期货法律适用意见第 18 号》规定“用于补充流动资金和偿还债务的比例不得超过募集资金总额的百分之三十。”

公司前次募资补充流动资金金额占募集资金总额比例的具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目名称</td><td rowspan=1 colspan=1>备注</td><td rowspan=1 colspan=1>使用募集资金金额</td></tr><tr><td rowspan=1 colspan=1>前次募集资金补充流动资金承诺金额</td><td rowspan=1 colspan=1>①</td><td rowspan=1 colspan=1>20,000.00</td></tr><tr><td rowspan=1 colspan=1>前次募集资金补流实际金额合计（包含历年的利息收入及理财收益等)</td><td rowspan=1 colspan=1>②</td><td rowspan=1 colspan=1>127,138.48</td></tr><tr><td rowspan=1 colspan=1>前次募集资金总额（实际投资金额，包含历年的利息收入及理财收益等)</td><td rowspan=1 colspan=1>③</td><td rowspan=1 colspan=1>140,357.75</td></tr><tr><td rowspan=1 colspan=1>前次募集资金补流占前次募集资金总额比例</td><td rowspan=1 colspan=1>A=②/③</td><td rowspan=1 colspan=1>90.58%</td></tr><tr><td rowspan=1 colspan=1>前次募集资金补流累计超过《证券期货法律适用意见第18号》规定比例的金额</td><td rowspan=1 colspan=1>B=②-③*30%</td><td rowspan=1 colspan=1>85,031.16</td></tr></table>

综上所述，发行人前次募集资金投资项目补充流动资金的承诺金额为20,000万元，实际用于补充流动资金的金额为 127,138.48 万元，占前次募集资金总额的实际比例为90.58%，存在超过前次募集资金金额 30%的情况，超出部分的金额85,031.16 万元将于本次募集资金总额中扣减。

## 八、核查程序及核查意见

## （一）核查程序

针对上述事项（1），保荐人及申报会计师执行的核查程序如下：

1、查阅发行人报告期内相关财务数据，了解发行人未来三年日常经营积累、最低现金保有量要求、偿还有息负债本金及利息、预留偿还的有息负债、未来重大的资本性支出等；

2、获取发行人财务报表，结合发行人业务规模变动情况、资产负债结构等，分析测算发行人未来三年资金需求缺口及本次补充流动资金的必要性与规模的

合理性；

3、获取了贝特莱和上海通途的审计报告、评估报告等，分析测算未来三年营业收入及资金需求；

4、查阅发行人的公司公告、董事会决议、董事长审批文件、总裁办公会会议决议，了解发行人的投资项目和投资内容。

针对上述事项（2），保荐人及发行人律师执行的核查程序如下：

1、获取并查阅发行人本次发行的预案文件，了解本次发行的具体方案；

2、获取并查阅发行对象明弘毅、通域合盈与发行人签署的《附条件生效的股份认购协议》及发行对象出具的《关于认购股票数量及金额的承诺函》，了解发行对象所承诺的认购股票数量区间及股票认购金额区间的下限。

针对上述事项（3），保荐人、发行人律师及申报会计师执行的核查程序如下：

1、获取并查阅世纪金源投资集团有限公司、王波、任丽必的借款协议，以及天津信托有限责任公司出具的融资要素确认函；

2、获取并查阅自然人任丽必股票账户余额截图和基金投资人资产证明、自然人王波股票账户资产截图、世纪金源投资集团有限公司和天津信托有限责任公司的财务报表，证明借款主体具备相应的借款实力，不存在资金短缺风险；

3、访谈通域合盈及明弘毅实际控制人李明、任丽必、王波、天津信托有限责任公司以及世纪金源投资集团有限公司，获取并查阅任丽必、王波、以及世纪金源投资集团有限公司出具的承诺函，了解相关借款事项、核查是否存在除借款协议外的其他安排，是否存在对外募集、代持、结构化安排等情况；

4、访谈实际控制人李明，了解认购资金借款的偿债计划；

5、获取并查阅公司定期报告、相关方出具的确认函，合理测算未来实际控制人薪酬水平及公司现金分红情况；了解通域合盈收入来源情况，测算未来还款能力；了解股份减持用于还款的情况，测算股份减持比例等；

6、了解是否存在将发行人股票质押用于本次认购及减持发行人股票用于偿还借款的情形，测算本次发行完成后，通域合盈质押的股份数占实际控制人李明间接控制的股份数的比例情况，核查是否存在影响发行人控制权稳定的情形。

针对上述事项（4）（5）（6），保荐人及发行人律师执行的核查程序如下：

1、获取并查阅发行人 2026 年一季度报告、截至2026 年3月31 日的《合并普通账户和融资融券信用账户前 N名明细数据表》，了解发行人前十大股东的持股情况；

2、获取并查阅通域基金与通域众合签署的《表决权委托协议》、通域众合与百益钎顺签署的《一致行动协议》、发行人股权结构图、《关于不谋求控制权的承诺函》、本次发行预案，了解发行人的股份分布情况及控股股东、实际控制人对股东会的控制情况；

3、获取并查阅公司章程规定、公司董事会候选人推荐函、董事会及股东会选举产生董事等会议资料，了解董事会候选人的人选的提名和选举产生情况；

4、获取并查阅公司章程规定、高管提名函，了解实际控制人对管理层的提名及对管理层的控制力；

5、获取并查阅李明出具的董监高调查表、承诺函、检索天眼查《董监高对外投资及任职报告》，了解李明及其控制的主体的范围情况；

6、获取并查阅定价基准日（2025 年11 月1日）往前回溯至2025 年5月1日期间公司《合并普通账户和融资融券信用账户前 N名明细数据表》，了解李明及其控制的主体是否持有公司股份以及通域众合、通域基金在此期间是否存在减持情况；

7、获取并查阅《上市公司收购管理办法》、发行对象明弘毅及通域合盈出具的不减持承诺函，了解明弘毅及通域合盈是否已根据《上市公司收购管理办法》出具不减持承诺；

8、访谈实际控制人李明，了解发行人在 2025 年10 月对本次发行方案进行调整的原因，以及通过不同主体参与本次发行认购的背景和原因，了解明弘毅是否专为本次发行而设立；

9、获取并查阅实际控制人李明出具的关于后续对通域合盈和明弘毅持股结构安排的承诺，以及明弘毅和通域合盈出具的《关于特定期间不存在减持情况或减持计划的承诺函》，核查是否存在规避锁定期限的情形。

针对上述事项（7），保荐人、发行人律师及申报会计师执行的核查程序如下：

1、获取并查阅前次募投项目基本情况及调整、变更的原因及利用节余资金补充流动资金情况，并确认是否已履行相关审议程序；

2、查阅前次募集资金的相关公告、查询相关案例，了解补充流动资金的比例，确定是否符合《证券期货法律适用意见第 18 号》相关规定，并测算所需扣减的前次募集资金补充流动资金比例超过30%部分的具体金额及比例。

（二）核查意见

针对上述事项（1），保荐人及申报会计师认为：

本次募集资金用于补充流动资金具有必要性，本次募集资金用于补充流动资金的金额为 185,842.57 万元，低于发行人流动资金缺口，补充流动资金的规模具有合理性。未来大额资金支出安排已履行相关审议程序，具有必要性。

针对上述事项（2），保荐人及发行人律师认为：

明弘毅、通域合盈已分别作出承诺，承诺本次认购金额下限分别为 30,243.42万元、70,567.99 万元，对应认购股票数量下限分别为 43,143,256 股、100,667,598股，明弘毅、通域合盈已承诺的最低认购数量与拟募集的资金金额相匹配。

针对上述事项（3），保荐人、发行人律师及申报会计师认为：

本次认购资金不存在短缺的风险，各借款主体不存在除借款协议之外的其他安排，不存在对外募集、代持、结构化安排；本次认购资金借款有明确可行的偿债计划；本次认购资金存在将发行人股票质押用于本次认购的情形或计划，按照扣减后的实际募集资金金额和股份数计算，本次发行完成后，通域合盈质押的股份数占实际控制人李明间接控制的股份数的比例为 38.03%，未超过 50%，不属于高比例质押，不存在因质押平仓导致股权变动或控制权不稳定的风险；发行对象未来的偿还借款资金来源包括减持发行人股票用于偿还借款的情形，减持后李明仍然控制约16.95%的股份，高于目前李明控制的股权比例 13.68%，不影响其控制权的稳定性。通过本次向特定对象发行股票，实际控制人将进一步维持控制权的稳定。

针对上述事项（4）（5）（6），保荐人及发行人律师认为：

1、公司控股股东及实际控制人可主导发行人股东会决策，表决权支配地位清晰且稳固；控股股东能够主导董事会决策，控股股东对董事会具有实际控制力；实际控制人李明通过提名总裁、董事会秘书人选，并间接通过其所提名后聘任的总裁提名副总裁、财务总监等人选巩固了其在公司经营层面的控制权。发行人的控股股东及实际控制人认定合理，发行人的控制权稳定；

2、李明未直接持有公司股份，李明所控制的主体中仅通域众合、通域基金分别持有公司 5.85%、7.80%的股份，通域众合、通域基金在本次定价基准日前六个月均不存在减持发行人股份的情况；本次发行对象明弘毅及通域合盈已根据《上市公司收购管理办法》出具相关期限内不减持的承诺；

3、发行人调整发行方案主要涉及到发行对象由李明及其控制的企业通域合盈变更为李明控制的企业明弘毅和通域合盈；通过不同主体参与本次发行认购主要原因系直接提升公司实际控制人李明的持股比例，且考虑到实际控制人的财务状况和偿债能力，引入通域合盈共同作为认购主体也能够降低本次发行因认购资金不足导致无法实施的风险。明弘毅为公司实际控制人李明专门为本次发行而设立的持股平台，明弘毅除参与本次发行外，未实际开展业务。李明就后续对通域合盈和明弘毅持股结构安排及具体计划出具自本次发行完成之日起的 36 个月内，李明不会通过转让、增资等方式直接或间接向第三方转让通域合盈和明弘毅的权益的承诺；发行对象不存在规避锁定期限等相关要求的情形。

针对上述事项（7），保荐人、发行人律师及申报会计师认为：

1、发行人存在变更前次募集资金用途用于永久补充流动资金的情况，并已履行相关审批程序；

2、发行人前次募集资金投资项目补充流动资金的承诺金额为20,000 万元，实际用于补充流动资金的金额为 127,138.48 万元（含利息及理财收益），占前次募集资金总额的实际比例为 90.58%，存在超过前次募集资金金额 30%的情况，超出部分的金额85,031.16 万元将于本次募集资金总额中扣减。

## 问题2

最近一期，发行人实现营业收入 95,280.45 万元，同比下降 13.98%，归母净利润 3,303.70 万元，同比下降 67.53%，公司业绩下滑受芯片业务汇兑损失的影响较大。报告期内，发行人芯片业务收入金额分别为842.72 万元、13,335.09万元、22,189.82 万元和 17,552.97 万元。报告期内，发行人先后收购及并表北京芯能电子科技有限公司（以下简称北京芯能）、G2 Touch Co.,LTD.、江苏鼎茂半导体有限公司等 3 家芯片公司，其中北京芯能报告期内连续亏损，发行人已对收购北京芯能形成的14,333.21 万元商誉全额计提减值。2025 年11 月，发行人以 32,130 万元的价格收购深圳贝特莱电子科技股份有限公司（以下简称贝特莱）51%股权，以 35,700 万元的价格收购上海通途半导体科技有限公司（以下简称上海通途）51%股权，进一步增加芯片业务布局。报告期末，发行人存货账面价值为 50,242.55 万元，其中库存商品 48,121.02 万元，主要系户外板块的库存商品，库存商品存货跌价准备计提比例为 19.57%。报告期末，发行人应收账款账面余额为 42,447.77 万元，其中按组合计提坏账准备的应收账款余额为 34,366.64万元，坏账计提比例为 10.73%。报告期末，发行人持有参股公司襄阳东证和同探路者体育产业基金合伙企业（有限合伙）（以下简称襄阳合伙）的股权账面价值为3,183.46 万元，持有参股公司苏州荷塘创芯创业投资合伙企业（有限合伙）（以下简称苏州合伙）股权账面价值为 1,500.00 万元，未认定为财务性投资；发行人将华锡影视产业发展（无锡）有限公司（以下简称华锡影视）、北京元纬天浩科技发展有限公司（以下简称北京元纬）、乾境生物技术有限公司（以下简称乾境生物）等3家参股公司认定为财务性投资。

请发行人补充说明：（1）量化说明最近一期业绩大幅下滑的主要影响因素，与同行业公司是否一致，下滑趋势是否具有持续性及发行人的应对措施。（2）报告期内芯片业务收入大幅增长的原因及合理性，报告期内芯片业务的主要客户及回款情况，结合公司芯片业务的发展情况说明该业务增长是否具有可持续性。（3）发行人先后并购多家芯片业务公司的主要原因及考虑，发行人是否具备运营管理芯片业务公司的能力；在并购标的北京芯能持续亏损并全额计提商誉减值、芯片业务汇兑损失拖累公司业绩的情况下，发行人进一步收购贝特莱及上海通途两家芯片业务公司是否合理、谨慎；发行人收购贝特莱及上海通途后新增商誉情况；发行人并购芯片业务公司形成的商誉是否存在大额计提减值风险。（4）结合报告期末库存商品的主要内容、库龄、期后结转情况、是否存在滞销、可变现净值与账面价值对比情况等说明跌价准备计提是否充分，是否存在大额计提减值的风险。

（5）结合按组合计提坏账准备的应收账款的主要客户资信情况、账龄、回款情况、是否逾期等说明相关坏账准备计提是否充分。（6）结合襄阳合伙及苏州合伙的投资范围、已投资标的情况、已投资标的是否均与发行人存在业务协同性、是否存在尚未投资金额及后续投资计划等说明未将以上两家合伙企业认定为财务性投资的合理性；补充华锡影视、北京元纬、乾境生物的认缴及实缴时间、金额、是否存在尚未实缴的金额，如是，说明后续计划，是否构成拟投入的财务性投资；自本次发行相关董事会决议日前六个月起至今，发行人已实施或拟实施的财务性投资（包括类金融投资）情况，是否已从本次募集资金总额中扣除。

请发行人补充披露（1）（3）（4）（5）相关风险。

请保荐人及会计师核查并发表明确意见，并说明针对发行人报告期内收入真实性采取的核查程序、比例及结论。

回复：

一、量化说明最近一期业绩大幅下滑的主要影响因素，与同行业公司是否一致，下滑趋势是否具有持续性及发行人的应对措施

（一）量化说明最近一期业绩大幅下滑的主要影响因素

2025 年1-9月，发行人的主要业绩指标与2024 年同期的对比情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>业绩指标</td><td rowspan=1 colspan=1>2025年1-9月</td><td rowspan=1 colspan=1>2024年1-9月</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>95,280.45</td><td rowspan=1 colspan=1>110,764.24</td><td rowspan=1 colspan=1>-13.98%</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>3,303.70</td><td rowspan=1 colspan=1>10,174.62</td><td rowspan=1 colspan=1>-67.53%</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益后的净利润</td><td rowspan=1 colspan=1>2,693.70</td><td rowspan=1 colspan=1>9,119.85</td><td rowspan=1 colspan=1>-70.46%</td></tr></table>

2025 年 1-9 月，发行人的营业收入为 95,280.45 万元，同比减少 13.98%，归属于上市公司股东的净利润为 3,303.70 万元，同比减少67.53%，归属于上市公司股东的扣除非经常性损益后的净利润为2,693.70 万元，同比减少70.46%。

2025 年度，公司的主要业绩指标与2024 年同期的对比情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>业绩指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>变动金额</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>138,071.31</td><td rowspan=1 colspan=1>159,158.96</td><td rowspan=1 colspan=1>-21,087.65</td><td rowspan=1 colspan=1>-13.25%</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>7,898.80</td><td rowspan=1 colspan=1>10,662.31</td><td rowspan=1 colspan=1>-2,763.51</td><td rowspan=1 colspan=1>-25.92%</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益后的净利润</td><td rowspan=1 colspan=1>-343.06</td><td rowspan=1 colspan=1>8,412.42</td><td rowspan=1 colspan=1>-8,755.48</td><td rowspan=1 colspan=1>-104.08%</td></tr></table>

2025 年度，发行人的营业收入为 138,071.31 万元，同比减少 13.25%，归属于上市公司股东的净利润为 7,898.80 万元，同比减少 25.92%，归属于上市公司股东的扣除非经常性损益后的净利润为-343.06 万元，同比减少104.08%。

2025 年1-9月和2025 年度，发行人营业收入及净利润均较上年同期有所下滑，主要系户外业务受市场环境和新品迭代节奏等因素影响，产品销售不及预期以及汇率波动致使的汇兑损失大幅增加所致。公司主要业绩指标均较上年同期有所下滑，量化分析如下：

## 1、户外业务受市场环境和新品迭代节奏等因素影响，产品销售不及预期，导致发行人整体经营业绩下滑

报告期内，公司营业收入99%以上来源于主营业务收入，2024 年和2025 年公司主营业务收入、毛利率具体情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=3>2025年度</td><td rowspan=1 colspan=3>2024年度</td><td rowspan=2 colspan=1>收入变动比例</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入金额</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入金额</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>户外业务</td><td rowspan=1 colspan=1>47.82%</td><td rowspan=1 colspan=1>114,486.01</td><td rowspan=1 colspan=1>83.45%</td><td rowspan=1 colspan=1>47.53%</td><td rowspan=1 colspan=1>136,380.20</td><td rowspan=1 colspan=1>86.01%</td><td rowspan=1 colspan=1>-16.05%</td></tr><tr><td rowspan=1 colspan=1>芯片业务</td><td rowspan=1 colspan=1>46.81%</td><td rowspan=1 colspan=1>22,701.80</td><td rowspan=1 colspan=1>16.55%</td><td rowspan=1 colspan=1>47.74%</td><td rowspan=1 colspan=1>22,189.82</td><td rowspan=1 colspan=1>13.99%</td><td rowspan=1 colspan=1>2.31%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>47.65%</td><td rowspan=1 colspan=1>137,187.81</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>47.56%</td><td rowspan=1 colspan=1>158,570.02</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>-13.48%</td></tr></table>

由上表所示，主营业务收入由户外业务和芯片业务组成，其中户外业务占比超 80%，为主营业务收入的主要贡献来源。2025 年户外业务收入较上年有所下降，下降幅度为16.05%，致使公司营业收入整体大幅下降。

2024 年和2025 年户外业务之主营业务销量、单价及毛利率对净利润的影响量化分析如下：

单位：万元、万件、元/件

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>主营业务收入</td><td rowspan=1 colspan=1>114,486.01</td><td rowspan=1 colspan=1>136,380.20</td><td rowspan=1 colspan=1>-16.05%</td></tr><tr><td rowspan=1 colspan=1>销量</td><td rowspan=1 colspan=1>637.46</td><td rowspan=1 colspan=1>799.75</td><td rowspan=1 colspan=1>-20.29%</td></tr><tr><td rowspan=1 colspan=1>销售单价</td><td rowspan=1 colspan=1>179.60</td><td rowspan=1 colspan=1>170.53</td><td rowspan=1 colspan=1>5.32%</td></tr><tr><td rowspan=1 colspan=1>主营业务毛利</td><td rowspan=1 colspan=1>54,746.42</td><td rowspan=1 colspan=1>64,825.21</td><td rowspan=1 colspan=1>-15.55%</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>47.82%</td><td rowspan=1 colspan=1>47.53%</td><td rowspan=1 colspan=1>0.29%</td></tr><tr><td rowspan=1 colspan=1>销量变动对净利润的影响（A)</td><td rowspan=1 colspan=3>-13,154.45</td></tr><tr><td rowspan=1 colspan=1>销售单价变动对净利润的影响（B)</td><td rowspan=1 colspan=3>2,747.54</td></tr><tr><td rowspan=1 colspan=1>销售毛利率变动对净利润的影响（C)</td><td rowspan=1 colspan=3>328.11</td></tr><tr><td rowspan=1 colspan=1>对净利润的影响合计数（D=A+B+C)</td><td rowspan=1 colspan=3>-10,078.79</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润变动额(E)</td><td rowspan=1 colspan=3>-2,763.51</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润变动的贡献率(F=D/E)</td><td rowspan=1 colspan=3>364.71%</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益后的净利润变动额（G)</td><td rowspan=1 colspan=3>-8,755.48</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益后的净利润的贡献率 (H=D/G)</td><td rowspan=1 colspan=3>115.11%</td></tr></table>

注 1：销售变动对净利润的影响=销量变动\*上期销售单价\*上期毛利率  
注 2：销售单价变动对净利润的影响=本期销量\*销售单价变动\*上期毛利率  
注 3：销售毛利率变动对净利润的影响=本期销量\*本期销售单价\*毛利率变动  
注 4：户外业务所属公司均为全资控股子公司，故无对少数股东损益的影响额；  
注 5：上表量化分析不考虑企业所得税的影响。

由上表可知，公司最近一期业绩大幅下滑主要系户外业务销量下降所致。户外业务销量下降主要原因系 2025 年随着各类体育品牌、垂直领域品牌进军户外行业，市场红利消退，竞争越发激烈，而探路者在新品迭代中未能构建显著的差异化特征与体验优势，同时公司营销策略偏传统，未能及时适应市场变化、在新兴渠道布局上相对滞后，导致品牌声量与市场响应能力不足，导致 2025 年公司在激烈竞争中应对乏力，户外业务收入显著下滑。具体分析如下：

## （1）户外市场环境竞争激烈

当前户外行业的竞争格局呈现出多元化、专业化与生态化并行的特征。国际知名品牌凭借技术积累与全球化布局主导高端市场，尤其在功能性服饰领域占据显著优势，而公司在品牌知名度、功能性上仍无法与之媲美；本土新兴品牌则依托供应链效率与本土化创新快速崛起，以轻量化装备、场景化消费为突破口，通过电商与社交平台抢占中端及大众市场，持续挤压公司的市场份额。产业链各环节竞争持续升级：上游材料企业加速推进环保科技研发，例如低碳保暖材料、可降解纤维等创新应用；中游制造端向高附加值设计与定制化生产转型；下游渠道端形成“专业零售+内容生态+文旅体验”深度融合的新模式。公司现有的产业链布局未能在激烈的竞争中占据优势。

## （2）户外产品新品迭代节奏较快

当前行业变革驱动的产品迭代速度已显著超越公司内部的产品创新与发布节奏，同时户外产业正从粗放扩张转向垂类细分，消费者不再满足于通用型产品，而是追求深度契合特定场景、承载情感价值并融合前沿科技的解决方案。这迫使企业必须快速度响应快速演变的细分需求，进行高频次、精准化的产品迭代。公司现有体系在趋势洞察、技术整合、敏捷研发与供应链响应等环节未能完全同步升级，导致新品开发周期长、场景适配度不足，导致在激烈的场景化竞争中错失市场先机，致使公司户外业务收入大幅下降。

## （3）品牌知名度不足

品牌知名度的不足以成为制约公司市场扩张与价值提升的关键瓶颈。当前，公司在大众认知广度上缺乏高频、多元的曝光，尤其在年轻客群及新兴社交媒体场域中的声量远逊于国际头部品牌与本土网红品牌；在专业认知深度上，公司虽积淀了一定的技术底蕴与产品功能，却未能通过体系化的品牌叙事将其转化为清晰可感的消费者价值标签，导致“专业”形象长期停留在行业端，未能有效穿透至大众心理。这种“广度缺失”与“深度沉寂”并存的局面，使得公司在激烈的品牌心智竞争中难以建立差异化认知，限制并压缩了公司的市场份额，制约了产品溢价能力的提升。

## 2、芯片业务虽整体向好，但受汇率波动影响，汇兑损失对业绩形成反向拖累，导致 2025 年财务费用大幅增长

2024 年度和 2025 年度公司财务费用-汇兑损益对净利润的影响情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024年度</td><td colspan="1" rowspan="1">变动额</td></tr><tr><td colspan="1" rowspan="1">财务费用-汇兑损益（收益为+)</td><td colspan="1" rowspan="1">-939.93</td><td colspan="1" rowspan="1">3,416.64</td><td colspan="1" rowspan="1">-4,356.57</td></tr><tr><td colspan="1" rowspan="1">对净利润的影响（A）</td><td colspan="3" rowspan="1">-4,356.57</td></tr><tr><td colspan="1" rowspan="1">对少数股东损益的影响（B)</td><td colspan="3" rowspan="1">-213.78</td></tr><tr><td colspan="1" rowspan="1">对归属于上市公司股东的净利润的影响(C=A-B)</td><td colspan="3" rowspan="1">-4,142.79</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净利润变动额(D)</td><td colspan="3" rowspan="1">-2,763.51</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净利润变动的贡献率(E=C/D)</td><td colspan="3" rowspan="1">149.91%</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的扣除非经常性损益后的净利润变动额（F)</td><td colspan="3" rowspan="1">-8,755.48</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的扣除非经常性损益后的净利润的贡献率（G=C/F)</td><td colspan="3" rowspan="1">47.32%</td></tr></table>

注：上表量化分析不考虑企业所得税的影响。

如上表所示，除户外业务业绩下滑外，汇兑损失是净利润下降的另一主要因素。报告期内，公司汇兑损益主要来源于 G2 Touch 业务：其交易主要以美元结算，而报表本位币为韩元，由此形成汇兑损益。2025 年度公司归属于上市公司股东的净利润较上年同期比较情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润A</td><td rowspan=1 colspan=1>7,898.80</td><td rowspan=1 colspan=1>10,662.31</td><td rowspan=1 colspan=1>-25.92%</td></tr><tr><td rowspan=1 colspan=1>其中：芯片业务-归属于上市公司股东的净利润B</td><td rowspan=1 colspan=1>-773.82</td><td rowspan=1 colspan=1>3,203.32</td><td rowspan=1 colspan=1>-124.16%</td></tr><tr><td rowspan=1 colspan=1>汇兑损益C（收益为+)</td><td rowspan=1 colspan=1>-890.05</td><td rowspan=1 colspan=1>3,252.74</td><td rowspan=1 colspan=1>-127.36%</td></tr><tr><td rowspan=1 colspan=1>其中：芯片业务-汇兑损益D（收益为+)</td><td rowspan=1 colspan=1>-890.05</td><td rowspan=1 colspan=1>3,249.92</td><td rowspan=1 colspan=1>-127.39%</td></tr><tr><td rowspan=1 colspan=1>剔除汇兑损益影响的归属于上市公司股东的净利润E=A-C</td><td rowspan=1 colspan=1>8,788.85</td><td rowspan=1 colspan=1>7,409.58</td><td rowspan=1 colspan=1>18.61%</td></tr><tr><td rowspan=1 colspan=1>其中：芯片业务-剔除汇兑损益影响的归属于上市公司股东的净利润F=B-D</td><td rowspan=1 colspan=1>116.23</td><td rowspan=1 colspan=1>-46.60</td><td rowspan=1 colspan=1>349.43%</td></tr></table>

注 1：上表量化分析不考虑企业所得税的影响；  
注 2：上表汇兑损益为归属于上市公司股东的汇兑损益。

由上表可知，2025 年归属于上市公司股东的净利润为 7,898.80 万元，较上年下降 25.92%，其中，2025 年芯片业务-归属于上市公司股东的净利润-773.82万元，较上年下降了 124.16%，主要系公司汇兑损益波动较大所致，剔除汇兑损益影响的归属于上市公司股东的净利润及芯片业务-剔除汇兑损益影响的归属于上市公司股东的净利润均较上年有所增长，增幅分别为18.61%和349.43%。2024年和2025 年公司汇兑损益变动主要系美元兑韩元的汇率波动较大所致，2024 年至2025 年美元兑韩元的汇率波动情况如下：

2024年至2025年USD/KRW汇率波动情况  
![](images/4100cdbeec5ad79d524c7e78aa5a90b93dfd0d0fd3ad85fbbd71d25089bba19b.jpg)  
注：数据来源于中国货币网，根据 USD/CNY 汇率与 CNY/KRW 汇率计算所得。

由上图可知，2024 年度，韩元持续贬值，整体波动较大，公司因持有较高的美元资产获取较高的汇兑收益；2025 年上半年韩元持续升值，下半年转为韩元贬值，全年整体波动较小，故 2025 年公司承担较高的汇兑损失。可见，2024年至2025年公司财务费用-汇兑损益的变动趋势与美元兑韩元汇率波动趋势基本一致。

综上，通过量化分析可知，公司最近一期业绩大幅下滑的主要影响因素系户外业务受市场环境和新品迭代节奏等因素影响，产品销售不及预期以及汇率波动导致的汇兑损失增加所致。

## （二）与同行业公司是否一致

发行人与同行业可比公司最近一期业绩指标对比情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">公司简称</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024年度</td><td colspan="1" rowspan="1">同比变动幅度</td></tr><tr><td colspan="1" rowspan="4">营业收入</td><td colspan="1" rowspan="1">三夫户外</td><td colspan="1" rowspan="1">95,561.87</td><td colspan="1" rowspan="1">80,026.30</td><td colspan="1" rowspan="1">19.41%</td></tr><tr><td colspan="1" rowspan="1">牧高笛</td><td colspan="1" rowspan="1">101,202.71</td><td colspan="1" rowspan="1">130,420.75</td><td colspan="1" rowspan="1">-22.40%</td></tr><tr><td colspan="1" rowspan="1">比音勒芬</td><td colspan="1" rowspan="1">431,391.10</td><td colspan="1" rowspan="1">400,446.33</td><td colspan="1" rowspan="1">7.73%</td></tr><tr><td colspan="3" rowspan="1">平均值</td><td colspan="1" rowspan="1">2.83%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">探路者</td><td colspan="1" rowspan="1">115,077.48</td><td colspan="1" rowspan="1">136,928.12</td><td colspan="1" rowspan="1">-15.96%</td></tr><tr><td colspan="1" rowspan="5">归属于上市公司股东的净利润</td><td colspan="1" rowspan="1">三夫户外</td><td colspan="1" rowspan="1">5,335.12</td><td colspan="1" rowspan="1">-2,149.41</td><td colspan="1" rowspan="1">348.21%</td></tr><tr><td colspan="1" rowspan="1">牧高笛</td><td colspan="1" rowspan="1">-3,418.84</td><td colspan="1" rowspan="1">8,376.16</td><td colspan="1" rowspan="1">-140.82%</td></tr><tr><td colspan="1" rowspan="1">比音勒芬</td><td colspan="1" rowspan="1">55,069.25</td><td colspan="1" rowspan="1">78,069.01</td><td colspan="1" rowspan="1">-29.46%</td></tr><tr><td colspan="1" rowspan="1">平均值</td><td colspan="2" rowspan="1"></td><td colspan="1" rowspan="1">-32.40%</td></tr><tr><td colspan="1" rowspan="1">探路者</td><td colspan="1" rowspan="1">8,672.61</td><td colspan="1" rowspan="1">7,458.99</td><td colspan="1" rowspan="1">16.27%</td></tr><tr><td colspan="1" rowspan="5">归属于上市公司股东的扣除非经常性损益后的净利润</td><td colspan="1" rowspan="1">三夫户外</td><td colspan="1" rowspan="1">4,695.45</td><td colspan="1" rowspan="1">-2,799.93</td><td colspan="1" rowspan="1">267.70%</td></tr><tr><td colspan="1" rowspan="1">牧高笛</td><td colspan="1" rowspan="1">-4,515.30</td><td colspan="1" rowspan="1">5,981.26</td><td colspan="1" rowspan="1">-175.49%</td></tr><tr><td colspan="1" rowspan="1">比音勒芬</td><td colspan="1" rowspan="1">50,020.13</td><td colspan="1" rowspan="1">74,425.24</td><td colspan="1" rowspan="1">-32.79%</td></tr><tr><td colspan="1" rowspan="1">平均值</td><td colspan="2" rowspan="1"></td><td colspan="1" rowspan="1">-35.31%</td></tr><tr><td colspan="1" rowspan="1">探路者</td><td colspan="1" rowspan="1">575.39</td><td colspan="1" rowspan="1">5,359.67</td><td colspan="1" rowspan="1">-89.26%</td></tr></table>

注：数据来源于同行业可比公司年度报告，公司数据为 2025 年度公司户外业务数据。

2025 年度，公司户外业务营业收入同比下降15.96%，变动幅度位于同行业可比公司区间内，与牧高笛变动趋势基本保持一致，主要系市场环境和新品迭代节奏等因素影响，产品销售不及预期；同期三夫户外和比音勒芬营业收入实现同比增长，主要系：三夫户外通过专业功能户外运动用品的自主研发和代理运营，围绕 X-BIONIC、HOUDINI、CRISPI 等品牌线，加强线上线下双线渠道等多元推广策略，提升品牌知名度与产品信赖度，使得 2025 年营业收入较上年同期有所增长。比音勒芬聚焦于高尔夫运动与时尚休闲服饰领域，针对中高端消费群体进行差异化产品布局与精准营销。该公司以直营渠道为主导，产品定位清晰且客群相对稳定故受市场环境及新品迭代影响较小，营业收入保持增长趋势。根据牧高笛定期报告，其业绩下滑的主要原因是“业务受市场环境影响、新品迭代节奏等原因，销售不及预期，同时销售结构调整导致利润下降”，与发行人业绩变化情况和原因基本一致。

2025 年度公司户外业务归属于上市公司股东的扣除非经常性损益后的净利润同比分别下降89.26%，下降趋势与牧高笛、比音勒芬保持一致，但降幅不同。2025 年度，三夫户外除营业收入增长外，当期该公司收到的政府补助、确认的对外投资收益及资产处置收益等均同比增长，同时资产减值损失同比下降，从而带动该公司归属于上市公司股东的净利润和扣非净利润进一步提升。2025 年度，比音勒芬归属于上市公司股东的净利润和扣非净利润较上年同期有所下降同比下降主要受以下两方面因素影响：一方面比音勒芬以直营渠道为主，2025 年度通过拓展实体门店网络、加强线下渠道运营，并加速布局线上销售平台，使得该公司销售费用有所增加，另一方面受定期存款利息收入减少的影响，财务费用较上年同期有所增加。

综上，发行人 2025 年度主要业绩指标下降与同行业可比公司牧高笛基本保持一致，且降幅高于三夫户外和比音勒芬，主要系各公司商业模式、产品定位及渠道布局情况不同所致，符合行业特征，具备合理性。

## （三）下滑趋势是否具有持续性及发行人的应对措施

## 1、发行人的应对措施

（1）针对公司户外业务收入下降的情况，公司将采取以下措施：

1）产品策略：持续研发新品，加快新品迭代速度，提升“四季品类”产品销售，强旺季、补淡季

公司持续强化版型、材料、工艺等硬核能力，融合自主创新与外部产学研优势，精准把握趋势，不断推出符合品牌定位、满足功能场景需求的高性价比户外产品，加快新品迭代速度，持续提升核心竞争力。

公司户外业务受季节性影响显著，导致全年销售不均、资源利用率低，且在淡季面临市场声量沉寂、客户流失的风险。2026 年公司将重点发力“四季品类”（鞋类与裤装）的产品销售，聚焦其在各类户外场景（如春季徒步、夏季城市户外、秋季露营、冬季轻运动）中的跨季应用价值，并通过全渠道内容体系持续输出产品适配不同场景的功能故事与体验叙事。该策略旨在维持品牌全年市场声量，强化“专业、全季可用”的户外伙伴形象，不仅有助于提升存量客户的忠诚度与复购频次，也将有效拓展泛户外人群，为公司构建更可持续的业绩增长基础。

2）渠道策略：优化实体网络，开拓即时渠道，深耕本地生活，构建可持续发展能力

2026 年，渠道策略将聚焦以下三方面系统推进：

第一，优化实体网络结构，提升高线城市能见度与效率。当前，公司在一至三线城市的非街铺渠道（主要为购物中心与奥特莱斯）入驻率仍处于较低水平，存在显著提升空间。资源将向购物中心和奥特莱斯倾斜，确保线下渠道拓展质量；对现有商场店分类评估、择优汰劣；同时对有保留价值的门店进行全方位形象升级，以提升单店零售业绩。

第二，深耕本地生活平台，打造线下增量引擎。如今，抖音本地生活业务正蓬勃发展，已经吸引了众多国内外知名品牌的加入，如ADIDAS、李宁、安踏等运动巨头。公司自 2025 年 10 月启动的抖音本地生活业务已显现强劲增长动力，当年10 月及11 月均已通过达人探店实现销售业绩，单店平均业绩突出。目前该业务已进入系统化推进阶段，运营上将构建“职人店播+分级账号矩阵”的差异化销售体系，通过遵循“试点、复制、全面推广”的路径持续扩大门店覆盖与运营深度。通过拉近与消费者的距离，更精准地触达目标客户，推动销售增长。

第三，全面开拓即时零售渠道，构建履约闭环。在当今快节奏的消费环境中，配送时效是影响消费者购物体验的关键因素。快速配送能满足消费者即时性需求，提升满意度与忠诚度，同时可增强公司在市场中的竞争力，吸引潜在客户。NIKE、ADIDAS等大品牌纷纷加入了即时零售渠道，抢占该渠道资源。公司计划自2026年1月起，全面接入京东秒送、美团闪购、淘宝闪送等即时零售平台，将门店库存在线化，提供小时级配送服务；同时在抖音、小红书、大众点评等平台规模化开通 POI 门店（即通过在数字地图或社交媒体平台上通过 POI 功能创建的线上门店标记，用于展示位置信息、商品服务及引流到店消费）或分享探店笔记，实现从线上内容种草至到店核销或即时配送的全链路闭环。

通过上述举措，公司将系统构建一个无缝衔接、即时响应、深度渗透的立体渠道网络，不仅能够满足消费者全场景、即时性的需求，提升其满意度与忠诚度，也将显著增强品牌的市场竞争力与渠道健康度，为可持续增长奠定基础。

3）营销策略：整合节庆、种草、会员与电商营销，提升品牌知名、美誉与 业绩

①节庆营销-聚焦节点，引爆销售高峰

2026 年，公司将聚焦五一、十一、年货节等核心节点，持续注入营销资源：

首先，通过抖音本地生活持续内容引流，通过营销费用投入、团购博主探店及商品组合优化，为品牌和门店积累常态化流量与口碑；第二，通过全渠道热销产品引流，实现销售增长；第三，通过品牌活动引流，如签约流量明星、合作超头部KOL、举办赛事及快闪活动，持续创造高话题度，为节庆销售增长提供支撑，最终形成贯穿全年、品效合一的营销节奏。

②种草营销-全域渗透，构建用户信任

当前，公司种草营销较为薄弱，2026 年，公司将加强推广种草营销策略：第一、通过整合运动员、赛事平台的专业背书，联动流量明星制造大众话题，并依托超头部 KOL（即关键意见领袖）共创深度产品内容，打造多层次种草资源矩阵，系统布局品牌影响力；第二，通过以店铺企微矩阵沉淀私域用户，培养店铺KOS（关键意见销售）产出真实口碑，常态化开展店铺直播，实现即看即买，构建立体化渠道内容体系，强化终端转化能力；第三，通过集中资源深耕抖音、小红书等内容生态，持续产出“专业评测”与“生活方式”相互交织的多元化内容，打造产品热点与消费场景，实现从认知到购买的完整转化路径，通过聚焦核心社交平台进行饱和式种草，精准渗透目标圈层。

③会员营销-深度运营，提升客户终身价值

当前，公司会员销售贡献占比和复购率较低，2026 年公司将“拉新与复购”为核心进行会员营销。2026 年，公司将全年策划多场会员专属活动（如徒步分享会、越野跑训练营），与消费者高频互动强化品牌连接与用户粘性。同时，公司将聚焦会员高配合度的城市，深度融合会员权益与线下体验，在提升会员对品牌认同度，并可直接驱动销售转化。线下店铺层面，公司将系统性赋能终端店铺，大幅提升企业微信等私域内容的质量与运营精细化程度，通过持续、优质的互动激活会员价值，最终构建一个从引流、深度互动到高效复购的完整闭环，为业绩稳健增长提供核心支撑。

④电商营销-节奏布局，实现品效持续增长

公司电商营销主要围绕“爆款打造与平台IP 联动”核心，全方位布局2026年下半年电商营销节奏，以达成声量与销量的双高增长。公司将依据销售周期科学规划种草投放，确保核心热销产品在各平台持续曝光，夯实日常销售基础。通过联动明星资源、举办品牌走秀、冠名或植入重要赛事等高端活动，提升全平台关注。上述举措不仅能极大提升品牌声量，其产生的流量也将反哺至电商渠道及线下门店，实现跨渠道销售增长，保障全年业绩稳健增长。

（2）针对汇率波动导致的汇兑损失大幅增加的情况，公司将采取以下措施：

1）公司财务部门实时跟踪外汇波动情况，以最大程度降低汇率波动风险。此外，为防范汇率大幅波动的风险，公司持续加强对汇率的研究分析，密切关注国际市场环境变化，预测汇率波动趋势，适时调整经营策略，并快速制定应对措施，以最大限度减少汇兑损失。

2）在持续加大研发投入、不断提升技术水平与产品竞争力以增强销售议价能力的同时，基于对汇率走势的分析形成未来预测，由此调整对客户的报价，从而降低产品定价后因汇率大幅波动所产生的不利影响。

## 2、下滑趋势是否具有可持续性

发行人预计相关不利影响不具有持续性，预计不会形成不可逆转的下滑，具体原因如下：

（1）国家政策支持行业发展，发行人户外业务下游行业发展态势良好，其下游市场空间巨大

近年来，国家政策持续支持体育与健康产业发展，户外运动行业迎来良好发展机遇。我国户外运动市场虽起步较晚、渗透率较低，但正处在快速发展阶段，与已进入成熟期的国外市场相比，具有显著增长潜力。随着社会经济发展、居民生活品质提升及户外生活方式逐步养成，国内户外运动用品市场预计将保持良好增长态势，未来发展空间广阔。此外，各类国内外大型体育赛事的举办，进一步激发了大众参与户外运动的热情，为我国户外运动市场的持续增长注入长期动力。

## （2）巩固及提升户外业务市场占有率

在户外业务上，公司未来将采取新的产品策略、渠道策略和营销策略来构建多维度战略矩阵，驱动营业收入增长并构建可持续竞争优势。产品方面，公司将持续研发新品，加快新品迭代速度。渠道方面，公司将持续优化实体网络，开拓即时渠道，深耕本地生活，构建可持续发展能力。营销策略方面，公司整合节庆、种草、会员与电商营销，提升品牌知名度、美誉与业绩。通过上述措施，公司户外业务市场占有率有望大幅提升，业绩将有所提升。

## （3）以技术领先与产业链协同，撬动芯片业务未来增长

未来公司芯片业务将成为公司业绩增长的核心引擎。一方面，得益于研发创新优势与技术领先实力，公司在触控芯片、Mini LED 驱动芯片等关键领域持续突破，以高性能、高可靠性的产品抢占市场高地，尤其在 On-Cell 单层触控、Mini LED 主动式驱动等高端细分赛道已建立起明显的技术护城河。另一方面，公司依托高度垂直整合的产业链布局，从设计、封测到销售实现全链条协同，不仅能快速响应客户定制化需求、缩短交付周期，更能通过规模化生产与工艺优化持续降低成本、提升产品竞争力。同时，深厚的客户基础与“自上而下”的客户拓展策略，保障了新产品、新技术的市场导入效率，并与三星、LG、京东方等国内外行业龙头形成稳定深化的合作，为业务持续放量奠定坚实基础。在显示技术升级、终端应用场景拓展的行业趋势下，公司凭借技术、客户与业态的多维优势，有望不断打开成长空间，驱动芯片业务实现规模化、高质量的发展。

2026 年1-3月，公司户外业务营业收入金额为 31,624.46 万元，较上年同期增长 6.46%，公司应对措施已初见成效。综上，面对业绩下滑的情形发行人已制定有效应对措施，预计下滑趋势不具有持续性。

## 二、报告期内芯片业务收入大幅增长的原因及合理性，报告期内芯片业务的主要客户及回款情况，结合公司芯片业务的发展情况说明该业务增长是否具有可持续性

## （一）报告期内芯片业务收入大幅增长的原因及合理性

报告期内，公司营业收入基本来自主营业务，芯片业务收入大幅增长亦主要由主营业务贡献，芯片业务主营业务收入明细情况如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>公司名称</td><td rowspan=2 colspan=1>业务类型</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=2>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>G2 Touch</td><td rowspan=1 colspan=1>触控芯片</td><td rowspan=1 colspan=1>17,323.19</td><td rowspan=1 colspan=1>-8.54%</td><td rowspan=1 colspan=1>18,939.77</td><td rowspan=1 colspan=1>54.81%</td><td rowspan=1 colspan=1>12,234.10</td></tr><tr><td rowspan=1 colspan=1>江苏鼎茂</td><td rowspan=1 colspan=1>芯片封测</td><td rowspan=1 colspan=1>5,210.50</td><td rowspan=1 colspan=1>65.11%</td><td rowspan=1 colspan=1>3,155.86</td><td rowspan=1 colspan=1>217.73%</td><td rowspan=1 colspan=1>993.24</td></tr><tr><td rowspan=1 colspan=1>北京芯能</td><td rowspan=1 colspan=1>Mini LED显示驱动芯片</td><td rowspan=1 colspan=1>168.12</td><td rowspan=1 colspan=1>78.49%</td><td rowspan=1 colspan=1>94.19</td><td rowspan=1 colspan=1>-12.58%</td><td rowspan=1 colspan=1>107.75</td></tr><tr><td rowspan=1 colspan=2>合计-</td><td rowspan=1 colspan=1>22,701.81</td><td rowspan=1 colspan=1>2.31%</td><td rowspan=1 colspan=1>22,189.82</td><td rowspan=1 colspan=1>66.40%</td><td rowspan=1 colspan=1>13,335.09</td></tr></table>

报告期内，公司芯片业务主营业务收入分别为13,335.09 万元、22,189.82 万元和 22,701.81 万元，呈现持续增长态势，2024 年芯片业务收入较 2023 年增长66.40%，主要系：一方面，公司于 2023 年 5 月末及 6 月末分别完成对 G2Touch和江苏鼎茂两家芯片业务公司的收购，使得 2023 年收入仅包含收购完成后的期间收入，而 2024 年及 2025 年为完整年度收入，从而带动芯片业务收入规模显著提升；另一方面，公司对 G2Touch 和江苏鼎茂的收购整合效果较好，业务融合顺利，客户订单持续释放，报告期内芯片业务持续提升。其中，江苏鼎茂在被收购后经营表现良好，2023 年度至 2025 年度净利润分别为-97.00 万元、222.51 万元和1,205.16 万元，成功实现扭亏为盈。

2025 年芯片业务收入较 2024 年增长 2.31%，增速有所放缓。其中，G2 Touch收入同比下降 8.54%，主要系触控芯片市场竞争加剧及部分客户订单波动所致；江苏鼎茂收入同比增长 65.11%，主要系封测业务持续拓展所致；北京芯能收入同比增长78.49%，但绝对规模较小（仅168.12 万元），对整体收入增长贡献有限。

综上，报告期内，公司芯片业务收入大幅增长主要系收购并表导致的年度涵盖期间差异和收购整合效果较好所致，具备合理性。

## （二）报告期内芯片业务的主要客户及回款情况

报告期内，公司芯片业务的主要客户收入及回款情况如下：

## 1、2025 年度

单位:万元

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>客户名称</td><td rowspan=1 colspan=2>主营业务收入</td><td rowspan=2 colspan=1>本期回款</td><td rowspan=2 colspan=1>应收账款余额</td><td rowspan=2 colspan=1>期后回款金额</td><td rowspan=2 colspan=1>期后回款占比</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占收入比重</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>京东方科技(香港)有限公司及其关联客户</td><td rowspan=1 colspan=1>17,237.73</td><td rowspan=1 colspan=1>75.93%</td><td rowspan=1 colspan=1>18,428.12</td><td rowspan=1 colspan=1>2,822.31</td><td rowspan=1 colspan=1>2,774.30</td><td rowspan=1 colspan=1>98.30%</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>杭州微影传感电子有限公司及其关联方</td><td rowspan=1 colspan=1>2,763.29</td><td rowspan=1 colspan=1>12.17%</td><td rowspan=1 colspan=1>2,659.52</td><td rowspan=1 colspan=1>754.21</td><td rowspan=1 colspan=1>754.21</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>北京安酷智芯科技有限公司及其关联方</td><td rowspan=1 colspan=1>1,525.48</td><td rowspan=1 colspan=1>6.72%</td><td rowspan=1 colspan=1>913.05</td><td rowspan=1 colspan=1>208.28</td><td rowspan=1 colspan=1>208.28</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>21,526.50</td><td rowspan=1 colspan=1>94.82%</td><td rowspan=1 colspan=1>22,000.69</td><td rowspan=1 colspan=1>3,784.80</td><td rowspan=1 colspan=1>3,736.80</td><td rowspan=1 colspan=1>98.73%</td></tr></table>

注 1：期后回款统计至 2026 年 3 月 31 日，下同；  
注 2：占收入比重指客户收入占芯片业务主营业务收入比重，下同。

## 2、2024 年度

单位:万元

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>客户名称</td><td rowspan=1 colspan=2>主营业务收入</td><td rowspan=2 colspan=1>本期回款</td><td rowspan=2 colspan=1>应收账款余额</td><td rowspan=2 colspan=1>期后回款金额</td><td rowspan=2 colspan=1>期后回款占比</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>占收入比重</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>京东方科技(香港)有限公司及其关联客户</td><td rowspan=1 colspan=1>18,458.69</td><td rowspan=1 colspan=1>83.19%</td><td rowspan=1 colspan=1>18,295.00</td><td rowspan=1 colspan=1>4,076.91</td><td rowspan=1 colspan=1>4,076.91</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>杭州微影传感电子有限公司及其关联方</td><td rowspan=1 colspan=1>1,230.85</td><td rowspan=1 colspan=1>5.55%</td><td rowspan=1 colspan=1>1,440.63</td><td rowspan=1 colspan=1>291.30</td><td rowspan=1 colspan=1>291.30</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>北京安酷智芯科技有限公司及其关联方</td><td rowspan=1 colspan=1>1,065.12</td><td rowspan=1 colspan=1>4.80%</td><td rowspan=1 colspan=1>547.98</td><td rowspan=1 colspan=1>62.10</td><td rowspan=1 colspan=1>62.10</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>20,754.65</td><td rowspan=1 colspan=1>93.53%</td><td rowspan=1 colspan=1>20,283.61</td><td rowspan=1 colspan=1>4,430.31</td><td rowspan=1 colspan=1>4,430.31</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 3、2023 年度

单位:万元

<table><tr><td colspan="1" rowspan="2">序号</td><td colspan="1" rowspan="2">客户名称</td><td colspan="2" rowspan="1">主营业务收入</td><td colspan="1" rowspan="2">本期回款</td><td colspan="1" rowspan="2">应收账款余额</td><td colspan="1" rowspan="2">期后回款金额</td><td colspan="1" rowspan="2">期后回款占比</td></tr><tr><td colspan="1" rowspan="1">金额</td><td colspan="1" rowspan="1">占收入比重</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">京东方科技(香港)有限公司及其关联客户</td><td colspan="1" rowspan="1">12,195.25</td><td colspan="1" rowspan="1">91.45%</td><td colspan="1" rowspan="1">13,536.60</td><td colspan="1" rowspan="1">4,192.82</td><td colspan="1" rowspan="1">4,192.82</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">杭州微影传感电子有限公司及其关联方</td><td colspan="1" rowspan="1">614.63</td><td colspan="1" rowspan="1">4.61%</td><td colspan="1" rowspan="1">465.14</td><td colspan="1" rowspan="1">309.65</td><td colspan="1" rowspan="1">309.65</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">北京安酷智芯科技有限公司及其关联方</td><td colspan="1" rowspan="1">312.52</td><td colspan="1" rowspan="1">2.34%</td><td colspan="1" rowspan="1">188.50</td><td colspan="1" rowspan="1">34.99</td><td colspan="1" rowspan="1">34.99</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="2" rowspan="1">合计</td><td colspan="1" rowspan="1">13,122.40</td><td colspan="1" rowspan="1">98.41%</td><td colspan="1" rowspan="1">14,190.24</td><td colspan="1" rowspan="1">4,537.47</td><td colspan="1" rowspan="1">4,537.47</td><td colspan="1" rowspan="1">100.00%</td></tr></table>

由上表可知，报告期内，公司芯片业务主要客户收入占比分别为 98.41%、93.53%和 94.82%，截至 2026 年 3 月末，2023 年度、2024 年度和 2025 年度应收账款余额期后回款比例为100.00%、100.00%和98.73%，期后回款整体情况较好。综上，报告期内，公司芯片业务主要客户回款情况较好。

## （三）结合公司芯片业务的发展情况说明该业务增长是否具有可持续性

报告期内，公司芯片业务收入呈现持续增长态势，2023 年至2025 年芯片业务的营业收入分别实现 13,347.05 万元、22,230.84 万元和 22,993.83 万元，其中芯片业务主营业务收入分别实现 13,335.09 万元、22,189.82 万元和 22,701.81 万元。结合公司芯片业务的发展现状及未来规划，该业务增长具备可持续性，主要原因系：一是公司收购 G2 Touch 和江苏鼎茂后，整合效果良好，客户订单持续释放，成为稳定的收入来源，其中，江苏鼎茂在被收购后经营表现良好，2023年度至 2025 年度净利润为-97.00 万元、222.51 万元和 1,205.16 万元，成功实现扭亏为盈；二是本次收购贝特莱及上海通途进一步完善了芯片产业战略布局，两家标的公司分别在国内智能门锁指纹传感器及显示桥接芯片市场占有率排名位居前列，2025 年度已分别实现净利润 1,364.75 万元和 2,204.96 万元，并设置了业绩承诺的保障，2026 年度贝特莱和上海通途将纳入公司合并报表范围，为未来增长提供了坚实保障；三是公司“户外+芯片”双主业协同发展，芯片技术可赋能户外智能装备，户外场景需求反哺芯片研发，形成独特的商业模式和竞争壁垒。

综上，公司芯片业务增长具备可持续性，主要系收购整合效果良好、产业布局持续完善、双主业协同发展所致，具备合理性。

三、发行人先后并购多家芯片业务公司的主要原因及考虑，发行人是否具备运营管理芯片业务公司的能力；在并购标的北京芯能持续亏损并全额计提商誉减值、芯片业务汇兑损失拖累公司业绩的情况下，发行人进一步收购贝特莱及上海通途两家芯片业务公司是否合理、谨慎；发行人收购贝特莱及上海通途后新增商誉情况；发行人并购芯片业务公司形成的商誉是否存在大额计提减值风险

（一）发行人先后并购多家芯片业务公司的主要原因及考虑，发行人是否具备运营管理芯片业务公司的能力

1、发行人先后并购多家芯片业务公司的主要原因及考虑；

发行人先后并购多家芯片业务公司的主要原因及考虑如下：

（1）公司董事长及高管团队具备丰富的芯片行业认知与履职背景

2021 年 2 月份，公司实际控制人由盛发强、王静变更为李明。以实际控制人、董事长李明和总裁何华杰为核心的管理层具备深厚的芯片行业从业经验，李明董事长曾担任紫光国微和国研科技董事长，紫光集团联席总裁等；何华杰总裁曾任联通在线信息科技有限公司总经理、东方网力科技股份有限公司副总裁、紫光集团副总裁等。

公司董事长及高管团队具备丰富的科技与芯片行业履职背景，基于公司管理层对芯片行业的认知与资源整合能力，为公司并购提供了专业判断与执行保障。此外，面对传统户外主营业务增长减缓的情况，公司通过资本运作快速切入芯片赛道，以“感知+显示”为核心技术主线，系统性整合显示驱动、触控、指纹识别及图像处理等领域，旨在构建技术协同的芯片矩阵，分散单一主业经营风险，并借助管理层在芯片领域的产业认知与资源实现投后赋能与价值释放，从而创造可持续的第二增长曲线，实现“户外+芯片”的双主业共同发展。

（2）对芯片行业的深层战略规划与布局

近年来，公司陆续收购了北京芯能、G2Touch、江苏鼎茂、贝特莱及上海通途。公司对芯片业务的战略规划及产业布局情况如下：

<table><tr><td rowspan=1 colspan=1>应用场景</td><td rowspan=1 colspan=1>图像</td><td rowspan=1 colspan=1>显示</td><td rowspan=1 colspan=1>触控</td><td rowspan=1 colspan=1>指纹</td></tr><tr><td rowspan=1 colspan=1>智能穿戴</td><td rowspan=1 colspan=1>通途算法</td><td rowspan=1 colspan=1>芯能 Micro LED 驱动芯片</td><td rowspan=1 colspan=1>贝特莱手表触控芯片</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>手机</td><td rowspan=1 colspan=1>通途SoC桥接芯片</td><td rowspan=1 colspan=1>上海通途算法</td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1>贝特莱指纹ASIC芯片</td></tr><tr><td rowspan=1 colspan=1>平板电脑、笔电、车载</td><td rowspan=1 colspan=1>通途算法</td><td rowspan=1 colspan=1>G2 Touch 和上海通途的Scaler 图像缩放芯片（合作在研项目）</td><td rowspan=1 colspan=1>①G2 Touch 触控芯片②贝特莱触控板 ASIC 芯片③G2 Touch 和贝特莱的主动笔芯片（合作在研项目）④G2 Touch 和贝特莱专用 MCU（合作在研项目)③G2 Touch 和上海通途 TDDI芯片（合作在研项目）</td><td rowspan=1 colspan=1>贝特莱指纹ASIC芯片</td></tr><tr><td rowspan=1 colspan=1>TV Monitor 透明屏</td><td rowspan=1 colspan=1>通途算法</td><td rowspan=1 colspan=1>①北京芯能Mini/MicroLED 驱动芯片②北京芯能透明屏驱动芯片③上海通途和北京芯能的高端 PQ画质芯片（合作在研项目）</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>安防监控</td><td rowspan=1 colspan=1>通途算法</td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1>①贝特莱智能门锁 ASIC芯片②贝特莱金融与安防 ASIC芯片</td></tr><tr><td rowspan=1 colspan=1>智能家居消费电子</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>①贝特莱专用MCU芯片②贝特莱 T-MCU芯片③贝特莱悬浮触控芯片</td><td rowspan=1 colspan=1>/</td></tr><tr><td rowspan=1 colspan=1>自动驾驶</td><td rowspan=1 colspan=1>通途算法</td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1></td></tr></table>

如上图所示，公司芯片业务主要聚焦在“图像、显示、触控、指纹”四大领域，公司近年来陆续收购的多家芯片企业，均聚焦在以上领域。通过整合这些标的公司的技术、团队与客户资源，公司已形成从感知层（指纹、触控）到处理层（图像）再到输出层（显示）的完整芯片产品矩阵。相关产品已广泛应用于平板电脑、笔记本电脑、车载电子、智能手机、智能穿戴设备、透明显示屏、安防监控以及智能家居等消费电子与行业终端，覆盖了从个人消费到安全物联的多元化场景。

## （3）发挥协同效应，拓展业务广度，突破技术深度

公司先后并购这几家芯片公司有利于发挥芯片业务的协同效应，北京芯能的技术主线为显示驱动，G2 Touch 的技术主线为显示屏触控，江苏鼎茂的技术主线为芯片封装，贝特莱的技术主线为感知交互，上海通途的技术主线为显示、图像及视频处理。从业务吻合度来看，贝特莱与 G2Touch 现有业务吻合度较高，在触控与人机交互领域具有较高的业务契合度，二者可以在产品定义、客户导入及技术迭代方面形成一定的联动。上海通途与北京芯能现有业务吻合度较高，在显示与图像处理链条上优势互补。尽管五家公司处于同一技术话语体系，但各自又拥有差异化的技术优势与市场侧重点，构成了“合而不同、协同并进”的良好产业生态。未来在市场、客户、产品、技术、供应链及人才培养等方面，五家芯片公司将发挥协同效应，实现交叉赋能。此外，陆续并购的芯片公司有助于公司进一步扩大芯片业务规模、显著提升公司盈利能力。

## （4）拓展芯片业务应用市场，优化客户结构

公司现有芯片业务聚焦笔记本电脑、Mini LED 显示及红外成像等应用领域，直接客户为面板厂、LED 显示屏厂、背光模组厂等。公司在 2025 年 12 月 1 日公告收购的贝特莱和上海通途，其中贝特莱业务覆盖智能终端、智能穿戴、笔记本电脑、智能家居、智能家电等场景，以及可信安防、工业控制等高可靠性领域；上海通途业务覆盖大、中、小尺寸的显示场景，以及机器视觉、智能驾驶等新兴场景。两家公司的客户包括电子 OEM 及ODM 厂商、头部消费电子品牌商、中大型芯片设计公司、智能视觉方案提供商。通过先后并购多家芯片公司，使公司覆盖的下游应用领域可延伸至更广泛的消费电子市场、更高可靠性的工业控制市场更高附加值的新兴市场，同时优化客户结构，改善盈利水平。

## （5）持续推动“户外+芯片”双主业战略，提升公司核心竞争力

公司全面深化“户外+芯片”双主业战略。户外业务以“巩固行业领军地位、强化经营质量、深化可持续发展”为战略中心，加大高性能材料研发投入，推进智能户外装备迭代，建立专业级产品认证体系，强化核心品类市场占位；优化全渠道成本结构，深化柔性供应链管理，精准匹配高毛利产品组合与场景化营销策略，提升高客单产品渗透率，通过数字化中台实现库存周转效率与终端动销能力双升级。

芯片业务方面，公司将坚持“技术驱动、生态聚合”的核心战略，在持续巩固显示芯片领域竞争优势的同时，深化产业链垂直整合能力，并向高附加值领域不断延伸。此外，公司先后并购多家芯片企业，亦是对“户外+芯片”双主业战略

的深入践行。

## 2、发行人是否具备运营管理芯片业务公司的能力。

自2021 年以来，公司在芯片产业领域相继完成了多项标的收购，积累了丰富的投后整合与管理经验。公司董事长及高管团队具备丰富的芯片行业认知与履职背景，公司具备运营管理芯片业务公司的能力。公司将通过以下措施构建一体化运营与管理体系：

在业务方面，公司拟从公司制度和公司治理等方面建立规范化体系，提升芯片公司运作效率，建立健全收购的芯片公司的信息披露制度、关联方交易制度、资金管理制度、现金管理制度、对外担保制度等，并与芯片公司管理层沟通制定适合芯片行业特点与公司经营模式的采购制度、销售制度、研发制度和外包封装测试制度等，促使芯片公司业务经营规范化、高效化、透明化，规避重大风险，促进公司与芯片公司整合。

在人员方面，公司将修改标的公司章程，对公司治理结构作出调整，集团派出高管进入标的公司管理层介入决策事项，确保公司在重大经营决策、财务运作、对外投资、关联交易及资产处置等关键环节对标的公司实施有效管控。标的公司核心团队成员将与标的公司签署长期劳动合同，确保核心团队人员稳定性，同时公司拟适时对外招聘行业专业人员扩充研发、技术人员队伍。

在财务方面，建立健全内部控制与监督机制，公司将委派人员担任标的公司的财务总监，标的公司的财务活动全面纳入上市公司统一管理。

报告期内，公司芯片业务收入稳步增长，公司通过外延式并购成功切入芯片业务后，并未止步于资源与技术的初步整合，而是加大力度推动该业务实现体系化发展与持续壮大，在公司有效的运营及管理下，被收购的芯片公司持续发展。

（二）在并购标的北京芯能持续亏损并全额计提商誉减值、芯片业务汇兑损失拖累公司业绩的情况下，发行人进一步收购贝特莱及上海通途两家芯片业务公司是否合理、谨慎

## 1、北京芯能持续亏损并全额计提商誉减值准备、芯片业务汇兑损失拖累公司业绩与本次公司收购贝特莱及上海通途两家芯片公司具有实质差别

报告期内，北京芯能持续亏损，2024 年已全额计提商誉减值主要系：北京芯能被收购时处于早期成长阶段，受宏观经济环境变化及全球消费电子市场需求持续放缓影响，Mini LED 技术因技术、成本、市场及生态四方面因素制约，应用推广不及预期。技术上，高密度封装工艺复杂、产业链成熟度低且标准不统一，限制了规模化生产和产品兼容性；成本上，芯片用量大、驱动 IC 精度要求高，叠加封装及维护成本高昂，导致终端价格缺乏竞争力；市场上，传统小间距LED在中低端场景性价比优势明显，OLED 在消费电子领域持续挤压，市场竞争激烈；生态上，Mini LED 在电视领域逐步应用，但在其他领域仍较有限，应用深度和广度有待拓展。背光业务方面，TV 大客户与原有固定供应商绑定较紧，北京芯能产品渗透需找准时机并经过时间验证；直显业务方面，同尺寸 TV Mini LED直显所需灯珠数量数百倍于背光，芯片成本指数级攀升，同时对芯片微缩化、巨量转移良率、高精度封装工艺要求极高，当前仍处于高成本试水期。北京芯能采取大客户销售策略，与行业头部客户定制研发 AM Mini LED 驱动芯片，目前相关芯片正在流片、验证进程中，部分项目验证周期较长，待验证量产后方可具备产品及客户领先性。未来若上述制约因素逐步消除，相关芯片实现量产并完成客户验证，北京芯能业绩将有所改善。

本次公司收购的贝特莱及上海通途与前期收购的北京芯能在盈利能力上存在显著差异。贝特莱及上海通途均已具备较强的盈利能力，处于较为成熟的盈利阶段，并在各自细分领域确立了市场领先地位；而北京芯能收购时处于Mini LED行业早期培育阶段，收入体量较小且尚未实现盈利。根据立信会计师事务所出具的信会师报字[2026]第 ZG50043号和信会师报字[2026]第ZG50084 号审计报告显示，2025 年度，贝特莱实现营业收入25,371.03 万元，净利润1,364.75 万元，上海通途实现营业收入 16,106.73 万元，净利润 2,204.96 万元。上述财务数据进一步印证了两家标的公司已具备稳定的盈利能力和成熟的商业模式，与北京芯能收购时的经营状况存在本质区别，充分体现了本次收购标的选择的谨慎性。

2025 年，公司芯片业务汇兑损失影响公司业务主要系子公司G2Touch 业务收入主要以美元结算所致，而贝特莱和上海通途两个芯片公司的业务收入均以人民币作为结算货币，故不存在外汇波动导致汇兑风险。

## 2、发行人进一步收购贝特莱及上海通途两家芯片业务公司具备合理性

发行人进一步收购贝特莱及上海通途两家芯片业务公司具备合理性，具体原因详见本题回复之“三、（一）发行人先后并购多家芯片业务公司的主要原因及考虑”。

## 3、发行人进一步收购贝特莱及上海通途两家芯片业务公司具备谨慎性

## （1）公司收购贝特莱及上海通途的选择系基于审慎判断，标的公司核心竞争力突出，有效规避了培育初创期企业可能带来的技术、市场及管理不确定性风险

本次收购标的选择具有谨慎性，贝特莱和上海通途均为各自细分领域的优质企业，具备核心竞争优势。贝特莱是数模混合信号链芯片领域的领先设计企业，在智能门锁指纹识别领域位居行业首位；在可信安防指纹、笔记本电脑触控板、电容式主动笔、智能穿戴等领域均位居行业前列。上海通途的视频压缩、AMOLED 显示驱动及视频处理三大 IP 技术在性能参数、算法效率、模型轻量化、架构灵活性等方面处于行业领先地位，IP 已成功授权超过20家中大型芯片公司；并基于以上技术开发的手机显示屏桥接芯片的出货量名列行业前茅。本次收购将受益于国产化替代进程，显著提升公司产业地位，增强公司核心竞争力。根据立信会计师事务所出具的信会师报字[2026]第 ZG50043 号和信会师报字[2026]第ZG50084 号审计报告显示，2025 年度，贝特莱实现营业收入25,371.03 万元，净利润 1,364.75 万元，上海通途实现营业收入 16,106.73 万元，净利润 2,204.96 万元，贝特莱和上海通途均具备稳定的盈利能力。

## （2）公司收购贝特莱和上海通途价格以评估值为基础，定价公允合理

## 1）贝特莱交易定价情况

公司聘请上海东洲资产评估有限公司对贝特莱股东全部权益价值进行了估值。根据上海东洲资产评估有限公司出具的《探路者控股集团股份有限公司拟现金收购股权所涉及的深圳贝特莱电子科技股份有限公司股东全部权益估值报告》（东洲咨报字【2025】第 2490 号），以2025 年8 月31 日为估值基准日，最终选取收益法对贝特莱股东全部权益市场价值进行估值，收益法估值步骤如下：

## A.确定预期收益额

结合被估值企业的人力资源、技术水平、资本结构、经营状况、历史业绩、发展趋势，以及宏观经济因素、所在行业现状与发展前景，对委托人或被估值企业管理层提供的未来收益预测资料进行必要的分析复核、判断和调整，在此基础上合理确定估值假设，形成未来预期收益额。预测数据如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目／年份</td><td colspan="1" rowspan="1">2025年9-12月</td><td colspan="1" rowspan="1">2026年度</td><td colspan="1" rowspan="1">2027年度</td><td colspan="1" rowspan="1">2028年度</td><td colspan="1" rowspan="1">2029年度</td><td colspan="1" rowspan="1">2030年度</td></tr><tr><td colspan="1" rowspan="1">一、营业收入</td><td colspan="1" rowspan="1">9,617.64</td><td colspan="1" rowspan="1">35,020.00</td><td colspan="1" rowspan="1">45,786.80</td><td colspan="1" rowspan="1">57,010.62</td><td colspan="1" rowspan="1">66,132.31</td><td colspan="1" rowspan="1">70,430.91</td></tr><tr><td colspan="1" rowspan="1">减：营业成本</td><td colspan="1" rowspan="1">6,450.28</td><td colspan="1" rowspan="1">23,488.50</td><td colspan="1" rowspan="1">30,732.27</td><td colspan="1" rowspan="1">38,273.57</td><td colspan="1" rowspan="1">44,397.33</td><td colspan="1" rowspan="1">47,283.16</td></tr><tr><td colspan="1" rowspan="1">税金及附加</td><td colspan="1" rowspan="1">24.75</td><td colspan="1" rowspan="1">79.16</td><td colspan="1" rowspan="1">101.88</td><td colspan="1" rowspan="1">125.57</td><td colspan="1" rowspan="1">144.82</td><td colspan="1" rowspan="1">153.89</td></tr><tr><td colspan="1" rowspan="1">销售费用</td><td colspan="1" rowspan="1">413.57</td><td colspan="1" rowspan="1">1,219.88</td><td colspan="1" rowspan="1">1,476.03</td><td colspan="1" rowspan="1">1,715.96</td><td colspan="1" rowspan="1">1,927.13</td><td colspan="1" rowspan="1">2,091.82</td></tr><tr><td colspan="1" rowspan="1">管理费用</td><td colspan="1" rowspan="1">407.86</td><td colspan="1" rowspan="1">1,062.25</td><td colspan="1" rowspan="1">1,215.27</td><td colspan="1" rowspan="1">1,290.04</td><td colspan="1" rowspan="1">1,366.67</td><td colspan="1" rowspan="1">1,458.67</td></tr><tr><td colspan="1" rowspan="1">研发费用</td><td colspan="1" rowspan="1">1,968.05</td><td colspan="1" rowspan="1">6,170.26</td><td colspan="1" rowspan="1">7,723.03</td><td colspan="1" rowspan="1">8,884.27</td><td colspan="1" rowspan="1">9,953.11</td><td colspan="1" rowspan="1">10,720.43</td></tr><tr><td colspan="1" rowspan="1">财务费用</td><td colspan="1" rowspan="1">59.00</td><td colspan="1" rowspan="1">183.15</td><td colspan="1" rowspan="1">191.09</td><td colspan="1" rowspan="1">199.37</td><td colspan="1" rowspan="1">206.09</td><td colspan="1" rowspan="1">209.26</td></tr><tr><td colspan="1" rowspan="1">加：其他收益</td><td colspan="1" rowspan="1">149.77</td><td colspan="1" rowspan="1">518.30</td><td colspan="1" rowspan="1">677.64</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">投资收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">净口套期收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">公允价值变动收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">信用减值损失</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">资产减值损失</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">资产处置收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">二、营业利润</td><td colspan="1" rowspan="1">443.89</td><td colspan="1" rowspan="1">3,335.10</td><td colspan="1" rowspan="1">5,024.87</td><td colspan="1" rowspan="1">6,521.84</td><td colspan="1" rowspan="1">8,137.16</td><td colspan="1" rowspan="1">8,513.68</td></tr><tr><td colspan="1" rowspan="1">三、利润总额</td><td colspan="1" rowspan="1">443.89</td><td colspan="1" rowspan="1">3,335.10</td><td colspan="1" rowspan="1">5,024.87</td><td colspan="1" rowspan="1">6,521.84</td><td colspan="1" rowspan="1">8,137.16</td><td colspan="1" rowspan="1">8,513.68</td></tr><tr><td colspan="1" rowspan="1">四、所得税</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">五、净利润</td><td colspan="1" rowspan="1">443.89</td><td colspan="1" rowspan="1">3,335.10</td><td colspan="1" rowspan="1">5,024.87</td><td colspan="1" rowspan="1">6,521.84</td><td colspan="1" rowspan="1">8,137.16</td><td colspan="1" rowspan="1">8,513.68</td></tr><tr><td colspan="1" rowspan="1">六、归属于母公司损益</td><td colspan="1" rowspan="1">443.89</td><td colspan="1" rowspan="1">3,335.10</td><td colspan="1" rowspan="1">5,024.87</td><td colspan="1" rowspan="1">6,521.84</td><td colspan="1" rowspan="1">8,137.16</td><td colspan="1" rowspan="1">8,513.68</td></tr></table>

## B.确定未来收益期限

在对被估值企业产品或者服务的剩余经济寿命以及替代产品或者服务的研发情况、收入结构、成本结构、资本结构、资本性支出、营运资金、投资收益和风险水平等综合分析的基础上，结合宏观政策、行业周期及其他影响企业进入稳定期的因素，本项目明确的预测期期间n选择为6年。

## C.确定折现率

按照折现率需与预期收益额保持口径一致的原则，本次折现率选取加权平均资本成本（WACC），即股权期望报酬率和经所得税调整后的债权期望报酬率的加权平均值，计算公式为：

$$
\mathrm { W A C C { = } R _ { d } \mathrm { ^ { * } _ { \alpha } \left( 1 { - } T \right) \mathrm { ^ { * } W _ { d } \mathrm { + } R _ { e } \mathrm { ^ { * } W _ { e } { = } 1 } } } } 1 2 . 1 0 \%
$$

采用收益法的估值结论为 65,060.00 万元，较被估值企业净资产账面价值增值 51,016.01 万元，增值率 363.26%。

## D.与同行业可比参照公司的对比情况

标的公司贝特莱为 Fabless 生产模式的半导体企业，所销售的芯片均为设计验证后交由代工厂生产、封测。评估机构在选取可比参照企业时，设定以下标准：可比企业须至少具备两年上市历史，且其所处行业及主营业务与被估值企业相同或相似。截止本次评估基准日（2025 年8月31 日）具体对比情况如下：

<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">公司名称</td><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">企业规模</td><td colspan="1" rowspan="1">经营模式</td><td colspan="1" rowspan="1">评估基准日</td><td colspan="1" rowspan="1">市盈率TTM</td><td colspan="1" rowspan="1">市净率LF</td></tr><tr><td colspan="1" rowspan="1">603160.SH</td><td colspan="1" rowspan="1">汇顶科技</td><td colspan="1" rowspan="3">集成电路设计产业</td><td colspan="1" rowspan="1">年收入43.75亿元</td><td colspan="1" rowspan="1">芯片设计为主</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">53.04</td><td colspan="1" rowspan="1">4.22</td></tr><tr><td colspan="1" rowspan="1">603501.SH</td><td colspan="1" rowspan="1">豪威集团(原“韦尔股份”）</td><td colspan="1" rowspan="1">年收入257.31亿元</td><td colspan="1" rowspan="1">芯片设计为主</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">43.36</td><td colspan="1" rowspan="1">6.91</td></tr><tr><td colspan="1" rowspan="1">688061.SH</td><td colspan="1" rowspan="1">灿瑞科技</td><td colspan="1" rowspan="1">年收入5.65亿元</td><td colspan="1" rowspan="1">芯片设计和封测为主</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">210.53</td><td colspan="1" rowspan="1">5.00</td></tr><tr><td colspan="1" rowspan="1">688286.SH</td><td colspan="1" rowspan="1">敏芯股份</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">年收入5.06亿元</td><td colspan="1" rowspan="1">具备芯片设计和制造工艺能力</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">-56.45</td><td colspan="1" rowspan="1">1.70</td></tr><tr><td colspan="6" rowspan="1">平均值</td><td colspan="1" rowspan="1">62.62</td><td colspan="1" rowspan="1">4.78</td></tr><tr><td colspan="6" rowspan="1">中位数</td><td colspan="1" rowspan="1">48.20</td><td colspan="1" rowspan="1">4.61</td></tr><tr><td colspan="2" rowspan="1">贝特莱</td><td colspan="1" rowspan="1">集成电路设计产业</td><td colspan="1" rowspan="1">2025年1-8月收入1.66亿元</td><td colspan="1" rowspan="1">芯片设计为主</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">46.16</td><td colspan="1" rowspan="1">4.49</td></tr></table>

注 1：同行业可比参照公司市盈率 TTM、同行业可比参照公司市净率 LF 数据来源于 Wind；注 2：贝特莱市盈率=（交易价格/收购股权比例）/评估基准日当年净利润；贝特莱市净率=（交易价格/收购股权比例）/交易基准日所有者权益。

本次交易标的的资产价格以估值结果为基础，最终由交易各方基于市场化交易原则谈判确定。参考上述估值结论，同时综合本次标的公司商业价值、行业发展前景与产品业务规划等多重因素，经与交易对手方多轮谈判协商，确定本次收购贝特莱 51%股权的交易价格合计为 32,130 万元，较贝特莱 51%股权的估值金额下降了3.17%，处于合理范围内。

根据与同行业可比参照公司的对比情况，贝特莱的市盈率为46.16 倍，显著低于同行业可比参照公司平均水平（62.62 倍）及中位数（48.20 倍）；贝特莱的市净率为4.49 倍，略低于同行业可比参照公司平均水平（4.78 倍）及中位数（4.61倍）。整体而言，贝特莱的估值水平在同行业可比参照公司中处于相对偏低区间，本次收购交易对价具备合理性。

本次交易价格以具有证券期货业务资格的独立第三方资产评估机构的评估值为定价基础，并经交易双方协商一致确定，定价公平、合理，不存在损害公司及其他股东利益的情形，特别是中小股东利益。

2）上海通途交易定价情况

公司聘请上海东洲资产评估有限公司对上海通途股东全部权益价值进行了估值。根据上海东洲资产评估有限公司出具的《探路者控股集团股份有限公司拟现金收购股权所涉及的上海通途半导体科技有限公司股东全部权益估值报告》（东洲咨报字【2025】第2612 号），以2025 年8月31 日为估值基准日，最终选取收益法对上海通途股东全部权益市场价值进行估值，收益法估值步骤如下：

## A.确定预期收益额

结合被估值企业的人力资源、技术水平、资本结构、经营状况、历史业绩、发展趋势，以及宏观经济因素、所在行业现状与发展前景，对委托人或被估值企业管理层提供的未来收益预测资料进行必要的分析复核、判断和调整，在此基础上合理确定估值假设，形成未来预期收益额。预测数据如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目/年份</td><td colspan="1" rowspan="1">2025全年E</td><td colspan="1" rowspan="1">2026年度</td><td colspan="1" rowspan="1">2027年度</td><td colspan="1" rowspan="1">2028年度</td><td colspan="1" rowspan="1">2029年度</td></tr><tr><td colspan="1" rowspan="1">一、营业收入</td><td colspan="1" rowspan="1">18,906.00</td><td colspan="1" rowspan="1">29,724.90</td><td colspan="1" rowspan="1">39,467.42</td><td colspan="1" rowspan="1">50,742.51</td><td colspan="1" rowspan="1">53,279.64</td></tr><tr><td colspan="1" rowspan="1">其中：主营业务收入</td><td colspan="1" rowspan="1">18,906.00</td><td colspan="1" rowspan="1">29,724.90</td><td colspan="1" rowspan="1">39,467.42</td><td colspan="1" rowspan="1">50,742.51</td><td colspan="1" rowspan="1">53,279.64</td></tr><tr><td colspan="1" rowspan="1">其他业务收入</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">减：营业成本</td><td colspan="1" rowspan="1">14,081.50</td><td colspan="1" rowspan="1">23,104.93</td><td colspan="1" rowspan="1">31,131.40</td><td colspan="1" rowspan="1">40,419.07</td><td colspan="1" rowspan="1">42,440.02</td></tr><tr><td colspan="1" rowspan="1">其中：主营业务成本</td><td colspan="1" rowspan="1">14,081.50</td><td colspan="1" rowspan="1">23,104.93</td><td colspan="1" rowspan="1">31,131.40</td><td colspan="1" rowspan="1">40,419.07</td><td colspan="1" rowspan="1">42,440.02</td></tr><tr><td colspan="1" rowspan="1">其他业务成本</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">税金及附加</td><td colspan="1" rowspan="1">33.45</td><td colspan="1" rowspan="1">55.15</td><td colspan="1" rowspan="1">74.57</td><td colspan="1" rowspan="1">96.95</td><td colspan="1" rowspan="1">101.78</td></tr><tr><td colspan="1" rowspan="1">销售费用</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">管理费用</td><td colspan="1" rowspan="1">228.71</td><td colspan="1" rowspan="1">247.40</td><td colspan="1" rowspan="1">279.58</td><td colspan="1" rowspan="1">295.33</td><td colspan="1" rowspan="1">311.49</td></tr><tr><td colspan="1" rowspan="1">研发费用</td><td colspan="1" rowspan="1">830.27</td><td colspan="1" rowspan="1">991.38</td><td colspan="1" rowspan="1">1,072.65</td><td colspan="1" rowspan="1">1,162.90</td><td colspan="1" rowspan="1">1,222.18</td></tr><tr><td colspan="1" rowspan="1">财务费用</td><td colspan="1" rowspan="1">-5.93</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">加：其他收益</td><td colspan="1" rowspan="1">5.79</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">投资收益</td><td colspan="1" rowspan="1">-13.92</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">净散口套期收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">公允价值变动收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">信用减值损失</td><td colspan="1" rowspan="1">-184.62</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">资产减值损失</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">资产处置收益</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">二、营业利润</td><td colspan="1" rowspan="1">3,545.25</td><td colspan="1" rowspan="1">5,326.04</td><td colspan="1" rowspan="1">6,909.22</td><td colspan="1" rowspan="1">8,768.26</td><td colspan="1" rowspan="1">9,204.16</td></tr><tr><td colspan="1" rowspan="1">加：营业外收入</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">减：营业外支出</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td><td colspan="1" rowspan="1">0.00</td></tr><tr><td colspan="1" rowspan="1">三、利润总额</td><td colspan="1" rowspan="1">3,545.25</td><td colspan="1" rowspan="1">5,326.04</td><td colspan="1" rowspan="1">6,909.22</td><td colspan="1" rowspan="1">8,768.26</td><td colspan="1" rowspan="1">9,204.16</td></tr><tr><td colspan="1" rowspan="1">四、所得税</td><td colspan="1" rowspan="1">522.03</td><td colspan="1" rowspan="1">910.03</td><td colspan="1" rowspan="1">1,250.23</td><td colspan="1" rowspan="1">1,649.14</td><td colspan="1" rowspan="1">1,730.94</td></tr><tr><td colspan="1" rowspan="1">五、净利润</td><td colspan="1" rowspan="1">3,023.22</td><td colspan="1" rowspan="1">4,416.01</td><td colspan="1" rowspan="1">5,658.99</td><td colspan="1" rowspan="1">7,119.12</td><td colspan="1" rowspan="1">7,473.22</td></tr><tr><td colspan="1" rowspan="1">减：少数股东损益</td><td colspan="1" rowspan="1">247.43</td><td colspan="1" rowspan="1">479.04</td><td colspan="1" rowspan="1">662.87</td><td colspan="1" rowspan="1">876.12</td><td colspan="1" rowspan="1">919.78</td></tr><tr><td colspan="1" rowspan="1">六、归属于母公司损益</td><td colspan="1" rowspan="1">2,775.79</td><td colspan="1" rowspan="1">3,936.97</td><td colspan="1" rowspan="1">4,996.12</td><td colspan="1" rowspan="1">6,243.00</td><td colspan="1" rowspan="1">6,553.45</td></tr></table>

## B.确定未来收益期限

在对被估值企业产品或者服务的剩余经济寿命以及替代产品或者服务的研发情况、收入结构、成本结构、资本结构、资本性支出、营运资金、投资收益和风险水平等综合分析的基础上，结合宏观政策、行业周期及其他影响企业进入稳定期的因素，本项目明确的预测期期间n选择为5年。

## C.确定折现率

按照折现率需与预期收益额保持口径一致的原则，本次折现率选取加权平均资本成本（WACC），即股权期望报酬率和经所得税调整后的债权期望报酬率的加权平均值，计算公式为：

$$
\mathrm { W A C C = R _ { d } ^ { * } \Sigma ( 1 - T ) \Sigma ^ { * } W _ { d } + R _ { e } ^ { * } W _ { e } = 1 1 . 4 0 \% }
$$

采用收益法的估值结论为 70,278.02 万元，较被估值企业净资产账面价值增值 67,111.85 万元，增值率 2,119.65%。

D. 与同行业可比参照公司的对比情况

标的公司上海通途主要从事芯片设计研发、IP 技术授权、人工智能系统及软硬件/平台产品设计开发。评估机构在选取可比参照企业时，设定以下标准：可比企业近年为盈利公司、可比企业须至少具备三年以上的上市历史，且其所处行业及主营业务与被估值企业相同或相似。截止本次评估基准日（2025 年 8 月31 日）具体对比情况如下：

<table><tr><td>代码</td><td>公司名称</td><td>所处行业</td><td>经营模式</td><td>业务结构</td><td>评估基准 日</td><td>市盈率 TTM （A）</td><td>市净率 LF (B）</td><td>ROE (C=B/ A）</td></tr><tr><td>688385.SH</td><td>复旦微电</td><td>电子-半导 体-数字芯 片设计</td><td>Fabless （Fabricat ion-Less， 无晶圆</td><td>主营业务是超 大规模集成电 路的设计、开 发、测试</td><td>2025-8-31</td><td>125.09</td><td>8.67</td><td>6.93%</td></tr><tr><td colspan="1" rowspan="1">688325.SH</td><td colspan="1" rowspan="1">赛微微电</td><td colspan="1" rowspan="1">电子-半导体-模拟芯片设计</td><td colspan="1" rowspan="2">厂模式）模式</td><td colspan="1" rowspan="1">主营业务是模拟芯片的研发和销售</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">58.70</td><td colspan="1" rowspan="1">3.05</td><td colspan="1" rowspan="1">5.20%</td></tr><tr><td colspan="1" rowspan="1">002049.SZ</td><td colspan="1" rowspan="1">紫光国微</td><td colspan="1" rowspan="1">电子-半导体-数字芯片设计</td><td colspan="1" rowspan="1">主营业务是集成电路芯片设计、服务、销售</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">61.13</td><td colspan="1" rowspan="1">5.46</td><td colspan="1" rowspan="1">8.93%</td></tr><tr><td colspan="6" rowspan="1">平均值</td><td colspan="1" rowspan="1">81.64</td><td colspan="1" rowspan="1">5.73</td><td colspan="1" rowspan="1">7.02%</td></tr><tr><td colspan="6" rowspan="1">中位数</td><td colspan="1" rowspan="1">61.13</td><td colspan="1" rowspan="1">5.46</td><td colspan="1" rowspan="1">6.93%</td></tr><tr><td colspan="2" rowspan="1">上海通途</td><td colspan="1" rowspan="1">电子-半导体-数字芯片设计</td><td colspan="1" rowspan="1">Fabless（Fabrication-Less,无晶圆厂模式）模式</td><td colspan="1" rowspan="1">主要从事芯片设计研发、IP 技术授权、人工智能系统及软硬件/平台产品设计开发</td><td colspan="1" rowspan="1">2025-8-31</td><td colspan="1" rowspan="1">36.08</td><td colspan="1" rowspan="1">22.11</td><td colspan="1" rowspan="1">61.27%</td></tr></table>

注 1：同行业可比参照公司市盈率 TTM、同行业可比参照公司市净率 LF 数据来源于 Wind；注 2：上海通途市盈率=（交易价格/收购股权比例）/评估基准日当年净利润；上海通途市净率=（交易价格/收购股权比例）/交易基准日所有者权益。

本次交易标的的资产价格以估值结果为基础，最终由交易各方基于市场化交易原则谈判确定。参考上述估值结论，同时综合本次标的公司商业价值、行业发展前景与产品业务规划等多重因素，经与交易对手方多轮谈判协商，确定本次收购上海通途 51%股权的交易价格为 35,700 万元，较上海通途 51%股权的估值金额下降了0.40%，处于合理范围内。

根据与同行业可比参照公司的对比情况，上海通途的市盈率为36.08 倍，显著低于同行业可比参照公司平均水平（81.64 倍）及中位数（61.13 倍）；上海通途的市净率为 22.11 倍，高于可比同行业参照公司平均水平（5.73 倍）及中位数（5.46 倍），主要系上海通途在评估期间及截至2026 年一季度末均无银行借款，资产负债结构以净资产为主，导致市净率偏高所致。上海通途ROE 为61.27%，远超同行业可比参照公司平均水平（7.02%）及中位数（6.93%），即上海通途具备较强的净资产回报能力。整体而言，上海通途的估值水平在同行业可比参照公司中处于相对偏低区间，高市净率与高 ROE 相匹配，故本次收购交易对价具备合理性。

本次交易价格以具有证券期货业务资格的独立第三方资产评估机构的评估值为定价基础，并经交易双方协商一致确定，定价公平、合理，不存在损害公司及其他股东利益的情形，特别是中小股东利益。

## （3）业绩承诺安排为本次收购提供了充分保障

本次收购设置了严格的业绩承诺及补偿机制，为公司收购贝特莱和上海通途提供充分保障，业绩承诺具体情况如下：

## 1）贝特莱业绩承诺补偿情况

本次交易中，公司合计收购贝特莱 51%股权。其中，从创始人处收购的18.35%股权设置了业绩承诺，其余来源于投资者及持股平台合计 32.65%股权未设置业绩承诺，主要系：①创始人作为标的公司的核心经营管理团队，对公司的日常经营及业绩实现具有直接责任与影响力。本次对其转让的 18.35%股权设置业绩承诺，能够有效约束其履行经营管理职责，保障业绩目标的实现；②投资者及持股平台不参与标的公司日常经营决策，无法对业绩实现施加有效影响。要求其承担业绩补偿义务既不符合其角色定位，也不具备可执行性。该安排符合并购重组市场的通行惯例。③创始人接受的交易定价较评估值存在一定折让，以此换取其承担业绩承诺及补偿义务。关于贝特莱业绩承诺主要条款设置情况如下：

<table><tr><td colspan="1" rowspan="1">业绩承诺条款</td><td colspan="1" rowspan="1">补偿工具、顺序和时间</td><td colspan="1" rowspan="1">超额业绩奖励</td></tr><tr><td colspan="1" rowspan="2">1、转让方共同且连带地承诺，目标公司在2026年度、2027年度及2028年度内（合称“业绩承诺期”），经审计的归属目标公司母公司股东的净利润应分别不低于3,370 万元、4,770万元和6,860万元。（“承诺净利润”）</td><td colspan="1" rowspan="2">在受让方向转让方发出要求进行业绩补偿的通知后60日内（“补偿期限”），除受让方另行书面同意外，转让方应按照以下顺序及方式对受</td><td colspan="1" rowspan="2">若目标公司在业绩承诺期内完成的累计实</td></tr><tr><td colspan="1" rowspan="2">累计承诺净利润，受让方同意目标公司对转让方按照如下机制在业绩承诺期结束后</td></tr><tr><td colspan="1" rowspan="1">2、本次交易完成后，于业绩承诺期内的每个会计年度结束以后的4个月之内，受让方有权聘请具有证券业务资格的会计师事务所对目标公司当期业绩承诺实现情况按照中国会计准则等相关法律法规和/或证券监督管理机构的监管政策进行审核并出具年度审计报告，转让方应配合在上述期间内完成相关审计工作。</td><td colspan="1" rowspan="1">让方进行补偿：1、转让方先以转让对价按本协议约定缴纳各项税费后剩余金额的100%作为现金补偿上限；2、不足部分转让方应以向受让方无偿转让其持有的目标公司剩余股份</td></tr><tr><td colspan="1" rowspan="1">3、若目标公司在业绩承诺期中的任一会计年度完成的实际净利润低于当年承诺净利润的90%（含本数)，则转让方应当共同且连带地按照如下机制对受让方进行补偿：补偿金额=（当年承诺净利润一当年实现净利润）-当年承诺净利润*转让对价(扣除转让方应就本次交易缴纳的相应个人所得税后的金额）-3</td><td colspan="1" rowspan="1">的方式进行补偿，剩余股份的价值按照本次交易目标公司的整体估值乘以业绩完成率相应计算。为免疑义，业绩完成率=当期/累计实际净利润除以当年/累计承诺净利润;3、当进行上述1和/或2进行补偿时，</td><td colspan="1" rowspan="2">的4个月内进行一次性现金奖励：超额业绩奖励金额=（业绩承诺期累计实际净利润—业绩</td></tr><tr><td colspan="1" rowspan="2">4、若当年实现的实际净利润不低于当年承诺数的90%（含本数)，则无需在当年进行补偿。但业绩承诺期结束后，应计算三年累计实现净利润与三年累计承诺净利润的差额，如存在差额，则转让方应当共同且连带地按照如下机制对</td><td colspan="1" rowspan="2">各转让方应该按照其在本次交易中取得的转让对价的相对比例进行补偿。如按照上述补偿顺序及方式,受让方</td></tr><tr><td colspan="1" rowspan="1">承诺期累计承诺净利润)*50%；但超额</td></tr><tr><td colspan="1" rowspan="1">受让方进行补偿：补偿金额=（业绩承诺期累计承诺净利润—业绩承诺期累计实际净利润）-业绩承诺期累计承诺净利润*转让对价（扣除转让方应就本次交易缴纳的相应个人所得税后的金额）一业绩承诺期内已补偿金额</td><td colspan="1" rowspan="1">未在补偿期限内获得全部补偿金额或对应补偿股票/股份，转让方应就受让方未获得补偿的金额范围向受让方另行支付每日万分之五的滞纳金。</td><td colspan="2" rowspan="1">业绩奖励金额不超过转让总对价的20%，即6,426万元。</td></tr></table>

根据上述业绩补偿承诺的设置，业绩补偿承诺的充分性论证过程如下：

单位：万元
<table><tr><td rowspan=1 colspan=2>项目</td><td rowspan=1 colspan=1>2026年</td><td rowspan=1 colspan=1>2027年</td><td rowspan=1 colspan=1>2028年</td><td rowspan=1 colspan=1>合计</td></tr><tr><td rowspan=1 colspan=2>当年承诺净利润(不低于)</td><td rowspan=1 colspan=1>3,370.00</td><td rowspan=1 colspan=1>4,770.00</td><td rowspan=1 colspan=1>6,860.00</td><td rowspan=1 colspan=1>15,000.00</td></tr><tr><td rowspan=6 colspan=1>假设实现的净利润占承诺净利润的比例低于90%</td><td rowspan=1 colspan=1>1-1 假设实现的净利润占承诺净利润的比例</td><td rowspan=1 colspan=1>0.00%</td><td rowspan=1 colspan=1>0.00%</td><td rowspan=1 colspan=1>0.00%</td><td rowspan=1 colspan=1>0.00%</td></tr><tr><td rowspan=1 colspan=1>未实现承诺的净利润金额</td><td rowspan=1 colspan=1>3,370.00</td><td rowspan=1 colspan=1>4,770.00</td><td rowspan=1 colspan=1>6,860.00</td><td rowspan=1 colspan=1>15,000.00</td></tr><tr><td rowspan=1 colspan=1>补偿金额</td><td rowspan=1 colspan=1>2,714.51</td><td rowspan=1 colspan=1>2,714.51</td><td rowspan=1 colspan=1>2,714.51</td><td rowspan=1 colspan=1>8,143.54</td></tr><tr><td rowspan=1 colspan=1>1-2假设实现的净利润占承诺净利润的比例</td><td rowspan=1 colspan=1>89.99%</td><td rowspan=1 colspan=1>89.99%</td><td rowspan=1 colspan=1>89.99%</td><td rowspan=1 colspan=1>89.99%</td></tr><tr><td rowspan=1 colspan=1>未实现承诺的净利润金额</td><td rowspan=1 colspan=1>337.34</td><td rowspan=1 colspan=1>477.48</td><td rowspan=1 colspan=1>686.69</td><td rowspan=1 colspan=1>1,501.50</td></tr><tr><td rowspan=1 colspan=1>补偿金额</td><td rowspan=1 colspan=1>271.72</td><td rowspan=1 colspan=1>271.72</td><td rowspan=1 colspan=1>271.72</td><td rowspan=1 colspan=1>815.17</td></tr><tr><td rowspan=6 colspan=1>假设实现的净利润占承诺净利润的比例不低于90%(含本数）</td><td rowspan=1 colspan=1>2-1假设实现的净利润占承诺净利润的比例</td><td rowspan=1 colspan=1>90.00%</td><td rowspan=1 colspan=1>90.00%</td><td rowspan=1 colspan=1>90.00%</td><td rowspan=1 colspan=1>90.00%</td></tr><tr><td rowspan=1 colspan=1>未实现承诺的净利润金额</td><td rowspan=1 colspan=1>337.00</td><td rowspan=1 colspan=1>477.00</td><td rowspan=1 colspan=1>686.00</td><td rowspan=1 colspan=1>1,500.00</td></tr><tr><td rowspan=1 colspan=1>补偿金额</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>814.35</td><td rowspan=1 colspan=1>814.35</td></tr><tr><td rowspan=1 colspan=1>2-2 假设实现的净利润占承诺净利润的比例</td><td rowspan=1 colspan=1>99.99%</td><td rowspan=1 colspan=1>99.99%</td><td rowspan=1 colspan=1>99.99%</td><td rowspan=1 colspan=1>99.99%</td></tr><tr><td rowspan=1 colspan=1>未实现承诺的净利润金额</td><td rowspan=1 colspan=1>0.34</td><td rowspan=1 colspan=1>0.48</td><td rowspan=1 colspan=1>0.69</td><td rowspan=1 colspan=1>1.50</td></tr><tr><td rowspan=1 colspan=1>补偿金额</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>0.81</td><td rowspan=1 colspan=1>0.81</td></tr></table>

注：上表测算暂不考虑个人所得税等各类税费影响。

如上表所示，在极端情况下，各年业绩完成率均为 0.00%，补偿金额可达8,143.54 万元。业绩承诺补偿公式的设置与交易对价挂钩，在极端情况下的最大补偿金额与公司收购创始人 18.35%股权的交易对价相等。因此业绩承诺补偿的条款设计充分、合理。

## （2）上海通途业绩承诺补偿情况

本次交易中，公司合计收购上海通途51%股权，均来自创始人。关于上海通途业绩承诺主要条款设置情况如下：

<table><tr><td>业绩承诺条款 1、转让方共同且连带地承</td><td>补偿工具、顺序和时间</td><td>转让对价的锁定与解锁</td><td>超额业绩 奖励</td></tr><tr><td>诺，目标公司在 2026 年度、 2027年度及2028年度（合 称“业绩承诺期&quot;）内，经 审计的归属目标公司母公 司股东的净利润应累计不 低于人民币15,000万元 (“承诺净利润&quot;)。 2、本次交易完成后，于业 绩承诺期内的每个会计年 度结束以后的4个月之内， 受让方有权聘请具有证券 业务资格的会计师事务所 对目标公司当期业绩承诺 实现情况按照中国会计准 则等相关法律法规和/或证 券监督管理机构的监管政 策进行审核并出具年度审 计报告，转让方应配合在上 述期间内完成相关审计工 作。</td><td>在受让方向转让方发出要 求进行业绩补偿的通知后 60日内(“补偿期限&quot;)， 除受让方另行书面同意 外，转让方应按照以下顺 序及方式对受让方进行补 偿：1、转让方先以转让对 价按本协议约定缴纳各项 税费后剩余金额的36%作 为现金补偿上限; 2、不足部分转让方以其持 有的目标公司剩余股权进 行补偿，剩余股权的价值 按照本次交易目标公司的 整体估值（即人民币7亿 元）乘以业绩完成率相应 计算； 3、当进行上述1和/或2 进行补偿时，各转让方应 该按照其在本次交易中取</td><td>1、各方同意，本次交易交割后，转让方与 受让方应将本次转让对价中的 5000 万元 （以转让方依照各自的股权比例取得转让 对价)，以转让方自身或其为达成本次交易 专门设立的由转让方实际控制的特殊目的 实体的名义设立银行共管账户（“共管账 户&quot;）进行存放。未经受让方同意，转让方 不得单方面向共管账户开户行申请印鉴变 更及划款，否则受让方应向转让方支付不低 于违约划款对应金额的罚金。相应的，在未 达到约定的转回情形的情况下,受让方单方 面转回共管账户中的资金的，则受让方应向 转让方支付不低于违约划款对应金额的罚 金。 2、各方同意，在目标公司达到以下条件后 的10 个工作日内，受让方应批准一次性解 除对共管账户的共管资格并允许转让方自 由支配账户内的转让对价：根据受让方聘请 的具有证券业务资格的会计师事务所对目</td><td>若目标公 司实际完 成的净利 润超过承 诺净利润， 受让方将 对转让方 按照如下 机制在 2028年年 度审计报 告出具后 的3个月 内进行一 次性现金 奖励：超额 业绩奖励 金额=（业 绩承诺期</td></tr><tr><td>3、若目标公司在业绩承诺 期内未能完成业绩承诺，则 转让方应当共同且连带地 按照如下机制对受让方进 行补偿：补偿金额=（业绩 承诺期的承诺净利润一业 绩承诺期的实现净利润）÷ 业绩承诺期的承诺净利润* 转让对价（税后）</td><td>得的交易对价的比例进行 补偿。如按照上述补偿顺 序及方式,受让方未在补 偿期限内获得全部补偿金 额或对应股权,转让方应 就受让方未获得补偿的金 额范围向受让方另行支付 每日万分之二的滞纳金 （从补偿期限届满次日起 计算至完成补偿之日)。</td><td>标公司按照中国会计准则等相关法律法规 和/或证券监督管理机构的监管政策进行审 核并出具的年度审计报告，目标公司 2026 年归母净利润不低于4,000 万元。 3、各方同意，若转让方未达到6.2条约定 的解除条件，共管账户中的5,000 万元资金 应用于5.4条的补偿，并属于5.4.（a）约定 的补偿承诺中的一部分；若转让方达到6.2 条约定的解除条件，共管账户中的5,000 万 元资金应按6.2条解锁，但5.4.（a）约定的 补偿承诺金额不变。</td><td>实现净利 润一业绩 承诺期的 承诺净利 润） *50%; 但超额业 绩奖励金 额不超过 转让总对 价的20%， 即7,140万 元。</td></tr></table>

根据上述业绩补偿承诺的设置，业绩补偿承诺的充分性论证过程如下：

单位：万元
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2026年</td><td colspan="1" rowspan="1">2027年</td><td colspan="1" rowspan="1">2028年</td></tr><tr><td colspan="1" rowspan="1">累计承诺净利润（不低于）</td><td colspan="3" rowspan="1">15,000.00</td></tr><tr><td colspan="1" rowspan="1">①假设实现的净利润占承诺净利润的比例</td><td colspan="3" rowspan="1">99%</td></tr><tr><td colspan="1" rowspan="1">在①的情况下未实现承诺的净利润金额</td><td colspan="3" rowspan="1">150.00</td></tr><tr><td colspan="1" rowspan="1">在①的情况下补偿金额</td><td colspan="3" rowspan="1">357.00</td></tr><tr><td colspan="1" rowspan="1">②假设实现的净利润占承诺净利润的比例</td><td colspan="3" rowspan="1">0%</td></tr><tr><td colspan="1" rowspan="1">在②的情况下未实现承诺的净利润金额</td><td colspan="3" rowspan="1">15,000.00</td></tr><tr><td colspan="1" rowspan="1">在②的情况下补偿金额</td><td colspan="3" rowspan="1">35,700.00</td></tr></table>

注：上表测算暂不考虑个人所得税等各类税费影响。

根据上述测算结果可知，假设业绩承诺期累计实现的净利润占承诺净利润的比例为 99%，则补偿金额为 357.00 万元，该补偿金额大于未实现承诺的净利润金额150.00 万元。假设在极端情况下业绩承诺期累计实现的净利润均为 0.00 万元，则补偿金额等于交易对价金额 35,700.00 万元。除此之外，公司设置了转让对价的锁定与解锁条款，对公司支付的 5,000.00 万元对价设置共管账户，并与2026 年业绩达成情况挂钩，有效控制整合期风险。业绩承诺补偿公式的设置与交易对价挂钩，在极端情况下的最大补偿金额测算结果与交易对价（税后）金额相等，补偿能覆盖投资人的全部损失，因此业绩承诺补偿的条款设计充分、合理。

综上，在并购标的北京芯能持续亏损并全额计提商誉减值、芯片业务汇兑损失拖累公司业绩的情况下，发行人进一步收购贝特莱及上海通途两家芯片业务公司具备合理性、谨慎性。

## （三）发行人收购贝特莱及上海通途后新增商誉情况

公司于 2025 年 11 月 30 日召开董事会并于次日公告收购贝特莱及上海通途51%的股权，其中公司拟以自有资金32,130.00 万元收购贝特莱51.00%的股份；公司拟以自有资金 35,700.00 万元收购上海通途51.00%的股份。

2026 年度，公司非同一控制下收购贝特莱及上海通途新增商誉具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">贝特莱</td><td colspan="1" rowspan="1">上海通途</td></tr><tr><td colspan="1" rowspan="1">可辨认净资产公允价值（A）</td><td colspan="1" rowspan="1">18,934.68</td><td colspan="1" rowspan="1">7,554.34</td></tr><tr><td colspan="1" rowspan="1">账面价值（B）</td><td colspan="1" rowspan="1">13,964.49</td><td colspan="1" rowspan="1">3,337.58</td></tr><tr><td colspan="1" rowspan="1">资产评估增值确认的递延所得税负债（C=(A-B)*15%)</td><td colspan="1" rowspan="1">745.53</td><td colspan="1" rowspan="1">632.51</td></tr><tr><td colspan="1" rowspan="1">收购后合并报表中归属于合并方的资产组公允价值（D=(A-C)） *F)</td><td colspan="1" rowspan="1">9,276.47</td><td colspan="1" rowspan="1">3,530.13</td></tr><tr><td colspan="1" rowspan="1">支付的现金对价（E)</td><td colspan="1" rowspan="1">32,130.00</td><td colspan="1" rowspan="1">35,700.00</td></tr><tr><td colspan="1" rowspan="1">股权取得比例（F)</td><td colspan="1" rowspan="1">51.00%</td><td colspan="1" rowspan="1">51.00%</td></tr><tr><td colspan="1" rowspan="1">商誉（G=E-D)</td><td colspan="1" rowspan="1">22,853.53</td><td colspan="1" rowspan="1">32,169.87</td></tr></table>

## （四）发行人并购芯片业务公司形成的商誉是否存在大额计提减值风险

报告期内，公司芯片业务为 G2 Touch、江苏鼎茂和北京芯能三家公司芯片业务组成，上述公司均为非同一控制下收购取得，上述收购形成的商誉减值测试情况如下：

## 1、G2 Touch 商誉减值情况

2023 年 5 月 31 日，公司非同一控制下收购 G2 Touch 95.01%股权，并形成商誉。报告期各期末，G2Touch 资产组的商誉减值测试具体计算过程如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>商誉账面价值(A)</td><td rowspan=1 colspan=1>16,660.84</td><td rowspan=1 colspan=1>16,660.84</td><td rowspan=1 colspan=1>16,660.84</td></tr><tr><td rowspan=1 colspan=1>归属于少数股东权益的商誉(B)</td><td rowspan=1 colspan=1>875.04</td><td rowspan=1 colspan=1>875.04</td><td rowspan=1 colspan=1>875.04</td></tr><tr><td rowspan=1 colspan=1>整体商誉(C=A+B)</td><td rowspan=1 colspan=1>17,535.88</td><td rowspan=1 colspan=1>17,535.88</td><td rowspan=1 colspan=1>17,535.88</td></tr><tr><td rowspan=1 colspan=1>资产组账面价值（D)</td><td rowspan=1 colspan=1>737.95</td><td rowspan=1 colspan=1>677.39</td><td rowspan=1 colspan=1>1,098.01</td></tr><tr><td rowspan=1 colspan=1>包含整体商誉的资产组账面价值（E=C+D)</td><td rowspan=1 colspan=1>18,273.83</td><td rowspan=1 colspan=1>18,213.27</td><td rowspan=1 colspan=1>18,633.89</td></tr><tr><td rowspan=1 colspan=1>资产组可收回金额（F)</td><td rowspan=1 colspan=1>27,473.63</td><td rowspan=1 colspan=1>40,188.62</td><td rowspan=1 colspan=1>49,603.00</td></tr><tr><td rowspan=1 colspan=1>商誉减值金额（G=E-F)</td><td rowspan=1 colspan=1>：</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr></table>

注 1：资产组可收回金额按期末 CNY/KRW 汇率与评估数据的韩元金额计算得出；  
注 2：上表提及账面价值指以合并日公允价值持续计算的账面价值。

上表所示，报告期各期末，G2 Touch 资产组可回收金额均远高于包含整体商誉的资产组账面价值，故无需计提商誉减值准备。

## 2、江苏鼎茂商誉减值情况

2023年5月22日，公司经总裁办公会会议决议以1,800万收购江苏鼎茂60%的股权，本次收购商誉形成情况如下：

单位：万元
<table><tr><td>项目</td><td>金额</td></tr><tr><td>合并成本（A）</td><td>1,800.00</td></tr><tr><td colspan="1" rowspan="1">按持股比例计算取得的可辨认净资产公允价值份额（B)</td><td colspan="1" rowspan="1">404.31</td></tr><tr><td colspan="1" rowspan="1">商誉（合并成本大于合并中取得的可辨认净资产公允价值份额的差额）（C=A-B)</td><td colspan="1" rowspan="1">1,395.69</td></tr></table>

报告期内，江苏鼎茂净利润分别为-97.00 万元、222.51 万元和1,205.16 万元，经营业绩扭亏为盈且保持持续增长，通过结合当前的经营状况以及对未来经营情况的分析预测，判断该商誉未出现减值迹象，故不计提商誉减值准备。

## 3、北京芯能商誉减值情况

报告期各期末，北京芯能商誉减值计提情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2024年12月31日</td><td rowspan=1 colspan=1>2023年12月31日</td></tr><tr><td rowspan=1 colspan=1>商誉账面余额A</td><td rowspan=1 colspan=1>14,333.21</td><td rowspan=1 colspan=1>14,33.21</td></tr><tr><td rowspan=1 colspan=1>商誉减值准备余额B</td><td rowspan=1 colspan=1>14,333.21</td><td rowspan=1 colspan=1>9,434.17</td></tr><tr><td rowspan=1 colspan=1>商誉的账面价值C=A-B</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>4,899.04</td></tr><tr><td rowspan=1 colspan=1>商誉的账面价值（期初）D</td><td rowspan=1 colspan=1>4,899.04</td><td rowspan=1 colspan=1>13,437.41</td></tr><tr><td rowspan=1 colspan=1>未确认归属于少数股东权益的商誉账面价值（期初）E</td><td rowspan=1 colspan=1>3,266.03</td><td rowspan=1 colspan=1>8,958.27</td></tr><tr><td rowspan=1 colspan=1>整体商誉余额F=D+E</td><td rowspan=1 colspan=1>8,165.07</td><td rowspan=1 colspan=1>22,395.68</td></tr><tr><td rowspan=1 colspan=1>不含商誉资产组账面价值G</td><td rowspan=1 colspan=1>8,444.93</td><td rowspan=1 colspan=1>11,934.93</td></tr><tr><td rowspan=1 colspan=1>确定包含整体商誉的资产组账面价值H=F+G</td><td rowspan=1 colspan=1>16,610.00</td><td rowspan=1 colspan=1>34,330.61</td></tr><tr><td rowspan=1 colspan=1>预计未来现金流量法资产组现值I</td><td rowspan=1 colspan=1>7,600.00</td><td rowspan=1 colspan=1>20,100.00</td></tr><tr><td rowspan=1 colspan=1>公允价值减处置费用后净值J</td><td rowspan=1 colspan=1>7,456.20</td><td rowspan=1 colspan=1>19,890.00</td></tr><tr><td rowspan=1 colspan=1>测算资产组可收回金额 K=（MAX(I,J))</td><td rowspan=1 colspan=1>7,600.00</td><td rowspan=1 colspan=1>20,100.00</td></tr><tr><td rowspan=1 colspan=1>计算整体商誉减值损失L=H-K</td><td rowspan=1 colspan=1>9,010.00</td><td rowspan=1 colspan=1>14,230.61</td></tr><tr><td rowspan=1 colspan=1>当期应计提归属公司的商誉减值损失M=L*60%</td><td rowspan=1 colspan=1>4,899.04</td><td rowspan=1 colspan=1>8,538.37</td></tr></table>

注 1：2024 年度当期应计提归属公司的商誉减值损失为 5,406.00 万元，但公司商誉账面价值仅剩 4,899.04 万元，故 2024 年商誉减值准备最终计提金额为 4,899.04 万元；注 2：上表提及账面价值指以合并日公允价值持续计算的账面价值。

由上表所示，北京芯能商誉于2024 年末已全额计提减值。2025 年末公司对北京芯能商誉相关的资产组计提减值3,682.52 万元，其中固定资产计提2,858.57万元、使用权资产计提 163.47 万元、长期待摊费用计提 660.48 万元，计提减值后商誉相关的资产组账面价值为 1,519.59 万元。2025 年北京芯能与商誉相关资产组的可收回金额参考上海东洲资产评估有限公司出具的《探路者控股集团有限公司以财务报告为目的进行资产减值测试所涉及的北京芯能电子科技有限公司相关资产组的可回收价值资产评估报告》（东洲评报字【2026】第1148 号），以2025 年 12 月 31 日为评估基准日，采用资产组预计未来现金流量的现值作为评估方法。经评估，委托评估资产的可回收价值为1,900.00 万元，未发现新增减值迹象。

## 4、贝特莱商誉减值情况

2025 年12月1日，公司公告将非同一控制下收购贝特莱原股东持有的 51%股权，该收购将于 2026 年形成商誉 22,853.53 万元。2023 年度至 2026 年第一季度，贝特莱营业收入分别为 15,096.47 万元、17,938.53 万元、25,371.03 万元和6,675.63 万元，净利润分别为-2,720.27 万元、 -2,530.92 万元、1,364.75 万元和716.01 万元，经营业绩较好，通过结合当前的经营状况以及对未来经营情况的分析预测，判断该商誉未出现减值迹象，故不计提商誉减值准备。

## 5、上海通途商誉减值情况

2025 年12月1日，公司公告将非同一控制收购上海通途原股东持有的 51%股权，该收购将于 2026 年形成商誉 32,169.87 万元。2023 年度至 2026 年第一季度，上海通途营业收入分别为 1,908.42、5,941.18、16,106.73 和 4,414.41 万元，净利润分别为-452.66 万元、-781.51 万元、2,204.96 万元和 1,305.46 万元，经营业绩较好，通过结合当前的经营状况以及对未来经营情况的分析预测，判断该商誉未出现减值迹象，故不计提商誉减值准备。

综上，报告期内，G2 Touch、江苏鼎茂财务状况及盈利能力较好，公司对G2 Touch、江苏鼎茂未计提商誉减值谨慎合理，不存在大额计提商誉减值的风险。2025 年12月1日，公司公告将非同一控制下分别收购贝特莱和上海通途原股东持有的 51%股权，将新增商誉金额分别为 22,853.53 万元和 32,169.87 万元，报告期内，贝特莱和上海通途经营业务总体保持稳定，通过结合当前的经营状况以及对未来经营情况的分析预测，判断该商誉未出现减值迹象，预计不存在大额计提商誉减值的风险。

四、结合报告期末库存商品的主要内容、库龄、期后结转情况、是否存在滞销、可变现净值与账面价值对比情况等说明跌价准备计提是否充分，是否存在大额计提减值的风险

（一）报告期末库存商品的主要内容、库龄、期后结转情况、是否存在滞销

公司库存商品主要包括户外业务产品和芯片业务产品。针对户外业务产品，结合行业特点，公司对户外业务产成品按产品季过季情况执行阶梯式计提存货跌价准备。

对于户外业务发出商品，因其已在运送途中，尚未满足收入确认条件，但销售价格已基本确定、销售费用可合理预估，可变现净值能够可靠计量。公司按照扣除销售费用后的不含税售价确定可变现净值，按照可变现净值与账面成本孰低的原则计提存货跌价准备。该政策与产成品按产品季计提形成互补，共同构成户外业务完整的存货跌价准备计提体系。

针对芯片业务产品，因芯片行业技术迭代快产品定制化程度较高，跌价风险主要源于市场变化而非库龄长短。公司按照存货成本与可变现净值孰低计量的原则确认存货跌价准备，即以存货的预计售价减去估计的销售费用和相关税费后的金额与账面成本进行比较，以更及时、准确地反映芯片存货的减值风险。

基于上述存货跌价计提政策，报告期各期末，公司库存商品的主要内容、库龄、期后结转情况、是否存在滞销等具体情况如下：

## 1、2025 年末

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面金额</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>期后结转</td><td rowspan=1 colspan=1>期后尚未结转金额</td><td rowspan=1 colspan=1>存货跌价准备</td></tr><tr><td rowspan=1 colspan=1>户外产品</td><td rowspan=1 colspan=1>52,411.97</td><td rowspan=1 colspan=1>39,076.83</td><td rowspan=1 colspan=1>8,836.18</td><td rowspan=1 colspan=1>3,670.72</td><td rowspan=1 colspan=1>1,496.91</td><td rowspan=1 colspan=1>20,002.29</td><td rowspan=1 colspan=1>32,409.68</td><td rowspan=1 colspan=1>11,054.45</td></tr><tr><td rowspan=1 colspan=1>芯片产品</td><td rowspan=1 colspan=1>3,003.81</td><td rowspan=1 colspan=1>851.71</td><td rowspan=1 colspan=1>78.09</td><td rowspan=1 colspan=1>1,662.58</td><td rowspan=1 colspan=1>411.43</td><td rowspan=1 colspan=1>681.61</td><td rowspan=1 colspan=1>2,322.20</td><td rowspan=1 colspan=1>2,137.62</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>55,415.78</td><td rowspan=1 colspan=1>39,928.54</td><td rowspan=1 colspan=1>8,914.27</td><td rowspan=1 colspan=1>5,333.30</td><td rowspan=1 colspan=1>1,908.35</td><td rowspan=1 colspan=1>20,683.90</td><td rowspan=1 colspan=1>34,731.89</td><td rowspan=1 colspan=1>13,192.07</td></tr></table>

注：期后结转金额统计至 2026 年 3 月 31 日，下同。

## 2、2024 年末

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面金额</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>期后结转</td><td rowspan=1 colspan=1>期后尚未结转金额</td><td rowspan=1 colspan=1>存货跌价准备</td></tr><tr><td rowspan=1 colspan=1>户外产品</td><td rowspan=1 colspan=1>39,836.22</td><td rowspan=1 colspan=1>30,892.93</td><td rowspan=1 colspan=1>6,869.89</td><td rowspan=1 colspan=1>1,920.12</td><td rowspan=1 colspan=1>806.40</td><td rowspan=1 colspan=1>27,291.67</td><td rowspan=1 colspan=1>12,544.55</td><td rowspan=1 colspan=1>7,621.66</td></tr><tr><td rowspan=1 colspan=1>芯片产品</td><td rowspan=1 colspan=1>2,796.03</td><td rowspan=1 colspan=1>636.12</td><td rowspan=1 colspan=1>1,677.20</td><td rowspan=1 colspan=1>481.22</td><td rowspan=1 colspan=1>1.49</td><td rowspan=1 colspan=1>677.39</td><td rowspan=1 colspan=1>2,118.64</td><td rowspan=1 colspan=1>2,232.96</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>42,632.26</td><td rowspan=1 colspan=1>31,529.06</td><td rowspan=1 colspan=1>8,547.09</td><td rowspan=1 colspan=1>2,401.35</td><td rowspan=1 colspan=1>807.88</td><td rowspan=1 colspan=1>27,969.06</td><td rowspan=1 colspan=1>14,663.19</td><td rowspan=1 colspan=1>9,854.61</td></tr></table>

单位：万元

## 3、2023 年末

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面金额</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>期后结转</td><td rowspan=1 colspan=1>期后尚未结转金额</td><td rowspan=1 colspan=1>存货跌价准备</td></tr><tr><td rowspan=1 colspan=1>户外产品</td><td rowspan=1 colspan=1>38,345.29</td><td rowspan=1 colspan=1>27,973.64</td><td rowspan=1 colspan=1>8,078.14</td><td rowspan=1 colspan=1>2,400.52</td><td rowspan=1 colspan=1>760.03</td><td rowspan=1 colspan=1>35,718.44</td><td rowspan=1 colspan=1>2,626.85</td><td rowspan=1 colspan=1>8,689.01</td></tr><tr><td rowspan=1 colspan=1>芯片产品</td><td rowspan=1 colspan=1>2,617.18</td><td rowspan=1 colspan=1>2,122.39</td><td rowspan=1 colspan=1>493.08</td><td rowspan=1 colspan=1>1.70</td><td rowspan=1 colspan=1>0.00</td><td rowspan=1 colspan=1>554.11</td><td rowspan=1 colspan=1>2,063.06</td><td rowspan=1 colspan=1>1,711.11</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>40,962.46</td><td rowspan=1 colspan=1>30,096.03</td><td rowspan=1 colspan=1>8,571.22</td><td rowspan=1 colspan=1>2,402.23</td><td rowspan=1 colspan=1>760.03</td><td rowspan=1 colspan=1>36,272.55</td><td rowspan=1 colspan=1>4,689.91</td><td rowspan=1 colspan=1>10,400.13</td></tr></table>

报告期内，公司库存商品以户外产品和芯片产品为主。报告期内，公司户外产品库龄主要在 2 年以内，占户外业务库存商品账面余额比例分别为 94.02%、94.80%和 91.42%，总体保持稳定。

2023 年末户外产品期后结转金额为35,718.44 万元，结转比例较高，期后结转情况良好，且公司已计提充足的存货跌价准备。2024 年末户外产品期后结转金额为27,291.67 万元，2024 年末户外产品期后尚未结转金额虽暂时高于存货跌价准备金额，但参照 2023 年末库存商品的经验，经过 2年多的消化后，期后未结转金额预计将逐步降至存货跌价准备金额以下。2025 年末户外产品期后结转金额为 20,002.29 万元，期后结转比例相对较低，主要系统计期间仅覆盖 2026年第一季度所致，具有合理性。综上，公司户外业务存货跌价准备计提较为充分，发生大额存货跌价风险的可能性较小。

报告期内，芯片业务库存商品存货跌价计提金额分别为 1,711.11 万元、2,232.96 万元和 2,137.62 万元，期后未结转金额分别为 2,063.06 万元、2,118.64万元和 2,322.20 万元，计提金额基本可涵盖未结转金额，跌价准备计提较为充分。报告期各期末，公司芯片业务库存商品计提大额存货跌价主要系子公司北京芯能业绩不及预期、持续亏损导致存货出现积压。截至 2025 年末，北京芯能结余的库存商品账面价值仅为30.18 万元，即使全额计提跌价，发生大额存货跌价风险可能性较小。

## （二）报告期末库存商品可变现净值与账面价值对比情况

报告期各期末，公司库存商品可变现净值与账面价值对比情况如下：

## 1、2025 年末

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面价值（A）</td><td rowspan=1 colspan=1>可变现净值（B)</td><td rowspan=1 colspan=1>差异金额（C=B-A)</td></tr><tr><td rowspan=1 colspan=1>户外业务</td><td rowspan=1 colspan=1>41,357.52</td><td rowspan=1 colspan=1>60,727.30</td><td rowspan=1 colspan=1>19,369.78</td></tr><tr><td rowspan=1 colspan=1>芯片业务</td><td rowspan=1 colspan=1>866.19</td><td rowspan=1 colspan=1>3,488.77</td><td rowspan=1 colspan=1>2,622.58</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>42,223.71</td><td rowspan=1 colspan=1>64,216.07</td><td rowspan=1 colspan=1>21,992.36</td></tr></table>

## 2、2024 年末

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面价值（A）</td><td rowspan=1 colspan=1>可变现净值（B)</td><td rowspan=1 colspan=1>差异金额（C=B-A)</td></tr><tr><td rowspan=1 colspan=1>户外业务</td><td rowspan=1 colspan=1>32,214.57</td><td rowspan=1 colspan=1>47,322.43</td><td rowspan=1 colspan=1>15,107.87</td></tr><tr><td rowspan=1 colspan=1>芯片业务</td><td rowspan=1 colspan=1>563.07</td><td rowspan=1 colspan=1>1,485.63</td><td rowspan=1 colspan=1>922.56</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>32,777.64</td><td rowspan=1 colspan=1>48,808.06</td><td rowspan=1 colspan=1>16,030.42</td></tr></table>

## 3、2023 年末

单位：万元

<table><tr><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面价值（A）</td><td rowspan=1 colspan=1>可变现净值（B)</td><td rowspan=1 colspan=1>差异金额（C=B-A)</td></tr><tr><td rowspan=1 colspan=1>户外业务</td><td rowspan=1 colspan=1>29,656.27</td><td rowspan=1 colspan=1>44,585.76</td><td rowspan=1 colspan=1>14,929.49</td></tr><tr><td rowspan=1 colspan=1>芯片业务</td><td rowspan=1 colspan=1>906.06</td><td rowspan=1 colspan=1>1,734.48</td><td rowspan=1 colspan=1>828.42</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>30,562.34</td><td rowspan=1 colspan=1>46,320.24</td><td rowspan=1 colspan=1>15,757.91</td></tr></table>

由上表所示，报告期各期末，公司户外产品和芯片产品的账面价值均低于可变现净值，即公司库存商品存货跌价计提充分，具备合理性。

综上，公司已结合库存商品的主要内容、库龄、期后结转、滞销情况及可变现净值等因素，对存货跌价准备进行了充分计提，不存在大额计提减值的风险。

五、结合按组合计提坏账准备的应收账款的主要客户资信情况、账龄、回款情况、是否逾期等说明相关坏账准备计提是否充分

## （一）按组合计提坏账准备的应收账款的主要客户资信情况、账龄、回款情况

报告期各期末，公司按组合计提坏账准备的应收账款的主要客户资信情况、账龄、回款情况如下：

## 1、2025 年末

单位：万元

<table><tr><td rowspan=2 colspan=1>客户名称</td><td rowspan=2 colspan=1>资信情况</td><td rowspan=2 colspan=1>应收账款余额</td><td rowspan=1 colspan=4>账龄</td><td rowspan=2 colspan=1>期后回款金额</td><td rowspan=2 colspan=1>期后回款比例</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>3年及以上</td></tr><tr><td rowspan=1 colspan=1>美妙商贸(苏州)有限公司</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>5,497.55</td><td rowspan=1 colspan=1>5,497.55</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>=</td></tr><tr><td rowspan=1 colspan=1>上海探路者户外用品有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>3,911.79</td><td rowspan=1 colspan=1>2,278.76</td><td rowspan=1 colspan=1>140.18</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>1,492.85</td><td rowspan=1 colspan=1>47.97</td><td rowspan=1 colspan=1>1.23%</td></tr><tr><td rowspan=1 colspan=1>京东方科技（香港）有限公司及其关联客户</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>2,822.31</td><td rowspan=1 colspan=1>2,822.31</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>2,774.30</td><td rowspan=1 colspan=1>98.30%</td></tr><tr><td rowspan=1 colspan=1>北京山水乐途体育文化发展有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>1,811.98</td><td rowspan=1 colspan=1>661.67</td><td rowspan=1 colspan=1>645.56</td><td rowspan=1 colspan=1>504.75</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>57.69</td><td rowspan=1 colspan=1>3.18%</td></tr><tr><td rowspan=1 colspan=1>杭州微影传感电子有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>754.21</td><td rowspan=1 colspan=1>754.21</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>=</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>754.21</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>14,797.84</td><td rowspan=1 colspan=1>12,014.51</td><td rowspan=1 colspan=1>785.74</td><td rowspan=1 colspan=1>504.75</td><td rowspan=1 colspan=1>1,492.85</td><td rowspan=1 colspan=1>3,634.17</td><td rowspan=1 colspan=1>24.56%</td></tr><tr><td rowspan=1 colspan=2>组合计提合计数</td><td rowspan=1 colspan=1>21,063.03</td><td rowspan=1 colspan=1>17,702.44</td><td rowspan=1 colspan=1>1,208.43</td><td rowspan=1 colspan=1>601.40</td><td rowspan=1 colspan=1>1,550.77</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=2>占比</td><td rowspan=1 colspan=1>70.26%</td><td rowspan=1 colspan=1>67.87%</td><td rowspan=1 colspan=1>65.02%</td><td rowspan=1 colspan=1>83.93%</td><td rowspan=1 colspan=1>96.26%</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1>-</td></tr></table>

注：期后回款统计至 2026 年 3 月 31 日，下同。

## 2、2024 年末

单位：万元

<table><tr><td rowspan=2 colspan=1>客户名称</td><td rowspan=2 colspan=1>资信情况</td><td rowspan=2 colspan=1>应收账款余额</td><td rowspan=1 colspan=4>账龄</td><td rowspan=2 colspan=1>期后回款金额</td><td rowspan=2 colspan=1>期后回款比例</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>3年及以上</td></tr><tr><td rowspan=1 colspan=1>美妙商贸（苏州）有限公司</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>8,004.91</td><td rowspan=1 colspan=1>8,004.91</td><td rowspan=1 colspan=1>■</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>8,004.91</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>京东方科技（香港）有限公司及其关联客户</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>4,076.91</td><td rowspan=1 colspan=1>4,076.91</td><td rowspan=1 colspan=1>=</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>4,076.91</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>上海探路者户外用品有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>3,113.59</td><td rowspan=1 colspan=1>1,287.56</td><td rowspan=1 colspan=1>333.18</td><td rowspan=1 colspan=1>543.54</td><td rowspan=1 colspan=1>949.30</td><td rowspan=1 colspan=1>1,528.54</td><td rowspan=1 colspan=1>49.09%</td></tr><tr><td rowspan=1 colspan=1>山东中顶运商贸有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>1,761.96</td><td rowspan=1 colspan=1>1,192.15</td><td rowspan=1 colspan=1>457.01</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>112.80</td><td rowspan=1 colspan=1>1,761.96</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>北京山水乐途体育文化发展有限公司及其关联方</td><td rowspan=1 colspan=1>经营情况正常，未列入失信被执行人</td><td rowspan=1 colspan=1>1,698.03</td><td rowspan=1 colspan=1>645.56</td><td rowspan=1 colspan=1>682.76</td><td rowspan=1 colspan=1>369.71</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>548.11</td><td rowspan=1 colspan=1>32.28%</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>18,655.40</td><td rowspan=1 colspan=1>15,207.09</td><td rowspan=1 colspan=1>1,472.95</td><td rowspan=1 colspan=1>913.25</td><td rowspan=1 colspan=1>1,062.10</td><td rowspan=1 colspan=1>15,920.43</td><td rowspan=1 colspan=1>85.34%</td></tr><tr><td rowspan=1 colspan=2>组合计提合计数</td><td rowspan=1 colspan=1>25,177.91</td><td rowspan=1 colspan=1>21,338.91</td><td rowspan=1 colspan=1>1,659.41</td><td rowspan=1 colspan=1>1,111.26</td><td rowspan=1 colspan=1>1,068.33</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>占比</td><td rowspan=1 colspan=1>74.09%</td><td rowspan=1 colspan=1>71.26%</td><td rowspan=1 colspan=1>88.76%</td><td rowspan=1 colspan=1>82.18%</td><td rowspan=1 colspan=1>99.42%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

## 3、2023 年末

单位：万元

<table><tr><td colspan="1" rowspan="2">客户名称</td><td colspan="1" rowspan="2">资信情况</td><td colspan="1" rowspan="2">应收账款余额</td><td colspan="4" rowspan="1">账龄</td><td colspan="1" rowspan="2">期后回款金额</td><td colspan="1" rowspan="2">期后回款比例</td></tr><tr><td colspan="1" rowspan="1">1年以内</td><td colspan="1" rowspan="1">1-2年</td><td colspan="1" rowspan="1">2-3年</td><td colspan="1" rowspan="1">3年及以上</td></tr><tr><td colspan="1" rowspan="1">美妙商贸（苏州）有限公司</td><td colspan="1" rowspan="1">经营情况正常，未列入失信被执行人</td><td colspan="1" rowspan="1">8,505.96</td><td colspan="1" rowspan="1">8,505.96</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">8,505.96</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="1" rowspan="1">京东方科技（香港）有限公司及其关联客户</td><td colspan="1" rowspan="1">经营情况正常，未列入失信被执行人</td><td colspan="1" rowspan="1">4,192.82</td><td colspan="1" rowspan="1">4,192.82</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">=</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">4,192.82</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="1" rowspan="1">上海探路者户外用品有限公司及其关联方</td><td colspan="1" rowspan="1">经营情况正常，未列入失信被执行人</td><td colspan="1" rowspan="1">3,836.73</td><td colspan="1" rowspan="1">2,133.27</td><td colspan="1" rowspan="1">754.16</td><td colspan="1" rowspan="1">21.44</td><td colspan="1" rowspan="1">927.87</td><td colspan="1" rowspan="1">2,390.42</td><td colspan="1" rowspan="1">62.30%</td></tr><tr><td colspan="1" rowspan="1">山东中顶运商贸有限公司及其关联方</td><td colspan="1" rowspan="1">经营情况正常，未列入失信被执行人</td><td colspan="1" rowspan="1">3,280.71</td><td colspan="1" rowspan="1">457.01</td><td colspan="1" rowspan="1">■</td><td colspan="1" rowspan="1">2,823.70</td><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">3,280.71</td><td colspan="1" rowspan="1">100.00%</td></tr><tr><td colspan="1" rowspan="1">北京山水乐途体育文化发展有限公司及其关联方</td><td colspan="1" rowspan="1">经营情况正常,未列入失信被执行人</td><td colspan="1" rowspan="1">1,940.56</td><td colspan="1" rowspan="1">683.00</td><td colspan="1" rowspan="1">1,257.56</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">1,436.20</td><td colspan="1" rowspan="1">74.01%</td></tr><tr><td colspan="2" rowspan="1">小计</td><td colspan="1" rowspan="1">21,756.78</td><td colspan="1" rowspan="1">15,972.07</td><td colspan="1" rowspan="1">2,011.72</td><td colspan="1" rowspan="1">2,845.13</td><td colspan="1" rowspan="1">927.87</td><td colspan="1" rowspan="1">19,806.11</td><td colspan="1" rowspan="1">91.03%</td></tr><tr><td colspan="2" rowspan="1">组合计提合计数</td><td colspan="1" rowspan="1">28,165.68</td><td colspan="1" rowspan="1">21,486.34</td><td colspan="1" rowspan="1">2,794.42</td><td colspan="1" rowspan="1">2,893.02</td><td colspan="1" rowspan="1">991.91</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="2" rowspan="1">占比</td><td colspan="1" rowspan="1">77.25%</td><td colspan="1" rowspan="1">74.34%</td><td colspan="1" rowspan="1">71.99%</td><td colspan="1" rowspan="1">98.34%</td><td colspan="1" rowspan="1">93.54%</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr></table>

由上表可知，报告期各期末，公司按组合计提坏账准备的应收账款的主要客户资信情况较好，账龄主要在1 年以内。报告期各期末，公司按组合计提坏账准备的应收账款的主要客户应收账款余额期后回款比例分别为 91.03%、85.34%和24.56%，2023 年度和2024 年度期后回款情况较好，2025 年末期后回款较少，主要系户外业务主要客户回款较少所致，具体情况如下：

## （1）美妙商贸（苏州）有限公司

根据2025 年公司与美妙商贸签订的2025 年度《客户授信协议》显示，美妙商贸应确保截至 2025 年 12 月 31 日其欠付甲方的信贷本金总额小于或等于5,900万元（未扣减《美妙三年业务合作协议》项下的补贴金额）。2025 年末公司对美妙商贸（苏州）有限公司应收账款余额为5,497.55 万元，以满足客户授信协议的要求。考虑该公司应收账款余额均在1年以内，根据预计信用损失率，该公司计提坏账准备金额为558.86 万元。

（2）上海探路者户外用品有限公司及其关联方和北京山水乐途体育文化发展有限公司及其关联方

报告期内，上海探路者户外用品有限公司及其关联方和北京山水乐途体育文化发展有限公司及其关联方存在不同程度逾期情况，公司对上述两家客户计提充分的坏账准备，具体情况详见本回复之“问题 2”之“五、（二）按组合计提坏账准备的应收账款的主要客户逾期情况，说明相关坏账准备计提是否充分”。

## （二）按组合计提坏账准备的应收账款的主要客户逾期情况，说明相关坏账准备计提是否充分

公司按组合计提坏账准备的应收账款的主要客户中，上海探路者户外用品有限公司及其关联方和北京山水乐途体育文化发展有限公司及其关联方存在应收账款逾期的情形，截至 2025 年末，上述两家公司仍存在逾期款项，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>授信额度</td><td rowspan=1 colspan=1>应收账款余额</td><td rowspan=1 colspan=1>逾期金额</td><td rowspan=1 colspan=1>坏账准备</td><td rowspan=1 colspan=1>坏账准备/逾期金额</td><td rowspan=1 colspan=1>备注</td></tr><tr><td rowspan=1 colspan=1>上海探路者户外用品有限公司及其关联方</td><td rowspan=1 colspan=1>2025年12月31日前欠款总额应不超过【2300】万元</td><td rowspan=1 colspan=1>3,911.79</td><td rowspan=1 colspan=1>1,611.79</td><td rowspan=1 colspan=1>1,586.06</td><td rowspan=1 colspan=1>98.40%</td><td rowspan=1 colspan=1>抵押价值900万元房产、已缴纳130万元联营业务保证金</td></tr><tr><td rowspan=1 colspan=1>北京山水乐途体育文化发展有限公司及其关联方</td><td rowspan=1 colspan=1>2025年12月31日前欠款总额应不超过【1300】万元</td><td rowspan=1 colspan=1>1,811.98</td><td rowspan=1 colspan=1>511.98</td><td rowspan=1 colspan=1>480.38</td><td rowspan=1 colspan=1>93.83%</td><td rowspan=1 colspan=1>已缴纳482.85万元联营业务保证金</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>5,723.77</td><td rowspan=1 colspan=1>2,123.77</td><td rowspan=1 colspan=1>2,066.44</td><td rowspan=1 colspan=1>97.30%</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>占各期末组合计提方式下应收账款余额比重</td><td rowspan=1 colspan=1>27.17%</td><td rowspan=1 colspan=1>10.08%</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td></tr></table>

由上表可知，2025 年末，上海探路者户外用品有限公司及其关联方逾期金额 1,611.79 万元，公司已计提坏账准备1,586.06 万元，基本覆盖逾期金额，且该公司已向公司抵押 900 万元房产及 130 万元保证金，保障措施较为充分。2025年末，北京山水乐途体育文化发展有限公司及其关联方逾期金额 511.98 万元，公司已计提坏账准备 480.38 万元，基本覆盖逾期金额，其公司已收取 482.85 万元保证金，该保证金具有优先受偿权，保障措施较为充分。可见，公司基于组合模型及历史损失率对上述客户已足额计提坏账准备，整体坏账准备能够覆盖可预见的信用损失。

综上，报告期内，公司按组合计提坏账准备的应收账款的主要客户资信情况较好，账龄主要在 1 年以内，期后回款总体良好；报告期内，公司少量客户存在逾期欠款，但已通过抵押较高价值资产、缴纳保证金等方式有效降低了回款风险。公司基于组合模型及历史损失率已足额计提坏账准备，整体能够覆盖可预见的信用损失，应收账款坏账准备计提充分。

六、结合襄阳合伙及苏州合伙的投资范围、已投资标的情况、已投资标的是否均与发行人存在业务协同性、是否存在尚未投资金额及后续投资计划等说明未将以上两家合伙企业认定为财务性投资的合理性；补充华锡影视、北京元纬、乾境生物的认缴及实缴时间、金额、是否存在尚未实缴的金额，如是，说明后续计划，是否构成拟投入的财务性投资；自本次发行相关董事会决议日前六个月起至今，发行人已实施或拟实施的财务性投资（包括类金融投资）情况，是否已从本次募集资金总额中扣除

（一）结合襄阳合伙及苏州合伙的投资范围、已投资标的情况、已投资标的是否均与发行人存在业务协同性、是否存在尚未投资金额及后续投资计划等说明未将以上两家合伙企业认定为财务性投资的合理性

## 1、襄阳东证和同探路者体育产业基金合伙企业（有限合伙）

截至2026 年4 月末，襄阳东证和同探路者体育产业基金合伙企业（有限合伙）的投资范围明确，重点布局体育、大消费等领域，该企业现存的对外投资具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>被投资企业名称</td><td rowspan=1 colspan=1>首次持股日期</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>认缴金额</td><td rowspan=1 colspan=1>实缴金额</td><td rowspan=1 colspan=1>尚未投资金额及后续投资计划</td><td rowspan=1 colspan=2>主营业务/主要产品</td><td rowspan=1 colspan=1>与发行人的协同性</td></tr><tr><td rowspan=3 colspan=1>四川中科兴业高新材料有限公司</td><td rowspan=3 colspan=1>2020-06-12</td><td rowspan=3 colspan=1>2.7299%</td><td rowspan=2 colspan=1>465.00</td><td rowspan=2 colspan=1>465.00</td><td rowspan=1 colspan=1></td><td rowspan=3 colspan=2>聚芳硫醚矾（PASS）和聚苯硫醚（PPS）等特种高分子聚合材料及其深加工制品的研发、生产、销售，业务范围覆盖树脂合成、改性工程塑料及其制品研发制造，并重点布局人形机器人（含智能外骨骼产品）高性能耐磨材料领域。该公司属于户外智能装备产业链上游的关键材料供应商</td><td rowspan=3 colspan=1>该公司的主要产业属于体育类，与公司户外业务具有较强的协同性，属于户外业务的下游相关产业，方便公司拓展下游销售渠道，拓展公司户外业务的场景应用，满足公司户外业务的发展方向。</td></tr><tr><td rowspan=1 colspan=1>无</td><td rowspan=1 colspan=1>其制品</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>北京万国天骐体育股份有限公司</td><td rowspan=1 colspan=1>2019-11-28</td><td rowspan=1 colspan=1>2.25%</td><td rowspan=1 colspan=1>172.8028</td><td rowspan=1 colspan=1>172.8028</td><td rowspan=1 colspan=1>无</td><td rowspan=1 colspan=2>击剑培训服务、击剑赛事举办及击剑装备销售</td><td rowspan=1 colspan=1>该公司的主要产业属于体育类，与公司户外业务具有较强的协同性，属于户外业务的下游相关产业，方便公司拓展下游销售渠道，拓展公司户外业务的场景应用，满足公司户外业务的发展方向。</td></tr><tr><td rowspan=1 colspan=1>北京势至山水文化传播有限公司</td><td rowspan=1 colspan=1>2019-05-31</td><td rowspan=1 colspan=1>9.0918%</td><td rowspan=1 colspan=1>29.33</td><td rowspan=1 colspan=1>29.33</td><td rowspan=1 colspan=1>无</td><td rowspan=1 colspan=2>专注于户外体育赛事策划运营及“体育+旅游”产品打造</td><td rowspan=1 colspan=1>该公司的主要产业属于体育类，与公司户外业务具有较强的协同性，属于户外业务的下游相关产业，方便公司拓展下游销售渠道，拓展公司户外业务的场景应用，满足公司户外业务的发展方向。</td></tr></table>

由上表可知，襄阳东证对外投资的企业主营业务/主要产品均与发行人户外业务具有高度关联性及协同效应，一方面可协助拓展户外业务有力拓展了下游渠道的深度与广度；另一方面拓展公司户外智能装备提供了上游供应商渠道，与公司户外业务具有较高的相关性和较强的协同效应。因此，公司向襄阳东证和同探路者体育产业基金合伙企业（有限合伙）的投资属于围绕产业链、下游以获取技术、原料或者渠道为目的的产业投资，不确认为财务性投资具备合理性。

## 2、苏州荷塘创芯创业投资合伙企业（有限合伙）

截至2026 年4 月末，苏州荷塘创芯创业投资合伙企业（有限合伙）的投资范围对半导体相关行业的投资，重点布局第三代半导体产业链中具备核心技术的科技项目，该企业现存的对外投资具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">被投资企业名称</td><td colspan="1" rowspan="1">首次持股日期</td><td colspan="1" rowspan="1">持股比例</td><td colspan="1" rowspan="1">认缴金额</td><td colspan="1" rowspan="1">实缴金额</td><td colspan="1" rowspan="1">尚未投资金额及后续投资计划</td><td colspan="1" rowspan="1">主营业务/主要产品</td><td colspan="1" rowspan="1">与发行人业务协同性</td></tr><tr><td colspan="1" rowspan="1">苏州纳维科技有限公司</td><td colspan="1" rowspan="1">2023-07-31</td><td colspan="1" rowspan="1">2.2402%</td><td colspan="1" rowspan="1">135.4257</td><td colspan="1" rowspan="1">135.4257</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">研发与生产第三代半导体核心关键材料氮化镓（GaN）单晶衬底</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，其产品属于高性能芯片所依赖的关键基础原材料，一方面，符合探路者向半导体产业上游核心环节进行的关键性战略布局，另一方面，探路者可借助其高端客户渠道，快速切入激光制造、前沿科研等战略市场，符合探路者芯片业务未来纵深战略发展方向。</td></tr><tr><td colspan="1" rowspan="1">无限信通（苏州)科技有限责任公司</td><td colspan="1" rowspan="1">2025-01-24</td><td colspan="1" rowspan="1">16.6667%</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">100.00</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">汽车、卫星等终端射频测试算法与平台</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，该公司拥有汽车、卫星主机厂等高端客户渠道，可协助探路者打开通往这些高壁垒、高门槛行业的认证入口和销售通路，符合探路者芯片业务战略发展方向及布局。</td></tr><tr><td colspan="1" rowspan="1">苏州明义微电子技术有限公司</td><td colspan="1" rowspan="1">2023-10-31</td><td colspan="1" rowspan="1">9.1892%</td><td colspan="1" rowspan="1">89.549</td><td colspan="1" rowspan="1">89.549</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">基于硅基氮化镓材料的功率器件与电源模块</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司符合探路者“户外+芯片”双主业的战略布局，可协助探路者提升户外储能及智能装备能效的相关技术，强化了“户外+芯片”业务的技术联动与供应链自主性。</td></tr><tr><td colspan="1" rowspan="2">森一量子科技（厦门）有限公司</td><td colspan="1" rowspan="2">2025-11-17</td><td colspan="1" rowspan="2">1.3699%</td><td colspan="1" rowspan="2">73.9286</td><td colspan="1" rowspan="2">73.9286</td><td colspan="1" rowspan="2">无</td><td colspan="1" rowspan="1">法拉第旋光片等光、电晶体材料的</td><td colspan="1" rowspan="2">该公司主营业务与探路者业务具有协同性，该公司的主要产品制造高端光电子芯片（如激光器芯片、传感器芯片）的关键上游“材料原料”，探路者通过布局此类基础材料，一方面可支持户外装备中激光测距、环境感知、特种照明等核心功能的芯片实现性能突破与轻量化集成，为其“科技户外”战略中涉及光电与传感的芯片应用奠定材料基础，完善产业链上游布局；另一方面该公司光通信、激光雷达,工业激光、新能源、核工业、医疗航空等领域的标杆企业销售渠道，可协助探路者芯片业务拓展下游销售渠道，具有协同性。</td></tr><tr><td colspan="1" rowspan="1">研发、生产及销售</td></tr><tr><td colspan="1" rowspan="1">苏州晶和半导体科技有限公司</td><td colspan="1" rowspan="1">2025-10-22</td><td colspan="1" rowspan="1">7.8125%</td><td colspan="1" rowspan="1">50.00</td><td colspan="1" rowspan="1">50.00</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">基于常温表面活化技术路线高精度真空键合设备及键合工艺的研发、生产与销售</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，该公司服务的是晶圆厂、封测厂和顶尖芯片设计公司等产业链核心客户，投资该公司可协助探路者拓展芯片业务上游供应商渠道，符合探路者芯片业务纵向战略布局。</td></tr><tr><td colspan="1" rowspan="1">北京飓芯科技有限公司</td><td colspan="1" rowspan="1">2023-10-31</td><td colspan="1" rowspan="1">2.6098%</td><td colspan="1" rowspan="1">39.5385</td><td colspan="1" rowspan="1">39.5385</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">氮化镓半导体激光器制造，产品覆盖蓝光、绿光等波长</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司可协助探路者布局高端智能户外装备所需的核心光电技术，可提高探路者户外储能、激光传感与照明等领域的户外产品升级与市场拓展。</td></tr><tr><td colspan="1" rowspan="1">苏州中瑞宏芯半导体有限公司</td><td colspan="1" rowspan="1">2022-06-15</td><td colspan="1" rowspan="1">3.6474%</td><td colspan="1" rowspan="1">35.1563</td><td colspan="1" rowspan="1">35.1563</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">开发新一代节能高效碳化硅功率芯片和模块</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司符合探路者“户外+芯片”双主业的战略布局，可提升探路者未来新能源户外产品（如电动露营车、大型储能设备）储备关键的功率芯片技术、拓展相关供应链渠道。</td></tr><tr><td colspan="1" rowspan="1">武汉优炜芯科技有限公司</td><td colspan="1" rowspan="1">2023-02-23</td><td colspan="1" rowspan="1">2.924%</td><td colspan="1" rowspan="1">18.8829</td><td colspan="1" rowspan="1">18.8829</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">深紫外、近紫外LED芯片与模组的研发、生产与销售</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司可提高了探路者户外装备在即时消杀、便携光固化等场景的核心功能，同时借助该公司成熟的工业与消费渠道，快速开拓探路者户外装备制造与健康消费等高增长的下游市场，为探路者“科技户外”战略开辟全新的技术应用场景与商业化路径。</td></tr><tr><td colspan="1" rowspan="1">优镓科技(北京)有限公司</td><td colspan="1" rowspan="1">2023-01-17</td><td colspan="1" rowspan="1">4.386%</td><td colspan="1" rowspan="1">16.5383</td><td colspan="1" rowspan="1">16.5383</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">GaN射频PA、GaN射频模组的研发、生产与销售</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，该公司可为探路者提供关键核心器件，投资该公司可提升公司下一代户外智能装备（如高性能通信设备、卫星互联终端)，有助于提升探路者户外产品通信性能与竞争力。</td></tr><tr><td colspan="1" rowspan="1">鸾起科技（苏州)有限公司</td><td colspan="1" rowspan="1">2026-4-3</td><td colspan="1" rowspan="1">3.7037%</td><td colspan="1" rowspan="1">26.84835</td><td colspan="1" rowspan="1">26.848355</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">专注存储产品测试设备研发、生产、销售，包括SSD、UFS、DRAM等产品线</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，该公司聚焦存储介质的数据读写与测试验证，与上海通途布局的视频压缩IP 技术相结合，双方可在端侧AI领域形成"压缩+存储”的技术协同，有利于提升探路者芯片业务的整体竞争力。</td></tr><tr><td colspan="1" rowspan="1">河南中科清能科技有限公司</td><td colspan="1" rowspan="1">2026-1-7</td><td colspan="1" rowspan="1">1.3822%</td><td colspan="1" rowspan="1">306.1479</td><td colspan="1" rowspan="1">306.1479</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">氢液化设备、氮低温装备、深低温感知系统</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司可协助探路者布局航天装备级高端户外装备以及极低温环境下的智能控制与传感解决方案，促进探路者在极端环境场景、商业航天配套及高端户外装备领域产品升级，提升探路者户外产品竞争力。</td></tr><tr><td colspan="1" rowspan="1">苏州智驰领驭科技有限公司</td><td colspan="1" rowspan="1">2026-4-23</td><td colspan="1" rowspan="1">8.57149%</td><td colspan="1" rowspan="1">249.1319</td><td colspan="1" rowspan="1">249.1319</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">激光雷达、车载光通信系统以及相关激光解决方案等</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性，投资该公司可协助探路者布局智能户外装备。其激光雷达感知技术可实现主动测距与障碍预警，推动户外装备从"记录数据"向"主动守护"升级；同时，其车载传感经验与探路者极地、航天级极端环境测试能力形成技术互补与验证共享，有利于提升探路者户外业务的整体竞争力。</td></tr><tr><td colspan="1" rowspan="1">桑芯微测（上海)科技有限公司</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">/</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">/</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">二次分光电子束设备以及半导体良率管理算法、系统等</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性。一方面，投资该公司可协助探路者布局半导体良率管控与纳米级缺陷检测能力，促进贝特莱、上海通途等芯片公司产品升级；另一方面，探路者拥有的极地、航天等极端环境测试能力，可为桑芯微测的设备及算法提供高寒、低压、强振动等真实工况下的验证场景，推动其检测系统向更高可靠性标准迭代，拓展探路者芯片业务验证服务能力，有利于提升芯片业务竞争力。</td></tr><tr><td colspan="1" rowspan="1">擎岳问天科技（苏州）有限公司</td><td colspan="1" rowspan="1">2026-4-17</td><td colspan="1" rowspan="1">5.4054%</td><td colspan="1" rowspan="1">31.4286</td><td colspan="1" rowspan="1">31.4286</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">液氢无人机</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性。一方面，该公司的液氢无人机具备长续航、耐宽温域作业能力，在电力巡检、应急救援、极地科考等长航时场景中具备独特优势，可为探路者拓展户外产品极端环境应用场景；另一方面，探路者芯片产品可为其开发"液氢无人机+智能地面装备"系统方案提供芯片相关零部件，拓展探路者芯片业务下游销售渠道，有利于提升芯片业务竞争力。</td></tr><tr><td colspan="1" rowspan="1">江苏富林岚科技有限公司</td><td colspan="1" rowspan="1">2026-4-17</td><td colspan="1" rowspan="1">1.6227%</td><td colspan="1" rowspan="1">40.00</td><td colspan="1" rowspan="1">40.00</td><td colspan="1" rowspan="1">无</td><td colspan="1" rowspan="1">倾转旋翼组件及eVTOL整机</td><td colspan="1" rowspan="1">该公司主营业务与探路者业务具有协同性。一方面，贝特莱及上海通途的芯片产品可为富林岚eVTOL 提供人机交互与视觉显示支持，拓展公司芯片业务的下游渠道；另一方面，探路者的极端环境装备体系与国家级保障经验，可与富林岚在高原、海岛等复杂场景的作业需求形成互补，有利于提升探路者在该市场的产品竞争力。</td></tr></table>

注：苏州荷塘创芯创业投资合伙企业（有限合伙）于 2026 年 3 月 31 日与燊芯微测（上海）科技有限公司签署《可转债投资协议》，拟向燊芯微测（上海）科技有限公司投资 1,000.00万元，于 2026 年 4月 14 日支付 1,000.00 万元投资款，故上表未填写首次持股日期、持股比例、认缴金额和实缴金额、尚未投资金额及后续投资计划。

由上表可知，上述企业有助于实现公司主营业务产业链的上下游协同与横向业务拓展，为公司未来芯片业务的战略布局与资源整合奠定了重要基础，与公司的芯片业务具有较高的相关性和较强的协同效应，因此公司向苏州荷塘创芯创业投资合伙企业（有限合伙）的投资属于围绕产业链、下游以获取技术、原料或者渠道为目的的产业投资，不确认为财务性投资具备合理性。

## （二）补充华锡影视、北京元纬、乾境生物的认缴及实缴时间、金额、是否存在尚未实缴的金额，如是，说明后续计划，是否构成拟投入的财务性投资

华锡影视产业发展（无锡）有限公司、北京元纬天浩科技发展有限公司、乾境生物技术有限公司的认缴及实缴时间、金额情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>公司名称</td><td rowspan=1 colspan=1>认缴时间</td><td rowspan=1 colspan=1>认缴金额</td><td rowspan=1 colspan=1>实缴时间</td><td rowspan=1 colspan=1>实缴金额</td><td rowspan=1 colspan=1>尚未实缴金额</td></tr><tr><td rowspan=1 colspan=1>华锡影视产业发展（无锡）有限公司</td><td rowspan=1 colspan=1>2023-7-14</td><td rowspan=1 colspan=1>4,500.00</td><td rowspan=1 colspan=1>2023-7-14</td><td rowspan=1 colspan=1>4,500.00</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>北京元纬天浩科技发展有限公司</td><td rowspan=1 colspan=1>2028-5-22</td><td rowspan=1 colspan=1>217.32</td><td rowspan=1 colspan=1>2022-10-9</td><td rowspan=1 colspan=1>217.32</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>乾境生物技术有限公司</td><td rowspan=1 colspan=1>2029-6-30</td><td rowspan=1 colspan=1>2,800.00</td><td rowspan=1 colspan=1>2024-4-30</td><td rowspan=1 colspan=1>2,800.00</td><td rowspan=1 colspan=1>-</td></tr></table>

由上表所示，上述公司均已完成实缴，不存在尚未实缴的情况，不存在构成拟投入的财务性投资。

## （三）自本次发行相关董事会决议日前六个月起至今，发行人已实施或拟实施的财务性投资（包括类金融投资）情况，是否已从本次募集资金总额中扣除

自本次发行相关董事会决议日前六个月起至今，公司已实施或拟实施财务性投资行为的情况如下：

<table><tr><td rowspan=1 colspan=1>财务性投资情形</td><td rowspan=1 colspan=1>本次发行董事会前六个月至今公司相关情况</td></tr><tr><td rowspan=1 colspan=1>投资类金融业务</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在新投入或拟投入金融或类金融业务的情形。</td></tr><tr><td rowspan=1 colspan=1>非金融企业投资金融业务（不包括投资前后持股比例未增加的对集团财务公司的投资）</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在投资金融业务的情形。</td></tr><tr><td rowspan=1 colspan=1>与公司主营业务无关的股权投资</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在开展与公司主营业务无关的股权投资的情形。</td></tr><tr><td rowspan=1 colspan=1>投资产业基金、并购基金</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在设立或投资产业基金、并购基金的情形。</td></tr><tr><td rowspan=1 colspan=1>拆借资金</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在对外拆借资金的情形。</td></tr><tr><td rowspan=1 colspan=1>委托贷款</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在委托贷款的情形。</td></tr><tr><td rowspan=1 colspan=1>购买收益波动大且风险较高的金融产品</td><td rowspan=1 colspan=1>自本次发行相关董事会决议日前六个月起至今，公司不存在购买收益波动大且风险较高的金融产品的情形。</td></tr></table>

综上所述，自本次发行相关董事会决议日前六个月起至今，公司不存在已实施或者拟实施财务性投资及类金融业务的情况，不涉及募集资金扣减情形。

## 七、请发行人补充披露（1）（3）（4）（5）相关风险

## （一）问题（1）涉及的相关风险

发行人已在本次发行募集说明书“重大事项提示”之“二、重大风险提示”之“（一）业绩下滑风险”和“第七节 与本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（一）户外业务”之“3、业绩下滑的风险”部分补充披露如下：

“2025 年度，公司营业收入、归属于上市公司股东的净利润和扣除非经常性损益后归属于母公司所有者的净利润分别为 138,071.31 万元、7,898.80 万元和-343.06 万元，较上年同期分别下降 13.25%、25.92%和 104.08%，主要受户外业务市场环境和新品迭代节奏等因素影响，产品销售不及预期，同时芯片业务虽整体向好，但受汇率波动影响，汇兑损失对业绩形成反向拖累，2025 年度公司汇兑损益（正向为汇兑收益，负向为汇兑损失）为-939.93 万元，较上年减少4,356.57 万元。若未来户外行业竞争持续加剧、公司新产品迭代仍不及预期或汇率出现大幅不利波动，公司可能存在业绩持续下滑的风险，从而对公司持续经营产生不利影响。”

## （二）问题（3）涉及的相关风险

发行人已在本次发行募集说明书“重大事项提示”之“二、重大风险提示”之“（三）商誉减值风险”和“第七节 与本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（二）芯片业务”之“4、商誉减值风险”部分补充披露如下：

“2025年末，公司商誉账面价值18,056.53万元，占资产总额的比例为6.80%，主要为报告期内公司非同一控制下收购 G2Touch 95.01%股权和江苏鼎茂 60%股权时形成的商誉。公司于 2025 年 11 月 30 日召开第六届董事会第十次会议，审议通过《关于收购深圳贝特莱电子科技股份有限公司51%股权的议案》和《关于收购上海通途半导体科技有限公司 51%股权的议案》，即公司将非同一控制下收购贝特莱 51%股权和上海通途 51%股权，2026 年1 月 1 日起贝特莱和上海通途纳入公司合并范围，分别新增商誉 22,853.53 万元和 32,169.87 万元。

若未来 G2 Touch、江苏鼎茂、贝特莱和上海通途的经营业绩或现金流量出现明显的恶化，或行业竞争状况、行业政策等宏观环境因素出现明显不利变化，导致相关商誉出现明显的减值迹象，公司将根据会计准则等相关规定履行定期和及时的商誉减值测试，并基于减值测试结果计提相关商誉减值准备。届时，公司可能面临相关商誉将进一步计提大额减值准备的风险，对公司减值当期的经营业绩产生不利影响。”

## （三）问题（4）涉及的相关风险

发行人已在本次发行募集说明书“重大事项提示” 之“二、重大风险提示”之“（四）存货跌价风险”和“第七节 与本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（一）户外业务”之“4、存货跌价风险”部分补充披露如下：

“报告期各期末，公司存货账面价值分别为 33,307.40 万元、34,910.04 万元和 44,579.19 万元，占资产总额的比例分别为 12.63%、13.48%和 16.79%，存货规模持续增加且占比较高。报告期各期末，公司存货以户外用品存货为主，占比超 90%。户外用品存货的优化管理是公司户外业务的重要课题，虽然公司已采取措施持续优化进销存结构，但仍需预留部分库存应对正常经营。若在以后经营年度中因市场环境发生变化、竞争加剧导致存货积压和减值，将对公司经营造成不利影响。”

## （四）问题（5）涉及的相关风险

发行人已在本次发行募集说明书“重大事项提示” 之“二、重大风险提示”之“（二）应收账款规模较大的风险”和“第七节 与本次发行相关的风险因素”之“一、对公司核心竞争力、经营稳定性及未来发展可能产生重大不利影响的因素”之“（一）户外业务”之“5、应收账款规模较大的风险”部分补充披露如下：

“报告期各期末，公司应收账款账面价值分别为24,689.24 万元、21,698.19万元和 17,701.79 万元，占资产总额的比例分别为 9.37%、8.38%和 6.67%，占各年营业收入的比例分别为 17.75%、13.63%和12.82%，应收账款规模较大。如公司主要应收账款客户经营状况发生不利变化，导致回款情况不佳甚至发生坏账的风险，将会对公司的经营业绩产生不利影响。”

八、说明针对发行人报告期内收入真实性采取的核查程序、比例及结论。

## （一）核查程序及比例

针对发行人收入真实性采取的核查程序、比例情况如下：

## 1、函证程序

## （1）保荐机构函证

报告期内，保荐机构对公司主要客户实施了函证程序，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>营业收入（A)</td><td rowspan=1 colspan=1>138,071.31</td><td rowspan=1 colspan=1>159,158.96</td><td rowspan=1 colspan=1>139,071.09</td></tr><tr><td rowspan=1 colspan=1>发函客户对应收入金额（B)</td><td rowspan=1 colspan=1>70,257.35</td><td rowspan=1 colspan=1>79,105.88</td><td rowspan=1 colspan=1>65,900.78</td></tr><tr><td rowspan=1 colspan=1>发函比例（C=B/A）</td><td rowspan=1 colspan=1>50.88%</td><td rowspan=1 colspan=1>61.07%</td><td rowspan=1 colspan=1>60.34%</td></tr><tr><td rowspan=1 colspan=1>回函相符客户对应收入金额（D)</td><td rowspan=1 colspan=1>41,554.29</td><td rowspan=1 colspan=1>88,392.53</td><td rowspan=1 colspan=1>75,318.83</td></tr><tr><td rowspan=1 colspan=1>回函不符但调节后相符金额(E)</td><td rowspan=1 colspan=1>7,825.99</td><td rowspan=1 colspan=1>8,801.09</td><td rowspan=1 colspan=1>8,686.96</td></tr><tr><td rowspan=1 colspan=1>回函确认金额(F=D+E)</td><td rowspan=1 colspan=1>49,380.29</td><td rowspan=1 colspan=1>97,193.62</td><td rowspan=1 colspan=1>83,919.70</td></tr><tr><td rowspan=1 colspan=1>回函确认金额占比（K=F/A)</td><td rowspan=1 colspan=1>35.76%</td><td rowspan=1 colspan=1>61.07%</td><td rowspan=1 colspan=1>60.34%</td></tr><tr><td rowspan=1 colspan=1>未回函替代测试确认收入金额（G)</td><td rowspan=1 colspan=1>20,877.06</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>-</td></tr><tr><td rowspan=1 colspan=1>回函及未回函实施替代测试确认金额合计比例(H=(F+G)/B)</td><td rowspan=1 colspan=1>50.88%</td><td rowspan=1 colspan=1>61.07%</td><td rowspan=1 colspan=1>60.34%</td></tr></table>

2025 年度，保荐机构发函后，存在未收到回函的情况，主要原因系客户已向会计师回函，因此保荐机构复核了会计师的函证并实施替代测试，未发现异常。除此之外，保荐机构复核了报告期内会计师函证情况，未发现异常。2023 年至2025 年，发函覆盖的销售收入比例分别为 60.34%、61.07%和 50.88%，未回函或回函不符的函证在执行替代、调节程序后总体核查比例覆盖。

## （2）会计师函证

报告期内，会计师对公司主要客户实施了函证程序，具体情况如下：

单位：万元

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2025年度</td><td colspan="1" rowspan="1">2024年度</td><td colspan="1" rowspan="1">2023年度</td></tr><tr><td colspan="1" rowspan="1">营业收入（A)</td><td colspan="1" rowspan="1">138,071.31</td><td colspan="1" rowspan="1">159,158.96</td><td colspan="1" rowspan="1">139,071.09</td></tr><tr><td colspan="1" rowspan="1">发函客户对应收入金额（B)</td><td colspan="1" rowspan="1">74,317.66</td><td colspan="1" rowspan="1">78,548.80</td><td colspan="1" rowspan="1">35,999.75</td></tr><tr><td colspan="1" rowspan="1">发函比例（C=B/A）</td><td colspan="1" rowspan="1">53.83%</td><td colspan="1" rowspan="1">49.35%</td><td colspan="1" rowspan="1">25.89%</td></tr><tr><td colspan="1" rowspan="1">回函相符客户对应收入金额（D)</td><td colspan="1" rowspan="1">49,637.60</td><td colspan="1" rowspan="1">44,653.99</td><td colspan="1" rowspan="1">27,040.36</td></tr><tr><td colspan="1" rowspan="1">回函不符但调节后相符金额(E)</td><td colspan="1" rowspan="1">13,133.78</td><td colspan="1" rowspan="1">22,667.69</td><td colspan="1" rowspan="1">4,577.05</td></tr><tr><td colspan="1" rowspan="1">回函确认金额（F=D+E)</td><td colspan="1" rowspan="1">62,771.38</td><td colspan="1" rowspan="1">67,321.68</td><td colspan="1" rowspan="1">31,617.41</td></tr><tr><td colspan="1" rowspan="1">回函确认金额占比（K=F/A)</td><td colspan="1" rowspan="1">45.46%</td><td colspan="1" rowspan="1">42.30%</td><td colspan="1" rowspan="1">22.73%</td></tr><tr><td colspan="1" rowspan="1">未回函替代测试确认收入金额(G)</td><td colspan="1" rowspan="1">11,546.28</td><td colspan="1" rowspan="1">11,227.13</td><td colspan="1" rowspan="1">4,382.34</td></tr><tr><td colspan="1" rowspan="1">回函及未回函实施替代测试确认金额合计比例(H=(F+G)/A)</td><td colspan="1" rowspan="1">53.83%</td><td colspan="1" rowspan="1">49.35%</td><td colspan="1" rowspan="1">25.89%</td></tr></table>

## 2、走访程序

对发行人报告期内主要客户进行走访，并取得经被访谈人员确认的访谈记录，具体情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>营业收入（A)</td><td rowspan=1 colspan=1>137,187.81</td><td rowspan=1 colspan=1>158,570.02</td><td rowspan=1 colspan=1>138,448.52</td></tr><tr><td rowspan=1 colspan=1>访谈客户对应收入金额（B)</td><td rowspan=1 colspan=1>56,902.56</td><td rowspan=1 colspan=1>74,460.34</td><td rowspan=1 colspan=1>57,118.60</td></tr><tr><td rowspan=1 colspan=1>其中：取得客户签章的访谈客户对应收入金额(C)</td><td rowspan=1 colspan=1>56,902.56</td><td rowspan=1 colspan=1>74,460.34</td><td rowspan=1 colspan=1>57,118.60</td></tr><tr><td rowspan=1 colspan=1>走访比例（D=B/A）</td><td rowspan=1 colspan=1>41.48%</td><td rowspan=1 colspan=1>46.96%</td><td rowspan=1 colspan=1>41.26%</td></tr><tr><td rowspan=1 colspan=1>取得客户签章访谈记录的走访比例（E=C/A）</td><td rowspan=1 colspan=1>41.48%</td><td rowspan=1 colspan=1>46.96%</td><td rowspan=1 colspan=1>41.26%</td></tr><tr><td rowspan=1 colspan=1>其中：前十大客户走访家数</td><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>6</td></tr><tr><td rowspan=1 colspan=1>对当期前十大客户收入的覆盖比例</td><td rowspan=1 colspan=1>82.32%</td><td rowspan=1 colspan=1>86.38%</td><td rowspan=1 colspan=1>77.71%</td></tr></table>

## 3、IT 审计

报告期内，IT 审计专家对公司户外业务的财务报表和重要业务依赖的信息系统控制情况进行审计，审计内容包括 IT 系统的一般控制和IT 系统应用控制以及对业财数据的验证与分析，核对数据覆盖报告期各年度所有户外业务收入，即报告期内，IT 审计专家对户外业务收入核对确认比例均为 100.00%。IT 审计核查后认为：报告期内，公司信息系统相关内部控制设计和运行有效，业务数据完整、准确、真实，未发现信息系统存在重大或重要缺陷，对财务报表不存在重大错报影响。保荐机构、申报会计师复核了报告期内IT 审计备忘录，未发现异常。

## 4、细节测试

## （1）户外业务

公司户外业务呈现单笔交易金额小、交易频次高、客户分布分散的典型零售特征。报告期内，在执行前述IT 审计的基础上，针对户外业务收入，运用分层

抽样和随机抽样相结合的方式选取样本，检查相关会计凭证、业务合同/订单、出库单、签收单/结算单、发票等。

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>户外业务-营业收入（A)</td><td rowspan=1 colspan=1>114,486.01</td><td rowspan=1 colspan=1>136,380.20</td><td rowspan=1 colspan=1>125,113.42</td></tr><tr><td rowspan=1 colspan=1>细节测试笔数</td><td rowspan=1 colspan=1>120</td><td rowspan=1 colspan=1>126</td><td rowspan=1 colspan=1>227</td></tr><tr><td rowspan=1 colspan=1>细节测试金额页（B）</td><td rowspan=1 colspan=1>28,180.36</td><td rowspan=1 colspan=1>32,947.61</td><td rowspan=1 colspan=1>32,210.15</td></tr><tr><td rowspan=1 colspan=1>细节测试比例（C=B/A）</td><td rowspan=1 colspan=1>24.61%</td><td rowspan=1 colspan=1>24.16%</td><td rowspan=1 colspan=1>25.74%</td></tr></table>

## （2）芯片业务

报告期内，针对芯片业务收入，选取报告期内各期主要客户，检查相关会计凭证、业务合同、出库单、签收单/结算单/报关单、发票等，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=1 colspan=1>芯片业务-营业收入（A)</td><td rowspan=1 colspan=1>22,997.68</td><td rowspan=1 colspan=1>22,230.84</td><td rowspan=1 colspan=1>13,347.05</td></tr><tr><td rowspan=1 colspan=1>细节测试金额（B)</td><td rowspan=1 colspan=1>16,419.19</td><td rowspan=1 colspan=1>15,663.74</td><td rowspan=1 colspan=1>10,407.38</td></tr><tr><td rowspan=1 colspan=1>细节测试比例（C=B/A)</td><td rowspan=1 colspan=1>71.41%</td><td rowspan=1 colspan=1>70.46%</td><td rowspan=1 colspan=1>77.98%</td></tr></table>

## 5、期后回款检查

对发行人报告期内客户期后回款进行检查，具体情况如下：

单位：万元

<table><tr><td rowspan=1 colspan=2>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2023年度</td></tr><tr><td rowspan=3 colspan=1>应收账款余额</td><td rowspan=1 colspan=1>单项计提</td><td rowspan=1 colspan=1>7,517.41</td><td rowspan=1 colspan=1>8,214.78</td><td rowspan=1 colspan=1>10,394.02</td></tr><tr><td rowspan=1 colspan=1>组合计提</td><td rowspan=1 colspan=1>21,063.03</td><td rowspan=1 colspan=1>25,177.91</td><td rowspan=1 colspan=1>28,165.68</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>28,580.44</td><td rowspan=1 colspan=1>33,392.70</td><td rowspan=1 colspan=1>38,559.70</td></tr><tr><td rowspan=3 colspan=1>期后回款金额</td><td rowspan=1 colspan=1>单项计提</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>695.35</td><td rowspan=1 colspan=1>1,410.72</td></tr><tr><td rowspan=1 colspan=1>组合计提</td><td rowspan=1 colspan=1>6,660.60</td><td rowspan=1 colspan=1>16,676.61</td><td rowspan=1 colspan=1>24,041.56</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>6,660.60</td><td rowspan=1 colspan=1>17,371.96</td><td rowspan=1 colspan=1>25,452.28</td></tr><tr><td rowspan=3 colspan=1>期后回款比例</td><td rowspan=1 colspan=1>单项计提</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>8.46%</td><td rowspan=1 colspan=1>13.57%</td></tr><tr><td rowspan=1 colspan=1>组合计提</td><td rowspan=1 colspan=1>31.62%</td><td rowspan=1 colspan=1>66.24%</td><td rowspan=1 colspan=1>85.36%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>23.30%</td><td rowspan=1 colspan=1>52.02%</td><td rowspan=1 colspan=1>66.01%</td></tr></table>

注：上述期后回款统计截止日期为 2026 年 3 月 31 日。

2023 年至 2025 年公司应收账款期后回款比例分别为 66.01%、52.02%和  
23.30%，剔除单项计提坏账准备的应收账款余额期后回款比例分别为 85.36%、

66.24%和 31.62%，期后回款能力大幅增强，发行人已在积极推动催收工作。

## （二）核查结论

经核查，保荐人及申报会计师认为：

结合上述收入核查方式，发行人报告期内营业收入真实、准确。

## 九、核查程序及核查意见

## （一）核查程序

保荐人及申报会计师执行的核查程序如下：

1、查阅发行人的财务报告、会计账簿、年度报告及收入成本明细，分析最近一期业绩下滑情况；查询同行业可比公司业绩信息，对比分析发行人与同行业可比公司的业绩情况；访谈发行人管理层，了解公司对业绩下滑的主要应对措施。

2、获取芯片业务各公司收入明细，分析芯片业务收入大幅增长原因；获取芯片业务主要客户回款情况，分析是否存在大额坏账计提的风险；访谈公司管理层，了解芯片业务增长的可持续性。

3、取得董监高调查表，了解公司实际控制人、董事与高管的任职经历与背景；查阅发行人的公司公告、董事会决议，了解被收购公司的公司概况、产品情况、经营模式及交易的必要性和目的；查阅贝特莱及上海通途的评估报告、审计报告及业绩承诺协议，分析收购定价的公允性及业绩承诺的充分性；获取贝特莱及上海通途的收购协议、资产评估报告及商誉计算底稿，复核新增商誉金额的准确性及会计处理的合规性；获取报告期各年度 G2 Touch 及北京芯能的商誉减值评估报告，分析减值测试过程、关键参数选取及减值计提的充分性；获取贝特莱及上海通途的业绩实现情况及未来盈利预测，结合其经营表现评估商誉减值风险；获取关于收购江苏鼎茂的总裁办公会会议决议和盈利情况，复核江苏鼎茂商誉金额准确性，分析江苏鼎茂商誉减值风险。

4、获取报告期各年度末库存商品明细，了解库存商品的主要内容，库龄及期后结转情况，分析是否存在滞销的情形；对比分析库存商品的可变现净值与账面价值的差异情况，分析存货跌价准备计提的充分性，是否存在大额计提减值的风险。

5、获取报告期各年度末应收账款明细表，分析应收账款主要客户的账龄及回款情况，分析是否存在逾期情况，坏账准备计提是否充分；公开渠道查询主要客户的资信情况，是否存在资信异常的情况。

6、查阅襄阳东证和同探路者体育产业基金合伙企业（有限合伙）和苏州荷塘创芯创业投资合伙企业（有限合伙）合伙协议等了解其投资方向；公开渠道查询襄阳东证和同探路者体育产业基金合伙企业（有限合伙）和苏州荷塘创芯创业投资合伙企业（有限合伙）的对外投资情况；访谈发行人管理层，了解其对外投资情况与公司业务的协同性；公开渠道查询华锡影视、北京元纬、乾境生物的认缴及实缴时间、金额、分析是否存在尚未实缴的金额以及后续投资计划，分析是否构成拟投入的财务性投资；访谈发行人管理层，了解自本次发行相关董事会决议日前六个月起至今，发行人是否存在已实施或拟实施的财务性投资（包括类金融投资）情况；查阅并复核自本次发行相关董事会决议日前六个月起至今，财务报表各科目是否新增财务性投资和类金融业务的情况。

## （二）核查意见

经核查，保荐人及申报会计师认为：

1、最近一期业绩大幅下滑的主要影响因素系受户外业务受市场环境和新品迭代等因素的影响户外业务销量下滑以及汇率波动导致的汇兑损失所致；发行人2025 年度主要业绩指标下降与同行业可比公司牧高笛基本保持一致，且降幅高于三夫户外和比音勒芬，主要系各公司商业模式、产品定位及渠道布局情况不同所致，符合行业特征，具备合理性；面对业绩下滑的情形发行人已制定有效应对措施，预计下滑趋势不具有持续性。

2、报告期内，公司芯片业务收入大幅增长主要系收购并表导致的年度涵盖期间差异和收购整合效果较好所致，具备合理性；报告期内，公司芯片业务主要客户回款情况较好；公司芯片业务增长具备可持续性，主要系收购整合效果良好、产业布局持续完善、双主业协同发展所致，具备合理性。

3、发行人先后并购多家芯片业务公司的主要原因系：一方面，公司董事长及高管团队具备丰富的芯片行业认知与履职背景，并且公司对芯片行业有着深层战略规划与布局。另一方面，公司并购的多家芯片业务公司能发挥协同效应，拓展业务广度，突破技术深度，并且能拓展芯片业务应用市场，优化客户结构。发行人具备运营管理芯片业务公司的能力；在并购标的北京芯能持续亏损并全额计提商誉减值、芯片业务汇兑损失拖累公司业绩的情况下，发行人进一步收购贝特莱及上海通途两家芯片业务公司具备合理性和谨慎性；报告期内，G2Touch、江苏鼎茂财务状况及盈利能力较好，公司对 G2 Touch、江苏鼎茂未计提商誉减值谨慎合理，不存在大额计提商誉减值的风险。2025 年12 月1日，公司公告将非同一控制下分别收购贝特莱和上海通途原股东持有的 51%，将于 2026 年 1 月1日新增商誉金额分别为 22,853.53 万元和32,169.87 万元，报告期内，贝特莱和上海通途经营业务总体保持稳定，通过结合当前的经营状况以及对未来经营情况的分析预测，判断该商誉未出现减值迹象，预计不存在大额计提商誉减值的风险。

4、报告期内，公司已结合库存商品的主要内容、库龄、期后结转、滞销情况及可变现净值等因素，对存货跌价准备进行了充分计提，发生大额存货跌价风险的可能性较小。

5、报告期内，公司按组合计提坏账准备的应收账款的主要客户资信情况较好，账龄主要在1年以内，期后回款总体良好；报告期内，公司少量客户存在逾期欠款，但已通过抵押较高价值资产、缴纳保证金等方式有效降低了回款风险。公司基于组合模型及历史损失率已足额计提坏账准备，整体能够覆盖可预见的信用损失，应收账款坏账准备计提充分。

6、襄阳东证和同探路者体育产业基金合伙企业（有限合伙）的投资范围明确，重点布局体育、大消费等领域，其对外投资的企业主营业务均与发行人户外业务具有高度关联性及协同效应，不存在尚未投资的金额及后续投资计划，因此公司向襄阳东证和同探路者体育产业基金合伙企业（有限合伙）的投资属于围绕产业链、下游以获取技术、原料或者渠道为目的的产业投资，不确认为财务性投资具备合理性；苏州荷塘创芯创业投资合伙企业（有限合伙）的投资范围对半导体相关行业的投资，重点布局第三代半导体产业链中具备核心技术的科技项目，其对外投资的企业与公司在户外业务和芯片业务上具有业务协同性，不存在尚未投资的金额及后续投资计划，因此公司向苏州荷塘创芯创业投资合伙企业（有限合伙）的投资属于围绕产业链、下游以获取技术、原料或者渠道为目的的产业投资，不确认为财务性投资具备合理性；公司对华锡影视、北京元纬、乾境生物的投资均已实缴完毕，不存在构成拟投入的财务性投资；自本次发行相关董事会决议日前六个月起至今，发行人不存在已实施或拟实施的财务性投资（包括类金融投资）情况。

7、关于最近一期业绩大幅下滑风险、商誉减值风险、存货跌价风险以及应收账款规模较大的风险，发行人已在募集说明书补充披露。

8、结合函证程序、走访程序、IT 审计、细节测试及期后回款检查各类收入核查方式，发行人报告期内营业收入真实、准确。

## 其他问题

请发行人在募集说明书扉页重大事项提示中，按重要性原则披露对发行人及本次发行产生重大不利影响的直接和间接风险。披露风险应避免包含风险对策、发行人竞争优势及类似表述，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序。

同时，请发行人关注社会关注度较高、传播范围较广、可能影响本次发行的媒体报道情况，请保荐人对上述情况中涉及本次项目信息披露的真实性、准确性、完整性等事项进行核查，并于答复本审核问询函时一并提交。若无重大舆情情况，也请予以书面说明。

回复：

一、请发行人在募集说明书扉页重大事项提示中，按重要性原则披露对发行人及本次发行产生重大不利影响的直接和间接风险。披露风险应避免包含风险对策、发行人竞争优势及类似表述，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序。

公司已在募集说明书扉页重大事项提示中，按重要性原则披露对发行人及本次发行产生重大不利影响的直接和间接风险，并按对投资者作出价值判断和投资决策所需信息的重要程度进行梳理排序；披露风险已避免包含风险对策、发行人竞争优势及类似表述。

二、请发行人关注社会关注度较高、传播范围较广、可能影响本次发行的媒体报道情况，请保荐人对上述情况中涉及本次项目信息披露的真实性、准确性、完整性等事项进行核查，并于答复本审核问询函时一并提交。若无重大舆情情况，也请予以书面说明。

自预案发布以来，发行人已持续关注媒体报道情况，不存在社会关注度较高、传播范围较广、可能影响本次发行的媒体报道，未出现对本次发行项目信息披露的真实性、准确性、完整性等事项进行质疑的情形，发行人将持续关注有关公司本次发行相关的媒体报道情况。

## 三、核查程序及核查意见

## （一）核查程序

保荐人执行了以下核查程序：

持续关注发行人自本次向特定对象发行股票预案发布以来的重大舆情，通过网络检索等方式查询发行人自预案发布以来相关媒体报道的情况，查看是否存在与发行人相关的重大舆情或媒体质疑，并与本次发行相关申请文件进行对比。

## （二）核查意见

经核查，保荐人认为：

发行人自本次向特定对象发行股票预案发布以来，不存在社会关注度较高、传播范围较广、可能影响本次发行的媒体报道，未出现对本次发行项目信息披露的真实性、准确性、完整性等事项进行质疑的情形。

（以下无正文）

本页无正文，为《关于探路者控股集团股份有限公司向特定对象发行股票的问询函的回复》之签章页）

![](images/6dcc0930149b24688b7895e12afabb71feb84edacb15ba3e763e2f241066e3df.jpg)  
探路者桑股团股份有限公司 1101020439611

（本页无正文，为国泰海通证券股份有限公司《关于探路者控股集团股份有限公司向特定对象发行股票的审核问询函的回复》之签章页）

保荐代表人：

杨据里

杨振寰

双

邓昆鹏

![](images/378f6f2158388f9639ca0297297a1dfc4d58c4bf465d7cadc1aed4bcf3e148c8.jpg)  
国泰海通证券股份有限公司

## 保荐机构法定代表人声明

本人已认真阅读《关于探路者控股集团股份有限公司向特定对象发行股票的审核问询函的回复》的全部内容，了解报告涉及问题的核查过程、本公司的内核和风险控制流程，确认本公司按照勤勉尽责原则履行核查程序，审核问询函的回复不存在虚假记载、误导性陈述或者重大遗漏，并对上述文件的真实性、准确性、完整性、及时性承担相应法律责任。

代表人（董事长）：

![](images/91b027bbbba0215c598354832c0bb6c5cb79c5535595307ef25427cd47879b91.jpg)  
国泰海通证券股份有限公司