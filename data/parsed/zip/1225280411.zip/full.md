# 立信中联会计师事务所（特殊普通合伙）关于上海证券交易所对诚邦智芯科技股份有限公司2025年年度报告的信息披露监管问询函的回复意见

立信中联专复字［2026]D-0412号

立信中联会计师事务所（特殊普通合伙）

LixinZhonglian CPAs (SPECIAL GENERAL PARTNERSHIP)

目 录

## 专项说明

1-47

# 关于上海证券交易所对诚邦智芯科技股份有限公司2025年年度报告的信息披露监管问询函的回复意见

立信中联专复字[2026]D-0412号

上海证券交易所上市公司管理一部：

诚邦智芯科技股份有限公司（原名：诚邦生态环境股份有限公司，以下简称“诚邦股份”或“公司"）于近日收到贵部下发的《关于诚邦生态环境股份有限公司2025年年度报告的信息披露监管问询函》（上证公函【2026】0555号，以下简称“《监管问询函》")。其中要求年审会计师对有关事项发表意见，现就《监管问询函》中提及的相关问题回复如下：

问题1.关于收入和净利润。年报显示，2025年，公司实现主营业务收入5.01亿元，同比增长44.75%；税金及附加为72.39万元，同比下降71.57%；归母净利润为-1.20亿元，同比增亏20.23%。2025年1-4季度，公司营业收入分别为0.97亿元、1.10亿元、0.99亿元和1.98亿元。请公司补充披露：（1）收入大幅增长但归母净利润持续亏损且亏损金额增加的原因和合理性，并结合税金及附加的具体情况，说明收入增速与税金及附加增速相背离的原因及合理性；（2）分季度、分业务类别列示营业收入的金额、同比变动，并结合收入确认政策及变化，说明四季度收入大幅增加的原因及合理性，以及收入确认政策是否符合《企业会计准则》相关规定。

## 【公司回复】

一、收入大幅增长但归母净利润持续亏损且亏损金额增加的原因和合理性，并结合税金及附加的具体情况，说明收入增速与税金及附加增速相背离的原因及合理性

## （一）收入大幅增长但归母净利润持续亏损且亏损金额增加的原因和合理性

2025年，公司实现营业收入50,356.55万元，同比增长44.75%；归母净利润为-11,959.82万元，同比增亏20.23%。收入增长但净利润亏损扩大，主要系公司“半导体存储+生态环境建设”双主业战略推进阶段的阶段性特征，具有商业合理性，具体原因如下：

## 1、收入增长主要来源为半导体存储业务

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年度</td><td rowspan=1 colspan=1>2024年度</td></tr><tr><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>金额</td></tr><tr><td rowspan=1 colspan=1>半导体存储业务</td><td rowspan=1 colspan=1>34,048.57</td><td rowspan=1 colspan=1>207.88%</td><td rowspan=1 colspan=1>11,058.91</td></tr><tr><td rowspan=1 colspan=1>生态环境建设业务</td><td rowspan=1 colspan=1>16,307.97</td><td rowspan=1 colspan=1>-31.28%</td><td rowspan=1 colspan=1>23,730.48</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>50,356.55</td><td rowspan=1 colspan=1>44.75%</td><td rowspan=1 colspan=1>34,789.38</td></tr></table>

注：明细项目加总与合计数核对不符，系四舍五入差异所致，下同。

公司2025年聚焦半导体存储业务发展，子公司芯存科技完成对封测业务和模组生产业务的资源整合并积极拓展市场，全年实现收入34,048.57万元，占合并营业收入比重达到67.61%，已成为公司最主要的业务，是公司收入增长的来源。同比大幅增长207.88%，系公司2024年切入半导体存储领域，半导体存储业务于2024年10月份起纳入公司合并报表，即同比基数为芯存科技2024年四季度营业收入11,058.91万元。

生态环境建设业务受行业环境影响，公司主动采取收缩策略，全年实现营业收入16,307.97万元，同比下降31.28%。

## 2、归母净利润持续亏损且亏损金额增加主要系生态环境业务亏损增加所致

公司2025年度及2024年度分部财务信息列示如下：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>环境建设</td><td rowspan=1 colspan=2>半导体存储</td><td rowspan=1 colspan=2>合计</td></tr><tr><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>16,307.97</td><td rowspan=1 colspan=1>23,730.48</td><td rowspan=1 colspan=1>34,048.57</td><td rowspan=1 colspan=1>11,058.91</td><td rowspan=1 colspan=1>50,356.55</td><td rowspan=1 colspan=1>34,789.38</td></tr><tr><td rowspan=1 colspan=1>减：营业成本</td><td rowspan=1 colspan=1>17,982.41</td><td rowspan=1 colspan=1>22,796.82</td><td rowspan=1 colspan=1>28,989.19</td><td rowspan=1 colspan=1>10,596.92</td><td rowspan=1 colspan=1>46,971.60</td><td rowspan=1 colspan=1>33,393.74</td></tr><tr><td rowspan=1 colspan=1>营业毛利</td><td rowspan=1 colspan=1>-1, 674. 44</td><td rowspan=1 colspan=1>933.66</td><td rowspan=1 colspan=1>5,059.38</td><td rowspan=1 colspan=1>461.98</td><td rowspan=1 colspan=1>3,384.95</td><td rowspan=1 colspan=1>1,395.64</td></tr><tr><td rowspan=1 colspan=1>减：税金及附加、销售费用、管理费用、研发费用</td><td rowspan=1 colspan=1>3,045.95</td><td rowspan=1 colspan=1>4,835.46</td><td rowspan=1 colspan=1>2,005.92</td><td rowspan=1 colspan=1>222.98</td><td rowspan=1 colspan=1>5,051.87</td><td rowspan=1 colspan=1>5,058.44</td></tr><tr><td rowspan=1 colspan=1>减：财务费用</td><td rowspan=1 colspan=1>-1,414.12</td><td rowspan=1 colspan=1>-2,547.55</td><td rowspan=1 colspan=1>195.89</td><td rowspan=1 colspan=1>219.97</td><td rowspan=1 colspan=1>-1,218.23</td><td rowspan=1 colspan=1>-2,327.57</td></tr><tr><td rowspan=1 colspan=1>加：信用减值损失、资产减值损失</td><td rowspan=1 colspan=1>-6, 587. 13</td><td rowspan=1 colspan=1>-7,791.74</td><td rowspan=1 colspan=1>-922.81</td><td rowspan=1 colspan=1>-24.45</td><td rowspan=1 colspan=1>-7,509.93</td><td rowspan=1 colspan=1>-7,816.19</td></tr><tr><td rowspan=1 colspan=1>加：投资收益</td><td rowspan=1 colspan=1>-626. 64</td><td rowspan=1 colspan=1>125.77</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>/</td><td rowspan=1 colspan=1>-626.64</td><td rowspan=1 colspan=1>125.77</td></tr><tr><td rowspan=1 colspan=1>加：其他损益项目</td><td rowspan=1 colspan=1>139.05</td><td rowspan=1 colspan=1>401.67</td><td rowspan=1 colspan=1>153.26</td><td rowspan=1 colspan=1>58.12</td><td rowspan=1 colspan=1>292.31</td><td rowspan=1 colspan=1>459.78</td></tr><tr><td rowspan=1 colspan=1>减：所得税费用</td><td rowspan=1 colspan=1>2,673.14</td><td rowspan=1 colspan=1>1,852.25</td><td rowspan=1 colspan=1>259.70</td><td rowspan=1 colspan=1>-40. 68</td><td rowspan=1 colspan=1>2,932.84</td><td rowspan=1 colspan=1>1,811.57</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>-13,054.12</td><td rowspan=1 colspan=1>-10,470.81</td><td rowspan=1 colspan=1>1,828.33</td><td rowspan=1 colspan=1>93.38</td><td rowspan=1 colspan=1>-11,225.80</td><td rowspan=1 colspan=1>-10,377.43</td></tr></table>

如上表所示，公司归母净利润持续亏损且亏损金额增加主要系生态环境业务亏损且亏损增加所致。

2025 年受行业环境影响，公司生态环境建设业务规模收缩，营业收入同比下降，亏损金额有所增加，本期实现营业收入16,307.97万元，同比下降31.28%；净利润-13,054.12万元，同比增亏24.67%。本期增亏主要项目变动原因如下：

①营业毛利减少2,608.09万元，主要原因包括：营业收入规模下降；部分工程项目因工期延误、整改等因素影响，实际投入成本增加；以及部分前期项目在本期完成竣工决算审计，存在价审调减。

②财务费用增加1,133.43万元，主要受两方面因素影响：一是存量PPP项目因“贷款市场报价利率（LPR)”变动导致投资回报率调整，未实现融资收益减少，使得财务费用增加2,035万元；二是本期借款本金减少及借款利率随LPR下行，相应减少借款利息费用913.99万元。

③投资收益减少752.41万元，主要系致达金控投资管理（北京）有限公司向公司寻求利息减免，经双方协商一致，借款利息按原约定金额的30%核算，由此形成债务重组损失782.55万元。

④所得税费用增加820.89万元，主要系公司根据本期经营情况，对未来期间可取得的应纳税所得额进行重新预计，相应调整递延所得税资产所致。

半导体存储业务，芯存科技2025年度净利润为1,828.33万元，归属于母公司股东的净利润932.81万元，净利润金额仍不足以弥补生态环境建设板块产生的亏损。

综上，2025年公司围绕半导体存储和生态环境建设双主业发展，生态环境建设业务适度收缩、半导体存储业务适度扩张，半导体存储业务收入大幅增长，生态环境建设业务收入规模下降，导致公司营业收入大幅增长；生态环境建设业务产生金额较大的亏损，而半导体存储业务产生的净利润未能全部弥补生态环境建设业务产生的亏损；上述情况与公司双主业战略推进阶段的实际情况相符，具备商业合理性。

## （二）收入增速与税金及附加增速相背离的原因及合理性

2025年公司主营业务收入同比增长44.75%，税金及附加同比下降71.57%。两者背离的原因主要系计税基础与收入口径不同及待抵扣进项税额增加所致，具体原因如下：

## 1、税金及附加计税基础与收入确认口径不同

公司税金及附加主要包括城市维护建设税、教育费附加和地方教育附加。

（1)公司生态环境建设业务2024年度、2025年度营业收入分别为23,730.48万元、16,307.97万元；实际缴纳增值税分别为665.66万元、809.33万元；税金及附加分别为248.01万元、24.34万元。2025年该项业务收入同比下降31.28%，税金及附加同比下降90.19%，实际缴纳增值税同比增长21.58%。2025年度，税金及附加降幅高于收入降幅，且与增值税缴纳金额变动趋势存在差异，该变动符合公司实际经营现状及建筑行业特点，具体原因说明如下：

①生态环境建设业务属于建筑行业范畴，其业务收入按照企业会计准则规定确认，但增值税销项税额是在向业主办理工程价款结算、开具发票时确认，即销项税额确认时间点整体滞后于收入确认时点。2025年度公司开票结算规模高于2024年度，当期申报缴纳的增值税相应增加，因此实际缴纳增值税同比有所上升。

②2025年度前，公司以暂估的销项税额扣除进项税额后的净额为基数计提相关附加税费，按照实际缴纳的增值税为计税依据申报缴纳附加税。截至2025年末，生态环境建设板块应交税费中应交城市维护建设税、教育费附加和地方教育附加合计余额703.62万元，其中已计提但尚未达到纳税申报节点的相关附加税合计余额635.89万元，同时公司存在增值税留抵退税额1,709.98万元，可于未来期间抵减税金及附加申报基数。另外考虑到目前部分前期项目在完成竣工决算审计时存在价审调减情况，同时受行业整体环境影响，公司主动采取收缩策略，工程项目收入规模缩减。综上，2025年公司调整税金及附加计提口径为：仅对养护项目未开票收入，以暂估的销项税额扣除进项税额后的净额为基数计提相关税费，待后续正式开票结算时予以冲回；对于工程项目其他未开票收入，不再计提对应税金及附加。总体来说，计提口径的调整是2025年度税金及附加降幅高于收入降幅的主要原因。

（2）半导体存储业务主要的税金及附加计税依据为申报的应缴纳增值税，城建税、教育费附加、地方教育附加的税率5%、3%、2%，根据2023年至2025年申报表应缴纳的增值税，近三年税金及附加的计税依据金额分别为101.10万元、294.50万元、465.06万元，其中2023年1月至2025年6月享受小微企业六税两费减半征收政策。2024年10-12月、2025年度营业收入分别为11,058.91万元、34，048.57万元，实际缴纳的增值税分别为51.27万元、433.66万元，税金及附加分别为6.57万元、48.05万元，公司半导体存储业务2025年度收入较2024年四季度增长207.88%，税金及附加增长631.35%，税金及附加的增长幅度大于收入增长幅度主要由于附加税计税依据为已缴增值税，截至2025年12月31日，公司存在尚未认证抵扣的进项税额2,777.07万元，该部分进项税额已于2026年陆续进行认证抵扣，截止目前已勾选抵扣进项税1,542.13万元。若公司对于该部分进项税于2025年度进行抵扣，则2025年无需缴纳该部分增值税以及相关附加税，因此收入与税金及附加增速背离符合公司实际情况，目前未勾选抵扣使收入与税金及附加变动整体趋势一致，增值税变动具体情况详见下表：

单位：万元

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2023年度</td><td rowspan=1 colspan=1>2024年度</td><td rowspan=1 colspan=1>2025年度</td></tr><tr><td rowspan=1 colspan=1>期初数（A）</td><td rowspan=1 colspan=1>-2.49</td><td rowspan=1 colspan=1>-214.98</td><td rowspan=1 colspan=1>-403.17</td></tr><tr><td rowspan=1 colspan=1>销项税额（B）[注1]</td><td rowspan=1 colspan=1>656.94</td><td rowspan=1 colspan=1>4,307.79</td><td rowspan=1 colspan=1>4,689.28</td></tr><tr><td rowspan=1 colspan=1>进项税额（C）</td><td rowspan=1 colspan=1>789.92</td><td rowspan=1 colspan=1>4,073.74</td><td rowspan=1 colspan=1>4,932.59</td></tr><tr><td rowspan=1 colspan=1>进项加计抵减（D）</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>143.70</td><td rowspan=1 colspan=1>145.19</td></tr><tr><td rowspan=1 colspan=1>实际缴纳增值税（E）</td><td rowspan=1 colspan=1>79.51</td><td rowspan=1 colspan=1>278.54</td><td rowspan=1 colspan=1>433.66</td></tr><tr><td rowspan=1 colspan=1>期末金额（F=A+B-C-D-E)</td><td rowspan=1 colspan=1>-214.98</td><td rowspan=1 colspan=1>-403.17</td><td rowspan=1 colspan=1>-1,225.34</td></tr></table>

[注1]销项税额与按照收入测算应计提销项税部分差异为净额法处理部分。

[注2]根据账面应缴纳增值税与实际申报增值税差异主要为暂估收入确认的销项税以及未勾选认证的进项税产生。

账面计提主要税金及附加与测算的差异见下表：

单位：万元

<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=2 colspan=1>税率</td><td rowspan=1 colspan=4>2023年度</td><td rowspan=1 colspan=4>2024年度</td><td rowspan=1 colspan=4>2025年度</td></tr><tr><td rowspan=1 colspan=1>计税依据</td><td rowspan=1 colspan=1>税金及附加金额</td><td rowspan=1 colspan=1>测算金额</td><td rowspan=1 colspan=1>差异</td><td rowspan=1 colspan=1>计税依据</td><td rowspan=1 colspan=1>税金及附加金额</td><td rowspan=1 colspan=1>测算金额</td><td rowspan=1 colspan=1>差异</td><td rowspan=1 colspan=1>计税依据</td><td rowspan=1 colspan=1>税金及附加金额</td><td rowspan=1 colspan=1>测算金额</td><td rowspan=1 colspan=1>差异</td></tr><tr><td rowspan=1 colspan=1>城建税</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>101.10</td><td rowspan=1 colspan=1>2.53</td><td rowspan=1 colspan=1>2.53</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>294.50</td><td rowspan=1 colspan=1>7.36</td><td rowspan=1 colspan=1>7.36</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>465.06</td><td rowspan=1 colspan=1>17.51</td><td rowspan=1 colspan=1>17.51</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>教育费附加</td><td rowspan=1 colspan=1>3%</td><td rowspan=1 colspan=1>101.10</td><td rowspan=1 colspan=1>1.52</td><td rowspan=1 colspan=1>1.52</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>294.50</td><td rowspan=1 colspan=1>4.42</td><td rowspan=1 colspan=1>4.42</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>465.06</td><td rowspan=1 colspan=1>10.50</td><td rowspan=1 colspan=1>10.50</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>地方教育附加</td><td rowspan=1 colspan=1>2%</td><td rowspan=1 colspan=1>101.10</td><td rowspan=1 colspan=1>1.01</td><td rowspan=1 colspan=1>1.01</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>294.50</td><td rowspan=1 colspan=1>2.95</td><td rowspan=1 colspan=1>2.95</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>465.06</td><td rowspan=1 colspan=1>7.00</td><td rowspan=1 colspan=1>7.00</td><td rowspan=1 colspan=1>1</td></tr></table>

[注3]芯存科技2024年1月至2025年6月为小微企业，享受六税两费减免政策，故在测算时城建税、教育费附加、地方教育附加实际税率为2.5%、1.5%、1%。

整体来看，税金及附加与当期收入没有完全正相关关系。

## 2、增值税进项税增量较大

公司2025年存货同比增加11,481万元，新采购设备3,000万元，形成可抵扣增值税进项税额较大，导致当期计缴增值税金额较低，直接影响当期税金及附加计缴额。

综上，分板块来看，半导体存储业务税金及附加与收入变动趋势一致；合并范围来看，收入增长反映了公司业务规模的扩大，而税金及附加下降反映了公司实际增值税税负的降低，二者驱动因素不同，背离具有合理性。

出出

<table><tr><td rowspan=2 colspan=1>业务类别</td><td rowspan=1 colspan=3>一季度收入</td><td rowspan=1 colspan=3>二季度收入</td><td rowspan=1 colspan=3>三季度收入</td><td rowspan=1 colspan=3>四季度收入</td><td rowspan=1 colspan=3>年度收入</td></tr><tr><td rowspan=1 colspan=1>2025年一季度</td><td rowspan=1 colspan=1>2024年一季度</td><td rowspan=1 colspan=1>同比变动</td><td rowspan=1 colspan=1>2025年二季度</td><td rowspan=1 colspan=1>2024年二季度</td><td rowspan=1 colspan=1>同比变动</td><td rowspan=1 colspan=1>2025年三季度</td><td rowspan=1 colspan=1>2024年三季度</td><td rowspan=1 colspan=1>同比变动</td><td rowspan=1 colspan=1>2025年四季度</td><td rowspan=1 colspan=1>2024年四季度</td><td rowspan=1 colspan=1>同比变动</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>建设及养护</td><td rowspan=1 colspan=1>3,789.26</td><td rowspan=1 colspan=1>3,625.84</td><td rowspan=1 colspan=1>4.51%</td><td rowspan=1 colspan=1>2,248.02</td><td rowspan=1 colspan=1>3,272.36</td><td rowspan=1 colspan=1>-31.30%</td><td rowspan=1 colspan=1>3,151.72</td><td rowspan=1 colspan=1>2,814.56</td><td rowspan=1 colspan=1>11.98%</td><td rowspan=1 colspan=1>4,165.09</td><td rowspan=1 colspan=1>8,818.42</td><td rowspan=1 colspan=1>-52.77%</td><td rowspan=1 colspan=1>13,354.09</td><td rowspan=1 colspan=1>18, 531.17</td><td rowspan=1 colspan=1>-27.94%</td></tr><tr><td rowspan=1 colspan=1>设计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>370.92</td><td rowspan=1 colspan=1>-100.00%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>414.14</td><td rowspan=1 colspan=1>-100.00%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>402.17</td><td rowspan=1 colspan=1>-100.00%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>568.06</td><td rowspan=1 colspan=1>-100.00%</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1,755.30</td><td rowspan=1 colspan=1>-100. 00%</td></tr><tr><td rowspan=1 colspan=1>运维</td><td rowspan=1 colspan=1>717.41</td><td rowspan=1 colspan=1>1,080.98</td><td rowspan=1 colspan=1>-33.63%</td><td rowspan=1 colspan=1>683.91</td><td rowspan=1 colspan=1>938.27</td><td rowspan=1 colspan=1>-27.11%</td><td rowspan=1 colspan=1>774.95</td><td rowspan=1 colspan=1>742.88</td><td rowspan=1 colspan=1>4.32%</td><td rowspan=1 colspan=1>707.78</td><td rowspan=1 colspan=1>544.60</td><td rowspan=1 colspan=1>29.96%</td><td rowspan=1 colspan=1>2,884.04</td><td rowspan=1 colspan=1>3,306.73</td><td rowspan=1 colspan=1>-12.78%</td></tr><tr><td rowspan=1 colspan=1>商品贸易服务</td><td rowspan=1 colspan=1>-22.51</td><td rowspan=1 colspan=1>-3.84</td><td rowspan=1 colspan=1>486.20%</td><td rowspan=1 colspan=1>86.31</td><td rowspan=1 colspan=1>47.12</td><td rowspan=1 colspan=1>83.17%</td><td rowspan=1 colspan=1>143.26</td><td rowspan=1 colspan=1>20.58</td><td rowspan=1 colspan=1>596.11%</td><td rowspan=1 colspan=1>-181.56</td><td rowspan=1 colspan=1>48.65</td><td rowspan=1 colspan=1>-473.20%</td><td rowspan=1 colspan=1>25.51</td><td rowspan=1 colspan=1>112.51</td><td rowspan=1 colspan=1>-77.33%</td></tr><tr><td rowspan=1 colspan=1>租赁业务及搭电费</td><td rowspan=1 colspan=1>20.94</td><td rowspan=1 colspan=1>4.58</td><td rowspan=1 colspan=1>357.21%</td><td rowspan=1 colspan=1>3.21</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>21.00</td><td rowspan=1 colspan=1>20.19</td><td rowspan=1 colspan=1>4.01%</td><td rowspan=1 colspan=1>-0.80</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>44.34</td><td rowspan=1 colspan=1>24.77</td><td rowspan=1 colspan=1>79.01%</td></tr><tr><td rowspan=1 colspan=1>生态环境建设业务小计</td><td rowspan=1 colspan=1>4,505.10</td><td rowspan=1 colspan=1>5,078.48</td><td rowspan=1 colspan=1>-11.29%</td><td rowspan=1 colspan=1>3,021.45</td><td rowspan=1 colspan=1>4,671.89</td><td rowspan=1 colspan=1>-35.33%</td><td rowspan=1 colspan=1>4,090.92</td><td rowspan=1 colspan=1>4,000.38</td><td rowspan=1 colspan=1>2.26%</td><td rowspan=1 colspan=1>4,690.51</td><td rowspan=1 colspan=1>9,979.73</td><td rowspan=1 colspan=1>-53.00%</td><td rowspan=1 colspan=1>16,307.97</td><td rowspan=1 colspan=1>23,730.48</td><td rowspan=1 colspan=1>-31.28%</td></tr><tr><td rowspan=1 colspan=1>存储产品销售</td><td rowspan=1 colspan=1>4,830.56</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>7,527.68</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>5,118.85</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>14,078.38</td><td rowspan=1 colspan=1>10,443.35</td><td rowspan=1 colspan=1>34.81%</td><td rowspan=1 colspan=1>31,555.48</td><td rowspan=1 colspan=1>10,443.35</td><td rowspan=1 colspan=1>202.16%</td></tr><tr><td rowspan=1 colspan=1>存储产品加工</td><td rowspan=1 colspan=1>337.55</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>412.84</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>=</td><td rowspan=1 colspan=1>633.97</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>925.75</td><td rowspan=1 colspan=1>574.00</td><td rowspan=1 colspan=1>61.28%</td><td rowspan=1 colspan=1>2,310.10</td><td rowspan=1 colspan=1>574.00</td><td rowspan=1 colspan=1>302.46%</td></tr><tr><td rowspan=1 colspan=1>存储材料销售及其他业务</td><td rowspan=1 colspan=1>28.01</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>21.75</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>44.19</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>89.04</td><td rowspan=1 colspan=1>41.56</td><td rowspan=1 colspan=1>114.24%</td><td rowspan=1 colspan=1>182.99</td><td rowspan=1 colspan=1>41.56</td><td rowspan=1 colspan=1>340.30%</td></tr><tr><td rowspan=1 colspan=1>半导体存储业务小计</td><td rowspan=1 colspan=1>5,196.12</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>7,962.27</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>5,797.01</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>15,093.17</td><td rowspan=1 colspan=1>11,058.91</td><td rowspan=1 colspan=1>36,48%</td><td rowspan=1 colspan=1>34,048. 57</td><td rowspan=1 colspan=1>11,058.91</td><td rowspan=1 colspan=1>207.88%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>9,701.22</td><td rowspan=1 colspan=1>5,078.48</td><td rowspan=1 colspan=1>91.03%</td><td rowspan=1 colspan=1>10,983.72</td><td rowspan=1 colspan=1>4,671.89</td><td rowspan=1 colspan=1>135.10%</td><td rowspan=1 colspan=1>9,887.94</td><td rowspan=1 colspan=1>4,000.38</td><td rowspan=1 colspan=1>147.18%</td><td rowspan=1 colspan=1>19, 783. 68</td><td rowspan=1 colspan=1>21,038.64</td><td rowspan=1 colspan=1>-5.97%</td><td rowspan=1 colspan=1>50,356.55</td><td rowspan=1 colspan=1>34,789.39</td><td rowspan=1 colspan=1>44.75%</td></tr></table>

不暴品不（一）

## （二）四季度收入大幅增加的原因及合理性

2025年四季度公司实现营业收入1.98亿元，占全年收入的39.29%，环比增长100.08%。收入增长主要源于半导体存储业务受益于行业季节性旺季及市场需求驱动。

2025年第四季度，公司半导体存储业务营业收入为15,093.17万元，较2025年第三季度增长160.34%，较2024年第四季度增长36.48%。半导体存储业务收入显著增长主要受以下因素共同驱动：其一，行业下游客户如数据中心、云服务商、消费电子厂商通常在四季度完成年度采购计划，订单下达及交付验收较为集中，形成年度备货高峰；其二，自2025年第三季度末起，AI模型与数据中心需求爆发驱动存储需求结构性旺盛；同时，全球存储原厂产能持续向高毛利企业级、AI相关产品倾斜，通用型存储供给持续收紧，存储产品价格自第三季度末起进入快速上涨通道。受季节性旺季、AI需求拉动、供给收缩、价格上行多重利好共振，公司半导体存储产品收入实现同比显著增长。

公司2025年第四季度半导体存储行业实现同比、环比双增长，整体增长趋势与同行业公司基本一致。同比增长幅度明显低于同行业公司，主要系公司2025年经营重点为整合封装资源、规范营运管理、优化客户结构，而非短期内快速扩大规模；环比增长幅度明显高于同行业公司，主要因前三季度受整合封装资源、搬迁新厂房、产线安装调试、以及优化客户结构等因素综合影响，产销量相对较低，而四季度行业进入量价齐升上行周期，公司产销量得以较大幅度的提升，进而形成较高环比增长，符合行业周期上行的整体发展态势。

<table><tr><td rowspan=2 colspan=1>公司简称</td><td rowspan=1 colspan=3>2025年第4季度</td></tr><tr><td rowspan=1 colspan=1>收入金额（万元）</td><td rowspan=1 colspan=1>同比增长</td><td rowspan=1 colspan=1>环比增长</td></tr><tr><td rowspan=1 colspan=1>江波龙</td><td rowspan=1 colspan=1>603,183.80</td><td rowspan=1 colspan=1>43.77%</td><td rowspan=1 colspan=1>-7.75%</td></tr><tr><td rowspan=1 colspan=1>佰维存储</td><td rowspan=1 colspan=1>472,739.61</td><td rowspan=1 colspan=1>183.08%</td><td rowspan=1 colspan=1>77.54%</td></tr><tr><td rowspan=1 colspan=1>德明利</td><td rowspan=1 colspan=1>412,999.06</td><td rowspan=1 colspan=1>251.33%</td><td rowspan=1 colspan=1>61.96%</td></tr><tr><td rowspan=1 colspan=1>诚邦股份-半导体存储业务</td><td rowspan=1 colspan=1>15,093.17</td><td rowspan=1 colspan=1>36.48%</td><td rowspan=1 colspan=1>160.34%</td></tr></table>

## （三）收入确认政策及合规性说明

## 1、公司收入确认政策

公司收入确认严格遵循企业会计准则及相关规定，根据业务性质和合同条款，在客户取得相关商品或服务控制权时确认收入。2025年度较2024年度，收入确认会计政策未发生变更，具体如下：

## （1）建造服务业务

根据履约进度在一段时间内确认收入，履约进度的确定方法为产出法，具体根据累计已履约的工程量/预计总工程量确定。

## （2）设计业务

公司向客户提供设计等劳务，由于公司履约过程中所提供产出的服务或商品具有不可替代用途，且公司在整个合同期间内有权就累计至今已完成的履约部分收取款项，公司将其作为在某一时段内履行的履约义务，按照履约进度确认收入，履约进度不能合理确定的除外。履约进度的确定方法为产出法，具体根据业务类型和阶段节点，根据客户或第三方确认的进度佐证资料确定。履约义务中已履行部分相关的支出计入当期损益。

## （3）养护及运维服务

公司向客户提供养护及运维等服务，由于公司履约过程中是持续地向客户转移企业履约所带来的经济利益，同时客户为养护提供了不可或缺的基础条件，即养护及运维服务在客户指定场地内进行，从而在履约期间内按养护/运维单价乘以实际工作量确认收入，履约义务中已履行部分相关的支出计入当期损益。

## （4）PPP业务

1）建造期间：公司对于所提供的建造服务应当按照《企业会计准则第14号一收入》确认相关的收入和费用。建造服务收入应当按照收取或应收对价的公允价值计量，并分别以下情况在确认收入的同时，确认金融资产或无形资产：

①合同规定基础设施建成后的一定期间内，项目公司可以无条件地自合同授予方收取确定金额的货币资金或其他金融资产的；或在项目公司提供经营服务的收费低于某一限定金额的情况下，合同授予方按照合同规定负责将有关差价补偿给项目公司的，应当在确认收入的同时确认金融资产，并按照《企业会计准则第22 号一一金融工具确认和计量》的规定处理。

②合同规定项目公司在有关基础设施建成后，从事经营的一定期间内有权利向获取服务的对象收取费用，但收费金额不确定的，该权利不构成一项无条件收取现金的权利，应当在确认收入的同时确认无形资产。建造过程如发生借款利息，应当按照《企业会计准则第17号一一借款费用》的规定处理。

2）运营期：根据《企业会计准则解释第14号》，基础设施建成后，项目公司应当按照《企业会计准则第14号一一收入》确认与后续经营服务相关的收入。

## （5）半导体存储业务

## 1）销售收入

①由公司负责将货物送达客户或客户指定交货地点的，在货物已运抵客户或客户指定地点，经客户确认签收，已收取货款或取得收取货款的凭证且相关的经济利益很可能流入时，确认销售收入；

②由客户自提货物时，在客户提取货物并签收确认，已收取货款或取得收取货款的凭证且相关的经济利益很可能流入，确认销售收入；

③外销且不属于上述①、②的收入确认需满足以下条件：公司已根据合同约定将产品报关、货物装运离港，取得报关单、提单，已收取货款或取得收取货款的凭证且相关的经济利益很可能流入时，确认销售收入。

## 2）加工收入

在公司完成履约义务并与客户确认结算、已收取货款或取得收取货款的凭证且相关的经济利益很可能流入时，确认销售收入。

## 2、收入确认政策合规性

公司2025年度收入确认政策未发生变更，与企业会计准则及相关规定一致，符合监管要求。公司收入确认依据充分，包括合同、发货单、签收单、验收报告、结算单、产值单、价审报告等，确保了收入确认的真实性、准确性和完整性。

综上，公司收入确认政策符合企业会计准则的相关规定，收入确认真实、合规。

## 【年审会计师回复】

## （一）核查程序

## 1、针对收入的核查程序

1)了解与收入确认相关的内部控制，评价这些控制的设计，确定其是否得到执行，并测试关键控制是否得到有效运行；

2)获取重大工程施工合同，复核关键合同条款；获取重大建造合同的结算资料，根据经客户确认的产值确认单验证合同收入；

3)获取并检查重大销售合同，识别与商品控制权转移相关的合同条款与条件，评价收入确认政策是否符合企业会计准则的要求；

4)执行细节测试，抽样检查客户的合同或订单、报关单、签收记录、运输单据、银行收款单、发票等原始单据；

5)结合应收款项函证，以抽样方式向主要客户函证已经完成的合同工作量、本期销售额，对未回函的样本执行替代测试;

6)抽样选取重大工程项目，现场查看已经完成的合同工作量；抽样选取重要客户和供应商执行实地走访、访谈程序；

7)对客户变动情况进行分析，查询新增重要客户的工商登记等信息，检查是否存在异常客户，识别客户与公司是否存在关联关系；

8)执行收入截止性测试，复核收入是否确认在恰当的会计期间；

9)结合销售回款情况检查收入的真实性；

10)对本期重大工程项目、本期及期后销售商品收入及毛利率执行分析性复核程序；

11)比较各季度收入及毛利率波动情况，分析其变动趋势是否正常及合理性的原因，并与同行业企业进行对比分析；

12)检查与营业收入相关的信息是否已在财务报表中作出恰当列报。

## 2、针对税费的核查程序

1)针对城市维护建设税、教育费附加、地方教育附加等增值税附加税费，核查其计税依据与收入的匹配关系：

①根据已确认的收入、本年存货和新增设备的采购按适用的税率重新测算应交增值税销项税额、进项税额并与账面及获取的纳税申报表相关数据进行核对，分析数据的匹配性；

②以经检查核对确认的应交增值税为计税依据，按照适用税率重新测算城市维护建设税、教育费附加、地方教育附加等增值税附加税费，复核附加税费计算的准确性和完整性；

2)获取财产和行为税纳税申报表，重新测算印花税应缴纳情况，核对印花税与收入增减变动趋势是否一致，分析变动原因。

## 3、针对会计政策的核查程序

我们获取了公司现行收入确认会计政策文件，结合工程建筑行业与制造业的行业特性，重点核查以下内容：

分析公司收入确认政策是否符合《企业会计准则第14号——收入》及相关准则要求，是否与同行业可比公司会计政策保持一致，是否符合行业惯例；

对比公司以前年度收入确认政策，确认本期是否发生会计政策变更、会计估计调整，若存在变更是否履行了必要的决策程序及信息披露义务。

## （二）核查结论

经审核，我们认为公司归母净利润持续亏损且亏损金额增加主要系生态环境业务亏损增加所致；收入增速与税金及附加增速相背离、四季度收入大幅增加等情况，符合公司实际经营情况；公司收入确认政策未发生变更，收入确认政策符合企业会计准则相关规定。

问题2.关于芯存科技。年报和往年回函显示，公司半导体存储业务主要通过下属控股子公司芯存电子开展，分直销和贸易两种销售模式。2025年，公司半导体存储业务收入3.39亿元，较上年增加207.38%；毛利率为14.91%，同比增加11.06个百分点。其中，存储产品销售业务收入3.16亿元，毛利率为16.59%，毛利率同比增加13.09个百分点；存储产品加工业务收入2310.10万元，毛利率-8.09%，毛利率同比减少18.25个百分点。公司境内外毛利率差异较大且同比变化较大，2025年，公司境内业务毛利率为21.94%，同比增加19.06个百分点；境外毛利率为6.67%，同比增加0.83个百分点。此外，2025年，公司研发人员为15人，同比减少12人。请公司补充披露：（1）按照2025年和2024年全年口径，分业务类别、直销和贸易模式、境内和境外，列示前十大客户及关联关系、销售产品、收入、销量、回款、贸易商的终端销售情况等，说明半导体存储业务收入大幅增加的原因，以及收入规模扩大但研发人员大幅下降的合理性；（2）结合业务模式、主要客户、产品类型、产品价格及成本变化、同行业可比公司情况，说明半导体存储业务毛利率大幅增加、半导体存储产品加工业务毛利率大幅下降且为负的原因及合理性；（3）结合境内外客户构成差异和变化情况、销售的具体产品、销售模式、定价模式、市场需求和竞争格局以及同行业可比公司情况等，说明公司2025年境内毛利率大幅增加的原因和合理性，以及境内外毛利率差异较大的原因和合理性。

## 【公司回复】

一、按照2025年和2024年全年口径，分业务类别、直销和贸易模式、境内和境外，列示前十大客户及关联关系、销售产品、收入、销量、回款、贸易商的终端销售情况等，说明半导体存储业务收入大幅增加的原因，以及收入规模扩大但研发人员大幅下降的合理性

## （一）2025年度半导体存储业务收入增长的原因

芯存科技自2024年10月纳入公司合并报表。从合并范围和口径看，2024年四季度营业收入11,058.91万元。2025年全年，公司半导体存储业务实现收入34，048.57万元，较2024年度同比增长207.88%，主要系合并报表期间差异导致收入大幅增长。按全年完整口径，2024年年度芯存科技实现收入31,742.17万元，2025年同比增长7.26%。2025年，公司整合封装测试资源、完善产业链布局、优化客户结构，同时叠加存储行业上行周期，业务整体呈现稳步增长态势，相关变动具备合理的业务基础与行业背景。

## 1、合并期间差异导致收入同比大幅增长

公司于2024年10月新切入半导体存储领域，当期仅将芯存科技2024年第四季度实现的收入11,058.91万元纳入合并报表范围，因对比基数较低导致公司2025年度半导体业务收入在合并报表口径下呈现同比大幅增长。按全年完整口径，2024年年度芯存科技实现收入31,742.17万元，2025年同比增长7.26%。

<table><tr><td rowspan=1 colspan=1>排名</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>关联关系</td><td rowspan=1 colspan=1>模式</td><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>业务类别</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>含税销售额（万元）</td><td rowspan=1 colspan=1>回款金额（万元）</td><td rowspan=1 colspan=1>回款比例</td></tr><tr><td rowspan=6 colspan=1>1</td><td rowspan=6 colspan=1>香港**有限公司A</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>贸易商</td><td rowspan=6 colspan=1>境外</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>9,636.24</td><td rowspan=6 colspan=1>10,601.35</td><td rowspan=6 colspan=1>10,768. 67</td><td rowspan=6 colspan=1>101.58%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>799.15</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>157.10</td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>3.27</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>10,595. 76</td></tr><tr><td rowspan=6 colspan=1>2</td><td rowspan=6 colspan=1>香港**科技有限公司B</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>贸易商</td><td rowspan=6 colspan=1>境外</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>1,840.97</td><td rowspan=6 colspan=1>2,154.01</td><td rowspan=6 colspan=1>5,895.60</td><td rowspan=6 colspan=1>273.70%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>160.27</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>2,001.24</td></tr><tr><td rowspan=5 colspan=1>3</td><td rowspan=5 colspan=1>深圳市天捷恒大科技发展有限公司</td><td rowspan=5 colspan=1>非关联方</td><td rowspan=5 colspan=1>直销</td><td rowspan=5 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1></td><td rowspan=5 colspan=1>2,163.56</td><td rowspan=5 colspan=1>1,592.28</td><td rowspan=5 colspan=1>73.60%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>1,689.72</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>=</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>0.81</td></tr></table>

<table><tr><td rowspan=1 colspan=1>排名</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>关联关系</td><td rowspan=1 colspan=1>模式</td><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>业务类别</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>含税销售额（万元）</td><td rowspan=1 colspan=1>回款金额（万元）</td><td rowspan=1 colspan=1>回款比例</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1,690.53</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=6 colspan=1>4</td><td rowspan=6 colspan=1>深圳市鹏润宁科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>1,427.68</td><td rowspan=6 colspan=1>1,829.72</td><td rowspan=6 colspan=1>1,591.99</td><td rowspan=6 colspan=1>87.01%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>0.06</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>191.29</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>0.19</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1,619.22</td></tr><tr><td rowspan=6 colspan=1>5</td><td rowspan=6 colspan=1>王储电子（香港）有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境外</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>1,459.18</td><td rowspan=6 colspan=1>1,459.18</td><td rowspan=6 colspan=1>1,459.18</td><td rowspan=6 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1,459.18</td></tr><tr><td rowspan=6 colspan=1>6</td><td rowspan=6 colspan=1>深圳**科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>990.07</td><td rowspan=6 colspan=1>1,202.81</td><td rowspan=6 colspan=1>1,124. 81</td><td rowspan=6 colspan=1>93.52%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>=</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>71.38</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>2.97</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1,064.43</td></tr><tr><td rowspan=3 colspan=1>7</td><td rowspan=3 colspan=1>深圳市金胜电子科技有限公司</td><td rowspan=3 colspan=1>非关联方</td><td rowspan=3 colspan=1>直销</td><td rowspan=3 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>1,030.88</td><td rowspan=3 colspan=1>1,166.86</td><td rowspan=3 colspan=1>1,167.96</td><td rowspan=3 colspan=1>100.09%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=2 colspan=1>排名</td><td rowspan=2 colspan=1>客户名称</td><td rowspan=2 colspan=1>关联关系</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2></td><td rowspan=2 colspan=1>模式</td><td rowspan=1 colspan=8></td><td rowspan=2 colspan=1>地区</td><td rowspan=2 colspan=1>业务类别</td><td rowspan=2 colspan=1>销售产品</td><td rowspan=2 colspan=1>收入（万元）</td><td rowspan=2 colspan=2>含税销售额（万元）</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=3 colspan=1></td><td rowspan=3 colspan=1></td><td rowspan=3 colspan=1></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=3 colspan=2></td><td rowspan=3 colspan=8></td><td rowspan=3 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>一</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>1,032. 62</td></tr><tr><td rowspan=6 colspan=1>8</td><td rowspan=6 colspan=1>东莞市晶亿康电子有限公司</td><td rowspan=6 colspan=1>非关联方</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=2>2,051.31</td><td rowspan=6 colspan=8>177. 07%</td><td rowspan=6 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>452.99</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>449.65</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>59.01</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1,008.60</td></tr><tr><td rowspan=6 colspan=1>9</td><td rowspan=6 colspan=1>恒芯电子香港有限公司</td><td rowspan=6 colspan=1>非关联方</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=2>970.33</td><td rowspan=6 colspan=8>100.00%</td><td rowspan=6 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>■</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>=</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>970.33</td></tr><tr><td rowspan=6 colspan=1>10</td><td rowspan=6 colspan=1>深圳豪杰创新电子有限公司</td><td rowspan=6 colspan=1>非关联方</td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=2>621.50</td><td rowspan=6 colspan=9>71. 57%</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>487.48</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>768. 46</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>27,243.63</td><td rowspan=1 colspan=9>115.56%</td></tr></table>

7

<table><tr><td rowspan=1 colspan=1>2024年排名</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>关联关系</td><td rowspan=1 colspan=1>模式</td><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>业务类别</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>含税销售额（万元）</td><td rowspan=1 colspan=1>回款金额（万元）</td><td rowspan=1 colspan=1>回款比例</td></tr><tr><td rowspan=6 colspan=1>5</td><td rowspan=6 colspan=1>深圳市金光泰科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>29.09</td><td rowspan=6 colspan=1>32.87</td><td rowspan=6 colspan=1>32.87</td><td rowspan=6 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>二</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>29.09</td></tr><tr><td rowspan=6 colspan=1>6</td><td rowspan=6 colspan=1>深圳市优讯佳电子科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>6.73</td><td rowspan=6 colspan=1>7.60</td><td rowspan=6 colspan=1>7.60</td><td rowspan=6 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>6.73</td></tr><tr><td rowspan=6 colspan=1>7</td><td rowspan=6 colspan=1>深圳市芯晶彩科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td rowspan=6 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>1</td><td rowspan=6 colspan=1>64.92</td><td rowspan=6 colspan=1>72.47</td><td rowspan=6 colspan=1>111. 63%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>57.42</td></tr><tr><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>0.02</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>57.45</td></tr><tr><td rowspan=4 colspan=1>8</td><td rowspan=4 colspan=1>至誉科技股份有限公司</td><td rowspan=4 colspan=1>非关联方</td><td rowspan=4 colspan=1>直销</td><td rowspan=4 colspan=1>境内</td><td rowspan=3 colspan=1>产品销售</td><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>19.37</td><td rowspan=4 colspan=1>60.41</td><td rowspan=4 colspan=1>64.68</td><td rowspan=4 colspan=1>107.07%</td></tr><tr><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>17.07</td></tr></table>

2

不

<table><tr><td rowspan=1 colspan=1>2024年排名</td><td rowspan=1 colspan=1>客户名称</td><td rowspan=1 colspan=1>关联关系</td><td rowspan=1 colspan=1>模式</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=9></td><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>业务类别</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>含税销售额（万元）</td><td rowspan=1 colspan=2>回款金额（万元）</td></tr><tr><td rowspan=2 colspan=1></td><td rowspan=2 colspan=1></td><td rowspan=2 colspan=1></td><td rowspan=2 colspan=1></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=2 colspan=9></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>53.46</td></tr><tr><td rowspan=6 colspan=1>9</td><td rowspan=6 colspan=1>迈仕渡电子（珠海）有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>直销</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=9></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>一</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>一</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=6 colspan=1>10</td><td rowspan=6 colspan=1>深圳市鼎芯科微电子科技有限公司</td><td rowspan=6 colspan=1>非关联方</td><td rowspan=6 colspan=1>贸易商</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=9></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>一</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>0.18</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>0.39</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=9></td></tr></table>

<table><tr><td rowspan=1 colspan=1>排名</td><td rowspan=1 colspan=1>客户名称</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=10></td><td rowspan=1 colspan=1>关联关系</td><td rowspan=1 colspan=1>模式</td><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>业务类别</td><td rowspan=1 colspan=1>销售产品</td><td rowspan=1 colspan=1>收入（万元）</td><td rowspan=1 colspan=1>含税销售额（万元）</td></tr><tr><td rowspan=6 colspan=1>1</td><td rowspan=6 colspan=1>香港**科技有限公司B</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=1>14,106.88</td><td rowspan=6 colspan=10>80.38%</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>1,466.04</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>0.65</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>17,516.56</td></tr><tr><td rowspan=6 colspan=1>2</td><td rowspan=6 colspan=1>香港**有限公司A</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=1></td><td rowspan=6 colspan=10></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>29.80</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>3,357.45</td></tr><tr><td rowspan=6 colspan=1>3</td><td rowspan=6 colspan=1>深圳**科技有限公司</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=6 colspan=1>3,180.05</td><td rowspan=6 colspan=10>100.00%</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>1</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>其他</td><td rowspan=1 colspan=1>1.35</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>小计</td><td rowspan=1 colspan=1>2,814.20</td></tr><tr><td rowspan=4 colspan=1>4</td><td rowspan=4 colspan=1>东莞市晶亿康电子有限公司</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=4 colspan=1>226.25</td><td rowspan=4 colspan=10>18.65%</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>移动存储类</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=1>其他产品</td><td rowspan=1 colspan=1></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=1 colspan=2>产品加工</td><td rowspan=1 colspan=1>96.00</td></tr></table>

<table><tr><td>排名</td><td>客户名称</td><td>关联关系</td><td>模式</td><td>地区</td><td>业务类别</td><td>销售产品</td><td>收入（万元）</td><td>含税销售额（万元）</td><td>回款金额（万元）</td><td>回款比例</td></tr><tr><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td colspan="2">其他</td><td>1.41</td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td></tr><tr><td></td><td>小计</td><td>1,073.51</td></tr><tr><td rowspan="8">5</td><td rowspan="8">深圳市金光泰</td><td rowspan="8"></td><td rowspan="5">直销</td><td rowspan="5">境内</td><td></td><td>固态硬盘类</td><td>619.55</td><td rowspan="5">700.09</td><td rowspan="5">700.09</td><td rowspan="5">100.00%</td></tr><tr><td>产品销售</td><td>移动存储类</td><td></td></tr><tr><td></td><td>其他产品</td><td></td></tr><tr><td>产品加工</td><td></td><td>=</td></tr><tr><td>其他</td><td></td><td>= 1</td></tr><tr><td></td><td>小计</td><td>619.55</td></tr><tr><td rowspan="6">6</td><td rowspan="6">深圳市优讯佳 电子科技有限 公司</td><td rowspan="6">非关联方</td><td rowspan="6">直销</td><td rowspan="6">境内</td><td>产品销售</td><td>固态硬盘类 移动存储类</td><td>591.68</td><td rowspan="5">668.60</td><td rowspan="5">668.60</td><td rowspan="5">100.00%</td></tr><tr><td></td><td>其他产品</td><td>1</td></tr><tr><td>产品加工</td><td></td><td>1</td></tr><tr><td></td><td></td><td>1</td></tr><tr><td>其他</td><td></td><td>一</td></tr><tr><td rowspan="5"></td><td rowspan="5">非关联方</td><td rowspan="5">直销</td><td rowspan="5"></td><td rowspan="5">产品销售</td><td>小计 固态硬盘类</td><td>591.68 528.91</td><td rowspan="5"></td><td rowspan="5">597.67</td><td rowspan="5"></td></tr><tr><td>移动存储类</td><td></td></tr><tr><td rowspan="3">境内 产品加工 其他</td><td>其他产品</td><td></td></tr><tr><td></td><td>6.70</td></tr><tr><td></td><td></td></tr><tr><td rowspan="3"></td><td rowspan="2">至誉科技股份</td><td rowspan="2"></td><td rowspan="2">直销</td><td rowspan="2"></td><td rowspan="2"></td><td>小计</td><td>535.61</td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td></tr><tr><td>固态硬盘类</td><td>343.14</td></tr><tr><td rowspan="2">8</td><td rowspan="2">有限公司</td><td rowspan="2">非关联方</td><td rowspan="2"></td><td rowspan="2">境内</td><td rowspan="2">产品销售</td><td>移动存储类</td><td>8.05</td><td rowspan="2">553.21</td><td rowspan="2">548.94</td><td rowspan="2">99.23%</td></tr><tr><td>其他产品</td><td></td></tr></table>

<table><tr><td>排名</td><td>客户名称</td><td>关联关系</td><td>模式</td><td>地区</td><td>业务类别</td><td>销售产品</td><td>收入（万元）</td><td>含税销售额（万元）</td><td>回款金额（万元）</td><td>回款比例</td></tr><tr><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td>产品加工</td><td></td><td>70.53</td><td rowspan="2"></td><td rowspan="3"></td><td rowspan="3"></td></tr><tr><td>其他</td><td></td><td>54.21</td></tr><tr><td></td><td>小计</td><td>475.94</td></tr><tr><td rowspan="9">9</td><td rowspan="9">迈仕渡电子 （珠海）有限 公司</td><td rowspan="9">非关联方</td><td rowspan="9"></td><td rowspan="9"></td><td rowspan="9"></td><td>固态硬盘类</td><td></td><td>304.47</td><td rowspan="9"></td><td rowspan="9"></td></tr><tr><td rowspan="2">直销</td><td>产品销售</td><td>移动存储类</td><td></td></tr><tr><td>其他产品</td><td></td><td></td></tr><tr><td>境内 产品加工</td><td></td><td></td><td>344.05</td><td rowspan="3">344.05 100.00%</td></tr><tr><td colspan="3">其他 小计</td><td></td></tr><tr><td colspan="2"></td><td></td><td>304.47</td></tr><tr><td rowspan="3"></td><td>产品销售</td><td>固态硬盘类</td><td>295.85</td></tr><tr><td rowspan="2">贸易商 境内</td><td>移动存储类</td><td></td><td rowspan="2">334.31</td></tr><tr><td>其他产品</td><td></td></tr><tr><td rowspan="2">微电子科技有 非关联方 限公司</td><td rowspan="5"></td><td rowspan="5">其他</td><td colspan="2">产品加工</td><td></td><td rowspan="5">28,532.26</td><td rowspan="5">20,700.10</td><td rowspan="5">327.60 97.99%</td></tr><tr><td colspan="2"></td><td></td></tr><tr><td colspan="2" rowspan="3"></td><td>小计</td><td>295.85</td></tr><tr><td></td><td>27,584.81</td></tr><tr><td></td><td></td></tr></table>

公司2025年营运重点是：整合封装测试资源，完善产业链，优化客户结构，促进业务稳步增长，保障公司持续稳定的发展。从前十大客户相关数据可见：

2025年度，公司前十大客户业务收入为22,210.37万元，较2024年度的27,584.81万元有所下降，前十大客户收入占公司年度营业收入的比例由86.90%降至65.23%，客户集中度下降，客户覆盖范围更宽，收入增长来源更趋分散、稳健。

分业务模式来看，直销业务收入由2024年的5,341.45万元增长至2025年的8,604.77万元，收入占比由19.36%提升至38.74%，直销业务占比明显提升，有利于增强公司业务稳定性，改善整体盈利水平。

分区域来看，境内业务收入由2024年的6,710.81万元增长至2025年的7,183.86万元，收入占比由24.33%提升至32.34%，境内外业务结构更趋均衡。

分产品来看，整合封装测试资源后，公司产品结构得到优化，移动存储类业务收入由2024年的1,503.89万元增长至2025年的3,589.67万元，收入占比由5.45%提升至16.16%。

综上，公司客户结构和产品结构得以优化，客户集中度下降，境内外业务趋向均衡，毛利率较高的直销业务和移动存储类业务收入占比提升，促进公司业务更加稳健，业务收入和盈利稳步增长。

## 3、不同客户销售价格差异具备合理性

存储产品价格受存储容量、晶圆存储密度、晶圆等级、晶圆制程、主控方案、封装与通道设计、测试可靠性要求等因素综合影响，即使是同类产品，不同客户对产品有不同组合的细分要求，导致产品价格差异较大。同一时期采购的同类产品，比如128GB晶圆较低等级5U级和最高E0E级的晶圆采购价格差异超过2倍。2025年第四季度存储产品价格上涨，第四季度的存储产品价格比前三季度的存储产品价格也有超过一倍差异。因此不同客户销售价格差异具备合理性。

如2025年度前十大客户中，四季度销售的某客户256GB双叠纯金线BGA产品销售单价最高可达200元/件左右；而前三季度销售的某客户64GB单叠合金线BGA产品平均销售单价约为10元/件。四季度销售的某客户TF卡产品平均销售单价约为63元/件；上半年销售的某客户U盘平均销售单价约为7元/件。不同客户的产品类型、容量、晶圆等级及采购时点均不同，平均单价存在较大差异，具有合理性。

## 4、与同行业变动方向一致

同行业可比公司江波龙、德明利、佰维存储 2025年收入同比增幅分别为30.36%、126.07%、68.82%。芯存科技2025年收入与2024年同口径同比增长7.26%，变动方向与同行业一致，同比增幅明显低于同行业公司，主要系公司2025年经营重点为整合封装资源、规范营运管理、优化客户结构，而非短期内快速扩大规模，符合公司当前发展阶段实际情况，是具备合理性的。

## （二）收入规模扩大但研发人员下降的合理性

2025年末，公司研发人员数量为15人，其中半导体存储板块14人、生态环境建设板块1人。2024年末，公司研发人员数量为27人，其中半导体存储板块12人、生态环境建设板块15人。生态环境建设业务采取收缩策略，研发人员大幅缩减至1人，导致合并范围研发人员减少。半导体存储板块研发人员是随着收入增长而相应增加的，公司2025年度持续加大研发投入，开展多项研发项目，当期新增申请发明专利3项、实用新型17项。

因此，从公司两大业务板块分别来看，公司2025年收入规模扩大主要系半导体存储板块增加所致，研发人员下降系生态环境业务收缩所致，是公司转型阶段出现的特殊情况，符合公司业务发展需要的，具备合理性。

二、结合业务模式、主要客户、产品类型、产品价格及成本变化、同行业可比公司情况，说明半导体存储业务毛利率大幅增加、半导体存储产品加工业务毛利率大幅下降且为负的原因及合理性。

## （一）存储业务毛利率大幅上升的原因

2025年度，公司半导体存储业务毛利率为14.91%，同比增加11.06个百分点；其中，存储产品销售业务毛利率为16.59%，同比增加13.09个百分点，毛利率大幅上升主要源于以下因素：

（1）行业周期上行带动产品售价大幅上涨。

2025 年存储行业进入复苏上行周期，尤其是四季度进入大幅增长期，公司四季度实现主营业务收入15,004.13万元，占全年存储主营业务收入33,865.58万元的比重达44.30%，高景气阶段收入占比较高，有效推动整体毛利率提升。

（2）业务模式优化，高毛利直销占比提升。

分业务模式的主营收入、成本及毛利率情况如下：

①2025年度
<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2025年度收入</td><td rowspan=2 colspan=1>2025年度成本（万元）</td><td rowspan=2 colspan=1>2025年度毛利率</td></tr><tr><td rowspan=1 colspan=1>金额（万元）</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>18, 564.22</td><td rowspan=1 colspan=1>54.82%</td><td rowspan=1 colspan=1>14,191.50</td><td rowspan=1 colspan=1>23.55%</td></tr><tr><td rowspan=1 colspan=1>贸易</td><td rowspan=1 colspan=1>15,301.36</td><td rowspan=1 colspan=1>45.18%</td><td rowspan=1 colspan=1>14,625.21</td><td rowspan=1 colspan=1>4.42%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>33,865. 58</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>28,816.71</td><td rowspan=1 colspan=1>14.91%</td></tr></table>

②2024年10-12月
<table><tr><td rowspan=2 colspan=1>项目</td><td rowspan=1 colspan=2>2024年10-12月收入</td><td rowspan=2 colspan=1>2024年10-12月成本（万元）</td><td rowspan=2 colspan=1>2024年10-12月毛利率</td></tr><tr><td rowspan=1 colspan=1>金额（万元）</td><td rowspan=1 colspan=1>占比</td></tr><tr><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>2,564.87</td><td rowspan=1 colspan=1>23.28%</td><td rowspan=1 colspan=1>2,496.95</td><td rowspan=1 colspan=1>2.65%</td></tr><tr><td rowspan=1 colspan=1>贸易</td><td rowspan=1 colspan=1>8,452.47</td><td rowspan=1 colspan=1>76.72%</td><td rowspan=1 colspan=1>8,096.24</td><td rowspan=1 colspan=1>4.21%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>11, 017.34</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>10,593.19</td><td rowspan=1 colspan=1>3.85%</td></tr></table>

直销模式的客户为终端制造厂商，定价主要依据市场行情；渠道贸易模式主要服务渠道类客户，公司择优拓展长期战略合作型渠道客户，在市场行情相对疲软阶段即与渠道客户协商定价，以相对较低的价格保障适当的销量。2025年三季度起存储市场供给趋紧，存储产品价格出现明显上涨。在第四季度存储涨价期间，公司直销模式业务占比较高且毛利率随行业景气上行显著提升，而渠道贸易模式业务占比较低且毛利率较低，因此公司2025年渠道贸易模式的毛利率大幅低于直销模式。

公司主营业务收入中，2025年直销收入18,564.22万元，占全年收入比重为54.82%；2024年10-12月公司直销收入为2,564.87万元，占同期收入比重为23.28%。高毛利直销业务占比大幅提升，有效推动整体毛利率上升。

江波龙、德明利、佰维存储2025年度直销业务毛利率分别为20.98%、12.98%和15.10%，2024年度毛利率分别为19.77%、10.71%和19.57%（未单独披露四季度毛利率数据)。2025年度，公司直销业务毛利率与同行业可比公司不存在重大差异；2024年公司四季度毛利率低于同行业年度毛利率，主要系：①2024年存储行业处于下行周期，同行业上半年毛利率普遍高于全年毛利率，反映出行业第三、四季度盈利水平整体承压；②芯存科技2023年下半年开始由存储模组加工服务升级到产销研一体模式，2024年处于产品市场验证与客户拓展阶段，为加速市场渗透，公司主动采取让利定价策略，阶段性压低盈利空间。

总体来看，公司经营模式与同行业可比公司不存在明显差异，2025年公司直销业务毛利率已回归行业合理区间，与同行业基本保持一致。同时，由于直销业务收入占比持续提升，有效优化收入结构，进一步拉动公司整体毛利率稳步改善。

## （3）产品结构改进，高毛利产品占比提升。

公司主要产品为固态硬盘类产品和移动存储产品，其收入、成本、毛利率及单价情况列示如下：

<table><tr><td rowspan=1 colspan=1>细分产品</td><td rowspan=1 colspan=1>2025年度收入（万元）</td><td rowspan=1 colspan=1>2024年10-12月收入（万元）</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>24,779.92</td><td rowspan=1 colspan=1>10,251.91</td><td rowspan=1 colspan=1>141.71%</td></tr><tr><td rowspan=1 colspan=1>移动存储</td><td rowspan=1 colspan=1>6,461.22</td><td rowspan=1 colspan=1>191.44</td><td rowspan=1 colspan=1>3275.01%</td></tr></table>

续：

<table><tr><td rowspan=1 colspan=1>细分产品</td><td rowspan=1 colspan=1>2025年度成本（万元）</td><td rowspan=1 colspan=1>2024年10-12月成本（万元）</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>21,473.45</td><td rowspan=1 colspan=1>9,945.46</td><td rowspan=1 colspan=1>115.91%</td></tr><tr><td rowspan=1 colspan=1>移动存储</td><td rowspan=1 colspan=1>4,537.06</td><td rowspan=1 colspan=1>132.11</td><td rowspan=1 colspan=1>3334.27%</td></tr></table>

续：

<table><tr><td rowspan=1 colspan=1>细分产品</td><td rowspan=1 colspan=1>2025年度毛利率</td><td rowspan=1 colspan=1>2024年10-12月毛利率</td><td rowspan=1 colspan=1>变动</td></tr><tr><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>13.34%</td><td rowspan=1 colspan=1>2.99%</td><td rowspan=1 colspan=1>10.35%</td></tr><tr><td rowspan=1 colspan=1>移动存储</td><td rowspan=1 colspan=1>29.78%</td><td rowspan=1 colspan=1>30.99%</td><td rowspan=1 colspan=1>-1.21%</td></tr></table>

续：

<table><tr><td rowspan=1 colspan=1>细分产品</td><td rowspan=1 colspan=1>2025年度单价（元/件）</td><td rowspan=1 colspan=1>2024年10-12月单价（元/件）</td><td rowspan=1 colspan=1>变动比例</td></tr><tr><td rowspan=1 colspan=1>固态硬盘类</td><td rowspan=1 colspan=1>75.68</td><td rowspan=1 colspan=1>24.49</td><td rowspan=1 colspan=1>208.98%</td></tr><tr><td rowspan=1 colspan=1>移动存储</td><td rowspan=1 colspan=1>13.19</td><td rowspan=1 colspan=1>2.92</td><td rowspan=1 colspan=1>352.00%</td></tr></table>

如上述表格所示，2025年固态硬盘类产品平均售价由24.49元/件上涨至75.68元/件，涨幅达208.98%；移动存储类产品平均售价由2.92元/件上涨至13.19元/件，涨幅达352.00%。2025年4月公司整合封装测试资源，移动存储产品收入由191.44万元提升至6,461.22万元，收入占比由1.74%提升至19.08%，推动公司整体毛利率水平提升。

如前述，2025年公司前十大客户合计实现收入22,210.37万元，占全年收入比重65.23%。从业务模式看，贸易商收入合计13,605.60万元，占全年收入比重39.96%，其中直销收入合计8,604.77万元，占比25.27%。对比2024年，公司前十大客户合计收入占比由86.90%降至65.23%，客户集中度有所下降；同期直销收入占比由19.36%提升至38.74%，贸易商收入占比由80.64%降至61.26%，业务结构中高毛利的直销占比提升、低毛利率贸易商占比回落，客户结构进一步优化，推动整体毛利率上升。

## （4）与同行业可比公司变动趋势基本一致。

同行业可比公司2025年度与2024年10-12月整体毛利率情况具体如下：

<table><tr><td rowspan=1 colspan=1>公司简称</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年10-12月</td></tr><tr><td rowspan=1 colspan=1>江波龙</td><td rowspan=1 colspan=1>19.40%</td><td rowspan=1 colspan=1>11. 17%</td></tr><tr><td rowspan=1 colspan=1>德明利</td><td rowspan=1 colspan=1>14.81%</td><td rowspan=1 colspan=1>1.29%</td></tr><tr><td rowspan=1 colspan=1>佰维存储</td><td rowspan=1 colspan=1>21.45%</td><td rowspan=1 colspan=1>5.18%</td></tr><tr><td rowspan=1 colspan=1>可比公司平均</td><td rowspan=1 colspan=1>18.55%</td><td rowspan=1 colspan=1>5.88%</td></tr><tr><td rowspan=1 colspan=1>芯存科技</td><td rowspan=1 colspan=1>14.91%</td><td rowspan=1 colspan=1>3.85%</td></tr></table>

分产品来看，同行业可比公司主要产品毛利率情况如下：

<table><tr><td rowspan=2 colspan=1>公司简称</td><td rowspan=1 colspan=2>2025年度</td></tr><tr><td rowspan=1 colspan=1>固态硬盘</td><td rowspan=1 colspan=1>移动存储</td></tr><tr><td rowspan=1 colspan=1>江波龙</td><td rowspan=1 colspan=1>15.49%</td><td rowspan=1 colspan=1>29.77%</td></tr><tr><td rowspan=1 colspan=1>德明利</td><td rowspan=1 colspan=1>12.69%</td><td rowspan=1 colspan=1>20.74%</td></tr><tr><td rowspan=1 colspan=1>可比公司平均</td><td rowspan=1 colspan=1>14.09%</td><td rowspan=1 colspan=1>25.26%</td></tr><tr><td rowspan=1 colspan=1>芯存科技</td><td rowspan=1 colspan=1>13.34%</td><td rowspan=1 colspan=1>29.78%</td></tr></table>

注1：佰维存储产品分类方式不同，无法取得固态硬盘和移动存储相关毛利率。

注2：同行业公司未按季度披露分产品毛利数据。

公司整体毛利率和主要产品毛利率与同行业公司不存在重大差异。

## （二）存储产品加工业务毛利率大幅下降为负的原因

2025年度，公司存储产品加工业务实现收入2,310.10万元，毛利率为-8.09%，同比下降18.25个百分点，毛利率大幅下降的主要源于固定成本及分摊方式影响和加工价格等因素叠加影响：

（1）固定成本大幅上升。2025年初，芯存科技搬迁至新租赁厂房并完整装修改造，同时新增设备投入，导致房屋租金、装修费摊销及设备折旧等固定成本显著增加，相应推高加工业务成本。2025年度公司房租、装修费摊销及设备折旧等固定资产合计发生541.29万元，2024年10-12月固定成本为47.44万元，2025年度固定成本的增加较多。此外，芯存科技纳入上市公司体系后，为优化生产流程、完善岗位配置及改善员工薪酬福利水平，人员成本增加，进一步带动加工业务成本上升。在成本分摊口径上，固定成本按产品数量在销售产品与加工产品之间进行分摊。其中，加工产品单位收入水平偏低，固定成本上涨对其毛利率影响较大；销售产品整体售价较高、盈利空间充足，受固定成本变动的影响相对有限。

（2）固定成本分摊方式影响。芯存科技产品生产制造主要为自动化产线，且主要设备需24小时运行，生产员工的薪酬为计时工资，固定成本只能按产品数量分摊，成本增量大于产量增量致使单位成本上升。2025年9月份之前公司主营的消费类闪存市场疲软，叠加公司搬迁、设备调试、新招人员及培训等因素，前8个月的月均产量明显低于2024年四季度月均产量，致使单位产品加工费上升。

（3）公司存储加工业务，主要配套服务于产品销售客户。2025年加工业务收入的67.82%来自公司产品销售客户，按市场行情定价，未因自身成本增加提高定价。

综上，芯存科技2025年度加工业务毛利率为负，主要系固定成本大幅上升但产量没有相应提高，导致固定成本未能有效摊薄所致，是具有合理性的。同时，加工业务收入金额小、占比低，对公司综合毛利率影响有限。未来随着公司业务规模扩大，固定成本摊薄效应显现，则加工业务毛利率将可能由负转正。

三、结合境内外客户构成差异和变化情况、销售的具体产品、销售模式、定价模式、市场需求和竞争格局以及同行业可比公司情况等，说明公司2025年境内毛利率大幅增加的原因和合理性，以及境内外毛利率差异较大的原因和合理性。

芯存科技境内外主营业务收入、毛利率及变动情况列示如下：
<table><tr><td rowspan=2 colspan=1>销售地区</td><td rowspan=2 colspan=1>·销售模式</td><td rowspan=1 colspan=2>2025年</td><td rowspan=1 colspan=2>2024年10-12月</td></tr><tr><td rowspan=1 colspan=1>收入金额（万元）</td><td rowspan=1 colspan=1>模式/地区占比</td><td rowspan=1 colspan=1>收入金额（万元）</td><td rowspan=1 colspan=1>模式/地区占比</td></tr><tr><td rowspan=3 colspan=1>境内</td><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>16,134.71</td><td rowspan=1 colspan=1>89.27%</td><td rowspan=1 colspan=1>2,564.87</td><td rowspan=1 colspan=1>66.08%</td></tr><tr><td rowspan=1 colspan=1>贸易商</td><td rowspan=1 colspan=1>1,939.18</td><td rowspan=1 colspan=1>10.73%</td><td rowspan=1 colspan=1>1,316.70</td><td rowspan=1 colspan=1>33.92%</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>18,073.89</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>3,881.57</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=3 colspan=1>境外</td><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>2,429.51</td><td rowspan=1 colspan=1>15.38%</td><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>贸易商</td><td rowspan=1 colspan=1>13,362.18</td><td rowspan=1 colspan=1>84.62%</td><td rowspan=1 colspan=1>7,135.77</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>15,791.69</td><td rowspan=1 colspan=1>100.00%</td><td rowspan=1 colspan=1>7,135.77</td><td rowspan=1 colspan=1>100.00%</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>33,865.58</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>11,017.34</td><td rowspan=1 colspan=1>1</td></tr></table>

续：

<table><tr><td rowspan=1 colspan=1>销售地区</td><td rowspan=1 colspan=1>销售模式</td><td rowspan=1 colspan=1>2025年毛利率</td><td rowspan=1 colspan=1>2024年10-12月毛利率</td><td rowspan=1 colspan=1>变动</td></tr><tr><td rowspan=3 colspan=1>境内</td><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>24.46%</td><td rowspan=1 colspan=1>2.65%</td><td rowspan=1 colspan=1>增加21.81个百分点</td></tr><tr><td rowspan=1 colspan=1>贸易商</td><td rowspan=1 colspan=1>2.73%</td><td rowspan=1 colspan=1>0.48%</td><td rowspan=1 colspan=1>增加2.25个百分点</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>22.13%</td><td rowspan=1 colspan=1>1.91%</td><td rowspan=1 colspan=1>增加20.21个百分点</td></tr><tr><td rowspan=3 colspan=1>境外</td><td rowspan=1 colspan=1>直销</td><td rowspan=1 colspan=1>17.56%</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>贸易商</td><td rowspan=1 colspan=1>4.66%</td><td rowspan=1 colspan=1>4.90%</td><td rowspan=1 colspan=1>减少0.24个百分点</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>6.65%</td><td rowspan=1 colspan=1>4.90%</td><td rowspan=1 colspan=1>增加1.74个百分点</td></tr><tr><td rowspan=1 colspan=2>合计</td><td rowspan=1 colspan=1>14.91%</td><td rowspan=1 colspan=1>3.85%</td><td rowspan=1 colspan=1>增加11.06个百分点</td></tr></table>

## （一）境内毛利率大幅上升的原因

2025年度，芯存科技境内业务毛利率为22.13%，比2024年10-12月增加20.21个百分点，毛利率大幅上升主要源于：行业周期上行，尤其是进入四季度量价均出现较大幅度的提升，以及公司客户结构和产品结构优化，毛利较高的移动存储产品和直销业务占比提升。

## （二）境内外毛利率差异较大的原因

2025年度，公司境内主营业务毛利率22.13%，境外主营业务毛利率6.65%，境内外毛利率存在较大差异，该差异系客户结构优化、产品结构改善和境内外市场差异等因素导致，符合行业惯例，具备合理性：

（1）业务模式差异，公司直销模式系直接面向终端制造商开展销售，毛利率通常高于渠道贸易模式。2025年，公司境内主营业务收入为18,073.89万元，其中直销业务收入为16,134.71万元，直销占比89.27%；境外主营业务收入为15,791.69万元，其中直销收入为2,429.51万元，直销占比15.38%。公司境内销售以直销模式为主，境外销售则以渠道贸易商为主，由此导致境内业务毛利率明显高于境外。

（2）公司基于长远稳定发展考虑，年初确定销售策略为优化客户结构，逐步增加直销和品牌客户销售，保障公司业务持续稳定增长，促进研发和生产更具系统性；同时由于四季度市场环境变化，市场供不应求，公司优先考虑毛利更高的境内直销业务，导致四季度高毛利的直销、内销比例进一步提高。

（3）产品结构差异，2025年公司主要产品中，固态硬盘类产品毛利率为13.34%，移动存储产品毛利率为29.78%，移动存储产品毛利率相对较高。分区域来看，2025年移动存储产品境内收入5,159.33万元，占境内总收入比重28.55%;境外收入1,301.89万元，占境外总收入比重8.24%。由于境内高毛利率的移动存储产品收入占比明显高于境外，进而导致公司境内毛利率高于境外。

移动存储类产品平均售价涨幅高，但毛利率下降原因说明如下：

芯存科技移动存储类产品营业收入、平均售价与毛利率变动情况
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年度</td><td rowspan=1 colspan=1>2024年10-12月</td><td rowspan=1 colspan=1>变动</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>6,461.22万元</td><td rowspan=1 colspan=1>191.44万元</td><td rowspan=1 colspan=1>涨幅3275.01%</td></tr><tr><td rowspan=1 colspan=1>平均售价</td><td rowspan=1 colspan=1>13.19元/件</td><td rowspan=1 colspan=1>2.92元/件</td><td rowspan=1 colspan=1>涨幅352.00%</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>29.78%</td><td rowspan=1 colspan=1>30.99%</td><td rowspan=1 colspan=1>减少1.21个百分点</td></tr></table>

2025年4月之前，芯存科技尚不具备移动存储类产品自主封测的生产能力，相关产品委托东莞市芯源科技有限公司（系芯存科技少数股东文雨控制的公司，以下简称“芯源科技"）加工后对外销售，该委托加工业务采用净额法核算营业收入，导致账面毛利率偏高。2025年4月，芯存科技完成对芯源科技的资源整合，包括购置其生产设备、人员整合等，自此芯存科技具备芯片封测能力，实现移动存储类产品自主封测生产并销售。具体情况如下：

金额单位：万元

<table><tr><td rowspan=1 colspan=1>期间</td><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>净额法核算前</td><td rowspan=1 colspan=1>净额法扣除</td><td rowspan=1 colspan=1>净额法核算后</td></tr><tr><td rowspan=2 colspan=1>2024年10-12月</td><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>851.21</td><td rowspan=1 colspan=1>659.77</td><td rowspan=1 colspan=1>191.44</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>6.97%</td><td rowspan=1 colspan=1>二</td><td rowspan=1 colspan=1>30.99%</td></tr><tr><td rowspan=2 colspan=1>2025年度</td><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>8,279.65</td><td rowspan=1 colspan=1>1,818.43</td><td rowspan=1 colspan=1>6,461.22</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>23.24%</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>29. 78%</td></tr></table>

净额法核算口径下，2024年10-12月、2025年度移动存储类产品毛利率分别为30.99%、29.78%；净额法核算前，实际毛利率分别为6.97%、23.24%。2025年度，同行业可比公司德明利移动存储类产品毛利率为20.74%，江波龙的移动存储类产品毛利率为29.77%，芯存科技实际毛利率水平与同行业不存在重大差异，毛利率变动具有合理性。

（4）销售时期结构差异，存储市场行情，尤其公司主营的消费类闪存市场行情,2025年前三季度处于疲软和温和上升的状况,9月下旬进入大幅上涨。2025年四季度，公司内销业务收入9,323.50万元，占内销全年收入的51.59%；外销业务收入5,680.63万元，占外销全年收入的35.97%，其中贸易模式收入为3,251.12万元，占比57.23%、直销模式收入为2,429.51万元，占比42.77%。内销业务在四季度高价位期间的收入占比更高，因此更多受益于市场价格大幅上涨，进一步拉高境内整体毛利率。

（5）同行业可比公司验证。从公开信息查询，同行业可比公司境内外毛利率没有一致性，德明利2025年度内销毛利率比外销高5.68个百分点，佰维存储内销毛利率比外销低3.02个百分点。内外销毛利率受内外销产品结构、业务模式、品牌以及市场价格波动较大时期销售结构差异等因素的综合影响。

## 【年审会计师回复】

## （一）核查程序

## 1、针对存储芯片行业收入的核查程序

1)获取并核查了公司与供应链公司及终端客户签订的销售合同、货物签收记录、报关单据、交易对账单以及收款凭证等关键业务资料，基于上述核查资料，评估销售收入确认的时点与金额的恰当性及准确性；

2)执行收入截止性测试程序，以识别并确认是否存在收入跨期确认的情形；

3)了解并检查供应链公司、终端客户与公司的合作历史、合同履约情况以及期后回款情况；

4)核查主要结算周期及支付方式，调查并确认交易对手方（供应链公司及终端客户）与公司之间是否存在关联方关系；

5)抽样选取供应链公司向终端客户收款的回单，检验业务的真实性；

6)通过向供应链公司、终端客户分别发函询证，双向核验销售业务的真实性、准确性及商业实质；

7)对部分主要贸易商客户进行现场或视频访谈，了解其与公司的业务合作情况、其期末库存情况及下游终端用户对产品的实际使用或最终销售情况；

8)获取公司研发项目立项报告、研发进度跟踪记录及验收资料等，核实研发项目的真实性与合规性；同时查阅研发人员花名册，将研发人员职责与项目参与情况进行匹配，核查研发人员与生产、管理等其他职能人员的划分依据是否清晰，薪酬归集口径是否准确、一贯，确保研发费用中人员薪酬核算的合规性；分析研发费用与收入波动趋势不一致的合理性。

## 2、针对毛利率波动的核查程序

1)了解公司销售定价政策、成本核算流程、存货流转及成本结转方法，评价相关内部控制设计合理性，并对关键控制点执行控制测试，判断其能否有效防范收入、成本错报风险；

2)对资产负债表日前后收入、成本进行截止测试，检查是否存在跨期确认收入、延迟结转成本以调节毛利的情况；

3)对公司毛利率、各业务类别毛利率、境内外毛利率进行统计，结合公司经营情况，分析公司境内外毛利率差异较大的原因及合理性；

4)针对公司ERP系统上线前后的成本分配情况分别实施核查：①对ERP系统上线前的成本分配，基于历史成本数据、BOM表等原始资料，重新执行成本计算程序，核实成本分配标准的恰当性及计算结果的准确性，确认是否存在分配错误；②对ERP系统上线后的成本核算，复核成本计算单、产品物料清单（BOM表）、原材料领用单、制造费用分配表等资料，检查直接材料、直接人工、制造费用的归集范围是否完整，分配标准是否合理，核算金额是否准确，确保成本核算符合企业会计准则及公司会计政策要求。

## （二）核查结论

经核查，我们认为：公司半导体存储业务收入大幅增加，以及公司收入规模扩大但研发人员大幅下降，具备合理性；公司半导体存储业务毛利率大幅增加、半导体存储产品加工业务毛利率大幅下降且为负，具备合理性；公司半导体存储业务2025年境内毛利率大幅增加，以及境内外毛利率差异较大，具备合理性。

问题3.关于生态环境建设业务。年报显示，2025年，公司生态环境建设业务收入1.62亿元，同比下降31.17%。2025年末，公司应收账款6.87亿元，合同资产1.85亿元，一年内到期非流动资产(合同资产部分)2.98亿元、其他非流动资产(合同资产部分)11.08亿元，合计22.78亿元，同比下降2.85%，主要为生态环境建设业务形成。2025年末，公司应收账款、合同资产、一年内到期非流动资产(合同资产部分)其他非流动资产(合同资产部分)坏账准备分别为2.16亿元、0.40亿元、0.19亿元和0.11亿元，计提比例分别为31.47%、21.47%、6.48%和1.00%。此外，公司应收致达金控3900万元借款，到期未获偿还，从长期应收款转入其他应收款，坏账准备为335.38万元，计提比例为7.92%，公司已就相关事项提起仲裁。请公司补充披露：（1）应收账款、合同资产、一年内到期非流动资产(合同资产部分)、其他非流动资产(合同资产部分)合计余额前十大的项目名称、交易对手方的名称及关联关系、成立时间、合同金额、履约进度、历年收入确认依据、时点及确认金额、结算约定及结算金额、回款金额、应收款项对应科目和金额、账龄、坏账准备金额、合同约定的回款安排，以及是否存在逾期建设或回款等情形，并结合对手方资信情况、履约能力、公司期末及期后回款情况等，说明坏账计提是否充分、及时，以及历年收入确认是否审慎；（2）公司与致达金控3900万元的资金流向、借款形成的原因、时间、借款合同主要条款、还款安排、实际还款情况等，结合致达金控股东和相关方、主营业务、资信情况等，说明其与公司和相关方是否存在关联关系或其他利益安排，其是否具备还款能力，相关坏账准备计提是否充分。

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>项目名称</td><td rowspan=2 colspan=1>合同签订时间及金额</td><td rowspan=2 colspan=1>结算约定</td><td rowspan=2 colspan=1>履约进度</td><td rowspan=1 colspan=3>历年收入确认金额及依据</td></tr><tr><td rowspan=1 colspan=1>年份</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>依据</td></tr><tr><td rowspan=4 colspan=1>1</td><td rowspan=4 colspan=1>宿州市通桥区生态环境分局，2019年6月11日成立，非关联方</td><td rowspan=2 colspan=1>宿州市埔桥区北部片区乡镇污水治理提标改造PPP项目</td><td rowspan=2 colspan=1>2019年9月29日签订，总投资金额37,596.26万元；运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=2 colspan=1>建设期1年，运维期20年。项目完工验收后进入运维期，按运维期20年每年等额支付，支付时间为项目全部工程竣工验收完成后每满1年后的1个月内。</td><td rowspan=4 colspan=1>已完成竣工验收和项目审计</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>887.21</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>-111.61</td><td rowspan=1 colspan=1>财务决算报告、运维计价方式+绩效考核文件</td></tr><tr><td rowspan=2 colspan=1>埔桥区北部片区2019年度美丽乡村雨污水治理工程</td><td rowspan=2 colspan=1>2020年3月16日签订《委托函》，未明确具体项目金额</td><td rowspan=2 colspan=1>完成初步验收后14日内，按实际完成工程额的80%支付，当年内甲方需完成财政审计，剩余20%验收期满1年后14日内一次性付清。</td><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>37,368. 48</td><td rowspan=1 colspan=1>工程审计报告、运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>38,144.08</td><td rowspan=1 colspan=1>*</td></tr><tr><td rowspan=3 colspan=1>2</td><td rowspan=3 colspan=1>临汾市尧都区涝河生态景区服务中心，-，非关联方</td><td rowspan=3 colspan=1>山西省临汾市尧都区汾河-涝范河贯通PPP工程</td><td rowspan=3 colspan=1>2018年1月29日签订，总投资金额34,970.31万元，运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=3 colspan=1>建设期2年，运维期13年。项目完工验收后进入运维期，按运维期13年每年等额支付，首期于进入运营期第一个运营年度期末支付，以后年度以此类推。</td><td rowspan=3 colspan=1>建设已完成，运营中，已完成财务审计</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>655.04</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>497.84</td><td rowspan=1 colspan=1>财务决算报告、运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>17,663.71</td><td rowspan=1 colspan=1></td></tr></table>

十（一）

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>项目名称</td><td rowspan=2 colspan=1>合同签订时间及金额</td><td rowspan=2 colspan=1>结算约定</td><td rowspan=2 colspan=1>履约进度</td><td rowspan=1 colspan=3>历年收入确认金额及依据</td></tr><tr><td rowspan=1 colspan=1>年份</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>依据</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>18,816.59</td><td rowspan=1 colspan=1>*</td></tr><tr><td rowspan=4 colspan=1>3</td><td rowspan=4 colspan=1>云和县住房和城乡建设局，2019年1月24日成立，非关联方</td><td rowspan=4 colspan=1>云和县城市污水处理厂清洁排放技术改造及城区污水零直排工程</td><td rowspan=4 colspan=1>2020年12月18日签订，总投资额34，985.00万元，运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=4 colspan=1>建设期2年，运维期28年。项目完工验收后进入运维期，按运维期28年每年支付运营每满一年后的60日内完成可行性缺口补助的确认和支付。</td><td rowspan=4 colspan=1>建设已完成，运营中</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>1,010.41</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件+会议文件</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>919.31</td><td rowspan=1 colspan=1>部分工程审计报告、运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>27,752.39</td><td rowspan=1 colspan=1>产值月报、运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>29,682.11</td><td rowspan=1 colspan=1>*</td></tr><tr><td rowspan=4 colspan=1>4</td><td rowspan=4 colspan=1>松阳县住房和城乡建设局，2019年3月11日成立，非关联方</td><td rowspan=4 colspan=1>松阳县火车站站前大道站前广场及其配套工程PPP项目</td><td rowspan=4 colspan=1>2019年4月14日签订，总投资金额42,435.16万元。运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=4 colspan=1>建设期1.5年，运维期15年。项目完工验收后进入运维期，按运维期15年每年支付，支付期限自项目竣工验收合格次日起满一年后的十五个工作日内支付上年度可行性缺口补贴。</td><td rowspan=4 colspan=1>建设已完成，运营中</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>240.01</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>233.03</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>27,349.16</td><td rowspan=1 colspan=1>产值月报</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>27,822.20</td><td rowspan=1 colspan=1>*</td></tr><tr><td rowspan=4 colspan=1>5</td><td rowspan=4 colspan=1>赤峰宇恒诚邦两园建设运营有限公司，2017年8月25日成立,参股公司</td><td rowspan=4 colspan=1>赤峰市油松、樟子松园景观绿化提升工程PPP项目</td><td rowspan=4 colspan=1>2017年12月28日签订，42,167.76万元</td><td rowspan=4 colspan=1>按每月工程形象进度的70%支付，工程竣工验收合格后支付至签约合同价的85%，结算审计后付至审计后总工程款的97%，剩余工程款3%作为质量保修金：待缺陷责任期满后一次性付清。</td><td rowspan=4 colspan=1>建设已完成，已审定</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>38,926.45</td><td rowspan=1 colspan=1>工程审计报告</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>38,926.45</td><td rowspan=1 colspan=1>*</td></tr><tr><td rowspan=2 colspan=1>6</td><td rowspan=2 colspan=1>运城市盐湖区建设投资有限公司，2005年7月13日成立，非关联方</td><td rowspan=2 colspan=1>盐池神庙提升改造工程施工1标</td><td rowspan=2 colspan=1>2023年1月18日签订，8748.96万元</td><td rowspan=2 colspan=1>预付款签约合同价的30%，预付款扣回的方式：按月进度产值同比例扣除，在最后一次完工付款至85%时全部扣完；工程进度款的支付方式、支付条件和支付时间：按月支付进度款。A、进度款按已完工程量的85%（包含设计变更、签证等）进行支付，B、工程竣工验收合格后，经发包人审核完成后的</td><td rowspan=2 colspan=1>建设已完成，已审定</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>-112.39</td><td rowspan=1 colspan=1>工程审计报告</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>1,461.89</td><td rowspan=1 colspan=1>产值月报</td></tr></table>

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>项目名称</td><td rowspan=2 colspan=1>合同签订时间及金额</td><td rowspan=2 colspan=1>结算约定</td><td rowspan=2 colspan=1>履约进度</td><td rowspan=1 colspan=3>历年收入确认金额及依据</td></tr><tr><td rowspan=1 colspan=1>年份</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>依据</td></tr><tr><td rowspan=3 colspan=1></td><td rowspan=3 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>14日内支付至审定额（含变更工程量）的90%；C、工程备案后，经审计完成后（审计审定时间自总包单位提交完整结算资料之后起90天内完成）14日内发包人留建筑安装工程费用结算审定总额3%的质量保证金，剩余款项一次性支付给承包人；D、剩余3%的质量保证金在质保期2年满后14日内无息支付完毕。</td><td rowspan=3 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>运城高铁北站站前区域附属设施建设项目</td><td rowspan=1 colspan=1>2020年6月11日签订，9440.93万元</td><td rowspan=1 colspan=1>每月25日前，土建工程按月支付上月审定的工程进度款的85%，竣工验收合格后支付至合同价款的90%，工程竣工结算并经发包人审核确定后14日内支付至结算价的97%，剩余3%作为缺陷责任保修金，缺陷责任期满后30日内一次性无息付清（除绿化工程外）；绿化工程按月支付合格工程的40%（同比例扣除对应预付款），完工验收合格付至合格工程造价的50%，剩余50%从工程通过竣工验收之日起计，分二年付清。具体付款方式：工程竣工验收之日起计满1年验收合格，发包人应付结算价款的30%，2年后验收合格一次性支付剩余工程款。（绿化工程验收合格标准：贵重苗木成活率100%，其他苗木成活率98%）</td><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>27,841.06</td><td rowspan=1 colspan=1>产值月报+工程审计报告</td></tr><tr><td rowspan=1 colspan=1>盐池文化博览园提升开发项目</td><td rowspan=1 colspan=1>2021年8月18日签订，14,101.48万元</td><td rowspan=1 colspan=1>按月支付进度款。A、进度款按已完工程量的85%（包含设计变更、签证等）进行支付；B、工程竣工验收合格后，经造价咨询方审核完成后的14日内支付至审定额（施工图预算审定额+施工过程中的签证额）的90%；C、工程备案后，经审计完成后（审计审定时间自总包单位提交完整结算资料之后起90天内完成）14日内发包人留建筑安装工程费用结算审定总额3%的质量保证金，剩余款项一次性支付给承包人；D、剩余3%的质量保证金在质保期2年满后14日内支付完毕。</td><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>29,190.56</td><td rowspan=1 colspan=1>*</td></tr></table>

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>项目名称</td><td rowspan=2 colspan=1>合同签订时间及金额</td><td rowspan=2 colspan=1>结算约定</td><td rowspan=2 colspan=1>履约进度</td><td rowspan=1 colspan=3>历年收入确认金额及依据</td><td></td></tr><tr><td rowspan=1 colspan=1>年份</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>依据</td><td></td></tr><tr><td rowspan=4 colspan=1>7</td><td rowspan=4 colspan=1>庆元县住房和城乡建设局，一，非关联方</td><td rowspan=4 colspan=1>庆元县五都污水处理厂及城区地下污水等综合管网工程PPP项目</td><td rowspan=4 colspan=1>2019年11月签订，投资总额19,613.00万元，运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=4 colspan=1>建设期2年，运维期13年。项目完工验收后进入运维期，按运维期每年支付，可行性缺口补助在每个运营期年末按年度支付，支付时间为每个运营期年末年度绩效考核结果确定后的60日内。</td><td rowspan=4 colspan=1>建设已完成，运营中</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>316.06</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td><td></td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>413.59</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td><td></td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>10,729.99</td><td rowspan=1 colspan=1>产值月报、运维计价方式+绩效考核文件</td><td></td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>11,459.64</td><td rowspan=1 colspan=1>*</td><td></td></tr><tr><td rowspan=4 colspan=1>8</td><td rowspan=4 colspan=1>济宁市市政园林养护中心，-，非关联方</td><td rowspan=4 colspan=1>济宁示范路更新提升工程洗河路道路景观提升工程总承包EPC</td><td rowspan=4 colspan=1>2022年5月12日签订，6052.58万元</td><td rowspan=4 colspan=1>建安费：①工程施工产值完成50%时，付至合同价款的30%；②工程施工产值完成70%时，付至合同价款的50%；③竣工验收合格且提交完整的竣工资料后（含电子文件），支付至实际完成产值的70%；④工程价款结算经承发包人双方确认后，支付至结算审定价款的97%；③剩余3%留作质量保证金，以最终结算金额为准且在养护期满半年内付清，若承包人在养护期内未按时履行养护责任，则发包人有权扣除质量保证金且另行委托其他公司进行养护，第二年养护费用按照第一年养护费取费执行。</td><td rowspan=4 colspan=1>建设已完成，已审定</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>252.29</td><td rowspan=1 colspan=1>工程审计报告</td><td></td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>440.71</td><td rowspan=1 colspan=1>产值月报</td><td></td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>5,303.27</td><td rowspan=1 colspan=1>产值月报</td><td></td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>5,996.27</td><td rowspan=1 colspan=1>*</td><td></td></tr><tr><td rowspan=4 colspan=1>9</td><td rowspan=4 colspan=1>龙泉市住房和城乡建设局，-，非关联方</td><td rowspan=4 colspan=1>龙泉市溪北污水处理厂清洁排放提标改造工程</td><td rowspan=4 colspan=1>2020年12月18日签订，总投资额3,259.58万元，运维计价方式：根据各期已履约的工程量及对应的单价在服务期间分期计价</td><td rowspan=4 colspan=1>建设期1年，运维期25年。项目完工验收后进入运维期，按运维期25年每年支付，可行性缺口补助中可用性服务费每年支付一次：污水处理服务费采用“按日计量、按月支付、结合绩效考核”的方式支付，每月暂按上一年度确认的污水处理单价(运营期首年按中标价）和当月实际污水处理量的90%支付，年底绩效考核后再结算。政府方应在运营满一年后的30日内完成上一年度的绩效考核及财政支出审批工作，运营满一年后的60日内完成年度可行性缺口补助的确认和支付。</td><td rowspan=4 colspan=1>建设已完成，运营中</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>354.26</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>334.99</td><td rowspan=1 colspan=1>运维计价方式+绩效考核文件</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>以前年度累计</td><td rowspan=1 colspan=1>3,900.58</td><td rowspan=1 colspan=1>产值月报、运维计价方式+绩效考核文件</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>4,589.83</td><td rowspan=1 colspan=2>*</td></tr></table>

<table><tr><td rowspan="2">序号</td><td rowspan="2">交易对手方及 成立时间</td><td rowspan="2">项目名称</td><td rowspan="2">合同签订时间 及金额</td><td rowspan="2">结算约定</td><td rowspan="2">履约 进度</td><td colspan="3">历年收入确认金额及依据</td></tr><tr><td>年份</td><td>金额</td><td>依据</td></tr><tr><td rowspan="3">10</td><td rowspan="3">缙云县住房和 城乡建设局， -，非关联方</td><td rowspan="3">缙云县紫薇 路北延伸工 程PPP项目</td><td rowspan="3">2018年2月1日签订，总投 资额8,838.625万元，运维计 价方式：根据各期已履约的工 程量及对应的单价在服务期</td><td rowspan="3">建设期1年，运维期9年。项目完工验收后进入 运维期，可行性缺口补助在运营期的每周年末支 付。支付时点为自运营开始日起满一年的第一个 月内最后一期可行性缺口补助支付时点在移交完</td><td rowspan="3">建设已完 成，运营 中，已完成</td><td>2025年</td><td>28.17</td><td>运维计价方式+绩效考 核文件</td></tr><tr><td>2024年</td><td>17.24</td><td>运维计价方式+绩效考 核文件</td></tr><tr><td>以前年度 累计</td><td>4,174. 62</td><td>财务决算报告、运维计</td></tr><tr><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2"></td><td rowspan="2">间分期计价</td><td rowspan="2">成或甲方自行组织完成项目的质量整改并验收后 十五个工作日支付最后一期可行性缺口补助。</td><td rowspan="2">财务决算</td><td></td><td></td><td>价方式+绩效考核文件</td></tr><tr><td>合计</td><td>4,220.03</td><td>*</td></tr></table>

<table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=2>截止2025年末累计回款情况</td><td rowspan=1 colspan=2>应收款项</td></tr><tr><td></td><td></td><td></td><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>账龄</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>坏账准备金额</td><td rowspan=1 colspan=1>综合计提比例</td><td></td><td></td></tr><tr><td rowspan=4 colspan=1>1</td><td rowspan=4 colspan=1>宿州市埔桥区生态环境分局，2019年6月11日成立，非关联方</td><td rowspan=4 colspan=1>2022年12月至2025年末回款7,969.05万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>4,298.38</td><td rowspan=4 colspan=1>41,369.05</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>29,756.11</td><td rowspan=4 colspan=1>1,771. 60</td><td rowspan=4 colspan=1>4.28%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年2月回款2,500.00万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>→</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>3,168.02</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>10,225.50</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>8,444.92</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>26,845.17</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=4 colspan=1>2</td><td rowspan=4 colspan=1>临汾市尧都区涝范河生态景区服务中心，，非关联方</td><td rowspan=4 colspan=1>2024年5月至2025年末回款4,250.00万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>3,028.46</td><td rowspan=4 colspan=1>34,418.01</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>22,159.31</td><td rowspan=4 colspan=1>1,963.52</td><td rowspan=4 colspan=1>5.70%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年2月13日至3月20日回款500.00万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>一</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>3,979.58</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>12,515.48</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>7,329.87</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>18,874.07</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>949.25</td></tr></table>

8

<table><tr><td rowspan=2 colspan=1>序母</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>截止2025年末累计回款情况</td><td></td><td></td><td rowspan=1 colspan=3>应收款项</td><td rowspan=1 colspan=4>账龄结构</td></tr><tr><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>账龄</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>坏账准备金额</td><td rowspan=1 colspan=1>综合计提比例</td><td></td><td></td></tr><tr><td rowspan=4 colspan=1>3</td><td rowspan=4 colspan=1>云和县住房和城乡建设局，2019年1月24日成立，非关联方</td><td rowspan=4 colspan=1>2020年11月至2025年末回款6,564.63万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>840.29</td><td rowspan=4 colspan=1>28,604.25</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>27,763.96</td><td rowspan=4 colspan=1>319.65</td><td rowspan=4 colspan=1>1.12%</td><td rowspan=4 colspan=1>否</td><td rowspan=4 colspan=1>期后于2026年2月至3月末回款572.30万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>840.29</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>994.13</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>26,769.83</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>=</td></tr><tr><td rowspan=4 colspan=1>4</td><td rowspan=4 colspan=1>松阳县住房和城乡建设局，2019年3月11日成立，非关联方</td><td rowspan=4 colspan=1>2023年1月至2025年末回款15,445.17万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>150.23</td><td rowspan=3 colspan=1>28,381.70</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>28,231.47</td><td rowspan=4 colspan=1>289.83</td><td rowspan=4 colspan=1>1.02%</td><td rowspan=4 colspan=1>否</td><td rowspan=4 colspan=1>期后无回款</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>150.23</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>2,970.72</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>25,260.75</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=4 colspan=1>5</td><td rowspan=4 colspan=1>赤峰宇恒诚邦两园建设运营有限公司，2017年8月25日成立，参股公司</td><td rowspan=4 colspan=1>2018年2月至2025年末回款26,231.18万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>16,198.64</td><td rowspan=4 colspan=1>16,198.64</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1></td><td rowspan=4 colspan=1>7,109.03</td><td rowspan=4 colspan=1>43.89%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年3月回款618.18万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>6,587.23</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>9,611. 41</td></tr><tr><td rowspan=4 colspan=1>6</td><td rowspan=4 colspan=1>运城市盐湖区建设投资有限公司，2005年7月13日成立，非关联方</td><td rowspan=4 colspan=1>2020年7月至2025年末回款19,421.26万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>12,112.97</td><td rowspan=3 colspan=1>12,373. 04</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1></td><td rowspan=4 colspan=1>6,186.52</td><td rowspan=4 colspan=1>50.00%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年2月回款1,500.00万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>260.07</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1,729.03</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>10,176.76</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>467.25</td></tr></table>

<table><tr><td rowspan=2 colspan=1>序号</td><td rowspan=2 colspan=1>交易对手方及成立时间</td><td rowspan=2 colspan=1>截止2025年末累计回款情况</td><td rowspan=1 colspan=5>应收款项</td><td rowspan=1 colspan=4>账龄结构</td><td rowspan=2 colspan=1>是否逾期回款</td><td rowspan=2 colspan=1>截止2026年3月末期后回款情况</td></tr><tr><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=3>合计</td><td rowspan=1 colspan=1>账龄</td><td rowspan=1 colspan=1>金额</td><td rowspan=1 colspan=1>坏账准备金额</td><td rowspan=1 colspan=1>综合计提比例</td></tr><tr><td rowspan=4 colspan=1>7</td><td rowspan=4 colspan=1>庆元县住房和城乡建设局，一，非关联方</td><td rowspan=4 colspan=1>2021年12月至2025年末回款5,844.00万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>377.20</td><td rowspan=3 colspan=3>7,781.96</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>7,404.75</td><td rowspan=4 colspan=1>98.12</td><td rowspan=4 colspan=1>1.26%</td><td rowspan=4 colspan=1>否</td><td rowspan=4 colspan=1>期后于2026年2月回款730.00万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>272.99</td></tr><tr><td rowspan=1 colspan=1>年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>21.37</td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>104.22</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>7,383.39</td><td rowspan=1 colspan=3></td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=4 colspan=1>8</td><td rowspan=4 colspan=1>济宁市市政园林养护中心，一，非关联方</td><td rowspan=4 colspan=1>2023年1月至2025年末回款727.00万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>5,808.93</td><td rowspan=2 colspan=3></td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>0.00</td><td rowspan=4 colspan=1>797.88</td><td rowspan=4 colspan=1>13.73%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年1月至2月回款2,016.04万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>2,299.13</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=2>5,808.93</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>3,509.80</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=3></td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=4 colspan=1>9</td><td rowspan=4 colspan=1>龙泉市住房和城乡建设局，一，非关联方</td><td rowspan=4 colspan=1>2023年8月至2025年末回款1,367.37万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>140.27</td><td rowspan=4 colspan=3>3,756.40</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>3,542.32</td><td rowspan=4 colspan=1>49.25</td><td rowspan=4 colspan=1>1.31%</td><td rowspan=4 colspan=1>否</td><td rowspan=4 colspan=1>期后于2026年3月回款56.56万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>151.70</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>311.38</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1>62.38</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产一合同资产</td><td rowspan=1 colspan=1>3,304.75</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>1</td></tr><tr><td rowspan=4 colspan=1>10</td><td rowspan=4 colspan=1>缙云县住房和城乡建设局，-，非关联方</td><td rowspan=4 colspan=1>2021年12月至2025年末回款6,252.42万元</td><td rowspan=1 colspan=1>应收账款</td><td rowspan=1 colspan=1>21.94</td><td rowspan=4 colspan=3>3,682.07</td><td rowspan=1 colspan=1>未到结算期</td><td rowspan=1 colspan=1>2,682.65</td><td rowspan=4 colspan=1>76.80</td><td rowspan=4 colspan=1>2.09%</td><td rowspan=4 colspan=1>是</td><td rowspan=4 colspan=1>期后于2026年1月至2月回款1,137.01万元</td></tr><tr><td rowspan=1 colspan=1>合同资产</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>999.42</td></tr><tr><td rowspan=1 colspan=1>一年内到期的非流动资产一合同资产</td><td rowspan=1 colspan=1>1,992.79</td><td rowspan=1 colspan=1>1-3年</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>其他非流动资产合同资产</td><td rowspan=1 colspan=1>1,667. 34</td><td rowspan=1 colspan=1>3年以上</td><td rowspan=1 colspan=1>1</td></tr></table>

## （二）结合对手方资信情况、履约能力、公司期末及期后回款情况等，说明坏账计提是否充分、及时

## 1、对手方资信情况和履约能力

公司原主营业务为市政施工业务，主要客户为政府部门和国有企业。大部分客户具有较大的资金实力与经营规模，经营情况良好，信誉较高，发生坏账的风险较小。部分客户如地方政府部门和国企客户资金紧张，付款存在逾期情况，但客户整体实力和资信较好，应收账款回款风险整体可控；房地产及其他民营企业整体景气度欠佳，资金紧张，针对客户信用较差及偿债能力较弱的客户，公司已逐一梳理并单项计提坏账。

## （1）应收账款和合同资产计提坏账准备的方法及期末计提情况

公司应收账款坏账准备计提方式划分为单项计提和账龄组合两种方式：公司将债务人信用状况明显恶化、未来回款可能性较低、已经发生信用减值等信用风险特征明显不同的应收账款单独进行减值测试，按照单项计提坏账准备；对于其余应收账款，公司参考历史信用损失经验，结合当前状况并考虑前瞻性信息，在组合基础上估计预期信用损失，确定按照账龄组合计提坏账准备。公司对合同资产减值准备计提的具体方法参照应收账款预期信用损失计提的具体方法。具体如下：

<table><tr><td rowspan=1 colspan=1>应收账款账龄</td><td rowspan=1 colspan=1>应收计提比例</td><td rowspan=1 colspan=1>合同资产账龄</td><td rowspan=1 colspan=1>合同资产判断说明</td><td rowspan=1 colspan=1>合同资产计提比例</td></tr><tr><td rowspan=5 colspan=1>1年以内</td><td rowspan=5 colspan=1>5%</td><td rowspan=1 colspan=1>未完工项目</td><td rowspan=3 colspan=1>考虑公司项目总体结算周期情况，未完工项目及2年以内项目一般处于正常结算周期内，预期信用损失应低于1年内应收账款，综合考虑按照1%和3%分别确认该阶段的合同资产的预期信用损失率</td><td rowspan=1 colspan=1>1.00%</td></tr><tr><td rowspan=1 colspan=1>1年以内</td><td rowspan=1 colspan=1>1.00%</td></tr><tr><td rowspan=1 colspan=1>1-2年</td><td rowspan=1 colspan=1>3.00%</td></tr><tr><td rowspan=1 colspan=1>2-3年</td><td rowspan=2 colspan=1>参照公司项目总体结算周期，完工后2-4年的项目将逐步进入结算期，在该账龄期间内尚未结算的合同资产参照1年内应收账款确认预期信用损失率</td><td rowspan=2 colspan=1>5.00%</td></tr><tr><td rowspan=1 colspan=1>3-4年</td></tr><tr><td rowspan=2 colspan=1>1-2年</td><td rowspan=2 colspan=1>10%</td><td rowspan=1 colspan=1>4-5年</td><td rowspan=2 colspan=1>参照结算周期，考虑结算风险，参照应收账款1-2年的预期信用损失率</td><td rowspan=2 colspan=1>10.00%</td></tr><tr><td rowspan=1 colspan=1>5-6年</td></tr><tr><td rowspan=1 colspan=1>2-3年</td><td rowspan=1 colspan=1>20%</td><td rowspan=2 colspan=1>6-7年</td><td rowspan=2 colspan=1>参照结算周期，考虑结算风险，综合判断该账龄和合同资产参照应收账款2-3年以及3-4年的预期信用损失率，确认为30%</td><td rowspan=2 colspan=1>30.00%</td></tr><tr><td rowspan=1 colspan=1>3-4年</td><td rowspan=1 colspan=1>50%</td></tr><tr><td rowspan=1 colspan=1>4-5年</td><td rowspan=1 colspan=1>80%</td><td rowspan=2 colspan=1>7年以上</td><td rowspan=2 colspan=1>参照结算周期，考虑结算风险，综合判断该账龄和合同资产参照应收账款4-5年以及5年以上的预期信用损失率，确认为90%</td><td rowspan=2 colspan=1>90.00%</td></tr><tr><td rowspan=1 colspan=1>5年以上</td><td rowspan=1 colspan=1>100%</td></tr></table>

其中 PPP项目相关应收款项科目包括一年内到期的非流动资产、其他非流动资产，按PPP项目合同约定，相关款项在运维期内（9-28年）逐年结算支付，未达到结算期的在其他非流动资产科目核算，报表日后1年内达到结算期的转入一年内到期的非流动资产核算。公司合并范围内的PPP 甲方均为地方政府部门，PPP项目在立项时已经过财政承受能力论证，PPP政府付费资金支出纳入当地财政预算，未来项目公司无法获得政府付费或可行性缺口补助的风险较低，PPP项目应收款项坏账计提方法为：

<table><tr><td rowspan=1 colspan=1>报表科目</td><td rowspan=1 colspan=1>具体类型</td><td rowspan=1 colspan=1>计提比例</td></tr><tr><td rowspan=1 colspan=1>其他非流动资产</td><td rowspan=1 colspan=1>未达到结算期的合同资产（结算期1年以上）</td><td rowspan=1 colspan=1>1.00%</td></tr><tr><td rowspan=2 colspan=1>一年内到期的非流动资产</td><td rowspan=1 colspan=1>未达到结算期的合同资产（结算期1年以内）</td><td rowspan=1 colspan=1>1.00%</td></tr><tr><td rowspan=1 colspan=1>已达到结算期的应收款</td><td rowspan=1 colspan=1>参照应收账款账龄计提比例</td></tr></table>

截至2025年12月31日，公司生态环境建设业务板块应收账款坏账准备、合同资产减值准备计提情况如下：

<table><tr><td rowspan=1 colspan=1>科目</td><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>账面余额（万元）</td><td rowspan=1 colspan=1>坏账准备/减值准备（万元）</td><td rowspan=1 colspan=1>预期信用损失率(%)</td></tr><tr><td rowspan=3 colspan=1>应收账款</td><td rowspan=1 colspan=1>按单项计提坏账准备</td><td rowspan=1 colspan=1>15,843.82</td><td rowspan=1 colspan=1>9,352.78</td><td rowspan=1 colspan=1>59.03</td></tr><tr><td rowspan=1 colspan=1>按组合计提坏账准备</td><td rowspan=1 colspan=1>44,074. 41</td><td rowspan=1 colspan=1>12,021.39</td><td rowspan=1 colspan=1>27.28</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>59,918.23</td><td rowspan=1 colspan=1>21,374.17</td><td rowspan=1 colspan=1>35.67</td></tr><tr><td rowspan=3 colspan=1>合同资产</td><td rowspan=1 colspan=1>按单项计提坏账准备</td><td rowspan=1 colspan=1>1,848.47</td><td rowspan=1 colspan=1>1,699. 61</td><td rowspan=1 colspan=1>91.95</td></tr><tr><td rowspan=1 colspan=1>按组合计提坏账准备</td><td rowspan=1 colspan=1>157,245.03</td><td rowspan=1 colspan=1>5,305.96</td><td rowspan=1 colspan=1>3.37</td></tr><tr><td rowspan=1 colspan=1>小计</td><td rowspan=1 colspan=1>159,093.50</td><td rowspan=1 colspan=1>7,005.56</td><td rowspan=1 colspan=1>4.40</td></tr><tr><td rowspan=3 colspan=1>总计</td><td rowspan=1 colspan=1>按单项计提坏账准备</td><td rowspan=1 colspan=1>17,692.29</td><td rowspan=1 colspan=1>11,052.39</td><td rowspan=1 colspan=1>62.47</td></tr><tr><td rowspan=1 colspan=1>按组合计提坏账准备</td><td rowspan=1 colspan=1>201,319.44</td><td rowspan=1 colspan=1>17,327.35</td><td rowspan=1 colspan=1>8.61</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>219,011.73</td><td rowspan=1 colspan=1>28,379.74</td><td rowspan=1 colspan=1>12.96</td></tr></table>

## （2）应收账款坏账准备计提比例的同行业可比上市公司比较分析

根据公开年报信息，公司与同行业可比上市公司应收账款实际坏账计提比例情况如下（鉴于同行业可比上市公司2025年度年报披露数量较少，故采用2024年度年报数据列示）：

<table><tr><td rowspan=1 colspan=1>公司简称</td><td rowspan=1 colspan=1>2024年12月31日实际计提比例</td></tr><tr><td rowspan=1 colspan=1>棕榈股份</td><td rowspan=1 colspan=1>41.85%</td></tr><tr><td rowspan=1 colspan=1>节能铁汉</td><td rowspan=1 colspan=1>32.26%</td></tr><tr><td rowspan=1 colspan=1>普邦股份</td><td rowspan=1 colspan=1>37.65%</td></tr><tr><td rowspan=1 colspan=1>蒙草生态</td><td rowspan=1 colspan=1>15.80%</td></tr><tr><td rowspan=1 colspan=1>文科股份</td><td rowspan=1 colspan=1>65.63%</td></tr><tr><td rowspan=1 colspan=1>东珠生态</td><td rowspan=1 colspan=1>24.57%</td></tr><tr><td rowspan=1 colspan=1>园林股份</td><td rowspan=1 colspan=1>41.50%</td></tr><tr><td rowspan=1 colspan=1>金埔园林</td><td rowspan=1 colspan=1>24.09%</td></tr><tr><td rowspan=1 colspan=1>平均值</td><td rowspan=1 colspan=1>35.42%</td></tr><tr><td rowspan=1 colspan=1>诚邦股份-生态环境建设业务（2024年12月31日）</td><td rowspan=1 colspan=1>21.59%</td></tr><tr><td rowspan=1 colspan=1>诚邦股份-生态环境建设业务（2025年12月31日）</td><td rowspan=1 colspan=1>35. 67%</td></tr></table>

综上，公司应收账款坏账计提政策较为谨慎，与同行业可比上市公司不存在较大差异。

## 2、公司期末及期后回款情况

截至2026年3月31日，公司相关应收款项回款情况如下：

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年12月31日（万元）</td></tr><tr><td rowspan=1 colspan=1>应收账款及合同资产账面余额</td><td rowspan=1 colspan=1>219,011.73</td></tr><tr><td rowspan=1 colspan=1>其中：应收账款账面余额(A)</td><td rowspan=1 colspan=1>59,918.23</td></tr><tr><td rowspan=1 colspan=1>期后截至2026.3.31回款金额(B)</td><td rowspan=1 colspan=1>12,285. 83</td></tr><tr><td rowspan=1 colspan=1>回款比例(C=B/A）（%）</td><td rowspan=1 colspan=1>20.50</td></tr></table>

综上所述，公司按坏账计提政策计提坏账准备，针对部分涉诉国企以及部分民营客户信用状况恶化、拖欠时间较久、偿债能力较弱，公司针对该类客户逐个核查信用情况及其回款能力，单项计提坏账准备，公司坏账准备计提具有充分性和及时性。

## （三）历年收入确认是否审慎

公司工程建设业务根据履约进度在一段时间内确认收入，履约进度的确定方法为产出法，具体根据累计已完成产值占项目预计总产值的比例确定。

项目建设过程中，公司每月根据项目产值月报表记载的履约进度和已完成产值确认收入，产值月报表均有经客户聘请的监理机构确认。

项目竣工后，根据竣工决算审计报告，对于审计结果与累计产值存在差异的，公司对对应项目的收入进行调整，竣工决算审计报告均由业主方聘请的第三方审计机构确认出具。公司在取得审计报告后当月与财务部完成核对并及时入账；对于项目分步进行竣工决算的，对已完成决算审计的工程部分，公司在取得该部分工程对应的审计决算报告或相关依据后当月与财务部完成核对并及时入账；对于项目竣工决算手续流程较长，业主方及审计机构已实际完成决算工作，公司已取得相关结果并确认无误的，项目部在取得相关结果时即与财务部完成核对并及时入账；对于在财务报表日至财务报告出具日之间取得以上决算审计依据的，公司将其作为期后调整事项纳入当期报表。

综上，公司历年收入确认依据均已完整取得，收入确认依据明确、审慎。

二、公司与致达金控3900万元的资金流向、借款形成的原因、时间、借款合同主要条款、还款安排、实际还款情况等，结合致达金控股东和相关方、主营业务、资信情况等，说明其与公司和相关方是否存在关联关系或其他利益安排，其是否具备还款能力，相关坏账准备计提是否充分。

## （一）借款形成及实际还款情况

2018年12月由致达金控与公司共同设立丽水致邦建设管理有限公司（即项目公司，简称“丽水致邦")，承接由浙江丽水工业园区管理委员会发包的丽水万洋低碳智造小镇基础设施PPP项目。基于上述合作关系，公司作为该PPP项目的社会资本方之一，为支持丽水致邦资金流动性、保障该项目按期完工，公司2019-2020年度对致达金控累计提供借款3,900.00万元（2019年12月借款2,800.00万元，2020年3月借款1,100.00万元），合同约定的借款期限为2019年11月1日至2025年10月31日，借款期限届满一次性还本付息，借款利率为同期贷款基准利率上浮15%，由致达金控以其在丽水致邦的股权质押担保。

2025年10月30日，公司与致达金控就上述借款本息结算事宜达成一致，并签署借款本息结算单。根据约定，截至2025年10月31日，致达金控应付公司的前述借款利息按30%确认，金额为335.38万元，相应借款本息合计4,235.38万元。

上述借款到期后，致达金控未按约定还款。公司已于2025年12月就该事项向杭州仲裁委员会提起仲裁申请，该申请已于当月获立案受理，目前案件尚在等待开庭通知。

截至目前，公司尚未收到该笔借款的本息。

## （二）致达金控股东和相关方情况

致达金控投资管理（北京）有限公司成立于2014年7月22日，股东：致达控股集团有限公司持股80%、王巍持股20%；实控人：严健军。

工商登记经营范围：项目投资、投资管理、资产管理；投资咨询、财务咨询、企业管理咨询。

实际核心业务：不动产投资：商业地产、产业地产等项目投资与运营；股权投资：成长期、成熟期企业股权直投与基金管理；不良资产投资：收购、处置金融及非金融类不良资产；综合金融服务：依托旗下基金、融资租赁、典当等牌照，提供多元化金融解决方案。

资信情况：注册资本与实缴资本充足，资本实力较强；为致达控股集团核心金融平台，股东背景具备产业支撑；无公开重大失信、被执行、行政处罚记录；经营状态稳定，持续开展资产管理与投资业务。

属民营投资机构，无国资/银行背景，抗周期能力中等；业务涉及股权投资、不良资产，存在市场波动与流动性风险。

根据上述相关情况，经核实，公司与致达金控不存在关联关系或其他利益安排。

## （三）致达金控还款能力及公司计提的坏账情况

致达金控目前经营情况正常，未出现被列为失信被执行人、限制高消费等经营异常事项，目前没有明确依据表明致达金控不具备还款能力。

根据借款协议，致达金控以自身在丽水致邦的股权对该笔借款进行质押担保，质押股权数量为该笔借款本金的1.2倍，折合丽水致邦股权比例为23.40%。截至2025年末，丽水致邦账面净资产20,088.95万元，对应质押股权价值为4,700.81万元，可以覆盖借款本金。该笔借款于2025年10月到期后由长期应收款等科目转入其他应收款科目核算，公司已于2025年末对该借款本息进行了单项计提坏账，计提金额为剩余利息部分335.38万元，计提比例7.92%，相关坏账计提充分。

2025年12月，丽水万洋低碳智造小镇基础设施PPP项目已完成初步审计决算，归属于公司部分的决算价格为36,117.18万元。截至2025年末，公司已累计收到回款33,731.32万元，占比93.39%。考虑到该项目回款情况良好，丽水致邦不存在经营异常情况，近几年处于持续回款状态，因此公司对丽水致邦的应收账款不存在显著的无法收回迹象。公司已对该部分应收账款按照账龄组合计提坏账，计提比例为20.00%，坏账准备的计提是充分的。

## 【年审会计师回复】

## （一）核查程序

## 1、针对坏账计提的核查程序

1)了解管理层与信用控制、应收账款回收和评估减值准备相关的关键财务报告内部控制，并评价和测试内部控制的设计和运行有效性；

2)评价管理层对基于历史信用损失经验并结合当前状况及对未来经济状况的预期信用损失率的合理性；

3)对应收账款、合同资产账龄和历史还款记录进行核查及分析；

4)实施函证程序，并将函证结果与公司记录的应收款项金额进行核对；

5)选取金额重大或高风险的应收账款、合同资产款项，检查了相关的支持性证据，包括对客户的背景调查、期后收款、客户的信用历史、经营情况和还款能力；

6)结合期后回款情况检查，评价应收账款、合同资产余额的可收回性；

7)查阅同行业坏账计提政策及实际计提比例，与公司计提政策及计提比例进行比较分析；

8)检查与应收账款、合同资产减值相关的信息是否已在财务报表中作出恰当列报。

## 2、针对致达金控的核查程序

1)通过企查查等公开信息平台，查询致达金控等相关方的工商登记信息、股权结构、主要管理人员等资料，核查其与公司及公司控股股东、实际控制人、董事、监事、高级管理人员是否存在关联关系或其他潜在利益安排；

2)向公司获取并查阅与致达金控签订的借款协议，逐条款核对合同约定的借款金额、利率、还款期限、违约责任等核心内容；了解该业务发生的背景及合理性，股权质押情况；同时获取该笔借款涉及的诉讼材料，包括起诉状、受理通知书等，核实借款实际履约情况及违约事实，评估相关信用风险与减值迹象；

3)向公司获取基于该笔借款测算的利息计算表，结合借款协议约定的利率、计息基数、起息及结息时间等条款，对利息金额进行独立重新测算与核对，复核利息计算的准确性、完整性及会计处理的恰当性；

4)针对致达金控相关协议条款及往来事项，设计并执行函证程序，向致达金控发函询证相关合同条款、债权债务金额、履约状态等信息，对回函情况进行核对与分析，对未回函情况分析其不予回函的原因及其合理性，以及对计提坏账是否产生影响。其中2024年度向致达金控函证并回函相符。

## （二）核查结论

经核查，我们认为：公司已根据坏账计提政策计提坏账准备，坏账计提具备充分性和及时性；致达金控与公司和相关方不存在关联关系或其他利益安排，公司对其的相关坏账准备计提充分。

![](images/f250c24182cfffdf0e160876e61eeb17cd591f955244923f31cbbfd954687828.jpg)  
立信中联会计师事务所（特殊普理合伙）

立信中计师务所特普通合伙）

中国注册会计师：

（项目合伙人）

![](images/65b49257d3781f20c9ccf2ac64acbd85691e82baf49b38cadcdd60a80e2a5eb0.jpg)

中国注册会计师：

![](images/44d8af20039a998ac95e5d9625663c730cae4bd875a51fa91b5f78fcc89d5e54.jpg)

中国天津市

2026年5月6日

梅子

![](images/85838c7ced0e8bb744e8edc7a6faabd938b792b18c4e0e62f88a6dc1771efc25.jpg)  
中国（天津）自由贸易试验区市场监督管理局 日

12211898日一十三日十出三-0二 黑日经

额出

![](images/993e5a4ed834df08daeb48cab6c4d7236aa5337bb552257b50942e4aa0a880ef.jpg)

（）

##

国用uAogXs8AM//:d

酒

![](images/3f3e2eb4f60d64efe9269e637e513c825566fb0c8e6da00fc12d6f6d21530c78.jpg)

名

##

## 日+-0

##

![](images/fe113dd818301aa9ff9e04bf1258f13e4a2e2d3ad07271e214a64e96af7d3073.jpg)  
成政局 ? W 1

《开医》

《不》

武《开不开出》

##

##

四十十三-0二日

## （暴）

![](images/4cde66b0f448faf05aee0264df69c845c17d5b6a75401606c33ff16b754eb4b6.jpg)  
立信中联会许练嘉务所特殊普通合院

具

##

##

![](images/13a78b93c240009e62aa125363a0e55be5ff95383e3044cbf15d2ed08186509a.jpg)

##

![](images/7b784607ce8bae96aa9f7701a7db413e95456416abefe3aaa25e26217c1098ae.jpg)

![](images/667e0e093891ab710466c1f737f0abc6a593c49e00aa5ba1d2876b9a0323e547.jpg)  
立信中联会计师事务所行珠普通合代） 0010050 虹 小 G

![](images/8ee27aa5c326388191dc62f4c4667be0c5b0a57a1aa88ebbcc2b257a939f1883.jpg)

![](images/bfe300e5215e96be2f5386931d56b853d685cac6e9d33fb69a4eb28cc8910f3f.jpg)  
陈小红120100232591

## 年度检验登记Annual Renewal Registration

本证书经检验合格·维续有效一年· This certificate is valid for another year after this renewal.

<table><tr><td>证书编号：</td><td>32591</td><td></td></tr><tr><td>No of Certificale</td><td></td><td></td></tr><tr><td>批准注册协会 Authorized Institute of CPAs</td><td></td><td>省注册会计师协会</td></tr><tr><td>发证日期： Date of lssance</td><td>2</td><td>年八 3 月 31 8 m</td></tr></table>

![](images/568b06236aa76b6a9ee067cdeb5518d43594894cba2ae4779575231e8ecff9b3.jpg)

![](images/0ad0c273e91592eae07b9ec37df31b7bb53279c76b0cca32b8292a98d0620fdc.jpg)  
立信中联会计师事务所特珠普通会伙） 0008000

![](images/d7152327ce8e23cf8e6a936ff36811bc18dcb1125b38bd685c02be5ac594bb00.jpg)

![](images/870b156ba6d0e97b1556896873061a3b9c14754ee60ed1e92df8fa7e026b9b64.jpg)  
刘欢120100230095

<table><tr><td>证书编号： No of Cernficate 批准注册协会 Anthorized Institute of CPAs</td><td>120100230095 </td><td>省注册会计师协会</td></tr></table>

## 年度检验登记Annual Renewal Registration

本证书经检验合格·继续有效一年 This certificate is valid for another year after this renewal